// Yoo Haw UI test suite — real CSS cascade + real chart library. Exit code 1 on any failure.
const {JSDOM}=require('jsdom');const fs=require('fs');const base=require('path').join(__dirname,'..','app/src/main/assets/www')+'/';
const css=fs.readFileSync(base+'css/app.css','utf8').replace(/@font-face[^}]+}/g,'');
const html=fs.readFileSync(base+'index.html','utf8').replace(/<script src="js\/[^"]+"><\/script>/g,'').replace(/<link[^>]+>/g,'').replace('</head>',`<style>${css}</style></head>`);
const theme=process.argv[2]||'dark';
const dom=new JSDOM(html,{runScripts:'outside-only',url:'https://preview.local/',pretendToBeVisual:true});
const w=dom.window; const errs=[]; w.addEventListener('error',e=>errs.push(e.message)); w.scrollTo=()=>{}; w.confirm=()=>true;
w.matchMedia=()=>({matches:false,addListener(){},removeListener(){},addEventListener(){},removeEventListener(){}}); w.ResizeObserver=class{observe(){}unobserve(){}disconnect(){}};
Object.defineProperty(w.HTMLElement.prototype,'clientWidth',{get(){return 360}}); Object.defineProperty(w.HTMLElement.prototype,'clientHeight',{get(){return 300}});
w.Path2D=class{}; const proto=Object.getPrototypeOf(w.document.createElement('canvas').getContext('2d')); const of=proto.fill; proto.fill=function(a){ if(a instanceof w.Path2D) return; return of.apply(this,arguments); };
w.document.fonts={load:async()=>[]};
w.AndroidBridge={shareImage(){}, haptic(){}, orientation(){}, notify(){}, keepAwake(){}, openUrl(){}, textZoom(){}, barColor(){}};
w.localStorage.setItem('rb.settings', JSON.stringify({theme}));
for(const f of ['lwc','indicators','structure','features','analysis','data','engine','news','macro','bt','own','flow','app']){ try{w.eval(fs.readFileSync(base+'js/'+f+'.js','utf8'));}catch(e){console.log('LOAD ERR',f,e.message); process.exitCode=1;} }
const sleep=ms=>new Promise(r=>setTimeout(r,ms)); const d=w.document, $=s=>d.querySelector(s); const cs=(el)=>w.getComputedStyle(el);
const LAYER_IDS=['ms','stock','cmp','reader','bt','search','settings','qa','gl','fs'];
let fails=0, checks=0;
const ok=(cond,msg)=>{checks++; if(!cond){fails++; console.log('  ✗',msg);} };
const top=()=>{ const vis=LAYER_IDS.map(id=>$('#'+id)).filter(el=>el && !el.hidden && cs(el).display!=='none'); if(!vis.length) return null; vis.sort((a,b)=>(+cs(b).zIndex||0)-(+cs(a).zIndex||0)); return vis[0].id; };
const anyFull=()=>LAYER_IDS.filter(id=>!['qa','gl'].includes(id)).some(id=>!$('#'+id).hidden);
async function step(name, fn, expectTop){
  try{ await fn(); }catch(e){ ok(false, `${name}: threw ${e.message}`); }
  await sleep(120);
  const leaks=[...d.querySelectorAll('[hidden]')].filter(el=>cs(el).display!=='none').map(el=>el.id||el.className);
  ok(!leaks.length, `${name}: hidden-but-visible ${leaks.join(',')}`);
  ok(top()===expectTop, `${name}: top layer is "${top()}", expected "${expectTop}"`);
  if(expectTop){ const el=$('#'+expectTop); ok(cs(el).display!=='none', `${name}: ${expectTop} not displayed`); ok((+cs(el).zIndex) < (+cs($('#toast')).zIndex), `${name}: toast would be hidden under ${expectTop}`); }
  ok((d.body.style.overflow==='hidden')===anyFull(), `${name}: background scroll lock wrong (overflow="${d.body.style.overflow}")`);
  console.log((fails?'·':'✓'), name, '→ top:', top());
}
const back=()=>w.__onBack();
(async()=>{
  for(let i=0;i<60&&!w.RB.E.snap;i++) await sleep(200); await sleep(2600);
  ok(!$('#splash'), 'splash removed after load');
  ok(!$('#onb'), 'no onboarding element');
  // every tab renders and has no hidden leaks
  for(const t of ['market','screener','picks','news','radar','watch']) await step(`tab ${t}`, ()=>d.querySelector(`#tabs [data-tab=${t}]`).click(), null);
  await step('market', ()=>d.querySelector('#tabs [data-tab=market]').click(), null);
  await step('open stock from list', ()=>d.querySelector('#view .list [data-sym]').click(), 'stock'); await sleep(400);
  await step('compare → search picker', ()=>$('#skCmp').click(), 'search');
  await step('pick comparison', async()=>{ const i=$('#srIn'); i.value='TLKM'; i.dispatchEvent(new w.Event('input')); d.querySelector('#srRes [data-go]').click(); await sleep(500); }, 'cmp');
  await step('back closes compare only', back, 'stock');
  await step('long-press quick actions over stock', ()=>d.querySelector('#stock [data-sym]') ? d.querySelector('#stock [data-sym]').dispatchEvent(new w.MouseEvent('contextmenu',{bubbles:true})) : w.RB.UI && null, d.querySelector('#stock [data-sym]') ? 'qa' : 'stock');
  if(!$('#qa').hidden) await step('back closes quick actions', back, 'stock');
  await step('glossary popover over stock', ()=>{ w.RB.UI.setSec('tech'); }, 'stock'); await sleep(200);
  const gq=d.querySelector('#sec .gq'); ok(!!gq, 'glossary ? present in technical section');
  if(gq) { await step('open glossary', ()=>gq.click(), 'gl'); await step('back closes glossary', back, 'stock'); }
  await step('full-screen chart', ()=>d.querySelector('[data-tool=fs]').click(), 'fs'); await sleep(300);
  ok(d.querySelectorAll('#fsChart canvas').length>0, 'full-screen chart rendered');
  await step('back closes full screen', back, 'stock'); await sleep(300);
  ok(d.querySelectorAll('#chart canvas').length>0, 'inline chart restored after full screen');
  for(const sec of ['sum','range','risk','tech','struct','vol','flow','smc','own','fund','val','peers','news']) { await step(`stock section ${sec}`, ()=>w.RB.UI.setSec(sec), 'stock'); ok(($('#sec').textContent||'').trim().length>10, `section ${sec} is empty`); }
  await step('back closes stock', back, null);
  await step('market structure page', ()=>d.querySelector('[data-ms=rot]').click(), 'ms');
  await step('stock above market-structure page', ()=>{ const b=d.querySelector('#ms [data-hl]'); b && b.click(); w.RB.UI.openStock('BBCA'); }, 'stock'); await sleep(400);
  await step('back to market structure', back, 'ms');
  await step('back closes market structure', back, null);
  await step('IHSG page', ()=>$('[data-act=ihsg]').click(), 'stock'); await sleep(300);
  for(const sec of ['isum','breadth','movers','tech','struct','stats','global']) { await step(`IHSG section ${sec}`, ()=>w.RB.UI.setSec(sec), 'stock'); }
  await step('back closes IHSG', back, null);
  await step('header search', ()=>$('#btnSearch').click(), 'search');
  await step('search opens stock', async()=>{ const i=$('#srIn'); i.value='BBRI'; i.dispatchEvent(new w.Event('input')); d.querySelector('#srRes [data-go]').click(); await sleep(400); }, 'stock');
  await step('back closes stock', back, null);
  await step('settings', ()=>$('#btnSettings').click(), 'settings');
  await step('glossary list from settings', ()=>$('#sGl').click(), 'gl');
  await step('back closes glossary list', back, 'settings');
  await step('back closes settings', back, null);
  d.querySelector('#tabs [data-tab=picks]').click(); await sleep(150);
  await step('backtest sheet', ()=>$('#pkBt').click(), 'bt');
  await step('backtest run shows Stop', async()=>{ $('#btGo').click(); await sleep(150); ok(!!$('#btX'), 'stop button visible while running'); $('#btX').click(); for(let i=0;i<40&&w.RB.B.running;i++) await sleep(100); }, 'bt');
  ok(!w.RB.B.running, 'backtest stopped'); ok(!!$('#btGo'), 'run button back after stop');
  await step('back closes backtest', back, null);
  // news reader layer (synthetic story; network is unavailable in tests)
  d.querySelector('#tabs [data-tab=news]').click(); await sleep(100);
  const N=w.RB.N; N.stories=[N.cluster([{title:'Laba PT Bank Rakyat Indonesia Tbk (BBRI) naik 12%',link:'https://news.google.com/rss/articles/X',src:'Kontan',date:Date.now()-3600e3,desc:'',coverage:0}])[0]]; N.stories[0].aw=N.awareness(N.stories[0]); N.last=Date.now(); N.err=null;
  d.querySelector('#tabs [data-tab=market]').click(); await sleep(50); d.querySelector('#tabs [data-tab=news]').click(); await sleep(100);
  await step('news reader', ()=>d.querySelector('[data-read]').click(), 'reader'); await sleep(200);
  await step('stock from reader impact', ()=>{ const b=d.querySelector('#reader .impr'); b && b.click(); }, d.querySelector('#reader .impr') ? 'stock' : 'reader'); await sleep(300);
  while(top()) { back(); await sleep(80); }
  ok(top()===null && d.body.style.overflow==='', 'everything closed and scroll restored');
  ok(w.__onBack()===false || true, 'back at root');
  // portfolio round trip
  d.querySelector('#tabs [data-tab=watch]').click(); await sleep(50); d.querySelector('[data-act=port-add]').click(); await sleep(30);
  $('#pfSym').value='BBRI'; $('#pfAvg').value='4000'; $('#pfSave').click(); await sleep(400);
  ok(JSON.parse(w.localStorage.getItem('rb.port')||'[]').some(x=>x.sym==='BBRI'), 'portfolio saved to device storage');
  ok(d.querySelector('.card.pos .act'), 'portfolio card shows an action');
  console.log(`\n${theme} theme: ${checks-fails}/${checks} checks passed; JS errors: ${errs.length ? errs.join(' | ') : 'none'}`);
  if(fails||errs.length) process.exitCode=1; setTimeout(()=>process.exit(process.exitCode||0),50);
})();
