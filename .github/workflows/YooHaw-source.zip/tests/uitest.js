// Yoo Haw UI test suite — real CSS cascade + real chart library. Exit code 1 on any failure.
const {JSDOM}=require('jsdom');const fs=require('fs');const base=require('path').join(__dirname,'..','app/src/main/assets/www')+'/';
const css=fs.readFileSync(base+'css/app.css','utf8').replace(/@font-face[^}]+}/g,'');
const html=fs.readFileSync(base+'index.html','utf8').replace(/<script src="js\/[^"]+"><\/script>/g,'').replace(/<link[^>]+>/g,'').replace('</head>',`<style>${css}</style></head>`);
const theme=process.argv[2]||'dark';
const dom=new JSDOM(html,{runScripts:'outside-only',url:'https://preview.local/',pretendToBeVisual:true});
const w=dom.window; const errs=[]; w.addEventListener('error',e=>errs.push(e.message)); w.scrollTo=()=>{}; w.confirm=()=>true;
w.matchMedia=()=>({matches:false,addListener(){},removeListener(){},addEventListener(){},removeEventListener(){}}); w.ResizeObserver=class{observe(){}unobserve(){}disconnect(){}};
Object.defineProperty(w.HTMLElement.prototype,'clientWidth',{get(){return 360}});
{ const ow=Object.getOwnPropertyDescriptor(w.HTMLElement.prototype,'offsetWidth'), ol=Object.getOwnPropertyDescriptor(w.HTMLElement.prototype,'offsetLeft');
  Object.defineProperty(w.HTMLElement.prototype,'offsetWidth',{configurable:true,get(){ return this.parentElement && this.parentElement.id==='tabs' && this.tagName==='BUTTON' ? 60 : ow.get.call(this); }});
  Object.defineProperty(w.HTMLElement.prototype,'offsetLeft',{configurable:true,get(){ const p=this.parentElement; return p && p.id==='tabs' && this.tagName==='BUTTON' ? [...p.querySelectorAll('button')].indexOf(this)*60 : ol.get.call(this); }});
  const gb=w.Element.prototype.getBoundingClientRect; w.Element.prototype.getBoundingClientRect=function(){ if(this.classList && (this.classList.contains('sym')||this.classList.contains('px')||this.matches('.stk-px b'))) { const y=this.closest('#stock')?60:220; return {left:this.classList.contains('px')?260:16, top:y, width:48, height:18, right:0, bottom:0, x:0, y}; } return gb.call(this); }; } Object.defineProperty(w.HTMLElement.prototype,'clientHeight',{get(){return 300}});
w.Path2D=class{}; const proto=Object.getPrototypeOf(w.document.createElement('canvas').getContext('2d')); const of=proto.fill; proto.fill=function(a){ if(a instanceof w.Path2D) return; return of.apply(this,arguments); };
w.document.fonts={load:async()=>[]};
let shares=0, sched=[]; w.AndroidBridge={shareImage(){ shares++; }, schedule(j){ sched.push(JSON.parse(j)); }, notifyTo(){}, openBatterySettings(){}, haptic(){}, orientation(){}, notify(){}, keepAwake(){}, openUrl(){}, textZoom(){}, barColor(){}};
w.localStorage.setItem('rb.settings', JSON.stringify({theme}));
const SCRIPTS=[...fs.readFileSync(base+'index.html','utf8').matchAll(/<script src="js\/([^"]+)\.js"><\/script>/g)].map(m=>m[1]).filter(n=>n!=='pdf.min');
for(const f of SCRIPTS){ try{w.eval(fs.readFileSync(base+'js/'+f+'.js','utf8'));}catch(e){console.log('LOAD ERR',f,e.message); process.exitCode=1;} }
const sleep=ms=>new Promise(r=>setTimeout(r,ms)); const d=w.document, $=s=>d.querySelector(s); const cs=(el)=>w.getComputedStyle(el);
const LAYER_IDS=['ms','stock','cmp','reader','bt','search','settings','qa','gl','buy','fs'];
let fails=0, checks=0; let lastBeat=Date.now(), maxGap=0, gapWhere=''; let curStep='boot';
setInterval(()=>{ const g=Date.now()-lastBeat; if(g>maxGap){ maxGap=g; gapWhere=curStep; } lastBeat=Date.now(); },100);
const ok=(cond,msg)=>{checks++; if(!cond){fails++; console.log('  ✗',msg);} };
const top=()=>{ const vis=LAYER_IDS.map(id=>$('#'+id)).filter(el=>el && !el.hidden && !el.classList.contains('leaving') && cs(el).display!=='none'); if(!vis.length) return null; vis.sort((a,b)=>(+cs(b).zIndex||0)-(+cs(a).zIndex||0)); return vis[0].id; };
const anyFull=()=>LAYER_IDS.filter(id=>!['qa','gl','buy'].includes(id)).some(id=>!$('#'+id).hidden);
async function step(name, fn, expectTop){
  curStep=name;
  try{ await fn(); }catch(e){ ok(false, `${name}: threw ${e.message}`); }
  await sleep(280);
  const leaks=[...d.querySelectorAll('[hidden]')].filter(el=>cs(el).display!=='none').map(el=>el.id||el.className);
  ok(!leaks.length, `${name}: hidden-but-visible ${leaks.join(',')}`);
  ok(top()===expectTop, `${name}: top layer is "${top()}", expected "${expectTop}"`);
  if(expectTop){ const el=$('#'+expectTop); ok(cs(el).display!=='none', `${name}: ${expectTop} not displayed`); ok((+cs(el).zIndex) < (+cs($('#toast')).zIndex), `${name}: toast would be hidden under ${expectTop}`); }
  ok(cs($('#ptr')).opacity==='0', `${name}: pull-to-refresh indicator visible at rest`);
  ok((d.body.style.overflow==='hidden')===anyFull(), `${name}: background scroll lock wrong (overflow="${d.body.style.overflow}")`);
  console.log((fails?'·':'✓'), name, '→ top:', top());
}
const back=()=>w.__onBack();
(async()=>{
  for(let i=0;i<60&&!w.RB.E.snap;i++) await sleep(200); await sleep(2600);
  ok(!$('#splash'), 'splash removed after load');
  ok(!$('#onb'), 'no onboarding element');
  ok(w.RB.UI.st.pickCat==='all', 'AI Picks default category is "Semua"');
  // every tab renders and has no hidden leaks
  for(const t of ['market','screener','picks','news','radar','watch']) await step(`tab ${t}`, ()=>d.querySelector(`#tabs [data-tab=${t}]`).click(), null);
  await step('market', ()=>d.querySelector('#tabs [data-tab=market]').click(), null);
  await step('open stock from list', ()=>d.querySelector('#view .list [data-sym]').click(), 'stock'); await sleep(400);
  await step('compare → search picker', ()=>$('#skCmp').click(), 'search');
  await step('pick comparison', async()=>{ const i=$('#srIn'); i.value='TLKM'; i.dispatchEvent(new w.Event('input')); d.querySelector('#srRes [data-go]').click(); await sleep(500); }, 'cmp');
  await step('back closes compare only', back, 'stock');
  await step('long-press quick actions over stock', ()=>d.querySelector('#stock [data-sym]') ? d.querySelector('#stock [data-sym]').dispatchEvent(new w.MouseEvent('contextmenu',{bubbles:true})) : w.RB.UI && null, d.querySelector('#stock [data-sym]') ? 'qa' : 'stock');
  if(!$('#qa').hidden) await step('back closes quick actions', back, 'stock');
  await step('glossary popover over stock', ()=>{ w.RB.UI.setSec('tech'); }, 'stock'); await sleep(200);
  const gq=d.querySelector('#sec .gq'); ok(!!gq, 'glossary ? present in technical section');
  if(gq) { await step('open glossary', ()=>gq.click(), 'gl'); await step('back closes glossary', back, 'stock'); }
  await step('full-screen chart', ()=>d.querySelector('[data-tool=fs]').click(), 'fs'); await sleep(300);
  ok(d.querySelectorAll('#fsChart canvas').length>0, 'full-screen chart rendered');
  await step('back closes full screen', back, 'stock'); await sleep(300);
  ok(d.querySelectorAll('#chart canvas').length>0, 'inline chart restored after full screen');
  for(const sec of ['sum','range','risk','tech','struct','vol','flow','smc','own','fund','val','peers','news']) { await step(`stock section ${sec}`, ()=>w.RB.UI.setSec(sec), 'stock'); ok(($('#sec').textContent||'').trim().length>10, `section ${sec} is empty`); }
  await step('back closes stock', back, null);
  await step('market structure page', ()=>d.querySelector('[data-ms=rot]').click(), 'ms');
  await step('stock above market-structure page', ()=>{ const b=d.querySelector('#ms [data-hl]'); b && b.click(); w.RB.UI.openStock('BBCA'); }, 'stock'); await sleep(400);
  await step('back to market structure', back, 'ms');
  await step('back closes market structure', back, null);
  await step('IHSG page', ()=>$('[data-act=ihsg]').click(), 'stock'); await sleep(300);
  for(const sec of ['isum','breadth','movers','tech','struct','stats','global']) { await step(`IHSG section ${sec}`, ()=>w.RB.UI.setSec(sec), 'stock'); }
  await step('back closes IHSG', back, null);
  await step('header search', ()=>$('#btnSearch').click(), 'search');
  await step('search opens stock', async()=>{ const i=$('#srIn'); i.value='BBRI'; i.dispatchEvent(new w.Event('input')); d.querySelector('#srRes [data-go]').click(); await sleep(400); }, 'stock');
  await step('back closes stock', back, null);
  await step('settings', ()=>$('#btnSettings').click(), 'settings');
  await step('glossary list from settings', ()=>$('#sGl').click(), 'gl');
  await step('back closes glossary list', back, 'settings');
  await step('back closes settings', back, null);
  d.querySelector('#tabs [data-tab=picks]').click(); await sleep(150);
  await step('backtest sheet', ()=>$('#pkBt').click(), 'bt');
  await step('backtest run shows Stop', async()=>{ ok(!!$('#btGo'), 'run button available even while evidence study runs'); $('#btGo').click(); for(let i=0;i<150 && !$('#btX');i++) await sleep(100); ok(!!$('#btX'), 'stop button visible while running'); $('#btX').click(); for(let i=0;i<40&&w.RB.B.running;i++) await sleep(100); }, 'bt');
  ok(w.RB.B.owner!=='user', 'user backtest stopped'); ok(!!$('#btGo'), 'run button back after stop');
  await sleep(1000); ok(/Backtest dihentikan/.test(($('#btMsg')||{}).textContent||''), 'stop message stays (no stale progress overwrites it)'); ok(!$('#prog i').style.width || $('#prog i').style.width==='0px' || $('#prog i').style.width==='0', 'header progress bar cleared after stop');
  await step('back closes backtest', back, null);
  // news reader layer (synthetic story; network is unavailable in tests)
  d.querySelector('#tabs [data-tab=news]').click(); await sleep(100);
  const N=w.RB.N; N.stories=[N.cluster([{title:'Laba PT Bank Rakyat Indonesia Tbk (BBRI) naik 12%',link:'https://news.google.com/rss/articles/X',src:'Kontan',date:Date.now()-3600e3,desc:'',coverage:0}])[0]]; N.stories[0].aw=N.awareness(N.stories[0]); N.last=Date.now(); N.err=null;
  d.querySelector('#tabs [data-tab=market]').click(); await sleep(50); d.querySelector('#tabs [data-tab=news]').click(); await sleep(100);
  await step('news reader', ()=>d.querySelector('[data-read]').click(), 'reader'); await sleep(200);
  await step('stock from reader impact', ()=>{ const b=d.querySelector('#reader .impr'); b && b.click(); }, d.querySelector('#reader .impr') ? 'stock' : 'reader'); await sleep(300);
  while(top()) { back(); await sleep(120); } await sleep(800);
  ok(top()===null && d.body.style.overflow==='', 'everything closed and scroll restored');
  ok(w.__onBack()===false || true, 'back at root');

  // ---- every share button on every screen must work ----
  const shareAudit=async(where)=>{ const btns=[...d.querySelectorAll('[data-share]')].filter(b=>!b.closest('[hidden]')); let okc=0; for(const b of btns){ const before=shares; b.click(); await sleep(250); if(shares>before) okc++; else ok(false, `${where}: share button for ${b.dataset.share} did nothing`); } ok(btns.length>0, `${where}: expected share buttons`); console.log(`✓ ${where}: ${okc}/${btns.length} share buttons work`); };
  d.querySelector('#tabs [data-tab=picks]').click(); await sleep(150);
  for(const c of ['mom','swing','early','acc','rev','risk']){ const b=d.querySelector(`#pkSeg [data-c=${c}]`); b.click(); await sleep(80); if(d.querySelector('#view [data-share]')) { await shareAudit('AI Picks '+c); break; } }
  w.RB.UI.openStock(d.querySelector('#view .pick [data-sym]') ? d.querySelector('#view .pick [data-sym]').dataset.sym : 'BBRI'); await sleep(500); w.RB.UI.setSec('sum'); await sleep(150);
  await shareAudit('stock page plan card');
  { const before=shares; $('#skShare').click(); await sleep(250); ok(shares>before, 'stock header share button did nothing'); }
  back(); await sleep(100);
  // ---- inflow / outflow radar ----
  d.querySelector('#tabs [data-tab=radar]').click(); await sleep(60);
  await step('inflow/outflow radar', ()=>d.querySelector('#rdSeg [data-v=flow]').click(), null);
  const vals=()=>[...d.querySelectorAll('#view .flr .px')].map(x=>{ const t=x.textContent.replace('Rp','').replace('−','-').trim(); const m=t.match(/(-?)([\d.,]+)\s*(T|M|jt)?/); if(!m) return NaN; const n=parseFloat(m[2].replace(',', '.')); const mul={T:1e12,M:1e9,jt:1e6}[m[3]]||1; return (m[1]?-1:1)*n*mul; });
  const sortedDesc=(a)=>a.every((x,i)=>i===0||a[i-1]>=x-1e-6), sortedAsc=(a)=>a.every((x,i)=>i===0||a[i-1]<=x+1e-6);
  for(const per of ['1','5','20']){ d.querySelector(`[data-fl="flowPer:${per}"]`).click(); await sleep(60); const v=vals(); ok(v.length>10, `flow ${per}d has rows`); ok(sortedDesc(v), `flow ${per}d sorted highest→lowest`); }
  d.querySelector('[data-fl="flowDir:out"]').click(); await sleep(60); { const v=vals(); ok(v.every(x=>x<0), 'outflow shows only negatives'); ok(sortedAsc(v), 'outflow largest first'); }
  d.querySelector('[data-fl="flowDir:in"]').click(); await sleep(60); { const v=vals(); ok(v.every(x=>x>0), 'inflow shows only positives'); ok(sortedDesc(v), 'inflow largest first'); }
  d.querySelector('[data-fl="flowKey:int"]').click(); await sleep(60); ok(d.querySelectorAll('#view .flr').length>5, 'intensity view has rows');
  d.querySelector('[data-fl="flowSrc:foreign"]').click(); await sleep(100); ok(/asing|IDX/i.test($('#view').textContent), 'foreign source shows status');
  d.querySelector('[data-fl="flowSrc:total"]').click(); d.querySelector('[data-fl="flowDir:all"]').click(); d.querySelector('[data-fl="flowKey:nom"]').click(); await sleep(60);
  await step('tap flow row opens stock', ()=>d.querySelector('#view .flr').click(), 'stock'); back(); await sleep(80);
  console.log('✓ inflow/outflow radar checks done');


  // ================= fluidity =================
  d.querySelector('#tabs [data-tab=market]').click(); await sleep(300);
  const mPane=d.querySelector('.pane[data-tab=market]'); const firstNode=mPane.firstElementChild; w.scrollY=0;
  w.scrollTo=(x,y)=>{ w.__sy=y; }; w.__sy=0;
  Object.defineProperty(w,'scrollY',{configurable:true,get(){return w.__sy||0;}}); w.__sy=420;
  d.querySelector('#tabs [data-tab=screener]').click(); await sleep(120); d.querySelector('#tabs [data-tab=market]').click(); await sleep(120);
  ok(mPane.firstElementChild===firstNode, 'switching back to a tab reuses its content (no re-render)');
  ok(w.__sy===420, `scroll position restored when returning to a tab (got ${w.__sy})`);
  ok(d.querySelectorAll('.pane:not([hidden])').length===1, 'exactly one tab pane visible');
  w.RB.D.saveSettings(); d.querySelector('#tabs [data-tab=screener]').click(); await sleep(120); d.querySelector('#tabs [data-tab=market]').click(); await sleep(120);
  ok(mPane.firstElementChild!==firstNode, 'a tab re-renders when its data changed');
  ok(!!d.querySelector('#tabs .tab-ind'), 'sliding tab indicator present');
  w.RB.UI.openStock('BBRI'); await sleep(30); ok($('#stock').classList.contains('entering'), 'stock page has an enter animation'); await sleep(450);
  back(); await sleep(30); ok($('#stock').classList.contains('leaving') && !$('#stock').hidden, 'stock page animates out'); await sleep(700); ok($('#stock').hidden, 'stock page hidden after exit animation'); ok(!$('#stock').style.transform, 'transform reset after close');
  w.RB.UI.openStock('BBRI'); await sleep(30); back(); await sleep(10); w.RB.UI.openStock('TLKM'); await sleep(450); ok(!$('#stock').hidden && !$('#stock').classList.contains('leaving'), 'reopening during exit animation cancels it');
  back(); await sleep(350);
  { const b=d.querySelector('#tabs [data-tab=picks]'); b.dispatchEvent(new w.Event('pointerdown',{bubbles:true})); ok(!!b.querySelector('.rip'), 'touch ripple on press'); }
  w.RB.D.settings.motion='off'; d.documentElement.dataset.motion='off'; w.RB.UI.openStock('BBRI'); await sleep(30); ok(!$('#stock').classList.contains('entering'), 'reduced motion: no enter animation'); back(); await sleep(20); ok($('#stock').hidden, 'reduced motion: closes instantly'); w.RB.D.settings.motion='on'; d.documentElement.dataset.motion='on';
  console.log('✓ fluidity checks done');

  // ================= nav, splash, titles =================
  const tabsEl=$('#tabs'); const tbtn=[...tabsEl.querySelectorAll('button[data-tab]')];
  ok(tbtn.length===6 && tbtn.every(b=>b.querySelector('svg.ti') && b.querySelector('span').textContent.trim()), 'nav: 6 tabs, each with an SVG icon and a label');
  ok(cs(tabsEl).gridTemplateColumns.includes('repeat(6') || cs(tabsEl).display==='grid', 'nav: equal-width grid');
  ok(tbtn.filter(b=>b.classList.contains('on')).length===1, 'nav: exactly one active tab');
  ok(!/[▦⧩✦☰◎◫]/.test(tabsEl.textContent), 'nav: no leftover unicode glyph icons');
  const ind=tabsEl.querySelector('.tab-ind'); const t0x=ind.style.transform; d.querySelector('#tabs [data-tab=news]').click(); await sleep(700);
  ok(ind.style.transform && ind.style.transform!==t0x, 'nav: indicator moved to the new tab'); d.querySelector('#tabs [data-tab=market]').click(); await sleep(600);
  ok(fs.readFileSync(base+'index.html','utf8').includes('Quiet signals. Clear decisions.'), 'splash: English tagline'); ok(!fs.readFileSync(base+'index.html','utf8').includes('id="spMsg"'), 'splash: no status text');
  for(const [tab,title] of [['screener','Screener'],['picks','AI Picks'],['watch','Portofolio'],['market','Pasar']]){ d.querySelector(`#tabs [data-tab=${tab}]`).click(); await sleep(120); ok($('#lt h1').textContent===title && $('#hdrT').textContent===title, `large title for ${tab}`); }
  w.__sy=200; w.dispatchEvent(new w.Event('scroll')); await sleep(60); ok(+$('#hdrT').style.opacity>0.9 && +$('#lt h1').style.opacity<0.1, 'title collapses into the header on scroll');
  w.__sy=0; w.dispatchEvent(new w.Event('scroll')); await sleep(60); ok(+$('#hdrT').style.opacity<0.1, 'title expands again at the top');
  // ================= gestures =================
  const touch=(type,x,y,target)=>{ const e=new w.Event(type,{bubbles:true,cancelable:true}); e.touches=type==='touchend'?[]:[{clientX:x,clientY:y}]; e.changedTouches=[{clientX:x,clientY:y}]; (target||d).dispatchEvent(e); };
  w.RB.UI.openStock('BBRI'); await sleep(700); const tgt=$('#stock .sh-b'); console.log('  [dbg] open layers before edge swipe:', LAYER_IDS.filter(id=>$('#'+id)&&!$('#'+id).hidden).join(','), '| motion', d.documentElement.dataset.motion, '| lite', d.documentElement.dataset.lite);
  touch('touchstart',20,300,tgt); for(const x of [40,120,240,400,600]){ await sleep(16); touch('touchmove',x,302,tgt); } touch('touchend',600,302,tgt); for(let i=0;i<30 && !$('#stock').hidden;i++) await sleep(50);
  if(false) console.log('  [dbg] after edge swipe:', JSON.stringify({reduced:w.RB.MO.reduced(), dm:d.documentElement.dataset.motion, mm:w.matchMedia('(prefers-reduced-motion: reduce)').matches, iw:w.innerWidth,cls:$('#stock').className, tf:$('#stock').style.transform, mx:$('#stock')._mx, sb:!!tgt, inDom:d.body.contains(tgt), lite:w.RB.D.settings.lite, top:top()}));
  ok($('#stock').hidden, 'edge swipe from the left closes the page');
  w.RB.UI.openStock('BBRI'); await sleep(700); touch('touchstart',20,300,tgt); for(const x of [30,45,60]){ await sleep(120); touch('touchmove',x,301,tgt); } touch('touchend',60,301,tgt); await sleep(800);
  ok(!$('#stock').hidden && !$('#stock').classList.contains('leaving') && !$('#stock').style.transform, 'short slow edge drag springs back open');
  touch('touchstart',200,300,tgt); for(const x of [220,260,300]){ await sleep(16); touch('touchmove',x,301,tgt); } touch('touchend',300,301,tgt); await sleep(400);
  ok(!$('#stock').hidden, 'a swipe that does not start at the edge never closes the page');
  back(); await sleep(700);
  d.querySelector('#tabs [data-tab=market]').click(); await sleep(150); const row=d.querySelector('#view .list [data-sym]');
  row.dispatchEvent(new w.MouseEvent('contextmenu',{bubbles:true})); await sleep(450); ok(!$('#qa').hidden, 'quick actions open'); const panel=$('#qa .bs-p');
  touch('touchstart',180,400,panel); for(const y of [430,480,560,660]){ await sleep(16); touch('touchmove',181,y,panel); } touch('touchend',181,660,panel); await sleep(800);
  ok($('#qa').hidden, 'dragging a bottom sheet down dismisses it');
  // ================= shared element =================
  const row2=d.querySelector('#view .list .row[data-sym]'); const sym2=row2.dataset.sym;
  let ghostSeen=0, hdrHiddenDuringFlight=false; const gObs=new w.MutationObserver(ms3=>{ for(const m of ms3) for(const n of m.addedNodes) if(n.nodeType===1 && n.classList.contains('ghost')){ ghostSeen++; const hs=d.querySelector('.stk-h .sym'); if(hs && hs.style.visibility==='hidden') hdrHiddenDuringFlight=true; } }); gObs.observe(d.body,{childList:true});
  row2.click(); for(let i=0;i<30 && !ghostSeen;i++) await sleep(20); await sleep(20); gObs.disconnect();
  ok(ghostSeen>=1, 'ticker flies from the row into the page header'); ok(hdrHiddenDuringFlight, 'header ticker hidden while the ghost flies');
  await sleep(1200); ok(d.querySelectorAll('.ghost').length===0, 'ghost removed after the flight'); ok($('.stk-h .sym').style.visibility==='', 'header ticker visible after the flight'); ok($('#stock').style.opacity===''||$('#stock').style.opacity==='1', 'page fully visible after the fade');
  back(); await sleep(700);
  // ================= rolling digits =================
  const s0=w.RB.E.snap.stocks.get(sym2); const old=s0.f.close; s0.f.close=old*1.07; w.RB.D.saveSettings(); d.querySelector('#tabs [data-tab=screener]').click(); await sleep(100); d.querySelector('#tabs [data-tab=market]').click(); await sleep(80);
  const pxEl=d.querySelector(`#view [data-roll="px:${sym2}"]`); ok(pxEl && pxEl.querySelector('.rd') && pxEl.classList.contains('rollup'), 'changed price rolls up digit by digit');
  await sleep(900); ok(pxEl && !pxEl.querySelector('.rd') && !pxEl.dataset.rolling, 'rolling settles back to plain text'); s0.f.close=old;
  // nothing left behind at rest
  ok(!$('#scrim') || $('#scrim').hidden, 'no dimming scrim left at rest'); ok(d.querySelectorAll('.ghost').length===0, 'no ghosts left at rest');
  console.log('✓ nav / gestures / shared element / rolling checks done');

  // ================= Lite | Pro, auto refresh, tappable numbers, breadth lists =================
  d.querySelector('#tabs [data-tab=market]').click(); await sleep(300);
  ok(!!$('#btnMode') && $('#btnMode').textContent.includes('Lite') && $('#btnMode').textContent.includes('Pro'), 'header has the Lite | Pro switch');
  ok(!d.querySelector('#top [data-act=scan], #btnRefresh'), 'manual refresh button replaced by the switch');
  // auto refresh when returning to the app with stale data
  { const s0=w.RB.E.snap; s0.asOf=Date.now()-2*3600e3; /* older than both limits: 4 min in session, 60 min outside */ const before=s0.asOf; Object.defineProperty(d,'hidden',{configurable:true,get(){return false;}}); d.dispatchEvent(new w.Event('visibilitychange'));
    for(let i=0;i<80 && !(w.RB.E.snap && w.RB.E.snap.asOf>before);i++) await sleep(150); ok(w.RB.E.snap.asOf>before, 'stale data refreshes automatically when returning to the app'); }
  await sleep(300);
  // breadth drill-down: every health metric opens its list of stocks
  for(const m of ['ema50','ema200','nh']){ const b=d.querySelector(`#view [data-brd="${m}"]`); ok(!!b, `health metric ${m} is tappable`); if(!b) continue;
    await step(`breadth list ${m}`, ()=>b.click(), 'ms'); ok(!d.querySelector('#msBody [data-sym]'), `breadth ${m}: no stock list until a sector is tapped`);
    const bars=[...d.querySelectorAll('#msBody .brs .bar i')]; ok(bars.length>3 && bars.every(i=>i.style.background && i.style.width), `breadth ${m}: sector bars are filled and coloured`);
    const sec0=[...d.querySelectorAll('#msBody [data-brdsec]')].find(b=>!/^0\//.test(b.querySelector('.brn').textContent)); if(sec0){ const nm=sec0.dataset.brdsec; sec0.click(); await sleep(250);
      ok(d.querySelector(`#msBody .brs.open[data-brdsec="${nm}"]`) && d.querySelectorAll('#msBody .brl [data-sym]').length>0, `breadth ${m}: tapping a sector shows its stocks`);
      const r0=d.querySelector('#msBody .brl .row'); ok(r0 && (r0.textContent.match(/%/g)||[]).length===1, `breadth ${m}: one percentage per stock`);
      d.querySelector(`#msBody [data-brdsec="${nm}"]`).click(); await sleep(250); ok(!d.querySelector('#msBody .brl'), `breadth ${m}: tapping again collapses`); }
    const alt=d.querySelector('#msBody [data-p^="brdS:"]:not(.on)'); if(alt){ alt.click(); await sleep(200); ok(true, 'above/below switch works'); }
    ok(/screener/i.test($('#msBody').textContent), `breadth ${m}: "Jadikan screener" offered`); back(); await sleep(350); }
  // regime components and sector rows open the data behind them
  { const rc=d.querySelector('#view [data-rc]'); ok(!!rc, 'market-condition components are tappable'); if(rc){ await step('regime component detail', ()=>rc.click(), 'gl'); ok($('#gl').textContent.length>40, 'component detail has content'); back(); await sleep(350); } }
  { const sec=d.querySelector('#view [data-sec]'); ok(!!sec, 'sector rows are tappable'); if(sec){ sec.click(); await sleep(250); ok(d.querySelectorAll('#view [data-sym]').length>5, 'sector row reveals its members'); } }
  // Lite mode: all six tabs stay, content gets simpler; Pro restores everything
  d.querySelector('#btnMode [data-m=lite]').click(); await sleep(300);
  ok(w.RB.D.settings.lite===true && d.documentElement.dataset.lite==='1', 'Lite mode on');
  ok([...d.querySelectorAll('#tabs button')].filter(b=>cs(b).display!=='none').length===6, 'Lite keeps all six tabs');
  for(const t of ['market','screener','picks','news','radar','watch']){ await step(`lite tab ${t}`, ()=>d.querySelector(`#tabs [data-tab=${t}]`).click(), null); ok(($('.pane[data-tab='+t+']').textContent||'').trim().length>20, `lite ${t} has content`); }
  d.querySelector('#tabs [data-tab=picks]').click(); await sleep(250);
  ok(cs($('#pkSeg')).display==='none', 'Lite AI Picks: category bar hidden'); const lc=d.querySelector('#view .pick'); ok(!lc || (lc.querySelector('.plain') && cs(lc.querySelector('details.why')||d.body).display==='none'), 'Lite pick card: reasons kept, technical detail hidden');
  w.RB.UI.openStock('BBRI'); await sleep(700); ok(!!$('#liteFull'), 'Lite stock page: simple summary with "full analysis" button'); ok(!d.querySelector('#stock .tabs2'), 'Lite stock page: section menu hidden');
  ok(d.querySelectorAll('#chart canvas').length>0 || $('#chart'), 'Lite stock page keeps the chart');
  $('#liteFull').click(); await sleep(500); ok(!!d.querySelector('#stock .tabs2'), 'full analysis opens the complete page'); back(); await sleep(350);
  d.querySelector('#btnMode [data-m=pro]').click(); await sleep(300);
  ok(w.RB.D.settings.lite===false && d.documentElement.dataset.lite!=='1', 'Pro mode restored'); d.querySelector('#tabs [data-tab=picks]').click(); await sleep(250); ok(cs($('#pkSeg')).display!=='none', 'Pro shows the category bar again');
  d.querySelector('#tabs [data-tab=market]').click(); await sleep(250);
  console.log('✓ lite / auto-refresh / tappable checks done');
  // ================= AI Picks v2 =================
  d.querySelector('#tabs [data-tab=picks]').click(); await sleep(150);
  d.querySelector('#pkSeg [data-c=all]').click(); await sleep(150);
  ok(!!d.querySelector('.brief'), 'brief / verdict card shown');
  const cards=d.querySelectorAll('#view .pick'); ok(cards.length>0, 'pick cards rendered');
  const total=w.RB.PK.all().length; ok(cards.length===Math.min(20,total), `first page shows ${Math.min(20,total)} of ${total}`);
  if(total>20){ $('#pkMore').click(); await sleep(100); ok(d.querySelectorAll('#view .pick').length===Math.min(40,total), 'show more extends the list (no cap)'); }
  const c0=d.querySelector('#view .pick'); ok(c0.querySelectorAll('.plain ol li').length>=1 && c0.querySelectorAll('.plain ol li').length<=3, 'plain-language reasons (1–3)'); ok(/Risiko:/.test(c0.querySelector('.prisk').textContent), 'one plain-language risk');
  ok(!!c0.querySelector('details.why'), 'technical details still available');
  console.log('  evidence state before wait:', JSON.stringify({busy:w.RB.PK.evidBusy, have:!!w.RB.PK.evid, running:w.RB.B.running, owner:w.RB.B.owner, pending:w.RB.B.userPending, evidTry:w.RB.UI.st.evidTry, err:w.RB.PK.evidErr}));
  for(let i=0;i<300 && (w.RB.PK.evidBusy || !w.RB.PK.evid); i++) await sleep(500);
  ok(!!w.RB.PK.evid && w.RB.PK.evid.byType.length>0, 'historical evidence built');
  d.querySelector('#tabs [data-tab=market]').click(); await sleep(50); d.querySelector('#tabs [data-tab=picks]').click(); await sleep(150);
  for(let i=0;i<40;i++){ const el=d.querySelector('[data-ev]'); if(el && el.dataset.done) break; await sleep(300); }
  const ev=d.querySelector('[data-ev]'); ok(ev && /muncul|Di \d+ saham/.test(ev.textContent), `evidence text shown: "${ev && ev.textContent.slice(0,90)}"`);
  const c1=d.querySelector('#view .pick'); const buySym=c1.querySelector('[data-buy]').dataset.buy;
  await step('Saya beli sheet', ()=>c1.querySelector('[data-buy]').click(), 'buy');
  $('#byLot').value='10'; $('#bySave').click(); await sleep(100);
  const pos=JSON.parse(w.localStorage.getItem('rb.port')||'[]').find(x=>x.sym===buySym); ok(pos && pos.plan && pos.plan.invalid>0, 'bought position stores its plan'); ok(pos && pos.lots===10, 'lots saved');
  ok($('#buy').hidden || $('#buy').classList.contains('leaving'), 'buy sheet closing after save'); await sleep(700); ok($('#buy').hidden, 'buy sheet hidden after its exit animation');
  d.querySelector('#tabs [data-tab=watch]').click(); await sleep(400);
  ok(/rencana|T1|Target 1|invalidasi|batal/i.test(d.querySelector(`.card.pos[data-sym="${buySym}"]`)?.textContent||''), 'portfolio card manages the bought plan');
  // ================= price alerts =================
  d.querySelector('[data-pw=alert]').click(); await sleep(50);
  $('#alSym').value='BBRI'; $('#alPx').value='99999'; d.querySelector('#alOp [data-v=">="]').click(); $('#alSave').click(); await sleep(80);
  $('#alSym').value='TLKM'; $('#alPx').value='1'; $('#alSave').click(); await sleep(80);
  ok(w.RB.AL.list().length===2, 'two alerts saved'); ok(d.querySelectorAll('.alr').length===2, 'alerts listed');
  ok(sched.length && sched[sched.length-1].alerts===false, 'background alerts stay off until enabled');
  w.RB.AL.list().forEach(a=>{}); const fired=await w.RB.AL.check(); ok(fired.length===0, 'no alert fires while price is far');
  { const a=w.RB.AL.list(); a[0].price=1; a[0].op='>='; w.RB.AL.save(a); } const fired2=await w.RB.AL.check(); ok(fired2.length===1, 'alert fires when the price condition is met'); ok(w.RB.AL.list()[0].on===false && w.RB.AL.list()[0].hitAt, 'fired alert is switched off and timestamped');
  w.RB.UI.openStock('BBRI'); await sleep(400);
  await step('stock bell → alert sheet', ()=>$('#skBell').click(), 'buy'); ok(!!d.querySelector('#buy #alSave'), 'alert form inside sheet'); back(); await sleep(50); back(); await sleep(80);
  // ================= heatmap & groups =================
  d.querySelector('#tabs [data-tab=market]').click(); await sleep(100);
  await step('heatmap page', ()=>d.querySelector('[data-ms=heat]').click(), 'ms'); await sleep(200);
  ok(d.querySelectorAll('.hm-c').length>=100, `heatmap tiles: ${d.querySelectorAll('.hm-c').length}`);
  const tiles=[...d.querySelectorAll('.hm-c')]; const within=tiles.every(t=>parseFloat(t.style.left)>=0 && parseFloat(t.style.left)+parseFloat(t.style.width)<=361 && parseFloat(t.style.top)>=0); ok(within, 'heatmap tiles stay inside the box');
  d.querySelector('[data-p="hmPer:perf1m"]').click(); await sleep(150); ok(d.querySelectorAll('.hm-c').length>=100, 'heatmap re-renders for 1 month');
  await step('heatmap tile opens stock', ()=>d.querySelector('.hm-c').click(), 'stock'); back(); await sleep(80);
  back(); await sleep(60);
  await step('groups page', ()=>d.querySelector('[data-ms=grp]').click(), 'ms'); await sleep(150);
  ok(d.querySelectorAll('[data-grsel]').length>=10, 'groups listed (built-in members while KSEI not loaded)');
  const rows=w.RB.O.parseCsv(fs.readFileSync(require('path').join(__dirname,'fixtures','ksei_sample.csv'),'utf8')); w.RB.O.cur=w.RB.O.build(rows,'2026-09-30'); d.querySelector('[data-p="grKind:theme"]').click(); await sleep(60); d.querySelector('[data-p="grKind:group"]').click(); await sleep(150);
  ok(/KSEI 2026-09-30|data KSEI/.test($('#msBody').textContent), 'group membership now derived from KSEI');
  const barito=w.RB.GR.list('group').find(g=>g.id==='barito'); ok(barito.syms.includes('BREN') && barito.syms.includes('TPIA'), 'Barito group resolved from holdings: '+barito.syms.join(','));
  d.querySelector('[data-grsel=astra]').click(); await sleep(500); ok(/Anggota/.test($('#msBody').textContent) && d.querySelectorAll('#msBody table.pt tr').length>3, 'group detail table'); ok(d.querySelectorAll('#grChart canvas').length>0, 'group vs IHSG chart');
  d.querySelector('[data-grback]').click(); await sleep(80); d.querySelector('[data-p="grKind:theme"]').click(); await sleep(80); ok(d.querySelectorAll('[data-grsel]').length>=10, 'themes listed');
  back(); await sleep(60);
  // ================= gorengan =================
  const anyG=[...w.RB.E.snap.stocks.values()].every(s=>s.goreng && typeof s.goreng.score==='number'); ok(anyG, 'every stock has a gorengan risk score');
  const fake={sym:'ZZZZ', f:{perf1w:40, chg1d:20, avgValue20:2e9, rvol:6, close:150, atrPct:9, marketCap:4e11, netMargin:-3}, cd:{c:[100,135,182,246,250,250,250,250,250,250,250],t:[]} };
  const gr=w.RB.RK.goreng(fake); ok(gr.level==='Tinggi' && gr.flags.length>=4, `synthetic pump scores high (${gr.score}: ${gr.flags.slice(0,2).join(' | ')})`);
  // ================= settings: schedule + Telegram =================
  $('#btnSettings').click(); await sleep(50);
  $('#nMorning').checked=true; $('#nMorning').dispatchEvent(new w.Event('change')); $('#nBg').checked=true; $('#nBg').dispatchEvent(new w.Event('change')); await sleep(30);
  const last=sched[sched.length-1]; ok(last.morning==='08:30' && last.alerts===true && last.evening==='', `schedule pushed to Android: ${JSON.stringify(last)}`);
  back(); await sleep(50);
  // regression: backtest started from the Screener tab reads its own controls (no ID clash with the screener's button)
  d.querySelector('#tabs [data-tab=screener]').click(); await sleep(150); d.querySelector('[data-pid=momentum]').click(); await sleep(300);
  await step('backtest from screener', ()=>$('#btS').click(), 'bt');
  $('#btN').value='20'; $('#btN').dispatchEvent(new w.Event('change')); $('#btP').value='126'; $('#btP').dispatchEvent(new w.Event('change'));
  ok($('#btStep') && ['1','2'].includes($('#btStep').value), 'backtest step control is its own element');
  $('#btGo').click(); for(let i=0;i<300 && !(w.RB.B.last && w.RB.B.last.cfg && w.RB.B.last.cfg.nStocks===20 && !w.RB.B.running);i++) await sleep(100);
  ok(w.RB.B.last && w.RB.B.last.evals>0 && w.RB.B.last.cfg.step>=1, `backtest from screener evaluated ${w.RB.B.last && w.RB.B.last.evals} points (step ${w.RB.B.last && w.RB.B.last.cfg.step})`);
  back(); await sleep(700);
  // no duplicate element IDs anywhere (tabs are retained, so their DOM coexists)
  for(const t of ['market','screener','picks','news','radar','watch']){ d.querySelector(`#tabs [data-tab=${t}]`).click(); await sleep(120); }
  { const ids={}; d.querySelectorAll('[id]').forEach(el=>{ ids[el.id]=(ids[el.id]||0)+1; }); const dup=Object.entries(ids).filter(([k,v])=>v>1).map(([k,v])=>k+'×'+v); ok(!dup.length, 'duplicate element IDs: '+dup.join(', ')); }
  // portfolio round trip
  d.querySelector('#tabs [data-tab=watch]').click(); await sleep(50); d.querySelector('[data-pw=port]').click(); await sleep(50); d.querySelector('[data-act=port-add]').click(); await sleep(30);
  $('#pfSym').value='BBRI'; $('#pfAvg').value='4000'; $('#pfSave').click(); await sleep(400);
  ok(JSON.parse(w.localStorage.getItem('rb.port')||'[]').some(x=>x.sym==='BBRI'), 'portfolio saved to device storage');
  ok(d.querySelector('.card.pos .act'), 'portfolio card shows an action');
  ok(maxGap<1500, `app froze for ${maxGap} ms (near step "${gapWhere}")`);
  ok(SCRIPTS.length>=18 && SCRIPTS.indexOf('motion')>=0 && SCRIPTS.indexOf('motion')<SCRIPTS.indexOf('app'), 'scripts loaded from index.html in the real order'); console.log(`\n${theme} theme: ${checks-fails}/${checks} checks passed; max UI freeze ${maxGap} ms (${gapWhere}); JS errors: ${errs.length ? errs.join(' | ') : 'none'}`);
  if(fails||errs.length) process.exitCode=1; setTimeout(()=>process.exit(process.exitCode||0),50);
})();
