// Yoo Haw UI test suite — real CSS cascade + real chart library. Exit code 1 on any failure.
const {JSDOM}=require('jsdom');const fs=require('fs');const base=require('path').join(__dirname,'..','app/src/main/assets/www')+'/';
const css=fs.readFileSync(base+'css/app.css','utf8').replace(/@font-face[^}]+}/g,'');
const html=fs.readFileSync(base+'index.html','utf8').replace(/<script src="js\/[^"]+"><\/script>/g,'').replace(/<link[^>]+>/g,'').replace('</head>',`<style>${css}</style></head>`);
const theme=process.argv[2]||'dark';
const dom=new JSDOM(html,{runScripts:'outside-only',url:'https://preview.local/',pretendToBeVisual:true});
const w=dom.window; const errs=[]; w.addEventListener('error',e=>errs.push(e.message)); w.scrollTo=()=>{}; w.confirm=()=>true;
w.matchMedia=()=>({matches:false,addListener(){},removeListener(){},addEventListener(){},removeEventListener(){}}); w.ResizeObserver=class{observe(){}unobserve(){}disconnect(){}};
Object.defineProperty(w.HTMLElement.prototype,'clientWidth',{get(){return 360}}); Object.defineProperty(w.HTMLElement.prototype,'clientHeight',{get(){return 300}});
w.Path2D=class{}; const proto=Object.getPrototypeOf(w.document.createElement('canvas').getContext('2d')); const of=proto.fill; proto.fill=function(a){ if(a instanceof w.Path2D) return; return of.apply(this,arguments); };
w.document.fonts={load:async()=>[]};
let shares=0, sched=[]; w.AndroidBridge={shareImage(){ shares++; }, schedule(j){ sched.push(JSON.parse(j)); }, notifyTo(){}, openBatterySettings(){}, haptic(){}, orientation(){}, notify(){}, keepAwake(){}, openUrl(){}, textZoom(){}, barColor(){}};
w.localStorage.setItem('rb.settings', JSON.stringify({theme}));
for(const f of ['lwc','indicators','structure','features','analysis','data','engine','news','macro','bt','own','flow','risk','heat','picks','alerts','jobs','app']){ try{w.eval(fs.readFileSync(base+'js/'+f+'.js','utf8'));}catch(e){console.log('LOAD ERR',f,e.message); process.exitCode=1;} }
const sleep=ms=>new Promise(r=>setTimeout(r,ms)); const d=w.document, $=s=>d.querySelector(s); const cs=(el)=>w.getComputedStyle(el);
const LAYER_IDS=['ms','stock','cmp','reader','bt','search','settings','qa','gl','buy','fs'];
let fails=0, checks=0; let lastBeat=Date.now(), maxGap=0, gapWhere=''; let curStep='boot';
setInterval(()=>{ const g=Date.now()-lastBeat; if(g>maxGap){ maxGap=g; gapWhere=curStep; } lastBeat=Date.now(); },100);
const ok=(cond,msg)=>{checks++; if(!cond){fails++; console.log('  ✗',msg);} };
const top=()=>{ const vis=LAYER_IDS.map(id=>$('#'+id)).filter(el=>el && !el.hidden && cs(el).display!=='none'); if(!vis.length) return null; vis.sort((a,b)=>(+cs(b).zIndex||0)-(+cs(a).zIndex||0)); return vis[0].id; };
const anyFull=()=>LAYER_IDS.filter(id=>!['qa','gl','buy'].includes(id)).some(id=>!$('#'+id).hidden);
async function step(name, fn, expectTop){
  curStep=name;
  try{ await fn(); }catch(e){ ok(false, `${name}: threw ${e.message}`); }
  await sleep(120);
  const leaks=[...d.querySelectorAll('[hidden]')].filter(el=>cs(el).display!=='none').map(el=>el.id||el.className);
  ok(!leaks.length, `${name}: hidden-but-visible ${leaks.join(',')}`);
  ok(top()===expectTop, `${name}: top layer is "${top()}", expected "${expectTop}"`);
  if(expectTop){ const el=$('#'+expectTop); ok(cs(el).display!=='none', `${name}: ${expectTop} not displayed`); ok((+cs(el).zIndex) < (+cs($('#toast')).zIndex), `${name}: toast would be hidden under ${expectTop}`); }
  ok(cs($('#ptr')).opacity==='0', `${name}: pull-to-refresh indicator visible at rest`);
  ok((d.body.style.overflow==='hidden')===anyFull(), `${name}: background scroll lock wrong (overflow="${d.body.style.overflow}")`);
  console.log((fails?'·':'✓'), name, '→ top:', top());
}
const back=()=>w.__onBack();
(async()=>{
  for(let i=0;i<60&&!w.RB.E.snap;i++) await sleep(200); await sleep(2600);
  ok(!$('#splash'), 'splash removed after load');
  ok(!$('#onb'), 'no onboarding element');
  ok(w.RB.UI.st.pickCat==='all', 'AI Picks default category is "Semua"');
  // every tab renders and has no hidden leaks
  for(const t of ['market','screener','picks','news','radar','watch']) await step(`tab ${t}`, ()=>d.querySelector(`#tabs [data-tab=${t}]`).click(), null);
  await step('market', ()=>d.querySelector('#tabs [data-tab=market]').click(), null);
  await step('open stock from list', ()=>d.querySelector('#view .list [data-sym]').click(), 'stock'); await sleep(400);
  await step('compare → search picker', ()=>$('#skCmp').click(), 'search');
  await step('pick comparison', async()=>{ const i=$('#srIn'); i.value='TLKM'; i.dispatchEvent(new w.Event('input')); d.querySelector('#srRes [data-go]').click(); await sleep(500); }, 'cmp');
  await step('back closes compare only', back, 'stock');
  await step('long-press quick actions over stock', ()=>d.querySelector('#stock [data-sym]') ? d.querySelector('#stock [data-sym]').dispatchEvent(new w.MouseEvent('contextmenu',{bubbles:true})) : w.RB.UI && null, d.querySelector('#stock [data-sym]') ? 'qa' : 'stock');
  if(!$('#qa').hidden) await step('back closes quick actions', back, 'stock');
  await step('glossary popover over stock', ()=>{ w.RB.UI.setSec('tech'); }, 'stock'); await sleep(200);
  const gq=d.querySelector('#sec .gq'); ok(!!gq, 'glossary ? present in technical section');
  if(gq) { await step('open glossary', ()=>gq.click(), 'gl'); await step('back closes glossary', back, 'stock'); }
  await step('full-screen chart', ()=>d.querySelector('[data-tool=fs]').click(), 'fs'); await sleep(300);
  ok(d.querySelectorAll('#fsChart canvas').length>0, 'full-screen chart rendered');
  await step('back closes full screen', back, 'stock'); await sleep(300);
  ok(d.querySelectorAll('#chart canvas').length>0, 'inline chart restored after full screen');
  for(const sec of ['sum','range','risk','tech','struct','vol','flow','smc','own','fund','val','peers','news']) { await step(`stock section ${sec}`, ()=>w.RB.UI.setSec(sec), 'stock'); ok(($('#sec').textContent||'').trim().length>10, `section ${sec} is empty`); }
  await step('back closes stock', back, null);
  await step('market structure page', ()=>d.querySelector('[data-ms=rot]').click(), 'ms');
  await step('stock above market-structure page', ()=>{ const b=d.querySelector('#ms [data-hl]'); b && b.click(); w.RB.UI.openStock('BBCA'); }, 'stock'); await sleep(400);
  await step('back to market structure', back, 'ms');
  await step('back closes market structure', back, null);
  await step('IHSG page', ()=>$('[data-act=ihsg]').click(), 'stock'); await sleep(300);
  for(const sec of ['isum','breadth','movers','tech','struct','stats','global']) { await step(`IHSG section ${sec}`, ()=>w.RB.UI.setSec(sec), 'stock'); }
  await step('back closes IHSG', back, null);
  await step('header search', ()=>$('#btnSearch').click(), 'search');
  await step('search opens stock', async()=>{ const i=$('#srIn'); i.value='BBRI'; i.dispatchEvent(new w.Event('input')); d.querySelector('#srRes [data-go]').click(); await sleep(400); }, 'stock');
  await step('back closes stock', back, null);
  await step('settings', ()=>$('#btnSettings').click(), 'settings');
  await step('glossary list from settings', ()=>$('#sGl').click(), 'gl');
  await step('back closes glossary list', back, 'settings');
  await step('back closes settings', back, null);
  d.querySelector('#tabs [data-tab=picks]').click(); await sleep(150);
  await step('backtest sheet', ()=>$('#pkBt').click(), 'bt');
  await step('backtest run shows Stop', async()=>{ ok(!!$('#btGo'), 'run button available even while evidence study runs'); $('#btGo').click(); for(let i=0;i<150 && !$('#btX');i++) await sleep(100); ok(!!$('#btX'), 'stop button visible while running'); $('#btX').click(); for(let i=0;i<40&&w.RB.B.running;i++) await sleep(100); }, 'bt');
  ok(w.RB.B.owner!=='user', 'user backtest stopped'); ok(!!$('#btGo'), 'run button back after stop');
  await step('back closes backtest', back, null);
  // news reader layer (synthetic story; network is unavailable in tests)
  d.querySelector('#tabs [data-tab=news]').click(); await sleep(100);
  const N=w.RB.N; N.stories=[N.cluster([{title:'Laba PT Bank Rakyat Indonesia Tbk (BBRI) naik 12%',link:'https://news.google.com/rss/articles/X',src:'Kontan',date:Date.now()-3600e3,desc:'',coverage:0}])[0]]; N.stories[0].aw=N.awareness(N.stories[0]); N.last=Date.now(); N.err=null;
  d.querySelector('#tabs [data-tab=market]').click(); await sleep(50); d.querySelector('#tabs [data-tab=news]').click(); await sleep(100);
  await step('news reader', ()=>d.querySelector('[data-read]').click(), 'reader'); await sleep(200);
  await step('stock from reader impact', ()=>{ const b=d.querySelector('#reader .impr'); b && b.click(); }, d.querySelector('#reader .impr') ? 'stock' : 'reader'); await sleep(300);
  while(top()) { back(); await sleep(80); }
  ok(top()===null && d.body.style.overflow==='', 'everything closed and scroll restored');
  ok(w.__onBack()===false || true, 'back at root');

  // ---- every share button on every screen must work ----
  const shareAudit=async(where)=>{ const btns=[...d.querySelectorAll('[data-share]')].filter(b=>!b.closest('[hidden]')); let okc=0; for(const b of btns){ const before=shares; b.click(); await sleep(250); if(shares>before) okc++; else ok(false, `${where}: share button for ${b.dataset.share} did nothing`); } ok(btns.length>0, `${where}: expected share buttons`); console.log(`✓ ${where}: ${okc}/${btns.length} share buttons work`); };
  d.querySelector('#tabs [data-tab=picks]').click(); await sleep(150);
  for(const c of ['mom','swing','early','acc','rev','risk']){ const b=d.querySelector(`#pkSeg [data-c=${c}]`); b.click(); await sleep(80); if(d.querySelector('#view [data-share]')) { await shareAudit('AI Picks '+c); break; } }
  w.RB.UI.openStock(d.querySelector('#view .pick [data-sym]') ? d.querySelector('#view .pick [data-sym]').dataset.sym : 'BBRI'); await sleep(500); w.RB.UI.setSec('sum'); await sleep(150);
  await shareAudit('stock page plan card');
  { const before=shares; $('#skShare').click(); await sleep(250); ok(shares>before, 'stock header share button did nothing'); }
  back(); await sleep(100);
  // ---- inflow / outflow radar ----
  d.querySelector('#tabs [data-tab=radar]').click(); await sleep(60);
  await step('inflow/outflow radar', ()=>d.querySelector('#rdSeg [data-v=flow]').click(), null);
  const vals=()=>[...d.querySelectorAll('#view .flr .px')].map(x=>{ const t=x.textContent.replace('Rp','').replace('−','-').trim(); const m=t.match(/(-?)([\d.,]+)\s*(T|M|jt)?/); if(!m) return NaN; const n=parseFloat(m[2].replace(',', '.')); const mul={T:1e12,M:1e9,jt:1e6}[m[3]]||1; return (m[1]?-1:1)*n*mul; });
  const sortedDesc=(a)=>a.every((x,i)=>i===0||a[i-1]>=x-1e-6), sortedAsc=(a)=>a.every((x,i)=>i===0||a[i-1]<=x+1e-6);
  for(const per of ['1','5','20']){ d.querySelector(`[data-fl="flowPer:${per}"]`).click(); await sleep(60); const v=vals(); ok(v.length>10, `flow ${per}d has rows`); ok(sortedDesc(v), `flow ${per}d sorted highest→lowest`); }
  d.querySelector('[data-fl="flowDir:out"]').click(); await sleep(60); { const v=vals(); ok(v.every(x=>x<0), 'outflow shows only negatives'); ok(sortedAsc(v), 'outflow largest first'); }
  d.querySelector('[data-fl="flowDir:in"]').click(); await sleep(60); { const v=vals(); ok(v.every(x=>x>0), 'inflow shows only positives'); ok(sortedDesc(v), 'inflow largest first'); }
  d.querySelector('[data-fl="flowKey:int"]').click(); await sleep(60); ok(d.querySelectorAll('#view .flr').length>5, 'intensity view has rows');
  d.querySelector('[data-fl="flowSrc:foreign"]').click(); await sleep(100); ok(/asing|IDX/i.test($('#view').textContent), 'foreign source shows status');
  d.querySelector('[data-fl="flowSrc:total"]').click(); d.querySelector('[data-fl="flowDir:all"]').click(); d.querySelector('[data-fl="flowKey:nom"]').click(); await sleep(60);
  await step('tap flow row opens stock', ()=>d.querySelector('#view .flr').click(), 'stock'); back(); await sleep(80);
  console.log('✓ inflow/outflow radar checks done');

  // ================= AI Picks v2 =================
  d.querySelector('#tabs [data-tab=picks]').click(); await sleep(150);
  d.querySelector('#pkSeg [data-c=all]').click(); await sleep(150);
  ok(!!d.querySelector('.brief'), 'brief / verdict card shown');
  const cards=d.querySelectorAll('#view .pick'); ok(cards.length>0, 'pick cards rendered');
  const total=w.RB.PK.all().length; ok(cards.length===Math.min(20,total), `first page shows ${Math.min(20,total)} of ${total}`);
  if(total>20){ $('#pkMore').click(); await sleep(100); ok(d.querySelectorAll('#view .pick').length===Math.min(40,total), 'show more extends the list (no cap)'); }
  const c0=d.querySelector('#view .pick'); ok(c0.querySelectorAll('.plain ol li').length>=1 && c0.querySelectorAll('.plain ol li').length<=3, 'plain-language reasons (1–3)'); ok(/Risiko:/.test(c0.querySelector('.prisk').textContent), 'one plain-language risk');
  ok(!!c0.querySelector('details.why'), 'technical details still available');
  console.log('  evidence state before wait:', JSON.stringify({busy:w.RB.PK.evidBusy, have:!!w.RB.PK.evid, running:w.RB.B.running, owner:w.RB.B.owner, pending:w.RB.B.userPending, evidTry:w.RB.UI.st.evidTry, err:w.RB.PK.evidErr}));
  for(let i=0;i<300 && (w.RB.PK.evidBusy || !w.RB.PK.evid); i++) await sleep(500);
  ok(!!w.RB.PK.evid && w.RB.PK.evid.byType.length>0, 'historical evidence built');
  d.querySelector('#tabs [data-tab=market]').click(); await sleep(50); d.querySelector('#tabs [data-tab=picks]').click(); await sleep(150);
  for(let i=0;i<40;i++){ const el=d.querySelector('[data-ev]'); if(el && el.dataset.done) break; await sleep(300); }
  const ev=d.querySelector('[data-ev]'); ok(ev && /muncul|Di \d+ saham/.test(ev.textContent), `evidence text shown: "${ev && ev.textContent.slice(0,90)}"`);
  const c1=d.querySelector('#view .pick'); const buySym=c1.querySelector('[data-buy]').dataset.buy;
  await step('Saya beli sheet', ()=>c1.querySelector('[data-buy]').click(), 'buy');
  $('#byLot').value='10'; $('#bySave').click(); await sleep(100);
  const pos=JSON.parse(w.localStorage.getItem('rb.port')||'[]').find(x=>x.sym===buySym); ok(pos && pos.plan && pos.plan.invalid>0, 'bought position stores its plan'); ok(pos && pos.lots===10, 'lots saved');
  ok($('#buy').hidden, 'buy sheet closed after save');
  d.querySelector('#tabs [data-tab=watch]').click(); await sleep(400);
  ok(/rencana|T1|Target 1|invalidasi|batal/i.test(d.querySelector(`.card.pos[data-sym="${buySym}"]`)?.textContent||''), 'portfolio card manages the bought plan');
  // ================= price alerts =================
  d.querySelector('[data-pw=alert]').click(); await sleep(50);
  $('#alSym').value='BBRI'; $('#alPx').value='99999'; d.querySelector('#alOp [data-v=">="]').click(); $('#alSave').click(); await sleep(80);
  $('#alSym').value='TLKM'; $('#alPx').value='1'; $('#alSave').click(); await sleep(80);
  ok(w.RB.AL.list().length===2, 'two alerts saved'); ok(d.querySelectorAll('.alr').length===2, 'alerts listed');
  ok(sched.length && sched[sched.length-1].alerts===false, 'background alerts stay off until enabled');
  w.RB.AL.list().forEach(a=>{}); const fired=await w.RB.AL.check(); ok(fired.length===0, 'no alert fires while price is far');
  { const a=w.RB.AL.list(); a[0].price=1; a[0].op='>='; w.RB.AL.save(a); } const fired2=await w.RB.AL.check(); ok(fired2.length===1, 'alert fires when the price condition is met'); ok(w.RB.AL.list()[0].on===false && w.RB.AL.list()[0].hitAt, 'fired alert is switched off and timestamped');
  w.RB.UI.openStock('BBRI'); await sleep(400);
  await step('stock bell → alert sheet', ()=>$('#skBell').click(), 'buy'); ok(!!d.querySelector('#buy #alSave'), 'alert form inside sheet'); back(); await sleep(50); back(); await sleep(80);
  // ================= heatmap & groups =================
  d.querySelector('#tabs [data-tab=market]').click(); await sleep(100);
  await step('heatmap page', ()=>d.querySelector('[data-ms=heat]').click(), 'ms'); await sleep(200);
  ok(d.querySelectorAll('.hm-c').length>=100, `heatmap tiles: ${d.querySelectorAll('.hm-c').length}`);
  const tiles=[...d.querySelectorAll('.hm-c')]; const within=tiles.every(t=>parseFloat(t.style.left)>=0 && parseFloat(t.style.left)+parseFloat(t.style.width)<=361 && parseFloat(t.style.top)>=0); ok(within, 'heatmap tiles stay inside the box');
  d.querySelector('[data-p="hmPer:perf1m"]').click(); await sleep(150); ok(d.querySelectorAll('.hm-c').length>=100, 'heatmap re-renders for 1 month');
  await step('heatmap tile opens stock', ()=>d.querySelector('.hm-c').click(), 'stock'); back(); await sleep(80);
  back(); await sleep(60);
  await step('groups page', ()=>d.querySelector('[data-ms=grp]').click(), 'ms'); await sleep(150);
  ok(d.querySelectorAll('[data-grsel]').length>=10, 'groups listed (built-in members while KSEI not loaded)');
  const rows=w.RB.O.parseCsv(fs.readFileSync(require('path').join(__dirname,'fixtures','ksei_sample.csv'),'utf8')); w.RB.O.cur=w.RB.O.build(rows,'2026-09-30'); d.querySelector('[data-p="grKind:theme"]').click(); await sleep(60); d.querySelector('[data-p="grKind:group"]').click(); await sleep(150);
  ok(/KSEI 2026-09-30|data KSEI/.test($('#msBody').textContent), 'group membership now derived from KSEI');
  const barito=w.RB.GR.list('group').find(g=>g.id==='barito'); ok(barito.syms.includes('BREN') && barito.syms.includes('TPIA'), 'Barito group resolved from holdings: '+barito.syms.join(','));
  d.querySelector('[data-grsel=astra]').click(); await sleep(500); ok(/Anggota/.test($('#msBody').textContent) && d.querySelectorAll('#msBody table.pt tr').length>3, 'group detail table'); ok(d.querySelectorAll('#grChart canvas').length>0, 'group vs IHSG chart');
  d.querySelector('[data-grback]').click(); await sleep(80); d.querySelector('[data-p="grKind:theme"]').click(); await sleep(80); ok(d.querySelectorAll('[data-grsel]').length>=10, 'themes listed');
  back(); await sleep(60);
  // ================= gorengan =================
  const anyG=[...w.RB.E.snap.stocks.values()].every(s=>s.goreng && typeof s.goreng.score==='number'); ok(anyG, 'every stock has a gorengan risk score');
  const fake={sym:'ZZZZ', f:{perf1w:40, chg1d:20, avgValue20:2e9, rvol:6, close:150, atrPct:9, marketCap:4e11, netMargin:-3}, cd:{c:[100,135,182,246,250,250,250,250,250,250,250],t:[]} };
  const gr=w.RB.RK.goreng(fake); ok(gr.level==='Tinggi' && gr.flags.length>=4, `synthetic pump scores high (${gr.score}: ${gr.flags.slice(0,2).join(' | ')})`);
  // ================= settings: schedule + Telegram =================
  $('#btnSettings').click(); await sleep(50);
  $('#nMorning').checked=true; $('#nMorning').dispatchEvent(new w.Event('change')); $('#nBg').checked=true; $('#nBg').dispatchEvent(new w.Event('change')); await sleep(30);
  const last=sched[sched.length-1]; ok(last.morning==='08:30' && last.alerts===true && last.evening==='', `schedule pushed to Android: ${JSON.stringify(last)}`);
  back(); await sleep(50);
  // portfolio round trip
  d.querySelector('#tabs [data-tab=watch]').click(); await sleep(50); d.querySelector('[data-pw=port]').click(); await sleep(50); d.querySelector('[data-act=port-add]').click(); await sleep(30);
  $('#pfSym').value='BBRI'; $('#pfAvg').value='4000'; $('#pfSave').click(); await sleep(400);
  ok(JSON.parse(w.localStorage.getItem('rb.port')||'[]').some(x=>x.sym==='BBRI'), 'portfolio saved to device storage');
  ok(d.querySelector('.card.pos .act'), 'portfolio card shows an action');
  ok(maxGap<3000, `app froze for ${maxGap} ms (near step "${gapWhere}")`);
  console.log(`\n${theme} theme: ${checks-fails}/${checks} checks passed; max UI freeze ${maxGap} ms (${gapWhere}); JS errors: ${errs.length ? errs.join(' | ') : 'none'}`);
  if(fails||errs.length) process.exitCode=1; setTimeout(()=>process.exit(process.exitCode||0),50);
})();
