// Background job test: loads the app exactly like JobService does (?job=...), with a fake Android bridge.
const {JSDOM}=require('jsdom');const fs=require('fs');const base=require('path').join(__dirname,'..','app/src/main/assets/www')+'/';
const job0=process.argv[2]; const forceOpen=job0==='alerts-open'; const job=forceOpen?'alerts':job0;
const html=fs.readFileSync(base+'index.html','utf8').replace(/<script src="js\/[^"]+"><\/script>/g,'').replace(/<link[^>]+>/g,'');
const dom=new JSDOM(html,{runScripts:'outside-only',url:'https://app.test/index.html?job='+job}); const w=dom.window; const errs=[];
w.addEventListener('error',e=>errs.push(e.message)); w.addEventListener('unhandledrejection',e=>errs.push('REJ '+e.reason)); w.scrollTo=()=>{};
const notes=[], tg=[]; let done=false, t0=Date.now();
w.AndroidBridge={ notifyTo:(t,b,tg0)=>notes.push({t,b,tg0}), notify:(t,b)=>notes.push({t,b}), jobDone:()=>{done=true;}, schedule(){}, haptic(){}, textZoom(){}, barColor(){},
  httpPost:(id,url,body,h)=>{ tg.push({url, body:JSON.parse(body)}); setTimeout(()=>w.__httpCb(id,200,JSON.stringify({ok:true,result:{}})),5); } };
w.localStorage.setItem('rb.settings', JSON.stringify({ tgToken:'123:ABC', tgChat:'42', morning:true, evening:true, bgAlerts:true }));
w.localStorage.setItem('rb.port', JSON.stringify([{sym:'BBRI',avg:900,lots:5,added:Date.now()-5*864e5}]));
w.localStorage.setItem('rb.palerts', JSON.stringify([{id:'a1',sym:'TLKM',op:'>=',price:1,on:true,created:Date.now()}]));
const SCRIPTS=[...fs.readFileSync(base+'index.html','utf8').matchAll(/<script src="js\/([^"]+)\.js"><\/script>/g)].map(m=>m[1]).filter(n=>n!=='pdf.min');
for(const f of SCRIPTS) { try{ w.eval(fs.readFileSync(base+'js/'+f+'.js','utf8')); if(f==='data' && forceOpen){ w.RB.D.wib=()=>({day:3,min:600,date:'2026-10-07'}); w.RB.D.marketOpen=()=>true; } }catch(e){ errs.push('LOAD '+f+': '+e.message); } }
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
  for(let i=0;i<600 && !done;i++) await sleep(250);
  const secs=((Date.now()-t0)/1000).toFixed(1); let fails=0; const ok=(c,m)=>{ if(!c){fails++; console.log('  ✗',m);} };
  ok(done, 'job reported done to Android');
  ok(!w.document.querySelector('#splash'), 'no splash in background mode');
  if(job==='morning'){ const b=JSON.parse(w.localStorage.getItem('rb.brief')||'null'); ok(b && b.items, 'brief saved'); ok(notes.some(n=>/Picks pagi/.test(n.t) && n.tg0==='picks'), 'morning notification (opens AI Picks)'); ok(tg.some(x=>/api\.telegram\.org\/bot123:ABC\/sendMessage/.test(x.url) && x.body.chat_id==='42' && /Picks pagi/.test(x.body.text) && x.body.parse_mode==='HTML'), 'Telegram brief sent');
    const txt=(tg.find(x=>/Picks pagi/.test(x.body.text))||{body:{text:''}}).body.text; console.log('  notification:', (notes[0]||{}).t, '—', ((notes[0]||{}).b||'').slice(0,110)); console.log('  telegram preview:\n'+txt.split('\n').slice(0,9).map(l=>'    '+l).join('\n')); ok(!/<(?!\/?(b|i)>)/.test(txt), 'Telegram text only uses allowed HTML tags'); }
  if(job==='evening'){ const r=JSON.parse(w.localStorage.getItem('rb.recap')||'null'); ok(r && r.gainers, 'recap saved'); ok(notes.some(n=>/Rangkuman sore/.test(n.t) && n.tg0==='recap'), 'evening notification'); ok(tg.some(x=>/Rangkuman/.test(x.body.text)), 'Telegram recap sent');
    console.log('  notification:', (notes[0]||{}).t, '—', ((notes[0]||{}).b||'').slice(0,120)); }
  if(job==='alerts'){ const open=forceOpen || (()=>{ const d=new Date(Date.now()+7*3600e3); const m=d.getUTCHours()*60+d.getUTCMinutes(); return d.getUTCDay()>=1&&d.getUTCDay()<=5&&m>=540&&m<=975; })();
    if(open){ ok(notes.some(n=>/TLKM/.test(n.t)), 'price alert notification'); ok(JSON.parse(w.localStorage.getItem('rb.palerts'))[0].on===false, 'alert switched off after firing'); ok(tg.some(x=>/TLKM/.test(x.body.text)), 'alert sent to Telegram'); }
    else ok(notes.length===0, 'outside trading hours: nothing fires'); console.log('  market open:', open, '| notifications:', notes.map(n=>n.t).join(' | ')); }
  ok(!errs.length, 'no JS errors: '+errs.join(' | '));
  console.log(`${job0}: ${fails?'FAIL':'ok'} in ${secs}s`); process.exit(fails?1:0);
})();
