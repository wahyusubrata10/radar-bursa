for (const f of ['indicators','structure','features','analysis','data','engine','scrdoc','own','flow','corp','caan']) require(require('path').join(__dirname,'..','app/src/main/assets/www/js',f+'.js'));
const R=global.RB; let fail=0; const ok=(c,m)=>{ if(!c){fail++; console.log('  ✗',m);} };
(async()=>{ await R.E.scan(); R.CA.items=R.CA.demo(); const it=R.CA.items.find(x=>x.code==='TOWR'); const s=R.E.getStock('TOWR'); s.fund=s.fund||{}; s.fund.cash=5e12; s.fund.sharesOut=5e10;
 const a=R.CAA.buyback(it,s); const S=a.sim;
 console.log('  TOWR price',s.f.close,'implied',Math.round(a.implied),'avg p25/p50/p75',Math.round(S.avg.p25),Math.round(S.avg.p50),Math.round(S.avg.p75),'done prob',S.done.prob.toFixed(2),'days',S.done.p50,'zone',S.zone.map(Math.round),'daysVol',a.daysVol.toFixed(1),'eps',a.eps.toFixed(2)+'%');
 console.log('  verdict:', a.verdict.slice(0,260)+'…');
 ok(S.avg.p10<=S.avg.p25 && S.avg.p25<=S.avg.p50 && S.avg.p50<=S.avg.p75 && S.avg.p75<=S.avg.p90, 'quantiles ordered');
 ok(S.zone[0]<=S.zone[1], 'support zone ordered'); ok(S.usedP50>=0 && S.usedP50<=100, 'used within 0–100');
 const a2=R.CAA.buyback(it,s); ok(a2.sim.avg.p50===S.avg.p50, 'deterministic: same input → same projection');
 // maximum price is respected
 const it3=JSON.parse(JSON.stringify(it)); it3.id+='cap'; it3.prog=null; it3.d.maxPrice=Math.round(s.f.close*0.95); const S3=R.CAA.buybackSim(it3,s); ok(!(S3.avg.p90>it3.d.maxPrice+1e-6), 'never buys above the stated maximum price');
 // faster participation finishes sooner
 R.D.settings.bbMin=2; R.D.settings.bbMax=4; R.D.settings.bbBase=3; const it4=JSON.parse(JSON.stringify(it)); it4.prog=null; it4.id='slow'; const slow=R.CAA.buybackSim(it4,s);
 R.D.settings.bbMin=30; R.D.settings.bbMax=40; R.D.settings.bbBase=35; it4.id='fast'; const fast=R.CAA.buybackSim(it4,s); R.D.settings.bbMin=5; R.D.settings.bbMax=20; R.D.settings.bbBase=10;
 ok(fast.usedP50>=slow.usedP50, `higher participation uses more of the budget (${slow.usedP50.toFixed(0)}% → ${fast.usedP50.toFixed(0)}%)`);
 // finished programme
 const it5=JSON.parse(JSON.stringify(it)); it5.id='done'; it5.prog={bought:it5.d.shares, avg:800, spent:it5.d.budget}; const S5=R.CAA.buybackSim(it5,s); ok(S5.remB===0 && S5.done.prob===1, 'fully executed programme is complete');
 // EPS accretion formula
 ok(Math.abs(a.eps - (1/(1-a.pctOut/100)-1)*100)<1e-9, 'EPS effect formula');
 // trading-day counter
 const mon=Date.parse('2026-10-12T00:00:00+07:00'); ok(R.CAA.tradingDays(mon, mon+7*864e5)===5, 'trading days skip weekends');
 // rights
 const ri=R.CA.items.find(x=>x.type==='rights'); const ra=R.CAA.rights(ri,R.E.getStock(ri.code)); ok(ra && Math.abs(ra.terp-(R.E.getStock(ri.code).f.close*10+ri.d.price*3)/13)<1e-6, 'TERP'); ok(ra.hmetd>=0 && Math.abs(ra.dil-300/13)<1e-9, 'HMETD value & dilution'); ok(/pembeli siaga/.test(ra.verdict), 'rights verdict mentions standby buyer');
 // dividend history behaviour
 const dv=R.CA.items.find(x=>x.type==='div'); const hist=await R.CAA.divHistory(dv.code); const da=R.CAA.dividend(dv,R.E.getStock(dv.code),hist); ok(hist.length>=2 && da.past.length>=2, `dividend history analysed (${da.past.length} past ex-dates)`); ok(/yield/.test(da.verdict), 'dividend verdict');
 // tender
 const tn=R.CA.items.find(x=>x.type==='tender'); const ta=R.CAA.tender(tn,R.E.getStock(tn.code)); ok(ta && ta.ann>ta.spread*0.9, 'tender annualised return'); 
 // insider cluster
 const ins=R.CA.items.find(x=>x.type==='insider'); R.CA.items.push(Object.assign(JSON.parse(JSON.stringify(ins)),{id:'ins2',d:Object.assign({},ins.d,{who:'Komisaris'})})); const ia=R.CAA.insider(ins,R.E.getStock(ins.code)); ok(ia.cluster && ia.buys===2, 'insider buying cluster detected');
 // parse new rights fields
 const pr=R.CA.parse('rights','Setiap 5 saham lama berhak atas 1 HMETD. Harga Pelaksanaan Rp 500. Perseroan telah menunjuk PT ABC sebagai pembeli siaga. Pemegang saham utama telah menyatakan akan melaksanakan seluruh HMETD. Rencana penggunaan dana: sekitar 60% untuk ekspansi pabrik dan sisanya modal kerja.'); ok(pr.standby && pr.controller && /ekspansi/.test(pr.use||''), 'rights: standby, controller commitment, use of funds parsed');
 console.log(fail?fail+' FAILED':'all analysis checks passed'); })();
