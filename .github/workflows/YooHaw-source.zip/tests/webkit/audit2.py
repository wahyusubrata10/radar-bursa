import json, subprocess, sys
probe = open(__import__('os').path.join(__import__('os').path.dirname(__file__),'probe.js')).read()
rest = "JSON.stringify({scrim: !!(document.querySelector('#scrim') && !document.querySelector('#scrim').hidden), ghosts: document.querySelectorAll('.ghost').length, open: ['stock','ms','cmp','reader','bt','search','settings','qa','gl','buy','fs'].filter(id=>{const e=document.getElementById(id); return e && !e.hidden;}), transforms: [...document.querySelectorAll('.sheet,.bsheet,#fs')].filter(e=>e.hidden && e.style.transform).map(e=>e.id), overflow: document.body.style.overflow, errs:(window.__errs||[]).slice(0,3)})"
for size in (sys.argv[1:] or ['320x640','412x915','1280x800']):
    w, h = map(int, size.split('x')); steps = [{"wait": 4800}]
    def add(name, js, wait=1100):
        steps.append({"js": js, "wait": wait}); steps.append({"name": name, "probe": probe}); steps.append({"js": "window.__onBack()", "wait": 700})
    add('quick-actions', "document.querySelector('#view .list [data-sym]').dispatchEvent(new MouseEvent('contextmenu',{bubbles:true}))")
    add('glossary', "document.querySelector('#tabs [data-tab=picks]').click(); setTimeout(()=>{const g=document.querySelector('#view .gq'); g && g.click();},600)", 1600)
    add('buy-sheet', "document.querySelector('#view [data-buy]').click()")
    for pg in ['rot','ff','own','net','brk','heat','grp']:
        add('ms-'+pg, "document.querySelector('#tabs [data-tab=market]').click(); setTimeout(()=>document.querySelector('[data-ms=%s]').click(),500)" % pg, 1700)
    steps.append({"js": "RB.UI.openStock('BBRI')", "wait": 1500})
    steps.append({"js": "document.querySelector('[data-tool=fs]').click()", "wait": 1300}); steps.append({"name": "fullscreen", "probe": probe})
    steps.append({"js": "window.__onBack()", "wait": 700}); steps.append({"js": "window.__onBack()", "wait": 900})
    steps.append({"name": "after-all-closed", "probe": rest})
    json.dump({"url": "file:///tmp/yoohaw-app.html", "w": w, "h": h, "boot": 600, "steps": steps, "timeout": 170000}, open('/tmp/plan2.json', 'w'))
    r = subprocess.run(['xvfb-run', '-a', '-s', '-screen 0 1600x1400x24', 'python3', __import__('os').path.join(__import__('os').path.dirname(__file__),'wk.py'), '/tmp/plan2.json'], capture_output=True, text=True, timeout=230)
    line = [l for l in r.stdout.strip().split('\n') if l.startswith('{')]; res = json.loads(line[-1]) if line else {}
    print('==', size, '(timeout!)' if res.get('timeout') else '')
    for k, v in res.items():
        if k in ('timeout',): continue
        if k == 'errors': print('  harness:', v); continue
        d = json.loads(v)
        if k == 'after-all-closed':
            bad = [x for x in (('scrim left on', d['scrim']), ('ghosts left', d['ghosts']), ('still open: ' + ','.join(d['open']), d['open']), ('transform left on ' + ','.join(d['transforms']), d['transforms']), ('scroll still locked', d['overflow'] == 'hidden'), ('JS errors ' + str(d['errs']), d['errs'])) if x[1]]
            print(f"  {k:17s}", 'OK' if not bad else 'ISSUES: ' + ' ; '.join(b[0] for b in bad)); continue
        issues = []
        if d['sw'] > d['W'] + 1: issues.append('sideways scroll')
        if d['nbad']: issues.append(f"{d['nbad']} off-screen: " + ', '.join(d['bad'][:4]))
        if d['errs']: issues.append('JS errors ' + ' | '.join(d['errs']))
        print(f"  {k:17s}", 'OK' if not issues else 'ISSUES: ' + ' ; '.join(issues))
