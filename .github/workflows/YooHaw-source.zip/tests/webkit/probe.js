(() => { const W = innerWidth, H = innerHeight; const bad = [];
 const scrollers = '.seg, .tbl-wrap, .hm, .rrg, .net, .tools, .fs-h, .wchips, .chart, #chart';
 document.querySelectorAll('body *').forEach(el => { if (el.closest('[hidden]') || el.closest('.leaving')) return; const cs = getComputedStyle(el); if (cs.display==='none' || cs.visibility==='hidden' || cs.position==='fixed' && el.id==='ptr') return;
   const sc = el.parentElement && el.parentElement.closest(scrollers); if (sc) return; if (el.closest('#splash')) return;
   const r = el.getBoundingClientRect(); if (r.width < 1 || r.height < 1) return;
   if (r.right > W + 1.5 || r.left < -1.5) bad.push(((el.id ? '#' + el.id : el.tagName.toLowerCase()) + (el.classList.length ? '.' + [...el.classList].slice(0,2).join('.') : '')) + ' [' + Math.round(r.left) + '..' + Math.round(r.right) + ']'); });
 const navClip = [...document.querySelectorAll('#tabs span')].filter(s => s.scrollWidth > s.clientWidth + 1).map(s => s.textContent.trim());
 const hdr = [...document.querySelectorAll('#top > *')].filter(e=>getComputedStyle(e).display!=='none').map(e => { const r = e.getBoundingClientRect(); return [e.id || e.className.split(' ')[0], Math.round(r.left), Math.round(r.right)]; });
 let overlap = []; for (let i = 0; i < hdr.length - 1; i++) if (hdr[i][2] > hdr[i + 1][1] + 1 && hdr[i][0] !== 'prog' && hdr[i+1][0] !== 'prog') overlap.push(hdr[i][0] + '/' + hdr[i + 1][0]);
 const tabs = document.querySelector('#tabs').getBoundingClientRect(); const main = document.querySelector('main');
 return JSON.stringify({ W, H, sw: document.documentElement.scrollWidth, bad: [...new Set(bad)].slice(0, 12), nbad: bad.length, navClip, hdrOverlap: overlap, tabs: [Math.round(tabs.left), Math.round(tabs.top), Math.round(tabs.width), Math.round(tabs.height)], padB: getComputedStyle(main).paddingBottom, errs: (window.__errs || []).slice(0, 3) }); })()
