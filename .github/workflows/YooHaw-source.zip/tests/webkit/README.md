# Real-engine layout tests (WebKitGTK)
apt install xvfb python3-gi python3-gi-cairo gir1.2-webkit2-4.1 gir1.2-gtk-3.0
python3 build_preview.py          # bundles the app (simulation mode) into /tmp/yoohaw-app.html
python3 audit.py 280x653 412x915 1280x800    # every tab, stock page, settings, heatmap: off-screen elements, clipped nav labels, header overlap
python3 audit2.py 320x640 1280x800           # every sheet & bottom sheet open/close; nothing left behind (scrim, ghosts, locked scroll)
python3 audit3.py 412x915 1280x800      # after scrolling every page, nothing paints over its header
