import json, subprocess, sys
probe = open(__import__('os').path.join(__import__('os').path.dirname(__file__),'probe.js')).read()
sizes = [(320,640),(360,780),(412,915),(600,960),(820,1180),(1280,800),(915,412)]
if len(sys.argv) > 1: sizes = [tuple(map(int, s.split('x'))) for s in sys.argv[1:]]
click = lambda sel: "document.querySelector(%s).click()" % json.dumps(sel)
for (w, h) in sizes:
    tag = f"{w}x{h}"; steps = [{"wait": 4800, "shot": f"s_{tag}_market.png"}, {"name": "market", "probe": probe}]
    for t in ['screener', 'picks', 'news', 'radar', 'watch']:
        steps += [{"js": click(f'#tabs [data-tab={t}]'), "wait": 900}, {"name": t, "probe": probe}]
    steps += [{"js": click('#tabs [data-tab=picks]'), "wait": 600, "shot": f"s_{tag}_picks.png"}]
    steps += [{"js": "RB.UI.openStock('BBRI')", "wait": 1500, "shot": f"s_{tag}_stock.png"}, {"name": "stock", "probe": probe}]
    steps += [{"js": "window.__onBack()", "wait": 600}, {"js": click('#btnSettings'), "wait": 900}, {"name": "settings", "probe": probe}, {"js": "window.__onBack()", "wait": 600}]
    steps += [{"js": click('#tabs [data-tab=market]') + ";document.querySelector('[data-ms=heat]').click()", "wait": 1500, "shot": f"s_{tag}_heat.png"}, {"name": "heatmap", "probe": probe}]
    json.dump({"url": "file:///tmp/yoohaw-app.html", "w": w, "h": h, "boot": 600, "steps": steps, "timeout": 150000}, open('/tmp/plan.json', 'w'))
    r = subprocess.run(['xvfb-run', '-a', '-s', '-screen 0 1600x1400x24', 'python3', __import__('os').path.join(__import__('os').path.dirname(__file__),'wk.py'), '/tmp/plan.json'], capture_output=True, text=True, timeout=200)
    line = [l for l in r.stdout.strip().split('\n') if l.startswith('{')]; res = json.loads(line[-1]) if line else {'err': r.stderr[-300:]}
    print(f"== {tag}")
    for k, v in res.items():
        if k == 'errors': print('  harness errors:', v); continue
        try: d = json.loads(v)
        except Exception: print('  ', k, v); continue
        issues = []
        if d['sw'] > d['W'] + 1: issues.append(f"page scrolls sideways ({d['sw']}>{d['W']})")
        if d['nbad']: issues.append(f"{d['nbad']} off-screen: {', '.join(d['bad'][:5])}")
        if d['navClip']: issues.append('nav label clipped: ' + ','.join(d['navClip']))
        if d['hdrOverlap']: issues.append('header overlap: ' + ','.join(d['hdrOverlap']))
        if d['errs']: issues.append('JS errors: ' + ' | '.join(d['errs']))
        print(f"  {k:9s} {'OK' if not issues else 'ISSUES: ' + ' ; '.join(issues)}")
