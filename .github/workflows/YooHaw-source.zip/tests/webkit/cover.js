((sel, hdrSel) => { const box = document.querySelector(sel); const h = box && box.querySelector(hdrSel); if (!h) return JSON.stringify({ err: 'no header ' + sel });
  const r = h.getBoundingClientRect(); const y = r.top + r.height / 2; const bad = [];
  for (let f = 0.05; f < 0.96; f += 0.1) { const x = r.left + r.width * f; const el = document.elementFromPoint(x, y); if (el && !h.contains(el) && !el.closest('#top') ) bad.push((el.id || el.tagName.toLowerCase()) + '.' + [...el.classList].slice(0, 2).join('.') + '@' + Math.round(x)); }
  return JSON.stringify({ hdr: [Math.round(r.top), Math.round(r.height)], covered: bad }); })
