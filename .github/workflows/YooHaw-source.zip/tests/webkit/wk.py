# Real-engine harness: WebKitGTK renders the app at a given viewport, runs steps, measures layout, saves screenshots.
import sys, json, gi
gi.require_version('Gtk', '3.0'); gi.require_version('WebKit2', '4.1')
from gi.repository import Gtk, WebKit2, GLib
plan = json.load(open(sys.argv[1])); W, H = plan['w'], plan['h']; out = {}
win = Gtk.OffscreenWindow(); win.set_default_size(W, H)
wv = WebKit2.WebView(); s = wv.get_settings(); s.set_enable_javascript(True); s.set_allow_file_access_from_file_urls(True); s.set_allow_universal_access_from_file_urls(True)
s.set_enable_write_console_messages_to_stdout(True)
wv.set_size_request(W, H); win.add(wv); win.show_all()
steps = list(plan['steps'])
def run_next():
    if not steps: print(json.dumps(out)); Gtk.main_quit(); return False
    st = steps.pop(0)
    def after_js(*_a):
        if st.get('shot'):
            def snap_done(view, res, *_):
                try: surf = view.get_snapshot_finish(res); surf.write_to_png(st['shot'])
                except Exception as e: out.setdefault('errors', []).append('snap ' + str(e))
                GLib.timeout_add(10, run_next)
            wv.get_snapshot(WebKit2.SnapshotRegion.VISIBLE, WebKit2.SnapshotOptions.NONE, None, snap_done)
        elif st.get('probe'):
            def probe_done(view, res, *_):
                try: v = view.evaluate_javascript_finish(res); out[st.get('name', 'probe%d' % len(out))] = json.loads(v.to_json(0))
                except Exception as e: out.setdefault('errors', []).append('probe ' + str(e))
                GLib.timeout_add(10, run_next)
            wv.evaluate_javascript(st['probe'], -1, None, None, None, probe_done)
        else: GLib.timeout_add(10, run_next)
        return False
    if st.get('js'):
        wv.evaluate_javascript(st['js'], -1, None, None, None, lambda *a: GLib.timeout_add(st.get('wait', 300), after_js))
    else: GLib.timeout_add(st.get('wait', 300), after_js)
    return False
def on_load(view, ev):
    if ev == WebKit2.LoadEvent.FINISHED: GLib.timeout_add(plan.get('boot', 3500), run_next)
wv.connect('load-changed', on_load)
wv.load_uri(plan['url'])
GLib.timeout_add(plan.get('timeout', 90000), lambda: (print(json.dumps(dict(out, timeout=True))), Gtk.main_quit()))
Gtk.main()
