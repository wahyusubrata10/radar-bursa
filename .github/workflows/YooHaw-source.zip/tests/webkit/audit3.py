import json, subprocess, sys
cov = open(__import__('os').path.join(__import__('os').path.dirname(__file__),'cover.js')).read()
def chk(sel, hdr): return cov + "(%s,%s)" % (json.dumps(sel), json.dumps(hdr))
for size in sys.argv[1:]:
    w, h = map(int, size.split('x')); S = [{"wait": 4800}]
    def scen(name, js, sel, hdr, scroll):
        S.append({"js": js, "wait": 1600}); S.append({"js": scroll, "wait": 700}); S.append({"name": name, "probe": chk(sel, hdr)})
    scen('main page', "document.querySelector('#tabs [data-tab=market]').click()", 'body', '#top', "window.scrollTo(0, 900)")
    scen('stock page', "window.scrollTo(0,0); RB.UI.openStock('BBRI')", '#stock', '.sh-h', "document.querySelector('#stock').scrollTop=520; document.querySelector('#stock').dispatchEvent(new Event('scroll'))")
    S.append({"js": "window.__onBack()", "wait": 700})
    scen('stock page (deep)', "RB.UI.openStock('TLKM')", '#stock', '.sh-h', "document.querySelector('#stock').scrollTop=1400")
    S.append({"js": "window.__onBack()", "wait": 700})
    scen('IHSG page', "RB.UI.openStock('^JKSE')", '#stock', '.sh-h', "document.querySelector('#stock').scrollTop=700")
    S.append({"js": "window.__onBack()", "wait": 700})
    scen('market structure', "document.querySelector('[data-ms=rot]').click()", '#ms', '.sh-h', "document.querySelector('#ms').scrollTop=500")
    S.append({"js": "window.__onBack()", "wait": 700})
    scen('stock page (Lite)', "document.querySelector('#btnMode [data-m=lite]').click(); setTimeout(()=>RB.UI.openStock('BBRI'),300)", '#stock', '.sh-h', "document.querySelector('#stock').scrollTop=520")
    S.append({"js": "window.__onBack(); document.querySelector('#btnMode [data-m=pro]').click()", "wait": 700})
    json.dump({"url": "file:///tmp/yoohaw-app.html", "w": w, "h": h, "boot": 600, "steps": S, "timeout": 120000}, open('/tmp/plan3.json', 'w'))
    r = subprocess.run(['xvfb-run', '-a', '-s', '-screen 0 1600x1400x24', 'python3', __import__('os').path.join(__import__('os').path.dirname(__file__),'wk.py'), '/tmp/plan3.json'], capture_output=True, text=True, timeout=160)
    line = [l for l in r.stdout.strip().split('\n') if l.startswith('{')]; res = json.loads(line[-1]) if line else {}
    print('==', size)
    for k, v in res.items():
        if k in ('timeout', 'errors'): print('  ', k, v); continue
        d = json.loads(v); print(f"  {k:18s}", 'OK' if not d.get('covered') and not d.get('err') else 'ISSUE: ' + (d.get('err') or 'header covered by ' + ', '.join(d['covered'][:4])))
