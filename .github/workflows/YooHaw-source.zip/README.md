# Yoo Haw — Intelijen Saham Indonesia (Android)

Aplikasi Android gratis untuk screening & radar saham BEI: screener modular (AND/OR/NOT, multi-timeframe),
24+ preset profesional, Setup Score yang bisa dijelaskan, AI Picks harian dengan rencana trading,
radar live, spike alert, dan bandar radar berbasis bukti.

## Cara dapat APK (cukup dari HP, gratis)

1. Buat repo baru di github.com (boleh private).
2. **Add file → Create new file**, ketik nama `.github/workflows/build.yml`, tempel isi file `build.yml`, Commit.
3. **Add file → Upload files**, unggah `YooHaw-source.zip` apa adanya (jangan diekstrak), Commit.
4. Tunggu ±5 menit (tab **Actions**). APK muncul di **Releases** → `YooHaw.apk`. Unduh & pasang
   (izinkan "instal dari sumber tidak dikenal").

Build berikutnya bisa langsung menimpa versi lama karena memakai keystore yang sama (`app/yoohaw.jks`).
Ganti keystore itu kalau aplikasinya mau dibagikan ke orang lain.

Dari laptop: ekstrak zip ke root repo lalu push — workflow yang sama akan jalan.

## Berita (tab Berita)
- Sumber: Google News RSS (10 kueri pasar + per emiten watchlist & penggerak hari ini), CNBC Indonesia Market RSS,
  dan RSS tambahan pilihanmu (Pengaturan).
- Berita yang sama dari banyak media digabung jadi satu **cerita** (kemiripan judul + emiten yang sama).
- **Kesadaran pasar** (0–100) = umur berita + jumlah sumber + reaksi harga (dalam ATR) & RVOL emiten sejak jam
  terbit (candle 5 menit). Label: *Sangat awal*, *Belum banyak yang tahu*, *Mulai menyebar*, *Sudah banyak yang tahu*.
  Berita yang terbit setelah bursa tutup ditandai *Belum diuji pasar*.
- **Dampak ke emiten**: emiten yang disebut langsung (arah dari jenis aksi korporasi: dividen, buyback, right issue,
  tender offer, laporan keuangan, hukum, indeks, dll.) + imbas tidak langsung lewat aturan tema (nikel, batu bara,
  emas, CPO, minyak, BI Rate, rupiah, cukai, data center, properti, infrastruktur, EBT, ritel, …).
- **Ringkasan**: otomatis berbasis aturan. Opsional: ringkasan & analisis dampak oleh AI memakai API key milikmu
  (Google Gemini atau endpoint OpenAI-compatible seperti Groq) — diatur di Pengaturan.

## Pengaturan screener
- Timeframe kondisi (1m–mingguan) dipakai saat memilih preset dan bisa diterapkan ke semua kondisi aktif;
  tiap kondisi juga bisa punya timeframe sendiri.
- Cakupan (semua / watchlist / per sektor) dan likuiditas minimum.
- Parameter detektor: kekuatan swing, ukuran & jendela FVG, jendela BOS/CHoCH, sweep, order block, displacement,
  breakout & retest, periode RSI/RVOL, squeeze, divergence.
- Field "Bar sejak …" (FVG, BOS/CHoCH, sweep, displacement) memberi jendela waktu berbeda per kondisi.

## Backtest & track record
- Uji kondisi screener, preset, atau kategori AI Picks ke riwayat harian 5 tahun (6 bln–3 thn periode uji).
- Point-in-time: di setiap titik uji fitur dihitung ulang hanya dari data sampai hari itu (RS Rating & kondisi
  pasar juga direkonstruksi per tanggal). Kondisi fundamental/foreign/sektor/intraday dilewati karena tidak ada
  riwayat gratisnya — aplikasi menyebutkan kondisi mana yang dilewati.
- Exit: invalidasi / target 1 rencana / batas hari; biaya beli-jual dihitung. Hasil: win rate, rata-rata R,
  profit factor, alpha vs IHSG, max drawdown, kurva ekuitas, serta kinerja per bucket Setup Score dan per regime.
- Track record AI Picks: pick harian dicatat otomatis lalu dievaluasi dengan harga sesudahnya (out-of-sample).

## Kondisi pasar (regime)
Skor 0–100 dari tren IHSG, breadth (% saham > EMA 50/20, A/D), volatilitas (ATR IHSG, VIX), minat asing
(foreign flow, EIDO), rupiah, dan pasar global. Risk-on ≥ 60, Netral 40–59, Risk-off < 40. Masuk ke Setup Score
dan memperketat AI Picks saat netral/risk-off (bisa dimatikan).

## Aturan BEI
ARA/ARB per Kep-00136/BEI/09-2026 (otomatis berganti ke simetris 1 Jan 2027), harga minimum Rp1, fraksi harga,
biaya beli/jual (default 0,15%/0,25%) pada R/R bersih & backtest, peringatan bila stop di bawah ARB / target di
atas ARA, event radar "Menyentuh ARA/ARB", daftar Papan Pemantauan Khusus (diisi manual) dikecualikan dari picks.

## Makro & komoditas
Emas, tembaga, Brent, gas, batu bara (API2, proxy), minyak kedelai (proxy CPO), USD/IDR, DXY, US10Y, VIX, S&P 500,
Hang Seng, Shanghai, EIDO. Tiap instrumen ditautkan ke emiten terkait dengan korelasi 6 bulan (termasuk jeda H+1)
dan penanda "belum ikut" untuk kandidat catch-up. Nikel LME & CPO Bursa Malaysia tidak tersedia gratis.

## Struktur pasar (data resmi gratis)
- **Rotasi sektor (RRG)**: RS-Ratio & RS-Momentum tiap sektor vs IHSG (mingguan/harian) dengan jejak 6 periode.
- **Asing vs domestik**: IDX Ringkasan Saham harian (30 hari, disimpan permanen per hari) — net asing pasar,
  per saham, per sektor, hari beruntun, partisipasi asing, divergensi asing vs harga, inventory asing kumulatif.
- **Kepemilikan & inventory**: daftar pemegang saham ≥1% dari KSEI (terbit bulanan di situs BEI). PDF resmi
  diunduh & dibaca otomatis di HP (pdf.js); perubahan bulan ke bulan, konsentrasi, perkiraan free float,
  komposisi per tipe investor. Bisa impor PDF/CSV manual bila situs BEI menolak koneksi otomatis.
- **Jaringan pemilik**: graf investor ↔ saham (termasuk emiten yang menjadi pemegang saham emiten lain).
- **Aktivitas broker**: total transaksi per broker se-pasar dari IDX (bukan per saham — data itu berbayar).
- Halaman saham: **Peers**, **Kepemilikan**, **Trade flow** (perkiraan tekanan beli/jual dari OHLCV),
  **Kisaran gerak** (rentang 1/5/20 hari & peluang menyentuh target).

## Arsitektur

```
app/src/main/java/.../MainActivity.java   WebView shell: server aset lokal (https://app.local),
                                          proxy HTTP native (tanpa batas CORS), POST untuk AI opsional, notifikasi, keep-awake
app/src/main/assets/www/
  js/indicators.js   EMA/SMA/RSI/MACD/ADX/ATR/Stoch/BB/OBV/MFI/CMF/A-D/VWAP/AVWAP/Volume Profile
  js/structure.js    pivot HH/HL/LH/LL, BOS/CHoCH, FVG + mitigasi, order block/breaker, S/R cluster,
                     equal highs/lows, liquidity sweep, divergence
  js/features.js     ±170 field screener + registry (label, grup, satuan)
  js/analysis.js     Setup Score (10 komponen + alasan), klasifikasi setup, rencana trading
                     (fraksi harga BEI), bandar radar berbasis bukti, ringkasan naratif
  js/data.js         provider data yang bisa diganti + cache IndexedDB + label status
  js/news.js         agregasi berita, clustering, skor kesadaran pasar, dampak emiten, ringkasan (+AI opsional)
  js/macro.js        makro & komoditas, korelasi lintas aset, regime pasar (kini & historis)
  js/bt.js           backtest point-in-time
  js/own.js          kepemilikan KSEI ≥1%: pencarian file, parser PDF, perubahan bulanan, jaringan
  js/flow.js         asing/domestik, broker, trade flow, RRG, kisaran gerak, peers
  js/engine.js       pemindaian universe, screener 3-nilai (prefilter harian → timeframe lain),
                     preset, AI Picks, radar live
  js/app.js          UI (Pasar | Screener | AI Picks | Berita | Radar | Watchlist + halaman saham)
```

Semua analisis berjalan di HP. Tidak ada server, domain, atau hosting berbayar.

## Sumber data & label status

| Data | Sumber default | Status yang ditampilkan |
|---|---|---|
| Candle intraday 1m/5m/15m/1H | Yahoo Finance | Tertunda (±10 menit) |
| Candle harian/mingguan | Yahoo Finance | Tertunda saat bursa buka, EOD setelah tutup |
| Fundamental & valuasi | Yahoo Finance quoteSummary | Laporan terakhir |
| Foreign flow | IDX Ringkasan Saham | EOD; nilai = volume asing × close (estimasi). Bisa diblokir proteksi bot IDX → tampil "Tidak tersedia" |
| Berita | Google News RSS, CNBC Indonesia, RSS tambahan | Kesadaran pasar & dampak = estimasi berbasis aturan (atau AI jika diaktifkan) |
| Akumulasi/distribusi, ROIC | Diturunkan dari data di atas | Estimasi |
| Broker summary / transaksi besar per broker | — | Tidak tersedia (butuh feed berbayar) |
| Valuasi vs rata-rata historis | — | Tidak tersedia dari sumber gratis |

Aplikasi tidak pernah mengarang data. Mode **Simulasi** hanya ada di pratinjau browser dan selalu diberi
banner peringatan.

### Provider kustom (mis. feed real-time berbayar)
Pilih *Provider kustom* di Pengaturan, isi URL dasar & API key. Endpoint yang diharapkan:

```
GET {base}/candles?symbol=BBRI&tf=5m&apikey=KEY
→ {"status":"realtime","name":"Bank Rakyat Indonesia","prevClose":4500,
   "candles":[[unixSeconds,open,high,low,close,volume], ...]}      // tf: 1m 5m 15m 1H D W

GET {base}/fundamentals?symbol=BBRI&apikey=KEY
→ {"pe":10.2,"pb":2.1,"roe":19.5,"revGrowth":8.1,"epsGrowth":6.3, ...}   // nama field = field screener
```
Buat adapter kecil (mis. Cloudflare Worker gratis) yang menerjemahkan API vendor ke format ini.

## Batasan yang perlu diketahui
- Alert berjalan selama aplikasi terbuka (radar menjaga layar menyala). Tidak ada servis latar belakang
  agar hemat baterai dan tidak diblokir Android.
- Data gratis Yahoo tertunda; untuk scalping 1 menit gunakan provider real-time.
- Universe bawaan ±150 saham likuid; tambah kode lain di Pengaturan.
- Setup Score menilai kualitas kondisi, **bukan** probabilitas profit. Bukan rekomendasi investasi.
