package id.radarbursa.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.TimeZone;

/** Exact alarms (WIB) for the morning brief, evening recap and in-session alert checks. */
final class Sched {
    private static final String PREFS = "yh_sched";
    static final String MORNING = "morning", EVENING = "evening", ALERTS = "alerts";
    private Sched() { }

    static void save(Context ctx, String json) { ctx.getSharedPreferences(PREFS, 0).edit().putString("cfg", json).apply(); }

    private static JSONObject cfg(Context ctx) {
        try { return new JSONObject(ctx.getSharedPreferences(PREFS, 0).getString("cfg", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    static void scheduleAll(Context ctx) {
        JSONObject c = cfg(ctx);
        set(ctx, MORNING, 1, nextAt(c.optString("morning", "")));
        set(ctx, EVENING, 2, nextAt(c.optString("evening", "")));
        set(ctx, ALERTS, 3, c.optBoolean("alerts", false) ? nextAlertSlot() : -1);
    }

    /** Next weekday occurrence of HH:MM in Asia/Jakarta, or -1 when disabled. */
    static long nextAt(String hhmm) {
        if (hhmm == null || !hhmm.matches("\\d{1,2}:\\d{2}")) return -1;
        String[] p = hhmm.split(":");
        Calendar k = Calendar.getInstance(TimeZone.getTimeZone("Asia/Jakarta"));
        Calendar t = (Calendar) k.clone();
        t.set(Calendar.HOUR_OF_DAY, Integer.parseInt(p[0])); t.set(Calendar.MINUTE, Integer.parseInt(p[1])); t.set(Calendar.SECOND, 0); t.set(Calendar.MILLISECOND, 0);
        if (!t.after(k)) t.add(Calendar.DAY_OF_MONTH, 1);
        while (t.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || t.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) t.add(Calendar.DAY_OF_MONTH, 1);
        return t.getTimeInMillis();
    }

    /** Every 15 minutes during the trading session (09:00–16:15 WIB, weekdays). */
    static long nextAlertSlot() {
        Calendar k = Calendar.getInstance(TimeZone.getTimeZone("Asia/Jakarta"));
        Calendar t = (Calendar) k.clone(); t.set(Calendar.SECOND, 0); t.set(Calendar.MILLISECOND, 0);
        int m = t.get(Calendar.MINUTE); t.set(Calendar.MINUTE, (m / 15) * 15); t.add(Calendar.MINUTE, 15);
        for (int i = 0; i < 7 * 24 * 4; i++) {
            int dow = t.get(Calendar.DAY_OF_WEEK), mins = t.get(Calendar.HOUR_OF_DAY) * 60 + t.get(Calendar.MINUTE);
            if (dow != Calendar.SATURDAY && dow != Calendar.SUNDAY && mins >= 9 * 60 && mins <= 16 * 60 + 15) return t.getTimeInMillis();
            t.add(Calendar.MINUTE, 15);
        }
        return -1;
    }

    private static void set(Context ctx, String job, int code, long at) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(ctx, AlarmReceiver.class).setAction("id.yoohaw.JOB." + job).putExtra("job", job);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        am.cancel(pi);
        if (at < 0) return;
        try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); }
        catch (SecurityException e) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); }
    }
}
