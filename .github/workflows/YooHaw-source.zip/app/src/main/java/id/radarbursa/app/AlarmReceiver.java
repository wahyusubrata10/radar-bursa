package id.radarbursa.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Fires a background job and re-arms the next alarm. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String job = intent.getStringExtra("job");
        if (job != null) {
            Intent s = new Intent(ctx, JobService.class).putExtra("job", job);
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(s); else ctx.startService(s);
            } catch (Exception ignored) { }
        }
        Sched.scheduleAll(ctx);
    }
}
