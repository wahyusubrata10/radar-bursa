package id.radarbursa.app;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

/** JavaScript bridge shared by the visible app (Activity) and background jobs (JobService). */
final class Bridge {
    static final String CH_ALERT = "radar_alerts";
    static final String CH_JOB = "yh_jobs";
    private static int notifId = 100;
    private final Context ctx;
    private final WebView web;
    private final Activity act;        // null inside background jobs
    private final JobService job;      // null inside the Activity
    private final Handler ui = new Handler(Looper.getMainLooper());

    Bridge(Context ctx, WebView web, Activity act, JobService job) {
        this.ctx = ctx; this.web = web; this.act = act; this.job = job;
        createChannels(ctx);
    }

    static void createChannels(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel a = new NotificationChannel(CH_ALERT, "Alert & briefing", NotificationManager.IMPORTANCE_HIGH);
        a.setDescription("Picks pagi, rangkuman sore, alert harga, dan sinyal radar");
        nm.createNotificationChannel(a);
        NotificationChannel j = new NotificationChannel(CH_JOB, "Pembaruan di latar belakang", NotificationManager.IMPORTANCE_MIN);
        j.setDescription("Ditampilkan singkat saat Yoo Haw memperbarui data");
        nm.createNotificationChannel(j);
    }

    private void post(Runnable r) { ui.post(r); }

    // ---------- notifications ----------
    @JavascriptInterface
    public void notify(String title, String body) { notifyTo(title, body, ""); }

    /** target: "" | "picks" | "recap" | "stock:BBRI" — opened when the notification is tapped. */
    @JavascriptInterface
    public void notifyTo(String title, String body, String target) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        if (target != null && !target.isEmpty()) i.putExtra("open", target);
        int id = notifId++;
        PendingIntent pi = PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CH_ALERT) : new Notification.Builder(ctx);
        b.setSmallIcon(R.drawable.ic_stat).setContentTitle(title).setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(pi);
        try { ((NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id, b.build()); } catch (SecurityException ignored) { }
    }

    // ---------- background schedule ----------
    /** JSON: {"morning":"08:30"|"" ,"evening":"16:30"|"", "alerts":true|false} */
    @JavascriptInterface
    public void schedule(String json) { Sched.save(ctx, json); Sched.scheduleAll(ctx); }

    @JavascriptInterface
    public void jobDone() { if (job != null) post(job::finish); }

    @JavascriptInterface
    public String jobName() { return job != null ? job.current() : ""; }

    @JavascriptInterface
    public void openBatterySettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception ignored) { }
    }

    // ---------- network ----------
    /** Async POST (Telegram, optional AI). Result: window.__httpCb(id, code, body). */
    @JavascriptInterface
    public void httpPost(final String id, final String url, final String body, final String headersJson) {
        new Thread(() -> {
            int code = 0;
            String resp;
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(15000);
                c.setReadTimeout(90000);
                c.setDoOutput(true);
                c.setRequestProperty("User-Agent", Web.UA);
                JSONObject h = new JSONObject(headersJson == null ? "{}" : headersJson);
                Iterator<String> it = h.keys();
                while (it.hasNext()) { String k = it.next(); c.setRequestProperty(k, h.optString(k)); }
                OutputStream os = c.getOutputStream();
                os.write(body.getBytes(StandardCharsets.UTF_8));
                os.close();
                code = c.getResponseCode();
                InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
                resp = new String(Web.readAll(is), StandardCharsets.UTF_8);
            } catch (Exception e) {
                resp = e.getClass().getSimpleName() + ": " + e.getMessage();
            } finally {
                if (c != null) c.disconnect();
            }
            final String js = "window.__httpCb && window.__httpCb(" + JSONObject.quote(id) + "," + code + "," + JSONObject.quote(resp) + ")";
            post(() -> web.evaluateJavascript(js, null));
        }).start();
    }

    // ---------- device ----------
    @JavascriptInterface
    public void openUrl(String url) {
        try { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void keepAwake(final boolean on) {
        if (act == null) return;
        post(() -> { if (on) act.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); else act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); });
    }

    @JavascriptInterface
    public void haptic(final String kind) {
        if (act == null) return;
        post(() -> {
            int c = HapticFeedbackConstants.KEYBOARD_TAP;
            if ("long".equals(kind)) c = HapticFeedbackConstants.LONG_PRESS;
            else if ("confirm".equals(kind)) c = Build.VERSION.SDK_INT >= 30 ? 16 : HapticFeedbackConstants.VIRTUAL_KEY;
            else if ("reject".equals(kind)) c = Build.VERSION.SDK_INT >= 30 ? 17 : HapticFeedbackConstants.LONG_PRESS;
            web.performHapticFeedback(c);
        });
    }

    @JavascriptInterface
    public void orientation(final String mode) {
        if (act == null) return;
        post(() -> act.setRequestedOrientation("landscape".equals(mode) ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));
    }

    @JavascriptInterface
    public void textZoom(final int z) { post(() -> web.getSettings().setTextZoom(Math.max(80, Math.min(150, z)))); }

    @JavascriptInterface
    @SuppressWarnings("deprecation")
    public void barColor(final String hex, final boolean light) {
        if (act == null) return;
        post(() -> {
            try {
                int c = Color.parseColor(hex.trim());
                act.getWindow().setStatusBarColor(c);
                act.getWindow().setNavigationBarColor(c);
                View d = act.getWindow().getDecorView();
                int f = d.getSystemUiVisibility();
                if (light) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                else f &= ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                d.setSystemUiVisibility(f);
                web.setBackgroundColor(c);
            } catch (Exception ignored) { }
        });
    }

    /** Share a PNG (base64, no data: prefix) through the Android share sheet. */
    @JavascriptInterface
    public void shareImage(final String b64, final String text) {
        try {
            byte[] png = Base64.decode(b64, Base64.DEFAULT);
            File dir = new File(ctx.getCacheDir(), "share");
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File o : old) if (System.currentTimeMillis() - o.lastModified() > 3600_000L) o.delete();
            File f = new File(dir, "yoohaw-" + System.currentTimeMillis() + ".png");
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(png);
            fo.close();
            Uri uri = Uri.parse("content://" + ctx.getPackageName() + ".share/" + f.getName());
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("image/png");
            i.putExtra(Intent.EXTRA_STREAM, uri);
            if (text != null && !text.isEmpty()) i.putExtra(Intent.EXTRA_TEXT, text);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            final Intent chooser = Intent.createChooser(i, "Bagikan");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            post(() -> ctx.startActivity(chooser));
        } catch (Exception ignored) { }
    }
}
