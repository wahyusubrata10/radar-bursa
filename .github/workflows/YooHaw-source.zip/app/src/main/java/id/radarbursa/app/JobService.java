package id.radarbursa.app;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.webkit.WebView;

import java.util.ArrayDeque;

/**
 * Runs the app's analysis engine headless (no UI) for scheduled jobs: morning picks, evening recap, alert checks.
 * The page is loaded with ?job=<name>; it calls AndroidBridge.jobDone() when finished (or times out).
 */
public class JobService extends Service {
    private static final long TIMEOUT_MS = 4 * 60 * 1000L;
    private final ArrayDeque<String> queue = new ArrayDeque<>();
    private final Handler h = new Handler(Looper.getMainLooper());
    private WebView web;
    private String current = "";
    private PowerManager.WakeLock lock;
    private final Runnable timeout = this::finish;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Bridge.createChannels(this);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, Bridge.CH_JOB) : new Notification.Builder(this);
        Notification n = b.setSmallIcon(R.drawable.ic_stat).setContentTitle("Yoo Haw").setContentText("Memperbarui data pasar…").setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC); else startForeground(77, n);
        String job = intent != null ? intent.getStringExtra("job") : null;
        if (job != null && !queue.contains(job) && !job.equals(current)) queue.add(job);
        if (web == null) next();
        return START_NOT_STICKY;
    }

    String current() { return current; }

    private void next() {
        String job = queue.poll();
        if (job == null) { stopForeground(true); stopSelf(); return; }
        current = job;
        if (lock == null) { lock = ((PowerManager) getSystemService(Context.POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "yoohaw:job"); }
        if (!lock.isHeld()) lock.acquire(TIMEOUT_MS + 30_000L);
        web = new WebView(this);
        Web.setup(this, web, new Bridge(this, web, null, this), false);
        web.loadUrl("https://" + Web.HOST + "/index.html?job=" + job);
        h.removeCallbacks(timeout);
        h.postDelayed(timeout, TIMEOUT_MS);
    }

    /** Called by the page (via Bridge.jobDone) or by the timeout. */
    void finish() {
        h.removeCallbacks(timeout);
        if (web != null) { try { web.stopLoading(); web.destroy(); } catch (Exception ignored) { } web = null; }
        current = "";
        if (lock != null && lock.isHeld()) lock.release();
        next();
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(timeout);
        if (web != null) { try { web.destroy(); } catch (Exception ignored) { } web = null; }
        if (lock != null && lock.isHeld()) lock.release();
        super.onDestroy();
    }
}
