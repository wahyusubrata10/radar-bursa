package id.radarbursa.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/** Shared WebView host: serves the app from assets at https://app.local/ and proxies network GETs natively. */
final class Web {
    static final String HOST = "app.local";
    static final String UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36";

    private Web() { }

    static void initCookies() {
        if (!(CookieHandler.getDefault() instanceof CookieManager)) CookieHandler.setDefault(new CookieManager(null, CookiePolicy.ACCEPT_ALL));
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    static void setup(final Context ctx, WebView web, Bridge bridge, final boolean openLinksExternally) {
        initCookies();
        web.setBackgroundColor(Color.parseColor("#0F1722"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setTextZoom(100);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(bridge, "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String path = u.getPath() == null ? "/" : u.getPath();
                if (path.equals("/proxy")) return proxy(u.getQueryParameter("u"));
                if (path.equals("/")) path = "/index.html";
                try {
                    InputStream in = ctx.getAssets().open("www" + path);
                    return new WebResourceResponse(mime(path), "utf-8", in);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (HOST.equals(u.getHost())) return false;
                if (openLinksExternally) {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW, u);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        ctx.startActivity(i);
                    } catch (Exception ignored) { }
                }
                return true;
            }
        });
    }

    static WebResourceResponse proxy(String target) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Cache-Control", "no-store");
        if (target == null || !(target.startsWith("https://") || target.startsWith("http://"))) {
            return new WebResourceResponse("text/plain", "utf-8", 400, "Bad Request", headers, new ByteArrayInputStream("bad url".getBytes()));
        }
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(target).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept", "application/json, text/plain, application/xml, */*");
            c.setRequestProperty("Accept-Language", "id-ID,id;q=0.9,en;q=0.8");
            if (target.contains("idx.co.id") || target.contains("idx.id")) c.setRequestProperty("Referer", "https://www.idx.co.id/");
            int code = c.getResponseCode();
            InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
            byte[] body = readAll(is);
            if (code >= 300 && code < 400) code = 502;
            if (code < 100 || code > 599) code = 502;
            String ct = c.getContentType();
            String type = ct == null ? "application/octet-stream" : ct.split(";")[0].trim();
            return new WebResourceResponse(type, "utf-8", code, code < 400 ? "OK" : "Error", headers, new ByteArrayInputStream(body));
        } catch (Exception e) {
            String msg = e.getClass().getSimpleName() + ": " + e.getMessage();
            return new WebResourceResponse("text/plain", "utf-8", 502, "Bad Gateway", headers, new ByteArrayInputStream(msg.getBytes()));
        } finally {
            if (c != null) c.disconnect();
        }
    }

    static byte[] readAll(InputStream is) throws IOException {
        if (is == null) return new byte[0];
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        is.close();
        return bo.toByteArray();
    }

    static String mime(String p) {
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }
}
