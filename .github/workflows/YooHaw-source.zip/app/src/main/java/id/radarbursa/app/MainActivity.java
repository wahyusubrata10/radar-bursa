package id.radarbursa.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

import org.json.JSONObject;

/** Yoo Haw — visible app shell. All analysis runs in the WebView (assets/www); see Web, Bridge, JobService. */
public class MainActivity extends Activity {
    private static final int REQ_FILE = 42;
    private WebView web;
    private ValueCallback<Uri[]> fileCb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#0F1722"));
        getWindow().setNavigationBarColor(Color.parseColor("#151F2C"));
        web = new WebView(this);
        Web.setup(this, web, new Bridge(this, web, this, null), true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "text/csv", "text/comma-separated-values", "text/plain"});
                try { startActivityForResult(Intent.createChooser(i, "Pilih file"), REQ_FILE); } catch (Exception e) { fileCb = null; return false; }
                return true;
            }
        });
        setContentView(web);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        }
        Sched.scheduleAll(this);
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl("https://" + Web.HOST + "/index.html" + openParam(getIntent()));
    }

    private static String openParam(Intent i) {
        String t = i != null ? i.getStringExtra("open") : null;
        return t == null || t.isEmpty() ? "" : "?open=" + Uri.encode(t);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String t = intent.getStringExtra("open");
        if (t != null && !t.isEmpty()) web.evaluateJavascript("window.__openTarget && window.__openTarget(" + JSONObject.quote(t) + ")", null);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCb != null) { fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data)); fileCb = null; }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        web.evaluateJavascript("(window.__onBack && window.__onBack()) ? 'y' : 'n'", v -> { if (v == null || !v.contains("y")) MainActivity.super.onBackPressed(); });
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }
}
