/* Yoo Haw — corporate-action analysis (analyst layer on top of corp.js). */
(function (R) {
  const { D, A, I, E } = R; const ok = I.ok; const CAA = { divCache: new Map() };
  const DAY = 864e5;
  // deterministic RNG so the same disclosure always produces the same projection (no jitter between renders)
  const seedOf = (s) => { let h = 2166136261; for (const c of String(s)) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; };
  const rng = (a) => () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const gauss = (r) => { let u = 0, v = 0; while (u === 0) u = r(); while (v === 0) v = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
  const q = (arr, p) => { if (!arr.length) return NaN; const a = arr.slice().sort((x, y) => x - y); const i = (a.length - 1) * p, lo = Math.floor(i), hi = Math.ceil(i); return a[lo] + (a[hi] - a[lo]) * (i - lo); };
  const wq = (pairs, p) => { const a = pairs.filter((x) => x[1] > 0).sort((x, y) => x[0] - y[0]); const tot = a.reduce((s, x) => s + x[1], 0); let acc = 0; for (const [v, w] of a) { acc += w; if (acc >= tot * p) return v; } return a.length ? a[a.length - 1][0] : NaN; };
  const isoToT = (iso) => Date.parse(iso + 'T00:00:00+07:00');
  // trading days (Mon–Fri) strictly after t0 up to and including t1
  CAA.tradingDays = (t0, t1) => { let n = 0; for (let t = t0 + DAY; t <= t1 + 1; t += DAY) { const d = new Date(t + 7 * 3600e3).getUTCDay(); if (d !== 0 && d !== 6) n++; } return n; };
  const dailyVol = (cd, n = 60) => { const c = cd.c, L = c.length; const r = []; for (let i = Math.max(1, L - n); i < L; i++) r.push(Math.log(c[i] / c[i - 1])); const m = r.reduce((a, b) => a + b, 0) / (r.length || 1); return Math.sqrt(r.reduce((a, b) => a + (b - m) ** 2, 0) / Math.max(1, r.length - 1)); };
  CAA.cfg = () => { const S = D.settings || {}; const base = +S.bbBase || 10, lo = +S.bbMin || 5, hi = +S.bbMax || 20; return { base: Math.min(Math.max(base, lo), hi) / 100, lo: lo / 100, hi: Math.max(lo, hi) / 100 }; };

  // ---------------- buyback ----------------
  // Monte Carlo of the remaining programme: zero-drift price paths from the stock's own volatility; every day the issuer buys a
  // share of average daily volume (sampled in the configured range, or around the pace it actually reported), never above the
  // stated maximum price, until money, shares or time run out.
  CAA.buybackSim = (it, s, opt = {}) => {
    const d = it.d || {}; const p0 = s.f.close; const advSh = s.f.avgValue20 / p0; const now = opt.now || Date.now();
    const C = CAA.cfg(); const prog = it.prog || {}; const boughtPrev = prog.bought || 0, spentPrev = prog.spent || (prog.bought && prog.avg ? prog.bought * prog.avg : 0);
    const budget = d.budget > 0 ? d.budget : d.shares > 0 ? d.shares * p0 * 1.15 : NaN; const maxSh = d.shares > 0 ? d.shares : budget / (p0 * 0.6);
    if (!(budget > 0) || !(advSh > 0)) return null;
    const remB = Math.max(0, budget - spentPrev), remS = Math.max(0, maxSh - boughtPrev);
    const end = d.to ? isoToT(d.to) : (d.from ? isoToT(d.from) : it.t) + 91 * DAY; const days = Math.max(0, Math.min(260, CAA.tradingDays(now, end)));
    let pace = null;
    // observed pace from the execution report, shrunk towards the base case (10 pseudo trading days) so a report covering only a
    // few days cannot dominate, and capped at 30% of daily volume (beyond that a buyback would itself move the price strongly)
    if (prog.bought > 0 && (d.from || it.t)) { const td = Math.max(1, CAA.tradingDays((d.from ? isoToT(d.from) : it.t) - DAY, prog.t || now)); const K = 10; pace = Math.min(0.3, Math.max(0.005, (prog.bought / advSh + C.base * K) / (td + K))); }
    const sigma = Math.max(0.004, Math.min(0.08, dailyVol(s.cd))); const cap = d.maxPrice > 0 ? d.maxPrice : Infinity; const r = rng(seedOf(it.id + '|' + C.lo + C.hi + C.base));
    const N = opt.n || 400; const avgs = [], dayDone = [], used = [], buys = []; let completed = 0;
    for (let k = 0; k < N; k++) {
      // participation: around the observed pace if known, otherwise skewed towards the base case inside [lo, hi]
      const pr = pace ? Math.max(0.01, pace * (0.7 + 0.6 * r())) : (r() < 0.5 ? C.lo + (C.base - C.lo) * Math.sqrt(r()) : C.hi - (C.hi - C.base) * Math.sqrt(r()));
      let P = p0, b = remB, sh = remS, cost = 0, got = 0, done = -1;
      for (let t = 1; t <= days; t++) {
        P *= Math.exp(sigma * gauss(r) - 0.5 * sigma * sigma);
        if (b <= 0 || sh <= 0) { done = t - 1; break; }
        if (P > cap) continue;
        const want = Math.min(pr * advSh * (0.6 + 0.8 * r()), sh, b / P); if (want <= 0) continue;
        cost += want * P; got += want; b -= want * P; sh -= want; if (k < 120) buys.push([P, want]);
        if (b <= budget * 1e-6 || sh <= 0.5) { done = t; break; }
      }
      const totS = boughtPrev + got, totC = spentPrev + cost; if (totS > 0) avgs.push(totC / totS);
      used.push(Math.min(100, (totC / budget) * 100)); if (done >= 0) { completed++; dayDone.push(done); }
    }
    return { p0, sigma, days, end, budget, maxSh, remB, remS, boughtPrev, spentPrev, pace, cfg: C, n: N,
      avg: { p10: q(avgs, 0.1), p25: q(avgs, 0.25), p50: q(avgs, 0.5), p75: q(avgs, 0.75), p90: q(avgs, 0.9) },
      done: { prob: completed / N, p50: q(dayDone, 0.5), p25: q(dayDone, 0.25), p75: q(dayDone, 0.75) }, usedP50: q(used, 0.5),
      zone: buys.length ? [wq(buys, 0.25), wq(buys, 0.75)] : null, reqPace: days > 0 ? remS / days / advSh : NaN };
  };
  const memo = new Map();
  CAA.buyback = (it, s) => {
    const C0 = CAA.cfg(); const mk = [it.id, s.f.close, C0.lo, C0.base, C0.hi, it.prog && it.prog.bought, R.CA.sym.has(s.sym)].join('|'); if (memo.has(mk)) return memo.get(mk); if (memo.size > 200) memo.clear();
    const res = CAA.buyback0(it, s); memo.set(mk, res); return res;
  };
  CAA.buyback0 = (it, s) => {
    const sim = CAA.buybackSim(it, s); if (!sim) return null; const d = it.d || {}; const f = s.f, fu = s.fund || {}; const p0 = f.close;
    const sharesOut = fu.sharesOut > 0 ? fu.sharesOut : f.marketCap > 0 ? f.marketCap / p0 : NaN;
    const flt = R.O && R.O.cur && R.O.stock(s.sym) ? R.O.stock(s.sym).floatEst : NaN; const floatSh = fu.floatShares > 0 ? fu.floatShares : ok(flt) && ok(sharesOut) ? (sharesOut * flt) / 100 : NaN;
    const out = { sim };
    out.daysVol = sim.remB / f.avgValue20; out.pctFloat = ok(floatSh) ? (Math.min(sim.remS, sim.remB / p0) / floatSh) * 100 : NaN; out.pctOut = ok(sharesOut) ? (sim.maxSh / sharesOut) * 100 : NaN;
    out.eps = ok(out.pctOut) ? (1 / (1 - out.pctOut / 100) - 1) * 100 : NaN;
    out.cashPct = fu.cash > 0 ? (sim.budget / fu.cash) * 100 : NaN;
    out.implied = d.budget > 0 && d.shares > 0 ? d.budget / d.shares : NaN;
    out.val = { pb: f.pb, pe: f.pe, peVs: f.peVsSector };
    // track record: earlier buyback programmes of the same issuer (from the 6-month history) and how the price behaved since
    const hist = [...(R.CA.sym.get(s.sym) || [])].filter((x) => x.type === 'buyback' && x.sub !== 'report' && x.id !== it.id && x.t < it.t);
    out.track = hist.map((h) => { const i0 = s.cd.t.findIndex((t) => t * 1000 >= h.t); return i0 >= 0 ? { t: h.t, ret: (p0 / s.cd.c[i0] - 1) * 100 } : null; }).filter(Boolean);
    // since this announcement
    { const i0 = s.cd.t.findIndex((t) => t * 1000 >= it.t - DAY); if (i0 >= 0) out.since = (p0 / s.cd.c[i0] - 1) * 100; }
    out.verdict = CAA.buybackVerdict(it, s, out); return out;
  };
  const rp = (x) => A.fmtRp(x), px = (x) => A.fmt(Math.round(x)), n1 = (x) => (Math.round(x * 10) / 10).toString().replace('.', ',').replace('-', '−');
  CAA.buybackVerdict = (it, s, a) => {
    const S = a.sim, d = it.d || {}; const L = [];
    const strength = a.daysVol >= 15 ? 'besar' : a.daysVol >= 5 ? 'cukup terasa' : 'kecil';
    L.push(`Sisa dana ${rp(S.remB)} setara ±${n1(a.daysVol)} hari nilai transaksi rata-rata — dorongan belinya ${strength}${ok(a.pctFloat) ? ` (±${n1(a.pctFloat)}% free float)` : ''}.`);
    if (S.days <= 0) L.push('Periode buyback sudah berakhir.');
    else L.push(`Dengan asumsi kecepatan beli ${S.pace ? `sesuai laporan (±${Math.round(S.pace * 100)}% volume harian)` : `${Math.round(S.cfg.lo * 100)}–${Math.round(S.cfg.hi * 100)}% volume harian`}, rata-rata beli akhir kemungkinan besar di ${px(S.avg.p25)}–${px(S.avg.p75)} (median ${px(S.avg.p50)}), dan ${S.done.prob >= 0.5 ? `program selesai dalam ±${Math.round(S.done.p50)} hari bursa (peluang ${Math.round(S.done.prob * 100)}%)` : `kemungkinan dana tidak habis sebelum periode berakhir (perkiraan terpakai ${Math.round(S.usedP50)}%)`}.`);
    if (S.zone && S.days > 0) L.push(`Pembelian paling terkonsentrasi di ${px(S.zone[0])}–${px(S.zone[1])}; selama harga di area ini ${ok(a.implied) ? `dan di bawah rata-rata implisit ${px(a.implied)}` : ''}, emiten berpotensi aktif menopang harga.`);
    if (d.maxPrice > 0 && S.p0 > d.maxPrice) L.push(`Harga sekarang di atas harga maksimal ${px(d.maxPrice)}, jadi emiten tidak bisa membeli sampai harga turun ke bawahnya.`);
    const cred = []; if (ok(a.cashPct)) cred.push(a.cashPct <= 30 ? `dana hanya ±${Math.round(a.cashPct)}% dari kas (kredibel)` : a.cashPct <= 70 ? `dana ±${Math.round(a.cashPct)}% dari kas` : `dana ±${Math.round(a.cashPct)}% dari kas — besar, bisa tidak dipakai penuh`);
    if (ok(a.val.pb)) cred.push(`P/B ${n1(a.val.pb)}x${ok(a.val.peVs) && a.val.peVs > 0 ? `, P/E ${a.val.peVs < 0.9 ? 'di bawah' : a.val.peVs > 1.1 ? 'di atas' : 'setara'} rata-rata sektor` : ''}`);
    if (cred.length) L.push('Kredibilitas: ' + cred.join('; ') + '.');
    if (ok(a.eps) && a.eps >= 0.3) L.push(`Jika saham hasil buyback tidak beredar lagi, laba per saham naik ±${n1(a.eps)}%.`);
    L.push('Ini proyeksi statistik, bukan kepastian — buyback bukan kewajiban dan bisa dihentikan kapan saja.');
    return L.join(' ');
  };

  // ---------------- rights issue ----------------
  CAA.rights = (it, s) => {
    const d = it.d || {}; const p0 = s.f.close; if (!(d.old > 0 && d.new > 0 && d.price > 0)) return null;
    const terp = (p0 * d.old + d.price * d.new) / (d.old + d.new); const hmetd = Math.max(0, terp - d.price); const dil = (d.new / (d.old + d.new)) * 100;
    const need = d.price * (d.new / d.old); // cash needed per old share to keep the stake
    const L = [`Harga teoretis setelah ex-HMETD ±${px(terp)} (${n1((terp / p0 - 1) * 100)}% dari harga sekarang), nilai teoretis 1 HMETD ±${px(hmetd)}.`,
      `Untuk mempertahankan porsi, pemegang perlu menebus ${n1(d.new / d.old)} saham baru per saham lama (±Rp${px(need)} per saham lama); yang tidak menebus terdilusi ${n1(dil)}%.`];
    if (d.standby) L.push('Ada pembeli siaga — sisa saham yang tidak ditebus akan diserap, mengurangi risiko gagal terkumpul.');
    if (d.controller) L.push('Pemegang pengendali menyatakan akan melaksanakan haknya — tanda dukungan.');
    if (d.use) L.push('Penggunaan dana: ' + d.use);
    L.push(d.price < p0 * 0.85 ? 'Diskon harga pelaksanaan besar: harga sering tertekan menjelang cum date karena pasar menyesuaikan ke harga teoretis.' : 'Diskon harga pelaksanaan kecil: tekanan ke harga biasanya terbatas.');
    return { terp, hmetd, dil, need, verdict: L.join(' ') };
  };

  // ---------------- dividend ----------------
  CAA.divHistory = async (sym) => {
    if (CAA.divCache.has(sym)) return CAA.divCache.get(sym); let ev = [];
    try {
      if (D.settings.provider === 'demo') { const s = E.getStock(sym); if (s) { const c = s.cd; for (let i = c.c.length - 250; i > 20; i -= 250) ev.push({ t: c.t[i], amount: Math.round(c.c[i - 1] * 0.03) }); } }
      else { const j = await D.get(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(sym + '.JK')}?range=5y&interval=1d&events=div`); const dv = j && j.chart && j.chart.result && j.chart.result[0] && j.chart.result[0].events && j.chart.result[0].events.dividends; if (dv) ev = Object.values(dv).map((x) => ({ t: x.date, amount: x.amount })); }
    } catch (e) { ev = []; }
    ev.sort((a, b) => a.t - b.t); CAA.divCache.set(sym, ev); return ev;
  };
  CAA.dividend = (it, s, hist) => {
    const d = it.d || {}; const p0 = s.f.close; const cd = s.cd; const out = { past: [] };
    for (const e of hist || []) { const i = cd.t.findIndex((t) => t >= e.t - 3600); if (i <= 0) continue; const prev = cd.c[i - 1]; const drop = ((cd.c[i] - prev) / prev) * 100; const dv = (e.amount / prev) * 100; let rec = null; for (let k = i; k < Math.min(cd.c.length, i + 60); k++) if (cd.c[k] >= prev) { rec = k - i; break; } out.past.push({ t: e.t, dv, drop, rec }); }
    const L = []; if (d.dps > 0) L.push(`Dividen Rp${A.fmt(d.dps)} per saham = yield ${n1((d.dps / p0) * 100)}% dari harga sekarang (sebelum pajak).`);
    if (out.past.length) { const avgRatio = out.past.reduce((a, x) => a + (x.dv > 0 ? -x.drop / x.dv : 0), 0) / out.past.length; const recs = out.past.filter((x) => x.rec !== null).map((x) => x.rec);
      out.ratio = avgRatio; out.recMed = recs.length ? q(recs, 0.5) : null; out.recRate = recs.length / out.past.length;
      L.push(`Di ${out.past.length} tanggal ex sebelumnya, harga rata-rata turun ±${Math.round(avgRatio * 100)}% dari nilai dividennya${recs.length ? `; harga kembali ke level sebelum ex dalam median ${Math.round(out.recMed)} hari bursa (${Math.round(out.recRate * 100)}% kasus pulih dalam 60 hari)` : '; harga belum pernah pulih dalam 60 hari'}.`); }
    if (d.cum) { const daysTo = CAA.tradingDays(Date.now(), isoToT(d.cum)); L.push(daysTo > 0 ? `Tanggal cum ${daysTo} hari bursa lagi — beli paling lambat di tanggal itu agar berhak.` : 'Tanggal cum sudah lewat.'); }
    out.verdict = L.join(' '); return out;
  };

  // ---------------- tender offer ----------------
  CAA.tender = (it, s) => {
    const d = it.d || {}; const p0 = s.f.close; if (!(d.price > 0)) return null; const spread = (d.price / p0 - 1) * 100;
    const days = d.to ? Math.max(1, (isoToT(d.to) - Date.now()) / DAY + 14) : 45; const ann = spread * (365 / days);
    const L = [`Selisih ${n1(spread)}% dalam ±${Math.round(days)} hari sampai pembayaran ≈ ${n1(ann)}% per tahun.`];
    L.push(/sukarela/i.test(d.kind || '') ? 'Tender sukarela bisa dijatah (prorata) bila yang menjual melebihi target, dan bisa batal bila syaratnya tidak terpenuhi.' : 'Tender wajib (MTO) mengikuti perubahan pengendali; setelah periode berakhir harga sering turun kembali bila tidak ada katalis lain.');
    if (spread < 0) L.push('Harga pasar sudah di atas harga penawaran — pasar memperkirakan ada penawaran lebih tinggi atau tidak tertarik menjual.');
    return { spread, ann, days, verdict: L.join(' ') };
  };

  // ---------------- insider ----------------
  CAA.insider = (it, s) => {
    const list = [...(R.CA.items || []), ...(R.CA.sym.get(s.sym) || [])].filter((x, i, a) => x.type === 'insider' && x.code === s.sym && a.findIndex((y) => y.id === x.id) === i && Math.abs(x.t - it.t) <= 30 * DAY);
    const buys = list.filter((x) => x.d && x.d.side === 'Beli'), sells = list.filter((x) => x.d && x.d.side === 'Jual');
    const val = (x) => (x.d.qty || 0) * (x.d.price || s.f.close); const net = buys.reduce((a, x) => a + val(x), 0) - sells.reduce((a, x) => a + val(x), 0);
    const who = new Set(buys.map((x) => x.d.who || x.id)); const cluster = who.size >= 2;
    const d = it.d || {}; const L = [];
    if (d.side && d.price) L.push(`${d.side === 'Beli' ? 'Membeli' : 'Menjual'} di ${px(d.price)} — harga sekarang ${n1((s.f.close / d.price - 1) * 100)}% dari harga transaksi itu.`);
    L.push(`Dalam 30 hari: ${buys.length} transaksi beli dan ${sells.length} jual oleh orang dalam (bersih ${rp(net)}).`);
    if (cluster) L.push('Beberapa orang dalam membeli dalam waktu berdekatan — sinyal keyakinan yang lebih kuat daripada pembelian tunggal.');
    return { buys: buys.length, sells: sells.length, net, cluster, verdict: L.join(' ') };
  };

  CAA.analyze = (it, s, extra) => {
    if (!s || !it.d) return null;
    try { return it.type === 'buyback' && it.sub !== 'report' ? CAA.buyback(it, s) : it.type === 'rights' ? CAA.rights(it, s) : it.type === 'div' ? CAA.dividend(it, s, extra) : it.type === 'tender' ? CAA.tender(it, s) : it.type === 'insider' ? CAA.insider(it, s) : null; }
    catch (e) { return null; }
  };
  R.CAA = CAA;
})((typeof window !== 'undefined' ? window : global).RB);
