/* Yoo Haw — explainable scoring, setup classification, trade plan, bandar evidence, narrative. */
(function (R) {
  const I = R.I; const A = {};
  const clamp = (x, a = 0, b = 100) => Math.max(a, Math.min(b, x));
  const ok = I.ok;

  // IDX price fractions (fraksi harga)
  A.tick = (p) => (p < 200 ? 1 : p < 500 ? 2 : p < 2000 ? 5 : p < 5000 ? 10 : 25);
  A.rt = (p, mode) => { if (!ok(p)) return p; const t = A.tick(p); return mode === 'down' ? Math.floor(p / t) * t : mode === 'up' ? Math.ceil(p / t) * t : Math.round(p / t) * t; };

  // ---------- BEI trading rules ----------
  // Auto rejection (Kep-00136/BEI/09-2026): transition 28 Sep–31 Dec 2026 = ARB 15% asymmetric; from 1 Jan 2027 symmetric.
  A.arPct = (p, when) => {
    const t = when || Date.now(); const sym = t >= Date.UTC(2027, 0, 1) - 7 * 3600e3;
    const ara = p <= 200 ? 0.35 : p <= 5000 ? 0.25 : 0.2; const arb = sym ? ara : 0.15; return { ara, arb };
  };
  A.limits = (prev, when) => {
    if (!ok(prev)) return null;
    if (prev <= 10) return { ara: prev + 1, arb: Math.max(1, prev - 1), araPct: (1 / prev) * 100, arbPct: (Math.min(1, prev - 1) / prev) * 100, nominal: true };
    const { ara, arb } = A.arPct(prev, when);
    const hi = A.rt(prev * (1 + ara), 'down'), lo = Math.max(1, A.rt(prev * (1 - arb), 'up'));
    return { ara: hi, arb: lo, araPct: ara * 100, arbPct: arb * 100 };
  };
  A.fees = () => { const s = (R.D && R.D.settings) || {}; return { buy: (s.feeBuy ?? 0.15) / 100, sell: (s.feeSell ?? 0.25) / 100 }; };
  A.rrNet = (entry, stop, target) => { const { buy, sell } = A.fees(); const cost = entry * (1 + buy), risk = cost - stop * (1 - sell); return risk > 0 ? (target * (1 - sell) - cost) / risk : NaN; };
  A.ppk = (sym) => { const s = (R.D && R.D.settings) || {}; return (s.ppkList || '').toUpperCase().split(/[\s,]+/).includes(sym); };

  // ---------- Fundamentals (normalized from provider) ----------
  A.qualityScore = (fu, sector) => {
    if (!fu) return NaN; let s = 0, m = 0; const bank = sector === 'Keuangan';
    const add = (val, pts, max) => { if (ok(val)) { s += pts; m += max; } };
    add(fu.roe, fu.roe >= 15 ? 25 : fu.roe >= 10 ? 15 : fu.roe >= 5 ? 6 : 0, 25);
    add(fu.netMargin, fu.netMargin >= 15 ? 15 : fu.netMargin >= 8 ? 10 : fu.netMargin > 0 ? 5 : 0, 15);
    if (!bank) add(fu.der, fu.der <= 50 ? 15 : fu.der <= 100 ? 10 : fu.der <= 200 ? 4 : 0, 15);
    add(fu.revGrowth, fu.revGrowth >= 10 ? 15 : fu.revGrowth >= 0 ? 8 : 0, 15);
    add(fu.epsGrowth, fu.epsGrowth >= 10 ? 15 : fu.epsGrowth >= 0 ? 8 : 0, 15);
    if (!bank) add(fu.fcf, fu.fcf > 0 ? 15 : 0, 15);
    return m >= 40 ? Math.round((s / m) * 100) : NaN;
  };

  // ---------- Bandar / big-money evidence ----------
  A.bandar = (cd, f, ff) => {
    const { o, h, l, c, v } = cd; const n = c.length, last = n - 1; const vA = I.sma(v, 20);
    const ev = []; const push = (key, side, w, txt, present, available = true) => ev.push({ key, side, w, txt, present, available });
    // repeated abnormal volume
    let days = 0, clvSum = 0; for (let i = n - 15; i < n; i++) if (vA[i - 1] && v[i] >= 1.8 * vA[i - 1]) { days++; clvSum += h[i] === l[i] ? 0 : ((c[i] - l[i]) - (h[i] - c[i])) / (h[i] - l[i]); }
    const hi15 = Math.max(...h.slice(-15)), lo15 = Math.min(...l.slice(-15)); const rp = ((hi15 - lo15) / lo15) * 100;
    const tight = rp <= Math.max(12, 4 * (f.atrPct || 3));
    f.abnVolDays = days;
    push('abnVol', 1, 20, `Volume abnormal berulang ${days} hari (15 bar) dengan close cenderung di atas, harga tertahan range ${rp.toFixed(1)}%`, days >= 3 && tight && clvSum > 0);
    push('abnVolD', -1, 20, `Volume abnormal berulang ${days} hari dengan close cenderung di bawah (tekanan jual)`, days >= 3 && clvSum < 0);
    push('udv', 1, 15, `Up-volume ${f.upDownVol.toFixed(2)}x down-volume (20 bar)`, f.upDownVol >= 1.4);
    push('udvD', -1, 15, `Down-volume dominan (rasio ${f.upDownVol.toFixed(2)}x)`, f.upDownVol <= 0.7);
    const obv = I.obv(c, v).map((x) => x + 1e13); const so = I.slope(obv, 20), sp = I.slope(c, 20);
    push('obvDiv', 1, 15, 'OBV naik saat harga relatif datar (indikasi akumulasi senyap)', so > 0 && Math.abs(sp) < 0.15);
    push('obvDivD', -1, 15, 'OBV turun saat harga datar (indikasi distribusi)', so < 0 && Math.abs(sp) < 0.15);
    push('cmf', 1, 10, `CMF 20 positif kuat (${f.cmf.toFixed(2)})`, f.cmf >= 0.1);
    push('cmfD', -1, 10, `CMF 20 negatif (${f.cmf.toFixed(2)})`, f.cmf <= -0.1);
    const adl = I.adl(h, l, c, v); const adHi = adl[last] >= Math.max(...adl.slice(-20)); const pxHi = c[last] >= Math.max(...c.slice(-20));
    push('adLead', 1, 10, 'A/D line mencetak high baru mendahului harga', adHi && !pxHi);
    // absorption: heavy volume, small body
    let absB = false, absS = false;
    for (let i = n - 10; i < n; i++) {
      if (!vA[i - 1] || v[i] < 1.8 * vA[i - 1]) continue; const rng = h[i] - l[i]; if (!rng) continue;
      const body = Math.abs(c[i] - o[i]) / rng, loc = (c[i] - l[i]) / rng;
      if (body <= 0.35 && loc >= 0.55 && f.distSupport <= 6) absB = true;
      if (body <= 0.35 && loc <= 0.45 && f.distResist <= 6) absS = true;
    }
    f.absorption = absB;
    push('absorb', 1, 15, 'Absorption: volume besar dengan body kecil di dekat support (supply diserap)', absB);
    push('absorbD', -1, 15, 'Volume besar dengan body kecil di dekat resistance (supply keluar)', absS);
    const prior = ev.some((e) => e.side === 1 && e.present && (e.key === 'abnVol' || e.key === 'obvDiv' || e.key === 'absorb'));
    push('boAccum', 1, 15, 'Breakout setelah fase akumulasi', f.breakout && (prior || f.baseFormation));
    const hasFF = ff && ok(ff.net5d);
    push('foreign', 1, 15, hasFF ? `Foreign net buy 5 hari ${fmtRp(ff.net5d)} (${ff.streak} hari beruntun)` : 'Foreign flow', hasFF && ff.net5d > 0 && ff.streak >= 2, hasFF);
    push('foreignD', -1, 15, hasFF ? `Foreign net sell 5 hari ${fmtRp(ff.net5d)}` : 'Foreign flow', hasFF && ff.net5d < 0, hasFF);
    push('broker', 0, 0, 'Data broker summary / transaksi besar per broker', false, false);
    const scoreSide = (side) => { const av = ev.filter((e) => e.side === side && e.available); const tot = av.reduce((s, e) => s + e.w, 0); const got = av.filter((e) => e.present).reduce((s, e) => s + e.w, 0); return tot ? Math.round((got / tot) * 100) : 0; };
    const acc = scoreSide(1), dis = scoreSide(-1);
    f.accumScore = acc; f.distScore = dis;
    const net = acc - dis; const conf = Math.max(acc, dis);
    const label = conf < 30 ? 'Tidak ada bukti kuat' : net > 15 ? 'Indikasi akumulasi' : net < -15 ? 'Indikasi distribusi' : 'Sinyal campuran';
    const confLabel = conf >= 60 ? 'Tinggi' : conf >= 35 ? 'Sedang' : 'Rendah';
    return { acc, dis, label, confLabel, evidence: ev };
  };

  // ---------- Setup classification + trade plan ----------
  A.plan = (cd, F) => {
    const { f, st } = F; const c = f.close, a = f.atr; const lv = st.levels;
    let type = 'Netral — tunggu konfirmasi', entryLo = c - 0.3 * a, entryHi = c, why = [], bias = 0;
    const res0 = lv.resistances[0];
    if (f.lhll && f.emaStackBear && !f.chochBull && !f.sweepReversal) { type = 'Downtrend — hindari posisi beli'; bias = -1; }
    else if (f.breakout && st.brk) { type = 'Breakout + Volume'; entryLo = st.brk.level; entryHi = Math.max(c, st.brk.level + 0.5 * a); why.push(`Close menembus resistance ${fmt(st.brk.level)} dengan RVOL ${st.brk.rvol.toFixed(1)}x`); bias = 1; }
    else if (f.retestHold && st.rt) { type = 'Breakout Retest'; entryLo = st.rt.level; entryHi = st.rt.level + 0.5 * a; why.push(`Breakout ${fmt(st.rt.level)} sudah di-retest dan bertahan`); bias = 1; }
    else if (f.sweepReversal) { const sw = [...st.sweeps].reverse().find((x) => x.dir === 1); type = 'Liquidity Sweep Reversal'; entryLo = sw ? sw.level : c - 0.5 * a; entryHi = c; why.push(`Likuiditas di bawah swing low ${fmt(entryLo)} disapu lalu harga kembali naik`); bias = 1; }
    else if ((f.fvgBullTap || (f.fvgBullOpen && f.distFvgBull <= 2)) && st.nearBull && f.swingTrend >= 0) { type = 'FVG Setup'; entryLo = st.nearBull.lo; entryHi = st.nearBull.hi; why.push(`Harga di/dekat FVG bullish ${fmt(st.nearBull.lo)}–${fmt(st.nearBull.hi)}`); bias = 1; }
    else if (f.obBullNear && f.swingTrend >= 0) { const ob = st.obs.filter((b) => b.dir === 1 && b.status !== 'breaker').pop(); type = 'Order Block Retest'; if (ob) { entryLo = ob.lo; entryHi = ob.hi; why.push(`Retest order block bullish ${fmt(ob.lo)}–${fmt(ob.hi)}`); } bias = 1; }
    else if (f.emaStackBull && Math.abs(f.distEma20) <= 2.5) { type = 'Pullback ke EMA 20'; entryLo = f.ema20 - 0.3 * a; entryHi = f.ema20 + 0.3 * a; why.push('Uptrend bertingkat, harga kembali ke EMA 20'); bias = 1; }
    else if ((f.compression || f.baseFormation || f.consolidation) && f.distResist <= 5 && f.aboveEma50) { type = 'Early Breakout (base/kompresi)'; entryLo = c - 0.3 * a; entryHi = res0 ? res0.price + 0.2 * a : c + 0.3 * a; why.push(`Konsolidasi rapat ${f.distResist.toFixed(1)}% di bawah resistance`); bias = 1; }
    else if (f.rsi <= 38 && (f.rsiDivBull || f.stochCrossUp || f.sweepBull || f.macdDivBull)) { type = 'Oversold Reversal'; entryLo = c - 0.5 * a; entryHi = c; why.push(`RSI ${f.rsi.toFixed(0)} dengan sinyal pembalikan`); bias = 1; }
    else if ((f.accumScore || 0) >= 60) { type = 'Akumulasi'; entryLo = c - 0.6 * a; entryHi = c; why.push('Bukti akumulasi harga–volume kuat'); bias = 1; }
    else if (f.emaStackBull && (f.rsRating || 0) >= 80) { type = 'Momentum Leader'; entryLo = c - 0.6 * a; entryHi = c; why.push(`RS Rating ${f.rsRating}`); bias = 1; }
    else if (f.emaStackBull) { type = 'Trend Following'; entryLo = Math.max(f.ema20, c - a); entryHi = c; bias = 1; }
    if (entryLo > entryHi) [entryLo, entryHi] = [entryHi, entryLo];
    entryLo = A.rt(entryLo, 'down'); entryHi = A.rt(entryHi, 'up'); const mid = (entryLo + entryHi) / 2;
    // invalidation: structure first
    const swingLow = [...st.piv].reverse().find((p) => p.type === 'L' && p.price < entryLo && p.conf <= cd.c.length - 1);
    let inv = swingLow && entryLo - swingLow.price <= 3 * a ? swingLow.price - 0.15 * a : entryLo - 1.5 * a;
    if (type === 'Liquidity Sweep Reversal') { const lowest = Math.min(...cd.l.slice(-5)); inv = lowest - 0.15 * a; }
    if (type === 'FVG Setup' || type === 'Order Block Retest') inv = Math.min(inv, entryLo - 0.25 * a);
    inv = A.rt(inv, 'down'); const risk = Math.max(mid - inv, A.tick(mid));
    const resAbove = lv.resistances.filter((r) => r.price > mid + 0.8 * a).map((r) => r.price);
    const tg = []; tg.push(resAbove[0] || mid + 2 * risk); tg.push(resAbove[1] || Math.max(tg[0] + risk, mid + 3 * risk));
    const t3 = f.hi52 && f.hi52 > tg[1] * 1.02 ? f.hi52 : tg[1] + 1.5 * risk; tg.push(t3);
    const targets = tg.map((x) => A.rt(x, 'down')).filter((x, i, arr) => x > entryHi && arr.indexOf(x) === i);
    const rr = targets[0] ? (targets[0] - mid) / risk : NaN; f.rr = ok(rr) ? Math.round(rr * 10) / 10 : NaN;
    const sup = lv.supports.slice(0, 2).map((x) => A.rt(x.price)); const resi = lv.resistances.slice(0, 2).map((x) => A.rt(x.price));
    const rrNet = targets[0] ? A.rrNet(mid, inv, targets[0]) : NaN; f.rrNet = ok(rrNet) ? Math.round(rrNet * 10) / 10 : NaN;
    const lim = A.limits(c); const notes = [];
    if (lim && inv < lim.arb) notes.push(`Invalidasi di bawah ARB besok (${fmt(lim.arb)}) — jika gap turun, keluar bisa butuh >1 hari`);
    if (lim && targets[0] > lim.ara) notes.push(`Target 1 di atas ARA besok (${fmt(lim.ara)}) — butuh lebih dari 1 hari`);
    const status = bias < 0 ? 'Hindari' : c > entryHi ? 'Tunggu pullback ke area entry' : c < entryLo ? 'Tunggu konfirmasi naik' : 'Harga di area entry';
    return { type, bias, status, entry: [entryLo, entryHi], invalid: inv, targets, rr: f.rr, rrNet: f.rrNet, limits: lim, notes, support: sup, resistance: resi, riskPct: ((mid - inv) / mid) * 100, why };
  };

  // ---------- Explainable setup score ----------
  A.score = (f, plan, extra = {}) => {
    const comp = []; const C = (key, label, w, score, reasons) => comp.push({ key, label, w, score: ok(score) ? Math.round(clamp(score)) : NaN, reasons });
    { const r = []; if (f.emaStackBull) r.push(['EMA 20 > 50 > 200, harga di atasnya', 1]); else if (f.emaStackBear) r.push(['EMA bertingkat turun', 0]); else if (f.aboveEma50) r.push(['Di atas EMA 50', 1]); else r.push(['Di bawah EMA 50', 0]);
      if (f.adx >= 25) r.push([`ADX ${f.adx.toFixed(0)} — tren kuat`, f.diBull ? 1 : 0]); if (f.sma200Rising) r.push(['SMA 200 menanjak', 1]);
      C('trend', 'Tren', 15, f.trendStrength, r); }
    { const r = []; let s = ok(f.rsRating) ? f.rsRating : 50 + (f.rsIhsg3m || 0) * 2; if (ok(f.rsRating)) r.push([`RS Rating ${f.rsRating} dari 99`, f.rsRating >= 70 ? 1 : 0]);
      if (ok(f.rsIhsg3m)) r.push([`${f.rsIhsg3m >= 0 ? 'Mengungguli' : 'Tertinggal dari'} IHSG ${Math.abs(f.rsIhsg3m).toFixed(1)}% (3 bln)`, f.rsIhsg3m >= 0 ? 1 : 0]);
      if (f.sectorLeader) { r.push(['Pemimpin di sektornya', 1]); s += 5; } C('rs', 'Relative strength', 12, s, r); }
    { const r = []; let s = f.rsi >= 50 && f.rsi <= 70 ? 75 : f.rsi > 70 && f.rsi <= 80 ? 60 : f.rsi > 80 ? 40 : f.rsi >= 40 ? 45 : 25;
      r.push([`RSI ${f.rsi.toFixed(0)}${f.rsi > 75 ? ' (jenuh beli)' : ''}`, f.rsi >= 50 && f.rsi <= 75 ? 1 : 0]);
      if (f.macdHist > 0) { s += 12; r.push(['Histogram MACD positif', 1]); } if (f.macdCrossUp) { s += 8; r.push(['MACD golden cross baru', 1]); }
      if (f.momAccelUp) { s += 8; r.push(['Momentum berakselerasi', 1]); } C('mom', 'Momentum', 12, s, r); }
    { const r = []; let s = 15; if (f.rvol >= 1.5 && f.bullCandle) { s += 25; r.push([`RVOL ${f.rvol.toFixed(1)}x pada candle naik`, 1]); } else if (f.rvol >= 1.5) r.push([`RVOL ${f.rvol.toFixed(1)}x pada candle turun`, 0]);
      if (f.obvRising) { s += 20; r.push(['OBV menanjak', 1]); } if (f.cmf > 0.05) { s += 20; r.push([`CMF ${f.cmf.toFixed(2)}`, 1]); } else if (f.cmf < -0.05) r.push([`CMF negatif ${f.cmf.toFixed(2)}`, 0]);
      if (f.upDownVol >= 1.2) { s += 20; r.push([`Up/down volume ${f.upDownVol.toFixed(2)}x`, 1]); } C('vol', 'Volume', 12, s, r); }
    { const r = []; let s = 20; if (f.hhhl) { s += 35; r.push(['Struktur HH + HL', 1]); } else if (f.lhll) { s -= 10; r.push(['Struktur LH + LL', 0]); }
      if (f.bosBull || f.chochBull) { s += 25; r.push([f.chochBull ? 'CHoCH bullish baru' : 'BOS bullish baru', 1]); } if (f.chochBear || f.bosBear) { s -= 20; r.push(['Ada break struktur bearish', 0]); }
      if (f.breakout || f.retestHold) { s += 20; r.push([f.retestHold ? 'Breakout + retest bertahan' : 'Breakout resistance', 1]); } C('struct', 'Struktur pasar', 12, s, r); }
    { const r = []; let s = 35; if (f.fvgBullTap) { s += 20; r.push(['Mitigasi FVG bullish', 1]); } if (f.obBullNear) { s += 15; r.push(['Di zona order block bullish', 1]); }
      if (f.sweepReversal) { s += 25; r.push(['Sweep likuiditas + reversal', 1]); } if (f.nearSupport) { s += 10; r.push(['Dekat support', 1]); }
      if (f.rsiDivBear || f.macdDivBear) { s -= 20; r.push(['Bearish divergence', 0]); } if (f.nearResist && !f.breakout) { s -= 10; r.push(['Mepet resistance', 0]); }
      if (f.pdPos > 0.9) { s -= 10; r.push(['Di zona premium atas', 0]); } C('pa', 'Price action / SMC', 10, s, r); }
    if (ok(f.qualityScore)) C('fund', 'Fundamental', 10, f.qualityScore, [[`Skor kualitas ${f.qualityScore}`, f.qualityScore >= 60 ? 1 : 0], ...(ok(f.roe) ? [[`ROE ${f.roe.toFixed(1)}%`, f.roe >= 12 ? 1 : 0]] : [])]);
    if (extra.news && extra.news.count) C('news', 'Katalis / berita', 5, 50 + extra.news.sent * 12, [[`${extra.news.count} berita terbaru, sentimen ${extra.news.sent > 0 ? 'positif' : extra.news.sent < 0 ? 'negatif' : 'netral'}`, extra.news.sent >= 0 ? 1 : 0]]);
    { const v = f.avgValue20; const s = v >= 2e10 ? 100 : v >= 5e9 ? 80 : v >= 1e9 ? 55 : v >= 3e8 ? 30 : 10; C('liq', 'Likuiditas', 6, s, [[`Nilai transaksi rata-rata ${fmtRp(v)}/hari`, v >= 1e9 ? 1 : 0]]); }
    if (plan && plan.bias > 0 && ok(plan.rrNet)) { const q = plan.rrNet; const s = q >= 3 ? 100 : q >= 2 ? 80 : q >= 1.5 ? 60 : q >= 1 ? 40 : 15; C('rr', 'Risk/reward', 6, s, [[`R/R bersih biaya ke target 1: ${q}x`, q >= 1.5 ? 1 : 0]]); }
    else if (plan && plan.bias < 0) C('rr', 'Risk/reward', 6, 10, [['Tidak ada setup beli yang valid', 0]]);
    if (ok(f.regimeScore)) C('regime', 'Kondisi pasar', 8, f.regimeScore, [[`Pasar ${f.regimeScore >= 60 ? 'risk-on' : f.regimeScore >= 40 ? 'netral' : 'risk-off'} (${f.regimeScore}/100)`, f.regimeScore >= 50 ? 1 : 0]]);
    if (f.ppk) C('ppk', 'Papan pemantauan', 6, 5, [['Saham di Papan Pemantauan Khusus (full call auction)', 0]]);
    const used = comp.filter((x) => ok(x.score)); const tw = used.reduce((s, x) => s + x.w, 0);
    const total = Math.round(used.reduce((s, x) => s + x.score * x.w, 0) / tw);
    const grade = total >= 75 ? 'Kuat' : total >= 60 ? 'Layak dipantau' : total >= 45 ? 'Netral' : 'Lemah';
    return { total, grade, comp };
  };

  // ---------- Narrative summary (rule-based "AI" explanation) ----------
  A.summary = (sym, F, plan, bd, fu) => {
    const f = F.f, st = F.st; const s = [];
    const tr = f.hhhl ? 'dalam uptrend (higher high & higher low)' : f.lhll ? 'dalam downtrend (lower high & lower low)' : 'bergerak sideways/transisi';
    s.push(`${sym} saat ini ${tr}${f.emaStackBull ? ', dengan EMA 20/50/200 tersusun naik' : f.aboveEma200 === false ? ', di bawah EMA 200' : ''}.`);
    if (st.brk) s.push(`Baru menembus resistance ${fmt(st.brk.level)} dengan relative volume ${st.brk.rvol.toFixed(1)}x.`);
    if (st.rt) s.push(`Breakout di ${fmt(st.rt.level)} sudah di-retest dan harga bertahan di atasnya.`);
    const lastEv = st.ev[st.ev.length - 1]; if (lastEv && F.f && cdLen(F) - lastEv.i <= 10) s.push(`${lastEv.type} ${lastEv.dir > 0 ? 'bullish' : 'bearish'} terjadi ${cdLen(F) - 1 - lastEv.i} bar lalu di ${fmt(lastEv.level)}.`);
    if (f.sweepBull) s.push('Ada liquidity sweep di bawah swing low terakhir.');
    s.push(f.rsiDivBear || f.macdDivBear ? 'Terdeteksi bearish divergence — waspadai pelemahan momentum.' : f.rsiDivBull || f.macdDivBull ? 'Terdeteksi bullish divergence.' : 'Tidak ada divergence RSI/MACD yang terdeteksi.');
    if (st.nearBull) s.push(`FVG bullish terdekat ada di ${fmt(st.nearBull.lo)}–${fmt(st.nearBull.hi)} (${st.nearBull.status === 'open' ? 'belum tersentuh' : 'sudah tersentuh sebagian'}).`);
    s.push(`RSI ${f.rsi.toFixed(0)}, RVOL ${ok(f.rvol) ? f.rvol.toFixed(1) : '-'}x, ATR ${f.atrPct.toFixed(1)}% per bar.`);
    if (bd && bd.label !== 'Tidak ada bukti kuat') s.push(`Radar bandar: ${bd.label.toLowerCase()} (kepercayaan ${bd.confLabel.toLowerCase()}).`);
    if (fu && ok(fu.pe)) s.push(`Valuasi: P/E ${fu.pe.toFixed(1)}x, P/B ${ok(fu.pb) ? fu.pb.toFixed(2) : '-'}x${ok(fu.roe) ? `, ROE ${fu.roe.toFixed(1)}%` : ''}.`);
    if (plan.bias > 0) s.push(`Setup terdeteksi: ${plan.type}. Area entry ${fmt(plan.entry[0])}–${fmt(plan.entry[1])}, batal jika close di bawah ${fmt(plan.invalid)}, target pertama ${fmt(plan.targets[0])} (R/R ${plan.rr}x, bersih biaya ${plan.rrNet}x).`);
    else s.push(`Belum ada setup beli yang valid (${plan.type}).`);
    return s.join(' ');
  };
  const cdLen = (F) => F.n;

  A.invalidators = (f, plan, ff) => {
    const r = [`Close di bawah ${fmt(plan.invalid)} membatalkan setup`];
    if (f.rsiDivBear || f.macdDivBear) r.push('Bearish divergence aktif');
    if (f.nearResist && !f.breakout) r.push(`Resistance dekat (${f.distResist.toFixed(1)}% di atas)`);
    if (f.rsi > 75) r.push('RSI jenuh beli — rawan koreksi');
    if (f.pdPos > 0.9) r.push('Harga di zona premium — risiko kejar harga');
    if (f.avgValue20 < 1e9) r.push('Likuiditas tipis — spread & slippage besar');
    if (f.distScore >= 50) r.push('Ada bukti distribusi');
    if (f.fvgBearOpen) r.push('FVG bearish di atas harga bisa menahan kenaikan');
    if (ff && ff.net5d < 0) r.push('Foreign net sell 5 hari');
    if (f.gapUp) r.push('Gap up bisa ditutup (gap fill)');
    if (ok(f.regimeScore) && f.regimeScore < 40) r.push('Kondisi pasar risk-off — breakout lebih sering gagal');
    if (f.ppk) r.push('Papan Pemantauan Khusus — diperdagangkan full call auction');
    for (const n of plan.notes || []) r.push(n);
    return r;
  };

  function fmt(x) { return ok(x) ? Math.round(x).toLocaleString('id-ID') : '-'; }
  function fmtRp(x) { if (!ok(x)) return '-'; const a = Math.abs(x), s = x < 0 ? '−' : ''; return a >= 1e12 ? `${s}Rp${(a / 1e12).toFixed(2)} T` : a >= 1e9 ? `${s}Rp${(a / 1e9).toFixed(1)} M` : a >= 1e6 ? `${s}Rp${(a / 1e6).toFixed(0)} jt` : `${s}Rp${Math.round(a)}`; }
  A.fmt = fmt; A.fmtRp = fmtRp;
  R.A = A;
})((typeof window !== 'undefined' ? window : global).RB);
