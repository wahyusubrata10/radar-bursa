/* Yoo Haw — scan engine, screener (AND/OR/NOT, multi-timeframe), presets, daily picks, live radar. */
(function (R) {
  const { D, F, A, I, S } = R; const ok = I.ok;
  const E = { snap: null, scanning: false, tfCache: new Map() };

  // ---------------- Universe scan (daily) ----------------
  E.analyzeDaily = (row, ihsg, ff) => {
    const F0 = F.compute(row.cd, { daily: true, ihsg }); if (!F0) return null;
    return Object.assign(row, { F: F0, f: F0.f, ff: ff ? ff[row.sym] : null });
  };
  E.rescore = () => { if (E.snap) for (const x of E.snap.stocks.values()) E.finish(x); };
  E.finish = (st) => {
    const f = st.f; const ffd = st.ff; f.ppk = A.ppk(st.sym);
    if (ffd) { f.fNet1d = ffd.net1d; f.fNet5d = ffd.net5d; f.fStreak = ffd.streak; }
    st.bandar = A.bandar(st.cd, f, ffd); st.plan = A.plan(st.cd, st.F); st.scoreObj = A.score(f, st.plan, { news: st.news }); f.score = st.scoreObj.total;
    return st;
  };
  E.scan = async ({ force = false, onProg } = {}) => {
    if (E.scanning) return E.snap; E.scanning = true;
    try {
      const uni = D.universe(); const ihsgR = await D.candles('^JKSE', 'D', force);
      const ff = await D.foreignFlow().catch(() => null);
      const old = E.raw ? new Map(E.raw.rows.map((r) => [r.sym, r])) : new Map();
      const rows = await D.pool(uni, async (u) => { const r = await D.candles(u.sym, 'D', force); const o = old.get(u.sym); return { sym: u.sym, sector: u.sector, meta: r.meta, cd: r.cd, fund: o ? o.fund : null, news: o ? o.news : null }; }, D.settings.concurrency, onProg);
      E.raw = { ihsgR, ff, uni, rows: rows.filter((x) => x && !x.error), failedSyms: uni.filter((u, i) => !rows[i] || rows[i].error).map((u) => u.sym) };
      for (const x of E.raw.rows) if (!x.fund) { const fu = await D.cacheGet(`f|${D.settings.provider}|${x.sym}`, 7 * 864e5); if (fu) x.fund = fu; }
      return E.build();
    } finally { E.scanning = false; }
  };
  // Pure computation from already-downloaded data (used after a scan and when detector parameters change)
  E.build = () => {
    const { ihsgR, ff, rows, failedSyms, uni } = E.raw; const ihsg = ihsgR.cd; E.tfCache.clear();
    const good = []; for (const r0 of rows) { const x = E.analyzeDaily({ sym: r0.sym, sector: r0.sector, meta: r0.meta, cd: r0.cd, raw: r0 }, ihsg, ff); if (x) good.push(x); }
    const sorted = good.map((x) => x.f.rsRaw).sort((a, b) => a - b);
    for (const x of good) { const rank = sorted.findIndex((v) => v >= x.f.rsRaw); x.f.rsRating = Math.max(1, Math.min(99, Math.round(((rank + 1) / sorted.length) * 99))); }
    const sec = {};
    for (const x of good) { const s = (sec[x.sector] = sec[x.sector] || { name: x.sector, n: 0, p1d: 0, p1m: 0, p3m: 0, members: [] }); s.n++; s.p1d += x.f.perf1d || 0; s.p1m += x.f.perf1m || 0; s.p3m += x.f.perf3m || 0; s.members.push(x); }
    const secs = Object.values(sec).map((s) => Object.assign(s, { p1d: s.p1d / s.n, p1m: s.p1m / s.n, p3m: s.p3m / s.n })).sort((a, b) => b.p1m - a.p1m);
    secs.forEach((s, i) => { s.rank = i + 1; s.members.sort((a, b) => b.f.rsRating - a.f.rsRating); s.members.forEach((m, k) => { m.f.sectorRank = i + 1; m.f.rsSector3m = (m.f.perf3m || 0) - s.p3m; m.f.sectorLeader = k < 3 && s.n >= 3; }); });
    const stocks = new Map(); for (const x of good) stocks.set(x.sym, x);
    E.snap = { asOf: E.snap && E.snap.asOf && E.building ? E.snap.asOf : Date.now(), stocks, failed: uni.length - good.length, failedSyms, ihsg: ihsgR, sectors: secs, ffState: D.ffState, status: ihsgR.meta.status };
    for (const x of good) { if (x.raw.fund) E.applyFund(x, x.raw.fund); x.news = x.raw.news; }
    E.sectorValuation(); if (R.M) R.M.computeRegime(); for (const x of good) E.finish(x);
    E.logPicks();
    return E.snap;
  };
  E.recompute = () => { if (!E.raw) return null; E.building = true; try { return E.build(); } finally { E.building = false; } };

  E.applyFund = (st, fu) => {
    st.fund = fu; if (st.raw) st.raw.fund = fu; const f = st.f;
    for (const k of ['revGrowth', 'epsGrowth', 'epsQGrowth', 'roe', 'roa', 'roic', 'grossMargin', 'opMargin', 'netMargin', 'der', 'currentRatio', 'ocf', 'fcf', 'fcfYield', 'marketCap', 'pe', 'pb', 'evEbitda', 'divYield', 'beta', 'earningsAccel']) f[k] = fu[k];
    f.qualityScore = A.qualityScore(fu, st.sector);
  };
  E.sectorValuation = () => {
    if (!E.snap) return; const med = (a) => { a = a.filter((x) => ok(x) && x > 0).sort((x, y) => x - y); return a.length >= 3 ? a[Math.floor(a.length / 2)] : NaN; };
    for (const s of E.snap.sectors) { const mp = med(s.members.map((m) => m.f.pe)), mb = med(s.members.map((m) => m.f.pb)); s.medPe = mp; s.medPb = mb; for (const m of s.members) { m.f.peVsSector = m.f.pe > 0 && mp ? m.f.pe / mp : NaN; m.f.pbVsSector = m.f.pb > 0 && mb ? m.f.pb / mb : NaN; } }
  };
  E.ensureFundamentals = async (syms, onProg) => {
    const list = syms.filter((s) => E.snap.stocks.get(s) && !E.snap.stocks.get(s).fund);
    await D.pool(list, async (s) => { const fu = await D.fundamentals(s); if (fu) E.applyFund(E.snap.stocks.get(s), fu); }, Math.max(2, D.settings.concurrency - 2), onProg);
    E.sectorValuation(); for (const s of syms) { const st = E.snap.stocks.get(s); if (st) E.finish(st); }
  };

  // features for any timeframe (memoized per scan)
  E.tfFeatures = async (sym, tf) => {
    const st = E.snap && E.snap.stocks.get(sym);
    if (tf === 'D' && st) return st.F;
    const k = sym + '|' + tf; if (E.tfCache.has(k)) return E.tfCache.get(k);
    const r = await D.candles(sym, tf); const Fx = F.compute(r.cd, { intraday: !['D', 'W'].includes(tf), daily: false }); if (Fx) Fx.meta = r.meta;
    E.tfCache.set(k, Fx); return Fx;
  };

  // ---------------- Screener ----------------
  const Sc = {};
  Sc.OPS = { '>': '>', '>=': '≥', '<': '<', '<=': '≤', between: 'antara', true: 'ya', false: 'tidak', crossAbove: 'cross ke atas', crossBelow: 'cross ke bawah' };
  // returns true / false / null (unknown — used for multi-timeframe prefiltering)
  Sc.eval = (node, get, getPrev) => {
    if (node.g) {
      let res;
      if (node.g === 'AND') { res = true; for (const ch of node.c) { const r = Sc.eval(ch, get, getPrev); if (r === false) { res = false; break; } if (r === null) res = null; } }
      else { res = false; for (const ch of node.c) { const r = Sc.eval(ch, get, getPrev); if (r === true) { res = true; break; } if (r === null) res = null; } }
      if (!node.c.length) res = true;
      return node.not ? (res === null ? null : !res) : res;
    }
    const tf = node.tf || 'D'; const lhs = get(node.f, tf); if (lhs === undefined) return null;
    if (node.op === 'true') return lhs === true; if (node.op === 'false') return lhs === false;
    if (!ok(lhs)) return false;
    let rhs = node.rf ? get(node.rf, tf) : node.v; if (rhs === undefined) return null; if (node.rf && ok(rhs)) rhs *= node.m || 1;
    if (!ok(rhs)) return false;
    switch (node.op) {
      case '>': return lhs > rhs; case '>=': return lhs >= rhs; case '<': return lhs < rhs; case '<=': return lhs <= rhs;
      case 'between': return lhs >= Math.min(node.v, node.v2) && lhs <= Math.max(node.v, node.v2);
      case 'crossAbove': case 'crossBelow': {
        const pl = getPrev(node.f, tf), pr = node.rf ? getPrev(node.rf, tf) * (node.m || 1) : node.v; if (pl === undefined || pr === undefined) return null; if (!ok(pl) || !ok(pr)) return false;
        return node.op === 'crossAbove' ? pl <= pr && lhs > rhs : pl >= pr && lhs < rhs;
      }
    }
    return false;
  };
  Sc.leaves = (node, out = []) => { if (node.g) node.c.forEach((c) => Sc.leaves(c, out)); else out.push(node); return out; };
  Sc.run = async (tree, { onProg, onStage, scope = 'all', minValue = 0 } = {}) => {
    if (!E.snap) throw new Error('Data pasar belum dimuat');
    const leaves = Sc.leaves(tree); const fields = new Set(leaves.flatMap((l) => [l.f, l.rf].filter(Boolean)));
    const needFund = [...fields].some((k) => F.byKey[k] && F.byKey[k].fund);
    let syms = [...E.snap.stocks.keys()];
    if (scope === 'watch') { const w = new Set(D.lsGet('rb.watch', [])); syms = syms.filter((x) => w.has(x)); }
    else if (scope !== 'all') syms = syms.filter((x) => E.snap.stocks.get(x).sector === scope);
    if (minValue > 0) syms = syms.filter((x) => E.snap.stocks.get(x).f.avgValue20 >= minValue);
    if (needFund) { onStage && onStage('Mengambil data fundamental…'); await E.ensureFundamentals(syms, onProg); }
    const tfs = new Set(leaves.map((l) => (F.byKey[l.f] && F.byKey[l.f].daily ? 'D' : l.tf || 'D')));
    const dailyGet = (st) => (k, tf) => (tf !== 'D' && !(F.byKey[k] && F.byKey[k].daily) ? undefined : st.f[k]);
    const dailyPrev = (st) => (k, tf) => (tf !== 'D' ? undefined : st.F.fp[k]);
    // 1) prefilter on daily (three-valued)
    let cands = syms.filter((s) => { const st = E.snap.stocks.get(s); return Sc.eval(tree, dailyGet(st), dailyPrev(st)) !== false; });
    // 2) other timeframes only for remaining candidates
    const others = [...tfs].filter((t) => t !== 'D');
    if (others.length) {
      onStage && onStage(`Memuat timeframe ${others.map((t) => D.TF[t]).join(', ')} untuk ${cands.length} kandidat…`);
      const mtf = {};
      await D.pool(cands, async (s) => { mtf[s] = {}; for (const t of others) mtf[s][t] = await E.tfFeatures(s, t); }, D.settings.concurrency, onProg);
      cands = cands.filter((s) => { const st = E.snap.stocks.get(s);
        const get = (k, tf) => { if (tf === 'D' || (F.byKey[k] && F.byKey[k].daily)) return st.f[k]; const x = mtf[s] && mtf[s][tf]; return x ? x.f[k] : NaN; };
        const getPrev = (k, tf) => { if (tf === 'D') return st.F.fp[k]; const x = mtf[s] && mtf[s][tf]; return x ? x.fp[k] : NaN; };
        return Sc.eval(tree, get, getPrev) === true; });
    } else cands = cands.filter((s) => { const st = E.snap.stocks.get(s); return Sc.eval(tree, dailyGet(st), dailyPrev(st)) === true; });
    return cands.map((s) => E.snap.stocks.get(s));
  };

  // ---------- presets ----------
  const L = (f, op, v, v2) => (typeof v === 'string' ? { f, op, rf: v, tf: 'D' } : { f, op, v, v2, tf: 'D' });
  const T = (f) => ({ f, op: 'true', tf: 'D' });
  const AND = (...c) => ({ g: 'AND', c }), OR = (...c) => ({ g: 'OR', c }), NOT = (x) => ({ g: 'AND', not: true, c: [x] });
  const LIQ = L('avgValue20', '>=', 1e9);
  Sc.PRESETS = [
    { id: 'momentum', name: 'Momentum Leader', desc: 'RS tinggi, tren bertingkat, RSI sehat', tree: AND(L('rsRating', '>=', 80), T('emaStackBull'), L('rsi', 'between', 55, 75), L('adx', '>=', 20), LIQ), sort: 'rsRating' },
    { id: 'bovol', name: 'Breakout + Volume', desc: 'Tembus resistance dengan RVOL ≥ 1.5x', tree: AND(T('breakout'), L('rvol', '>=', 1.5), T('aboveEma50'), LIQ), sort: 'rvol' },
    { id: 'early', name: 'Early Breakout', desc: 'Base/kompresi mepet resistance', tree: AND(OR(T('compression'), T('baseFormation'), T('consolidation')), L('distResist', '<=', 4), T('aboveEma50'), LIQ), sort: 'score' },
    { id: 'retest', name: 'Breakout Retest', desc: 'Breakout yang di-retest dan bertahan', tree: AND(T('retestHold'), T('aboveEma20'), LIQ), sort: 'score' },
    { id: 'fvg', name: 'FVG Setup', desc: 'Harga memitigasi FVG bullish dalam tren naik', tree: AND(OR(T('fvgBullTap'), AND(T('fvgBullOpen'), L('distFvgBull', '<=', 2))), L('swingTrend', '>=', 0), T('aboveEma50'), LIQ), sort: 'score' },
    { id: 'sweep', name: 'Liquidity Sweep Reversal', desc: 'Sweep swing low lalu berbalik', tree: AND(T('sweepReversal'), LIQ), sort: 'score' },
    { id: 'bosfvg', name: 'BOS + FVG', desc: 'Break of structure disertai FVG baru', tree: AND(T('bosFvg'), T('displacementBull'), LIQ), sort: 'score' },
    { id: 'smacc', name: 'Smart Money Accumulation', desc: 'Bukti akumulasi di area demand', tree: AND(L('accumScore', '>=', 50), OR(T('obBullNear'), T('fvgBullOpen'), T('nearSupport'), T('discount')), LIQ), sort: 'accumScore' },
    { id: 'stracc', name: 'Strong Accumulation', desc: 'Akumulasi kuat: CMF, up-volume, OBV', tree: AND(L('accumScore', '>=', 65), L('cmf', '>=', 0.1), L('upDownVol', '>=', 1.3), T('obvRising')), sort: 'accumScore' },
    { id: 'oversold', name: 'Oversold Reversal', desc: 'Jenuh jual dengan sinyal pembalikan', tree: AND(OR(L('rsi', '<=', 35), L('stochK', '<=', 20)), OR(T('rsiDivBull'), T('macdDivBull'), T('stochCrossUp'), T('sweepBull')), T('bullCandle'), LIQ), sort: 'score' },
    { id: 'trend', name: 'Trend Following', desc: 'Tren bertingkat, ADX kuat, HH-HL', tree: AND(T('emaStackBull'), L('adx', '>=', 25), T('diBull'), T('hhhl'), LIQ), sort: 'trendStrength' },
    { id: 'pullback', name: 'Pullback to EMA', desc: 'Uptrend, harga kembali ke EMA 20', tree: AND(T('emaStackBull'), L('distEma20', 'between', -2, 2), L('rsi', 'between', 40, 62), LIQ), sort: 'score' },
    { id: 'vwap', name: 'VWAP Reclaim', desc: 'Close kembali di atas VWAP dengan volume', tree: AND(T('vwapReclaim'), L('rvol', '>=', 1.2), LIQ), sort: 'rvol' },
    { id: 'rs', name: 'High Relative Strength', desc: 'RS Rating ≥ 85 dan unggul dari IHSG', tree: AND(L('rsRating', '>=', 85), L('rsIhsg3m', '>', 0), LIQ), sort: 'rsRating' },
    { id: 'h52', name: '52W High Breakout', desc: 'New high 52 minggu dengan volume', tree: AND(T('newHigh52'), L('rvol', '>=', 1.3)), sort: 'rvol' },
    { id: 'volx', name: 'Volume Explosion', desc: 'RVOL ≥ 3x pada candle naik', tree: AND(L('rvol', '>=', 3), L('chg1d', '>', 0)), sort: 'rvol' },
    { id: 'fgrowth', name: 'Fundamental Growth', desc: 'Pendapatan & laba tumbuh, ROE sehat', tree: AND(L('revGrowth', '>=', 10), L('epsGrowth', '>=', 15), L('roe', '>=', 12)), sort: 'epsGrowth' },
    { id: 'uq', name: 'Undervalued Quality', desc: 'P/E & P/B rendah, ROE tinggi', tree: AND(L('pe', 'between', 0.1, 12), L('pb', '<=', 2), L('roe', '>=', 12), OR(L('der', '<=', 100), L('roa', '>=', 1.5))), sort: 'roe' },
    { id: 'qm', name: 'Quality + Momentum', desc: 'Fundamental bagus dan memimpin pasar', tree: AND(L('qualityScore', '>=', 60), L('rsRating', '>=', 70), T('aboveEma50')), sort: 'score' },
    { id: 'canslim', name: 'CANSLIM-style', desc: 'Laba & penjualan melesat, dekat high, RS kuat', tree: AND(L('epsGrowth', '>=', 20), L('revGrowth', '>=', 15), L('roe', '>=', 15), L('dist52wHigh', '<=', 15), L('rsRating', '>=', 80)), sort: 'rsRating' },
    { id: 'minervini', name: 'Minervini Trend Template', desc: '8 syarat trend template', tree: AND(L('close', '>', 'sma150'), L('close', '>', 'sma200'), L('sma150', '>', 'sma200'), T('sma200Rising'), L('sma50', '>', 'sma150'), L('close', '>', 'sma50'), L('dist52wLow', '>=', 30), L('dist52wHigh', '<=', 25), L('rsRating', '>=', 70)), sort: 'rsRating' },
    { id: 'swing', name: 'Swing Trading Setup', desc: 'Uptrend + area entry (retest/FVG/OB/EMA)', tree: AND(T('aboveEma50'), OR(T('retestHold'), T('fvgBullTap'), T('obBullNear'), L('distEma20', 'between', -2, 2)), L('rsi', 'between', 42, 65), LIQ), sort: 'score' },
    { id: 'stm', name: 'Short-Term Momentum', desc: 'Naik ≥5% sepekan dengan volume', tree: AND(L('perf1w', '>=', 5), L('rvol', '>=', 1.5), L('rsi', '>=', 60), L('close', '>', 'ema9')), sort: 'perf1w' },
    { id: 'defensive', name: 'Defensive / Low Volatility', desc: 'ATR rendah, di atas SMA 200, likuid', tree: AND(L('atrPct', '<=', 2.2), L('close', '>', 'sma200'), L('avgValue20', '>=', 5e9)), sort: 'atrPct', dir: 1 },
    { id: 'mtf', name: 'Multi-timeframe: Daily trend + 1H BOS', desc: 'Contoh kombinasi Harian + 1 jam', tree: AND(T('emaStackBull'), LIQ, { f: 'bosBull', op: 'true', tf: '1H' }), sort: 'score' },
  ];
  Sc.blank = () => AND(L('rsi', '>', 50));
  E.Sc = Sc;

  // ---------------- Daily picks ----------------
  E.PICK_CATS = [
    { id: 'mom', name: 'Momentum', types: ['Momentum Leader', 'Breakout + Volume', 'Trend Following'] },
    { id: 'swing', name: 'Swing', types: ['Pullback ke EMA 20', 'Breakout Retest', 'FVG Setup', 'Order Block Retest'] },
    { id: 'early', name: 'Early breakout', types: ['Early Breakout (base/kompresi)'] },
    { id: 'acc', name: 'Akumulasi', types: ['Akumulasi'] },
    { id: 'rev', name: 'Reversal', types: ['Oversold Reversal', 'Liquidity Sweep Reversal'] },
    { id: 'risk', name: 'High-risk', types: [] },
  ];
  E.pickRules = () => { const r = R.M && R.M.regime; if (!D.settings.regimeFilter || !r) return { minScore: 0, minRR: 1, max: 8, label: null };
    return r.score < 40 ? { minScore: 68, minRR: 2, max: 3, label: 'Risk-off: hanya setup terkuat (skor ≥ 68, R/R bersih ≥ 2) yang ditampilkan' } : r.score < 60 ? { minScore: 55, minRR: 1.3, max: 6, label: 'Netral: syarat skor ≥ 55 dan R/R bersih ≥ 1,3' } : { minScore: 0, minRR: 1, max: 8, label: null }; };
  E.pickPass = (s) => { const pr = E.pickRules(); return s.f.score >= pr.minScore && (s.plan.bias < 0 || !ok(s.plan.rrNet) || s.plan.rrNet >= pr.minRR); };
  // Candidates are always shown; those that do not meet the current market-regime bar are flagged instead of hidden.
  E.picks = (catId, { strict = false } = {}) => {
    if (!E.snap) return []; const all = [...E.snap.stocks.values()].filter((s) => !s.f.ppk); const minV = D.settings.minValue; let list;
    if (catId === 'risk') list = all.filter((s) => s.f.atrPct >= 3.5 && s.f.rvol >= 1.5 && s.plan.bias >= 0 && s.f.avgValue20 >= 3e8).sort((a, b) => b.f.rvol - a.f.rvol);
    else if (catId === 'acc') list = all.filter((s) => (s.f.accumScore >= 50 || s.plan.type === 'Akumulasi') && s.plan.bias >= 0 && s.f.avgValue20 >= minV).sort((a, b) => b.f.accumScore - a.f.accumScore);
    else { const cat = E.PICK_CATS.find((c) => c.id === catId); list = all.filter((s) => cat.types.includes(s.plan.type) && s.f.avgValue20 >= minV && s.plan.rrNet >= 1).sort((a, b) => b.f.score - a.f.score); }
    if (strict) return catId === 'risk' ? list.slice(0, 8) : list.filter(E.pickPass).slice(0, E.pickRules().max);
    const pass = list.filter((s) => catId === 'risk' || E.pickPass(s)), rest = list.filter((s) => !pass.includes(s));
    return [...pass, ...rest].slice(0, 8);
  };

  // ---------------- AI Picks track record (forward, out-of-sample) ----------------
  E.logPicks = () => {
    if (!E.snap || D.settings.provider === 'demo') return; const log = D.lsGet('rb.picklog', []); const have = new Set(log.map((x) => x.d + x.sym + x.cat));
    for (const c of E.PICK_CATS) for (const s of E.picks(c.id, { strict: true })) {
      const d = new Date((s.cd.t[s.cd.t.length - 1] + 25200) * 1000).toISOString().slice(0, 10); if (have.has(d + s.sym + c.id)) continue; have.add(d + s.sym + c.id);
      log.push({ d, t: s.cd.t[s.cd.t.length - 1], sym: s.sym, cat: c.id, type: s.plan.type, e: s.plan.entry, inv: s.plan.invalid, t1: s.plan.targets[0], c: s.f.close, score: s.f.score, reg: s.f.regimeScore });
    }
    while (log.length > 600) log.shift(); D.lsSet('rb.picklog', log);
  };
  // evaluate logged picks against later prices: limit fill in area entry within 5 bars, then stop/target/20-bar time exit
  E.evalPick = (p) => {
    const st = E.snap && E.snap.stocks.get(p.sym); if (!st) return Object.assign({}, p, { status: 'Data tidak ada' });
    const cd = st.cd; let i = cd.t.findIndex((t) => t > p.t); if (i < 0) return Object.assign({}, p, { status: 'Menunggu', R: NaN });
    const fee = A.fees(); let j = -1, px = NaN;
    for (let k = i; k < Math.min(cd.c.length, i + 5); k++) if (cd.l[k] <= p.e[1]) { j = k; px = Math.min(cd.o[k], p.e[1]); break; }
    if (j < 0) return Object.assign({}, p, { status: cd.c.length - i >= 5 ? 'Tidak terisi' : 'Menunggu entry', R: NaN });
    const risk = px * (1 + fee.buy) - p.inv * (1 - fee.sell);
    for (let k = j; k < Math.min(cd.c.length, j + 20); k++) {
      if (cd.l[k] <= p.inv) { const x = Math.min(cd.o[k], p.inv); return Object.assign({}, p, { status: 'Kena invalidasi', R: (x * (1 - fee.sell) - px * (1 + fee.buy)) / risk, px, x }); }
      if (p.t1 && cd.h[k] >= p.t1) { const x = k > j ? Math.max(cd.o[k], p.t1) : p.t1; return Object.assign({}, p, { status: 'Kena target 1', R: (x * (1 - fee.sell) - px * (1 + fee.buy)) / risk, px, x }); }
    }
    const last = cd.c[cd.c.length - 1]; const done = cd.c.length - j >= 20; const R0 = (last * (1 - fee.sell) - px * (1 + fee.buy)) / risk;
    return Object.assign({}, p, { status: done ? 'Keluar waktu (20 hari)' : 'Aktif', R: R0, px, x: last, open: !done });
  };

  // ---------------- Live radar ----------------
  const Rd = { running: false, events: new Map(), timer: null, last: null, busy: false, listeners: new Set(), progress: null };
  const DEF_RULES = { notify: true, scope: 'liquid', pct: { on: true, v: 5 }, rvol: { on: true, v: 2.5 }, volAccel: { on: true, v: 3 }, breakout: { on: true }, newHigh: { on: true }, gap: { on: true, v: 2 }, fvg: { on: false }, bos: { on: false }, sweep: { on: true }, ubuy: { on: true }, usell: { on: false }, accel: { on: false }, volx: { on: false }, foreign: { on: false, v: 10 } };
  Rd.rules = Object.assign({}, DEF_RULES, D.lsGet('rb.alerts', {}));
  Rd.saveRules = () => D.lsSet('rb.alerts', Rd.rules);
  Rd.TYPES = { pct: 'Lonjakan harga', rvol: 'Unusual volume', volAccel: 'Akselerasi volume', breakout: 'Breakout', breakdown: 'Breakdown', newHigh: 'New high 52 mgg', newLow: 'New low 52 mgg', gapUp: 'Gap up', gapDown: 'Gap down', accel: 'Akselerasi momentum', volx: 'Ekspansi volatilitas', ubuy: 'Unusual buying', usell: 'Unusual selling', acc: 'Indikasi akumulasi intraday', dist: 'Indikasi distribusi intraday', fvg: 'FVG baru (5m)', bos: 'BOS (5m)', sweep: 'Liquidity sweep (5m)', foreign: 'Foreign flow', ara: 'Menyentuh ARA', arb: 'Menyentuh ARB' };
  Rd.ruleOf = { pct: 'pct', rvol: 'rvol', volAccel: 'volAccel', breakout: 'breakout', breakdown: 'breakout', newHigh: 'newHigh', newLow: 'newHigh', gapUp: 'gap', gapDown: 'gap', accel: 'accel', volx: 'volx', ubuy: 'ubuy', usell: 'usell', acc: 'ubuy', dist: 'usell', fvg: 'fvg', bos: 'bos', sweep: 'sweep', foreign: 'foreign', ara: 'pct', arb: 'pct' };
  Rd.symbols = () => {
    const wl = D.lsGet('rb.watch', []); if (!E.snap) return wl;
    const liquid = [...E.snap.stocks.values()].sort((a, b) => b.f.avgValue20 - a.f.avgValue20).slice(0, Rd.rules.scope === 'all' ? 999 : 70).map((s) => s.sym);
    return Rd.rules.scope === 'watchlist' ? wl : [...new Set([...wl, ...liquid])];
  };
  Rd.analyze = (sym, r) => {
    const cd = r.cd, n = cd.c.length; if (n < 30) return [];
    const st = E.snap && E.snap.stocks.get(sym); const evs = []; const L = n - 1;
    const day = (t) => Math.floor((t + 25200) / 86400); const today = day(cd.t[L]);
    let s0 = L; while (s0 > 0 && day(cd.t[s0 - 1]) === today) s0--; const k = L - s0 + 1;
    const prevClose = s0 > 0 ? cd.c[s0 - 1] : r.meta.prevClose;
    const px = cd.c[L], chg = prevClose ? ((px - prevClose) / prevClose) * 100 : 0;
    // intraday RVOL: cumulative volume vs same-time cumulative on prior sessions
    let cum = 0; for (let i = s0; i <= L; i++) cum += cd.v[i];
    const prior = []; let e = s0 - 1; while (e > 0 && prior.length < 4) { let b = e; while (b > 0 && day(cd.t[b - 1]) === day(cd.t[e])) b--; let cv = 0; for (let i = b; i < Math.min(b + k, e + 1); i++) cv += cd.v[i]; prior.push(cv); e = b - 1; }
    const avgCum = prior.length ? prior.reduce((a, b) => a + b, 0) / prior.length : NaN; const rvolI = avgCum ? cum / avgCum : NaN;
    const vA = I.sma(cd.v, 20), rng = cd.h.map((x, i) => x - cd.l[i]), rA = I.sma(rng, 20); const bar = { o: cd.o[L], h: cd.h[L], l: cd.l[L], c: px, v: cd.v[L] };
    const add = (type, sig, txt) => evs.push({ id: `${sym}|${type}|${today}`, sym, type, sig: Math.round(Math.min(100, sig)), txt, px, chg, t: cd.t[L] });
    const limI = A.limits(prevClose); if (limI && px >= limI.ara) add('ara', 70, `Menyentuh ARA ${A.fmt(limI.ara)} (+${limI.araPct.toFixed(0)}%)`); if (limI && px <= limI.arb) add('arb', 65, `Menyentuh ARB ${A.fmt(limI.arb)} (−${limI.arbPct.toFixed(0)}%)`);
    if (Math.abs(chg) >= Rd.rules.pct.v) add('pct', 30 + Math.abs(chg) * 5, `${chg > 0 ? '+' : ''}${chg.toFixed(2)}% dari penutupan kemarin`);
    if (rvolI >= Rd.rules.rvol.v && k >= 3) add('rvol', 25 + rvolI * 9, `Volume kumulatif ${rvolI.toFixed(1)}x rata-rata jam yang sama`);
    const v3 = (cd.v[L] + cd.v[L - 1] + cd.v[L - 2]) / 3, v12 = cd.v.slice(L - 14, L - 2).reduce((a, b) => a + b, 0) / 12;
    if (v12 && v3 / v12 >= Rd.rules.volAccel.v) add('volAccel', 25 + (v3 / v12) * 7, `Volume 3 bar terakhir ${(v3 / v12).toFixed(1)}x 12 bar sebelumnya`);
    if (st) {
      const res = st.F.st.levels.resistances[0], sup = st.F.st.levels.supports[0];
      if (res && px > res.price && cd.o[s0] <= res.price) add('breakout', 55 + Math.min(30, (rvolI || 1) * 6), `Menembus resistance harian ${A.fmt(res.price)}`);
      if (sup && px < sup.price && cd.o[s0] >= sup.price) add('breakdown', 50, `Menembus support harian ${A.fmt(sup.price)}`);
      const hi52 = Math.max(...st.cd.h.slice(-251, -1)), lo52 = Math.min(...st.cd.l.slice(-251, -1));
      if (px > hi52) add('newHigh', 65, `Di atas high 52 minggu ${A.fmt(hi52)}`); if (px < lo52) add('newLow', 55, `Di bawah low 52 minggu ${A.fmt(lo52)}`);
      const dayRange = Math.max(...cd.h.slice(s0)) - Math.min(...cd.l.slice(s0)); if (dayRange > 1.5 * st.f.atr) add('volx', 35 + (dayRange / st.f.atr) * 8, `Range hari ini ${(dayRange / st.f.atr).toFixed(1)}x ATR harian`);
      if (st.ff && Rd.rules.foreign.on && Math.abs(st.ff.net1d) >= Rd.rules.foreign.v * 1e9) add('foreign', 40, `Foreign net ${st.ff.net1d > 0 ? 'buy' : 'sell'} ${A.fmtRp(st.ff.net1d)} (EOD kemarin)`);
    }
    const gap = prevClose ? ((cd.o[s0] - prevClose) / prevClose) * 100 : 0;
    if (gap >= Rd.rules.gap.v) add('gapUp', 35 + gap * 5, `Gap up ${gap.toFixed(1)}%`); if (gap <= -Rd.rules.gap.v) add('gapDown', 35 - gap * 5, `Gap down ${gap.toFixed(1)}%`);
    const roc3 = ((px - cd.c[L - 3]) / cd.c[L - 3]) * 100, rocP = ((cd.c[L - 3] - cd.c[L - 6]) / cd.c[L - 6]) * 100;
    if (roc3 > 0.8 && roc3 > 2 * Math.abs(rocP)) add('accel', 30 + roc3 * 10, `Momentum berakselerasi +${roc3.toFixed(1)}% dalam 3 bar`);
    const loc = bar.h === bar.l ? 0.5 : (bar.c - bar.l) / (bar.h - bar.l);
    if (vA[L - 1] && bar.v >= 3 * vA[L - 1] && bar.c > bar.o && loc >= 0.75) add('ubuy', 40 + (bar.v / vA[L - 1]) * 4, `Bar hijau ${(bar.v / vA[L - 1]).toFixed(1)}x volume rata-rata, close dekat high`);
    if (vA[L - 1] && bar.v >= 3 * vA[L - 1] && bar.c < bar.o && loc <= 0.25) add('usell', 40 + (bar.v / vA[L - 1]) * 4, `Bar merah ${(bar.v / vA[L - 1]).toFixed(1)}x volume rata-rata, close dekat low`);
    if (k >= 12) { const cmf = I.cmf(cd.h.slice(s0), cd.l.slice(s0), cd.c.slice(s0), cd.v.slice(s0), k); const cv = cmf[cmf.length - 1]; if (cv >= 0.25 && Math.abs(chg) < 2.5) add('acc', 30 + cv * 60, `CMF intraday ${cv.toFixed(2)} dengan harga relatif datar (estimasi)`); if (cv <= -0.25 && Math.abs(chg) < 2.5) add('dist', 30 - cv * 60, `CMF intraday ${cv.toFixed(2)} (estimasi)`); }
    const atr = I.atr(cd.h, cd.l, cd.c); const fv = S.fvg(cd.h, cd.l, cd.c, atr, Math.max(0.3, R.P.fvgMinAtr)).filter((g) => g.i >= L - 1);
    if (fv.length) add('fvg', 30, `FVG ${fv[0].dir > 0 ? 'bullish' : 'bearish'} ${A.fmt(fv[0].lo)}–${A.fmt(fv[0].hi)}`);
    const piv = S.pivots(cd.h, cd.l, R.P.pivotLen, R.P.pivotLen); const bc = S.bosChoch(cd.c, piv).events.filter((x) => x.i >= L - 1);
    if (bc.length) add('bos', 35, `${bc[0].type} ${bc[0].dir > 0 ? 'bullish' : 'bearish'} di ${A.fmt(bc[0].level)}`);
    const sw = S.sweeps(cd.h, cd.l, cd.c, piv, L - 1); if (sw.length) add('sweep', 40, `Sweep likuiditas ${sw[0].dir > 0 ? 'bawah' : 'atas'} di ${A.fmt(sw[0].level)}`);
    return evs;
  };
  Rd.tick = async () => {
    if (Rd.busy) return; Rd.busy = true;
    try {
      const syms = Rd.symbols(); const notifyList = [];
      await D.pool(syms, async (s) => { const r = await D.candles(s, '5m', true); for (const ev of Rd.analyze(s, r)) { const prev = Rd.events.get(ev.id); Rd.events.set(ev.id, Object.assign(ev, { first: prev ? prev.first : Date.now() })); if (!prev) notifyList.push(ev); } },
        D.settings.concurrency, (d, t) => { Rd.progress = [d, t]; Rd.emit(); });
      const dayOf = (t) => Math.floor((t + 25200) / 86400); let latest = 0; for (const ev of Rd.events.values()) latest = Math.max(latest, dayOf(ev.t)); for (const [k, ev] of Rd.events) if (dayOf(ev.t) < latest) Rd.events.delete(k);
      Rd.last = Date.now(); Rd.progress = null;
      if (Rd.rules.notify && Rd.armed) for (const ev of notifyList.sort((a, b) => b.sig - a.sig).slice(0, 5)) { const rk = Rd.ruleOf[ev.type]; if (Rd.rules[rk] && Rd.rules[rk].on) R.notify(`${ev.sym} · ${Rd.TYPES[ev.type]}`, `${ev.txt} — ${A.fmt(ev.px)}`); }
      Rd.armed = true;
    } finally { Rd.busy = false; Rd.emit(); }
  };
  Rd.start = () => { if (Rd.running) return; Rd.running = true; Rd.armed = false; Rd.tick(); Rd.timer = setInterval(Rd.tick, Math.max(30, D.settings.radarInterval) * 1000); Rd.emit(); R.keepAwake && R.keepAwake(true); };
  Rd.stop = () => { Rd.running = false; clearInterval(Rd.timer); Rd.emit(); R.keepAwake && R.keepAwake(false); };
  Rd.emit = () => Rd.listeners.forEach((f) => f());
  Rd.list = () => [...Rd.events.values()].sort((a, b) => b.sig - a.sig || b.first - a.first);
  E.Rd = Rd;

  R.notify = (title, body) => { try { if (window.AndroidBridge) window.AndroidBridge.notify(title, body); } catch (e) {} };
  R.keepAwake = (on) => { try { if (window.AndroidBridge) window.AndroidBridge.keepAwake(!!on); } catch (e) {} };
  R.E = E;
})((typeof window !== 'undefined' ? window : global).RB);
