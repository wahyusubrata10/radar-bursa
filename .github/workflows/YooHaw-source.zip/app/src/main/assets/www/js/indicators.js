/* Yoo Haw — indicator library. All functions return arrays aligned to input (NaN during warm-up). */
(function (R) {
  const I = {};
  const nan = (n) => new Array(n).fill(NaN);
  const ok = (x) => x !== null && x !== undefined && !Number.isNaN(x);

  I.sma = (a, n) => {
    const o = nan(a.length); let s = 0, cnt = 0;
    for (let i = 0; i < a.length; i++) {
      s += a[i]; cnt++;
      if (i >= n) { s -= a[i - n]; cnt--; }
      if (i >= n - 1) o[i] = s / n;
    }
    return o;
  };

  // EMA that tolerates leading NaN (seeds with SMA of first n valid values)
  I.ema = (a, n, alpha) => {
    const o = nan(a.length); const k = alpha || 2 / (n + 1);
    let e = NaN, buf = [];
    for (let i = 0; i < a.length; i++) {
      const v = a[i];
      if (!ok(v)) { o[i] = e; continue; }
      if (!ok(e)) {
        buf.push(v);
        if (buf.length === n) { e = buf.reduce((x, y) => x + y, 0) / n; o[i] = e; }
        continue;
      }
      e = v * k + e * (1 - k); o[i] = e;
    }
    return o;
  };
  I.rma = (a, n) => I.ema(a, n, 1 / n);

  I.stdev = (a, n) => {
    const m = I.sma(a, n), o = nan(a.length);
    for (let i = n - 1; i < a.length; i++) {
      let s = 0; for (let j = i - n + 1; j <= i; j++) s += (a[j] - m[i]) ** 2;
      o[i] = Math.sqrt(s / n);
    }
    return o;
  };

  I.rsi = (c, n = 14) => {
    const g = [NaN], l = [NaN];
    for (let i = 1; i < c.length; i++) { const d = c[i] - c[i - 1]; g.push(Math.max(d, 0)); l.push(Math.max(-d, 0)); }
    const ag = I.rma(g, n), al = I.rma(l, n);
    return ag.map((x, i) => (!ok(x) ? NaN : al[i] === 0 ? 100 : 100 - 100 / (1 + x / al[i])));
  };

  I.macd = (c, f = 12, s = 26, sig = 9) => {
    const ef = I.ema(c, f), es = I.ema(c, s);
    const macd = ef.map((x, i) => x - es[i]);
    const signal = I.ema(macd, sig);
    return { macd, signal, hist: macd.map((x, i) => x - signal[i]) };
  };

  I.tr = (h, l, c) => h.map((x, i) => (i === 0 ? x - l[i] : Math.max(x - l[i], Math.abs(x - c[i - 1]), Math.abs(l[i] - c[i - 1]))));
  I.atr = (h, l, c, n = 14) => I.rma(I.tr(h, l, c), n);

  I.adx = (h, l, c, n = 14) => {
    const pdm = [0], mdm = [0];
    for (let i = 1; i < h.length; i++) {
      const up = h[i] - h[i - 1], dn = l[i - 1] - l[i];
      pdm.push(up > dn && up > 0 ? up : 0); mdm.push(dn > up && dn > 0 ? dn : 0);
    }
    const atr = I.atr(h, l, c, n), sp = I.rma(pdm, n), sm = I.rma(mdm, n);
    const pdi = sp.map((x, i) => (100 * x) / atr[i]), mdi = sm.map((x, i) => (100 * x) / atr[i]);
    const dx = pdi.map((x, i) => (x + mdi[i] === 0 ? 0 : (100 * Math.abs(x - mdi[i])) / (x + mdi[i])));
    return { adx: I.rma(dx, n), pdi, mdi };
  };

  I.stoch = (h, l, c, k = 14, d = 3, smooth = 3) => {
    const raw = nan(c.length);
    for (let i = k - 1; i < c.length; i++) {
      let hh = -Infinity, ll = Infinity;
      for (let j = i - k + 1; j <= i; j++) { hh = Math.max(hh, h[j]); ll = Math.min(ll, l[j]); }
      raw[i] = hh === ll ? 50 : (100 * (c[i] - ll)) / (hh - ll);
    }
    const K = smoothNaN(raw, smooth); const D = smoothNaN(K, d);
    return { k: K, d: D };
  };
  function smoothNaN(a, n) {
    const o = nan(a.length);
    for (let i = 0; i < a.length; i++) {
      if (i < n - 1) continue; let s = 0, bad = false;
      for (let j = i - n + 1; j <= i; j++) { if (!ok(a[j])) { bad = true; break; } s += a[j]; }
      if (!bad) o[i] = s / n;
    }
    return o;
  }

  I.bb = (c, n = 20, m = 2) => {
    const mid = I.sma(c, n), sd = I.stdev(c, n);
    const up = mid.map((x, i) => x + m * sd[i]), lo = mid.map((x, i) => x - m * sd[i]);
    return { mid, up, lo, width: mid.map((x, i) => (up[i] - lo[i]) / x), pctB: c.map((x, i) => (x - lo[i]) / (up[i] - lo[i])) };
  };

  I.obv = (c, v) => { const o = [0]; for (let i = 1; i < c.length; i++) o.push(o[i - 1] + (c[i] > c[i - 1] ? v[i] : c[i] < c[i - 1] ? -v[i] : 0)); return o; };

  I.clv = (h, l, c) => c.map((x, i) => (h[i] === l[i] ? 0 : ((x - l[i]) - (h[i] - x)) / (h[i] - l[i])));
  I.adl = (h, l, c, v) => { const clv = I.clv(h, l, c); const o = []; let s = 0; for (let i = 0; i < c.length; i++) { s += clv[i] * v[i]; o.push(s); } return o; };
  I.cmf = (h, l, c, v, n = 20) => {
    const clv = I.clv(h, l, c), mfv = clv.map((x, i) => x * v[i]); const a = I.sma(mfv, n), b = I.sma(v, n);
    return a.map((x, i) => (b[i] ? x / b[i] : 0));
  };
  I.mfi = (h, l, c, v, n = 14) => {
    const tp = c.map((x, i) => (h[i] + l[i] + x) / 3), o = nan(c.length);
    for (let i = n; i < c.length; i++) {
      let pos = 0, neg = 0;
      for (let j = i - n + 1; j <= i; j++) { const f = tp[j] * v[j]; if (tp[j] > tp[j - 1]) pos += f; else if (tp[j] < tp[j - 1]) neg += f; }
      o[i] = neg === 0 ? 100 : 100 - 100 / (1 + pos / neg);
    }
    return o;
  };

  // Session VWAP for intraday (resets each WIB trading day)
  I.vwapSession = (t, h, l, c, v) => {
    const o = []; let pv = 0, vv = 0, day = -1;
    for (let i = 0; i < c.length; i++) {
      const d = Math.floor((t[i] + 7 * 3600) / 86400);
      if (d !== day) { day = d; pv = 0; vv = 0; }
      const tp = (h[i] + l[i] + c[i]) / 3; pv += tp * v[i]; vv += v[i];
      o.push(vv ? pv / vv : c[i]);
    }
    return o;
  };
  I.avwap = (h, l, c, v, from) => {
    const o = nan(c.length); let pv = 0, vv = 0;
    for (let i = Math.max(0, from); i < c.length; i++) { const tp = (h[i] + l[i] + c[i]) / 3; pv += tp * v[i]; vv += v[i]; o[i] = vv ? pv / vv : c[i]; }
    return o;
  };
  // Rolling VWAP (for daily/weekly bars)
  I.vwapRolling = (h, l, c, v, n = 20) => {
    const o = nan(c.length);
    for (let i = n - 1; i < c.length; i++) { let pv = 0, vv = 0; for (let j = i - n + 1; j <= i; j++) { pv += ((h[j] + l[j] + c[j]) / 3) * v[j]; vv += v[j]; } o[i] = vv ? pv / vv : c[i]; }
    return o;
  };

  I.volumeProfile = (h, l, c, v, lookback = 120, bins = 30) => {
    const n = c.length, s = Math.max(0, n - lookback);
    let hi = -Infinity, lo = Infinity;
    for (let i = s; i < n; i++) { hi = Math.max(hi, h[i]); lo = Math.min(lo, l[i]); }
    if (!(hi > lo)) return null;
    const step = (hi - lo) / bins, vol = new Array(bins).fill(0);
    for (let i = s; i < n; i++) {
      const a = Math.floor((l[i] - lo) / step), b = Math.min(bins - 1, Math.floor((h[i] - lo) / step));
      const span = Math.max(1, b - a + 1);
      for (let k = Math.max(0, a); k <= b; k++) vol[k] += v[i] / span;
    }
    let poc = 0; vol.forEach((x, i) => { if (x > vol[poc]) poc = i; });
    const total = vol.reduce((x, y) => x + y, 0); let acc = vol[poc], up = poc, dn = poc;
    while (acc < total * 0.7 && (up < bins - 1 || dn > 0)) {
      const nu = up < bins - 1 ? vol[up + 1] : -1, nd = dn > 0 ? vol[dn - 1] : -1;
      if (nu >= nd) { up++; acc += nu; } else { dn--; acc += nd; }
    }
    const mid = (k) => lo + step * (k + 0.5);
    return { poc: mid(poc), vah: lo + step * (up + 1), val: lo + step * dn, bins: vol.map((x, k) => ({ price: mid(k), vol: x })) };
  };

  I.roc = (a, n) => a.map((x, i) => (i >= n && a[i - n] ? ((x - a[i - n]) / a[i - n]) * 100 : NaN));

  // normalized linear-regression slope over last n values (% of mean per bar)
  I.slope = (a, n, end) => {
    end = end === undefined ? a.length - 1 : end; const s = end - n + 1; if (s < 0) return NaN;
    let sx = 0, sy = 0, sxy = 0, sxx = 0, m = 0;
    for (let i = s; i <= end; i++) { const x = i - s, y = a[i]; if (!ok(y)) return NaN; sx += x; sy += y; sxy += x * y; sxx += x * x; m++; }
    const b = (m * sxy - sx * sy) / (m * sxx - sx * sx); const mean = sy / m;
    return mean ? (b / Math.abs(mean)) * 100 : b;
  };

  I.percentile = (arr, val) => { const v = arr.filter(ok); if (!v.length) return NaN; return (v.filter((x) => x <= val).length / v.length) * 100; };
  I.ok = ok;
  R.I = I;
})((typeof window !== 'undefined' ? window : global).RB = (typeof window !== 'undefined' ? window : global).RB || {});
