/* Yoo Haw — AI Picks v2: plain-language reasons & risk, historical evidence, "Saya beli", no-buy verdict. */
(function (R) {
  const { D, A, I, E, B } = R; const ok = I.ok; const PK = { evid: null, evidBusy: false, stockEv: new Map(), stockEvBusy: new Set() };
  const pctS = (x, d = 1) => `${x >= 0 ? '+' : '−'}${Math.abs(x).toFixed(d).replace('.', ',')}%`;
  const rp = (x) => A.fmtRp(x);

  // ---------------- merged list (all categories, unlimited) ----------------
  PK.all = () => {
    if (!E.snap) return []; const seen = new Set(), out = [];
    for (const c of E.PICK_CATS) for (const s of E.picks(c.id)) if (!seen.has(s.sym)) { seen.add(s.sym); out.push(Object.assign(s, { pickCat: c.id })); }
    return out.sort((a, b) => (PK.passes(b) - PK.passes(a)) || b.f.score - a.f.score);
  };
  PK.passes = (s) => (s.pickCat === 'risk' ? true : E.pickPass(s)) && !(s.goreng && s.goreng.level === 'Tinggi');
  // "today it is better not to buy": weak market and nothing clears the strict bar
  PK.verdict = () => {
    const reg = R.M && R.M.regime; const pass = PK.all().filter((s) => s.pickCat !== 'risk' && PK.passes(s)).length;
    if (reg && (reg.score < 30 || (reg.score < 40 && pass === 0))) return { noBuy: true, pass, text: `Hari ini lebih baik tidak beli: kondisi pasar ${reg.label.toLowerCase()} (${reg.score}/100)${pass ? '' : ' dan tidak ada setup yang lolos syarat ketat'}. Simpan modal, pantau saja.` };
    return { noBuy: false, pass, text: pass ? `${pass} kandidat lolos syarat ketat hari ini.` : 'Belum ada kandidat yang lolos syarat ketat — perlakukan daftar di bawah sebagai pantauan.' };
  };

  // ---------------- 3 reasons + 1 risk, in plain language ----------------
  const SETUP_WHY = {
    'Breakout + Volume': (s) => `Harga baru menembus resistance ${A.fmt(s.F.st.brk ? s.F.st.brk.level : s.plan.entry[0])} dengan volume ${num1(s.f.rvol)}x lebih ramai dari biasanya`,
    'Breakout Retest': (s) => `Harga sudah menembus resistance ${A.fmt(s.plan.entry[0])}, turun menguji ulang, dan bertahan di atasnya — area beli klasik`,
    'Liquidity Sweep Reversal': () => 'Harga sempat menembus titik terendah sebelumnya untuk "memancing" stop loss, lalu langsung berbalik naik',
    'FVG Setup': (s) => `Harga kembali ke celah harga (FVG) ${A.fmt(s.plan.entry[0])}–${A.fmt(s.plan.entry[1])} yang ditinggalkan saat naik kencang`,
    'Order Block Retest': (s) => `Harga kembali ke area order block ${A.fmt(s.plan.entry[0])}–${A.fmt(s.plan.entry[1])}, tempat pembeli besar masuk sebelumnya`,
    'Pullback ke EMA 20': () => 'Tren naik masih rapi dan harga sedang koreksi sehat ke rata-rata 20 hari (EMA 20)',
    'Early Breakout (base/kompresi)': (s) => `Harga bergerak sempit (kompresi) tepat di bawah resistance — tinggal ${num1(s.f.distResist)}% lagi untuk breakout`,
    'Oversold Reversal': (s) => `Sudah jenuh jual (RSI ${Math.round(s.f.rsi)}) dan mulai ada tanda pembalikan`,
    'Akumulasi': () => 'Ada jejak akumulasi: volume besar masuk tetapi harga ditahan di area sempit',
    'Momentum Leader': (s) => `Termasuk saham terkuat di pasar: lebih kuat dari ${s.f.rsRating}% saham lain`,
    'Trend Following': () => 'Tren naik bertingkat (EMA 20 > 50 > 200) dan masih berlanjut',
  };
  const num1 = (x) => (ok(x) ? (Math.round(x * 10) / 10).toString().replace('.', ',') : '—');
  let rrgCache = null, rrgAt = 0;
  const quadrant = (sector) => { if (!R.X || !E.snap) return null; if (!rrgCache || rrgAt !== E.snap.asOf) { try { rrgCache = R.X.rrg({ weekly: true }); } catch (e) { rrgCache = []; } rrgAt = E.snap.asOf; } const r = rrgCache.find((x) => x.sec === sector); return r ? r.q : null; };
  PK.plain = (s) => {
    const f = s.f, out = [], risks = []; const add = (w, t) => out.push({ w, t }); const risk = (w, t) => risks.push({ w, t });
    const sw = SETUP_WHY[s.plan.type]; if (sw && s.plan.bias > 0) add(10, sw(s));
    if (s.ff && s.ff.streak >= 3) add(8, `Investor asing membeli ${s.ff.streak} hari berturut-turut (${rp(s.ff.net5d)} dalam 5 hari)`);
    else if (s.ff && s.ff.net5d > 0 && s.ff.net5d >= 0.02 * f.avgValue20 * 5) add(6, `Asing net beli ${rp(s.ff.net5d)} dalam 5 hari`);
    const q = quadrant(s.sector); if (q === 'Memimpin') add(7, `Sektor ${s.sector} sedang memimpin pasar`); if (q === 'Membaik') add(6, `Sektor ${s.sector} mulai menguat dibanding IHSG`);
    if (f.rsRating >= 85 && s.plan.type !== 'Momentum Leader') add(6, `Lebih kuat dari ${f.rsRating}% saham lain dalam 3–12 bulan terakhir`);
    if (f.rvol >= 1.8 && f.bullCandle && s.plan.type !== 'Breakout + Volume') add(5, `Volume hari terakhir ${num1(f.rvol)}x lebih ramai dari biasanya saat harga naik`);
    if ((f.accumScore || 0) >= 60 && s.plan.type !== 'Akumulasi') add(6, 'Ada bukti akumulasi dari pola harga & volume');
    if (R.O && R.O.cur) { const o = R.O.stock(s.sym); const inst = o && o.changes.filter((c) => ['MF', 'IS', 'PF'].includes(c.r.type) && c.d > 0); if (inst && inst.length) add(7, `${inst[0].r.type === 'MF' ? 'Reksa dana' : inst[0].r.type === 'IS' ? 'Asuransi' : 'Dana pensiun'} menambah kepemilikan bulan ini (${inst[0].r.inv.split(' ').slice(0, 3).join(' ')})`); }
    if (R.N && R.N.stories) { const st = R.N.stories.find((x) => x.tickers.includes(s.sym) && x.sent > 0 && x.aw && x.aw.level === 'early'); if (st) add(7, `Ada berita positif yang belum banyak diketahui: "${st.title.slice(0, 70)}${st.title.length > 70 ? '…' : ''}"`); }
    if (R.M && R.M.data) for (const it of R.M.data.items) { const l = (it.linked || []).find((x) => x.sym === s.sym && x.lagging && it.p1m > 0); if (l) { add(6, `${it.name} naik ${pctS(it.p1m)} sebulan, saham ini belum ikut naik`); break; } }
    if (f.qualityScore >= 70) add(5, `Fundamental solid${ok(f.roe) ? `: ROE ${num1(f.roe)}%` : ''}${ok(f.epsGrowth) && f.epsGrowth > 0 ? `, laba tumbuh ${num1(f.epsGrowth)}%` : ''}`);
    if (f.peVsSector > 0 && f.peVsSector < 0.8) add(4, 'Valuasinya lebih murah dari rata-rata sektornya');
    if (f.hhhl && out.length < 3) add(3, 'Struktur harga naik: puncak dan dasarnya makin tinggi');
    // risks
    const reg = R.M && R.M.regime; if (reg && reg.score < 40) risk(10, 'Pasar secara umum sedang lemah — breakout lebih sering gagal');
    if (s.goreng && s.goreng.level !== 'Rendah') risk(9, `Ciri saham rawan "digoreng": ${s.goreng.flags[0]}`);
    if (f.rsiDivBear || f.macdDivBear) risk(8, 'Momentum mulai melemah (bearish divergence)');
    if ((f.distScore || 0) >= 50) risk(8, 'Ada jejak distribusi (pemain besar mulai melepas)');
    if (s.ff && s.ff.net5d < 0 && s.ff.streak <= -3) risk(7, `Asing justru menjual ${-s.ff.streak} hari berturut-turut`);
    if (f.nearResist && !f.breakout) risk(6, `Resistance dekat di atas (${num1(f.distResist)}%) bisa menahan kenaikan`);
    if (f.rsi > 75) risk(6, 'Sudah naik tinggi (RSI jenuh beli) — rawan koreksi dulu');
    if (f.avgValue20 < 1e9) risk(6, 'Saham kurang likuid — beli/jual dalam jumlah besar bisa susah');
    if (f.atrPct >= 6) risk(5, `Pergerakannya liar (rata-rata ${num1(f.atrPct)}% per hari)`);
    if (s.plan.bias > 0 && R.X) { const em = R.X.expectedMove(s.cd); const p = em && s.plan.targets[0] ? em.touch(s.plan.targets[0], 20) : NaN; if (ok(p) && p < 0.35) risk(5, `Target 1 cukup jauh — peluang tersentuh dalam 20 hari hanya ±${Math.round(p * 100)}%`); }
    if (!risks.length) risk(1, `Rencana batal jika harga close di bawah ${A.fmt(s.plan.invalid)}`);
    out.sort((a, b) => b.w - a.w); risks.sort((a, b) => b.w - a.w);
    return { reasons: out.slice(0, 3).map((x) => x.t), risk: risks[0].t };
  };

  // ---------------- historical evidence ----------------
  const EKEY = 'evid|v1';
  PK.loadEvidence = async () => { if (PK.evid) return PK.evid; const c = await D.cacheGet(EKEY, 30 * 864e5); if (c) PK.evid = c; return PK.evid; };
  PK.evidenceStale = () => !PK.evid || Date.now() - PK.evid.asOf > 7 * 864e5;
  // one pass over the 60 most liquid stocks, 2 years, every valid setup → stats per setup type and per market regime
  PK.buildEvidence = async (onProg) => {
    if (PK.evidBusy || !B || B.running || B.userPending) return PK.evid; PK.evidBusy = true;
    try { const r = await B.run({ mode: 'any', nStocks: 60, period: 504, step: 2, hold: 20, entry: 'limit', owner: 'evid' }, onProg);
      PK.evid = { asOf: Date.now(), byType: r.byType, byTypeReg: r.byTypeReg, n: r.n, nStocks: r.nStocks, from: r.from, to: r.to }; await D.cacheSet(EKEY, PK.evid); return PK.evid; }
    catch (e) { PK.evidErr = e.message; return PK.evid; } finally { PK.evidBusy = false; }
  };
  PK.typeEvidence = (type) => {
    if (!PK.evid) return null; const reg = R.M && R.M.regime ? R.M.label(R.M.regime.score) : null;
    const g = (reg && PK.evid.byTypeReg.find((x) => x.k === type + '|' + reg)) || null, all = PK.evid.byType.find((x) => x.k === type) || null;
    return { reg, g: g && g.n >= 8 ? g : null, all };
  };
  // this stock's own history for the same setup type (cached per symbol & setup)
  PK.stockEvidence = async (s) => {
    const key = s.sym + '|' + s.plan.type; if (PK.stockEv.has(key)) return PK.stockEv.get(key);
    const c = await D.cacheGet('sev|' + key, 7 * 864e5); if (c) { PK.stockEv.set(key, c); return c; }
    if (PK.stockEvBusy.has(key)) return null; PK.stockEvBusy.add(key);
    try {
      const cd = (await D.candles(s.sym, 'D5')).cd; const N = cd.c.length, WIN = 320, fee = A.fees(); const tr = [];
      let free = 0, steps = 0;
      for (let i = WIN; i < N - 2; i += 2) {
        if (++steps % 20 === 0) await new Promise((r2) => setTimeout(r2, 0)); // keep the UI responsive
        if (i < free) continue; const pre = { t: cd.t.slice(i - WIN + 1, i + 1), o: cd.o.slice(i - WIN + 1, i + 1), h: cd.h.slice(i - WIN + 1, i + 1), l: cd.l.slice(i - WIN + 1, i + 1), c: cd.c.slice(i - WIN + 1, i + 1), v: cd.v.slice(i - WIN + 1, i + 1) };
        const Fx = R.F.compute(pre, { daily: true }); if (!Fx) continue; A.bandar(pre, Fx.f, null); const plan = A.plan(pre, Fx);
        if (plan.type !== s.plan.type || plan.bias <= 0) continue;
        const t = B.simulate(cd, i, plan, Fx.f, { hold: 20, entry: 'limit', fee }); if (!t || t.out === 'Masih terbuka') continue; tr.push(t); free = t.k + 1;
      }
      const out = { n: tr.length, win: tr.filter((t) => t.R > 0).length, avgRet: tr.length ? tr.reduce((a, t) => a + t.ret, 0) / tr.length : NaN, worst: tr.length ? Math.min(...tr.map((t) => t.ret)) : NaN, bars: tr.length ? tr.reduce((a, t) => a + t.bars, 0) / tr.length : NaN, years: Math.max(1, Math.round(((cd.t[N - 1] - cd.t[WIN]) / 31557600) * 10) / 10) };
      PK.stockEv.set(key, out); await D.cacheSet('sev|' + key, out); return out;
    } catch (e) { return null; } finally { PK.stockEvBusy.delete(key); }
  };
  PK.evidenceText = (s, se) => {
    const te = PK.typeEvidence(s.plan.type); const parts = [];
    if (se) parts.push(se.n >= 3 ? `Pola ${s.plan.type} di ${s.sym} muncul ${se.n}× dalam ±${String(se.years).replace('.', ',')} tahun: ${se.win} untung (${Math.round((se.win / se.n) * 100)}%), rata-rata ${pctS(se.avgRet * 100)}, rugi terburuk ${pctS(se.worst * 100)}, ditahan ±${Math.round(se.bars)} hari.` : `Pola ${s.plan.type} baru ${se.n}× muncul di ${s.sym} — bukti khusus saham ini masih lemah.`);
    const g = te && (te.g || te.all);
    if (g) parts.push(`Di ${PK.evid.nStocks} saham terlikuid${te.g ? ` saat pasar ${te.reg.toLowerCase()}` : ''}: ${g.n}×, ${Math.round(g.win * 100)}% untung, rata-rata ${pctS(g.avgRet * 100)} (${g.avgR >= 0 ? '+' : '−'}${Math.abs(g.avgR).toFixed(2).replace('.', ',')}R), rugi terburuk ${pctS(g.worst * 100)}.`);
    return parts.join(' ');
  };

  // ---------------- "Saya beli" → portfolio with the plan attached ----------------
  PK.buy = (s, price, lots) => {
    const p = s.plan; const today = new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10);
    E.P.upsert({ sym: s.sym, avg: price > 0 ? price : null, lots: lots > 0 ? lots : null, added: Date.now(), plan: p.bias > 0 ? { type: p.type, entry: p.entry, invalid: p.invalid, targets: p.targets, date: today, score: s.f.score } : null });
  };
  R.PK = PK;
})((typeof window !== 'undefined' ? window : global).RB);
