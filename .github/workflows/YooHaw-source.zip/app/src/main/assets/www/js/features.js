/* Yoo Haw — feature extraction. Turns candles into a flat dictionary of screenable fields. */
(function (R) {
  const I = R.I, S = R.S;
  const F = {};

  // ---------- Field registry (drives screener UI, sorting, explanations) ----------
  const G = {
    price: 'Harga', perf: 'Performa & RS', ma: 'Tren (MA)', mom: 'Momentum', vol: 'Volatilitas', flow: 'Volume & Money Flow',
    vwap: 'VWAP & Profil Volume', st: 'Struktur Pasar', smc: 'Smart Money (SMC)', div: 'Divergensi', fund: 'Fundamental',
    val: 'Valuasi', ff: 'Foreign Flow', bd: 'Bandar Radar', ai: 'Skor AI',
  };
  const fl = [];
  const add = (g, k, label, t, u, extra) => fl.push(Object.assign({ g: G[g], k, label, t, u: u || '' }, extra || {}));
  // Harga
  add('price', 'close', 'Harga', 'num', 'Rp'); add('price', 'chg1d', 'Perubahan (bar terakhir)', 'num', '%');
  add('price', 'gapPct', 'Gap pembukaan', 'num', '%'); add('price', 'gapUp', 'Gap up (>1%)', 'bool'); add('price', 'gapDown', 'Gap down (>1%)', 'bool');
  add('price', 'bullCandle', 'Candle hijau', 'bool'); add('price', 'closeLoc', 'Posisi close dalam range (0–1)', 'num');
  add('price', 'newHigh20', 'New high 20 bar', 'bool'); add('price', 'newLow20', 'New low 20 bar', 'bool');
  add('price', 'newHigh52', 'New high 52 minggu', 'bool', '', { daily: 1 }); add('price', 'newLow52', 'New low 52 minggu', 'bool', '', { daily: 1 });
  add('price', 'dist52wHigh', 'Jarak dari high 52 mgg', 'num', '%', { daily: 1 }); add('price', 'dist52wLow', 'Di atas low 52 mgg', 'num', '%', { daily: 1 });
  // Performa & RS
  for (const [k, l] of [['perf1d', '1H'], ['perf1w', '1M'], ['perf1m', '1B'], ['perf3m', '3B'], ['perf6m', '6B'], ['perf1y', '1T']]) add('perf', k, 'Performa ' + l, 'num', '%', { daily: 1 });
  add('perf', 'rsIhsg1m', 'RS vs IHSG 1 bulan', 'num', '%', { daily: 1 }); add('perf', 'rsIhsg3m', 'RS vs IHSG 3 bulan', 'num', '%', { daily: 1 });
  add('perf', 'rsIhsg6m', 'RS vs IHSG 6 bulan', 'num', '%', { daily: 1 }); add('perf', 'rsSector3m', 'RS vs sektor 3 bulan', 'num', '%', { daily: 1 });
  add('perf', 'rsRating', 'RS Rating (1–99)', 'num', '', { daily: 1 }); add('perf', 'sectorRank', 'Peringkat sektor (1 = terkuat)', 'num', '', { daily: 1 });
  add('perf', 'sectorLeader', 'Pemimpin sektor (top 3 RS)', 'bool', '', { daily: 1 });
  // MA
  for (const n of [5, 9, 20, 21, 50, 100, 200]) add('ma', 'ema' + n, 'EMA ' + n, 'num', 'Rp');
  for (const n of [5, 9, 20, 50, 100, 150, 200]) add('ma', 'sma' + n, 'SMA ' + n, 'num', 'Rp');
  add('ma', 'aboveEma20', 'Di atas EMA 20', 'bool'); add('ma', 'aboveEma50', 'Di atas EMA 50', 'bool'); add('ma', 'aboveEma200', 'Di atas EMA 200', 'bool');
  add('ma', 'emaStackBull', 'EMA bertingkat naik (20>50>200)', 'bool'); add('ma', 'emaStackBear', 'EMA bertingkat turun', 'bool');
  add('ma', 'distEma20', 'Jarak dari EMA 20', 'num', '%'); add('ma', 'distEma200', 'Jarak dari EMA 200 (%)', 'num', '%', { daily: 1 }); add('ma', 'distEma50', 'Jarak dari EMA 50', 'num', '%');
  add('ma', 'sma200Rising', 'SMA 200 menanjak (1 bln)', 'bool'); add('ma', 'adx', 'ADX', 'num'); add('ma', 'diBull', '+DI > −DI', 'bool');
  add('ma', 'trendStrength', 'Kekuatan tren (0–100)', 'num');
  // Momentum
  add('mom', 'rsi', 'RSI 14', 'num'); add('mom', 'rsiRising', 'RSI naik', 'bool'); add('mom', 'macd', 'MACD', 'num'); add('mom', 'macdSignal', 'MACD signal', 'num');
  add('mom', 'macdHist', 'MACD histogram', 'num'); add('mom', 'macdCrossUp', 'MACD golden cross (baru)', 'bool'); add('mom', 'macdCrossDown', 'MACD death cross (baru)', 'bool');
  add('mom', 'stochK', 'Stochastic %K', 'num'); add('mom', 'stochD', 'Stochastic %D', 'num'); add('mom', 'stochCrossUp', 'Stoch cross up dari oversold', 'bool');
  add('mom', 'roc10', 'ROC 10', 'num', '%'); add('mom', 'momAccel', 'Akselerasi momentum', 'num'); add('mom', 'momAccelUp', 'Momentum berakselerasi', 'bool');
  // Volatilitas
  add('vol', 'atr', 'ATR 14', 'num', 'Rp'); add('vol', 'atrPct', 'ATR %', 'num', '%'); add('vol', 'bbWidth', 'Lebar Bollinger', 'num', '%');
  add('vol', 'bbWidthPctl', 'Persentil lebar BB (120 bar)', 'num'); add('vol', 'bbSqueeze', 'BB squeeze', 'bool'); add('vol', 'pctB', 'Bollinger %B', 'num');
  add('vol', 'volExpansion', 'Ekspansi volatilitas', 'bool'); add('vol', 'rangeExpansion', 'Range expansion (>1.8x)', 'bool');
  // Volume & money flow
  add('flow', 'volume', 'Volume (lembar)', 'num'); add('flow', 'rvol', 'Relative volume', 'num', 'x'); add('flow', 'volSpike', 'Volume spike (≥2x)', 'bool');
  add('flow', 'volTrend', 'Tren volume (avg5/avg20)', 'num', 'x'); add('flow', 'volContraction', 'Volume menyusut', 'bool');
  add('flow', 'upDownVol', 'Up/Down volume 20 bar', 'num', 'x'); add('flow', 'obvRising', 'OBV menanjak', 'bool'); add('flow', 'obvNewHigh', 'OBV new high 20', 'bool');
  add('flow', 'cmf', 'CMF 20', 'num'); add('flow', 'mfi', 'MFI 14', 'num'); add('flow', 'adRising', 'A/D line naik', 'bool');
  add('flow', 'value', 'Nilai transaksi', 'num', 'Rp'); add('flow', 'avgValue20', 'Rata-rata nilai transaksi 20', 'num', 'Rp');
  // VWAP
  add('vwap', 'vwap', 'VWAP', 'num', 'Rp'); add('vwap', 'aboveVwap', 'Di atas VWAP', 'bool'); add('vwap', 'vwapReclaim', 'VWAP reclaim', 'bool');
  add('vwap', 'avwap', 'Anchored VWAP (dari swing low)', 'num', 'Rp'); add('vwap', 'aboveAvwap', 'Di atas anchored VWAP', 'bool');
  add('vwap', 'poc', 'Volume profile POC', 'num', 'Rp'); add('vwap', 'aboveVah', 'Di atas value area high', 'bool'); add('vwap', 'nearPoc', 'Dekat POC (≤1 ATR)', 'bool');
  // Struktur
  add('st', 'swingTrend', 'Struktur swing (1 naik, 0 range, −1 turun)', 'num'); add('st', 'hhhl', 'HH + HL', 'bool'); add('st', 'lhll', 'LH + LL', 'bool');
  add('st', 'bosBull', 'BOS bullish (baru)', 'bool'); add('st', 'bosBear', 'BOS bearish (baru)', 'bool');
  add('st', 'chochBull', 'CHoCH bullish (baru)', 'bool'); add('st', 'chochBear', 'CHoCH bearish (baru)', 'bool');
  add('st', 'barsSinceBosBull', 'Bar sejak BOS/CHoCH bullish', 'num'); add('st', 'barsSinceBosBear', 'Bar sejak BOS/CHoCH bearish', 'num'); add('st', 'barsSinceChochBull', 'Bar sejak CHoCH bullish', 'num');
  add('st', 'barsSinceSweepBull', 'Bar sejak sweep bawah', 'num'); add('st', 'barsSinceSweepBear', 'Bar sejak sweep atas', 'num');
  add('st', 'distSupport', 'Jarak ke support', 'num', '%'); add('st', 'distResist', 'Jarak ke resistance', 'num', '%');
  add('st', 'nearSupport', 'Dekat support (≤1 ATR)', 'bool'); add('st', 'nearResist', 'Dekat resistance (≤1 ATR)', 'bool');
  add('st', 'breakout', 'Breakout resistance (baru)', 'bool'); add('st', 'breakdown', 'Breakdown support (baru)', 'bool');
  add('st', 'retestHold', 'Breakout lalu retest bertahan', 'bool'); add('st', 'consolidation', 'Konsolidasi', 'bool'); add('st', 'compression', 'Kompresi (volatilitas menyempit)', 'bool');
  add('st', 'baseFormation', 'Pembentukan base', 'bool'); add('st', 'equalHighs', 'Equal highs (liquidity atas)', 'bool'); add('st', 'equalLows', 'Equal lows (liquidity bawah)', 'bool');
  add('st', 'sweepBull', 'Liquidity sweep bawah (baru)', 'bool'); add('st', 'sweepBear', 'Liquidity sweep atas (baru)', 'bool'); add('st', 'stopHunt', 'Stop hunt (sweep + volume)', 'bool');
  // SMC
  add('smc', 'fvgBullOpen', 'FVG bullish terbuka di bawah', 'bool'); add('smc', 'fvgBullNew', 'FVG bullish baru (baru)', 'bool'); add('smc', 'fvgBullTap', 'Harga mitigasi FVG bullish', 'bool');
  add('smc', 'fvgBearOpen', 'FVG bearish terbuka di atas', 'bool'); add('smc', 'fvgBearNew', 'FVG bearish baru (baru)', 'bool');
  add('smc', 'distFvgBull', 'Jarak ke FVG bullish terdekat', 'num', '%'); add('smc', 'barsSinceFvgBull', 'Bar sejak FVG bullish terbentuk', 'num'); add('smc', 'barsSinceFvgBear', 'Bar sejak FVG bearish terbentuk', 'num'); add('smc', 'barsSinceDispBull', 'Bar sejak displacement naik', 'num');
  add('smc', 'obBullNear', 'Di/dekat order block bullish', 'bool'); add('smc', 'obBearNear', 'Di/dekat order block bearish', 'bool');
  add('smc', 'breakerBull', 'Breaker block bullish aktif', 'bool'); add('smc', 'displacementBull', 'Displacement candle naik (baru)', 'bool');
  add('smc', 'displacementBear', 'Displacement candle turun (baru)', 'bool'); add('smc', 'bosFvg', 'BOS + FVG bullish', 'bool');
  add('smc', 'sweepReversal', 'Sweep + reversal bullish', 'bool'); add('smc', 'pdPos', 'Posisi premium/discount (0–1)', 'num');
  add('smc', 'discount', 'Zona discount (<0.5)', 'bool'); add('smc', 'premium', 'Zona premium (>0.5)', 'bool');
  // Divergensi
  add('div', 'rsiDivBull', 'Bullish divergence RSI', 'bool'); add('div', 'rsiDivBear', 'Bearish divergence RSI', 'bool');
  add('div', 'macdDivBull', 'Bullish divergence MACD', 'bool'); add('div', 'macdDivBear', 'Bearish divergence MACD', 'bool');
  add('div', 'pvDivBull', 'Divergence harga–OBV bullish', 'bool'); add('div', 'pvDivBear', 'Divergence harga–OBV bearish', 'bool');
  // Fundamental
  const fu = (k, l, u) => add('fund', k, l, 'num', u, { fund: 1, daily: 1 });
  fu('revGrowth', 'Pertumbuhan pendapatan (YoY)', '%'); fu('epsGrowth', 'Pertumbuhan laba/EPS (YoY)', '%'); fu('epsQGrowth', 'Pertumbuhan laba kuartalan', '%');
  fu('roe', 'ROE', '%'); fu('roa', 'ROA', '%'); fu('roic', 'ROIC (estimasi)', '%'); fu('grossMargin', 'Gross margin', '%'); fu('opMargin', 'Operating margin', '%');
  fu('netMargin', 'Net margin', '%'); fu('der', 'Debt to equity', '%'); fu('currentRatio', 'Current ratio', 'x'); fu('ocf', 'Arus kas operasi', 'Rp'); fu('fcf', 'Free cash flow', 'Rp');
  fu('fcfYield', 'FCF yield', '%'); fu('marketCap', 'Kapitalisasi pasar', 'Rp'); fu('qualityScore', 'Skor kualitas fundamental', '');
  add('fund', 'earningsAccel', 'Akselerasi laba', 'bool', '', { fund: 1, daily: 1 });
  const va = (k, l, u) => add('val', k, l, 'num', u, { fund: 1, daily: 1 });
  va('pe', 'P/E', 'x'); va('pb', 'P/B', 'x'); va('evEbitda', 'EV/EBITDA', 'x'); va('divYield', 'Dividend yield', '%'); va('peVsSector', 'P/E vs median sektor', 'x');
  va('pbVsSector', 'P/B vs median sektor', 'x'); va('beta', 'Beta', '');
  // Foreign flow
  add('ff', 'fNet1d', 'Foreign net 1 hari', 'num', 'Rp', { ff: 1, daily: 1 }); add('ff', 'fNet5d', 'Foreign net 5 hari', 'num', 'Rp', { ff: 1, daily: 1 });
  add('ff', 'fStreak', 'Hari beruntun foreign net buy', 'num', '', { ff: 1, daily: 1 });
  // Bandar
  add('bd', 'accumScore', 'Skor akumulasi (bukti)', 'num', '', { daily: 1 }); add('bd', 'distScore', 'Skor distribusi (bukti)', 'num', '', { daily: 1 });
  add('bd', 'absorption', 'Absorption terdeteksi', 'bool', '', { daily: 1 }); add('bd', 'gorengScore', 'Skor risiko saham gorengan (0–100)', 'num', '', { daily: 1 }); add('bd', 'gorengan', 'Rawan digoreng (risiko tinggi)', 'bool', '', { daily: 1 }); add('bd', 'abnVolDays', 'Hari volume abnormal (15 bar)', 'num', '', { daily: 1 });
  // BEI
  add('price', 'atAra', 'Ditutup di ARA', 'bool', '', { daily: 1 }); add('price', 'atArb', 'Ditutup di ARB', 'bool', '', { daily: 1 });
  add('price', 'distAraPrev', 'Jarak close ke ARA hari ini', 'num', '%', { daily: 1 }); add('price', 'ppk', 'Papan Pemantauan Khusus (FCA)', 'bool', '', { daily: 1 });
  // Pasar
  add('price', 'regimeScore', 'Skor kondisi pasar (0–100)', 'num', '', { daily: 1 }); add('price', 'riskOn', 'Pasar risk-on', 'bool', '', { daily: 1 });
  // Skor
  add('ai', 'score', 'Setup Score (0–100)', 'num', '', { daily: 1 }); add('ai', 'rr', 'Risk/Reward ke target 1', 'num', 'x', { daily: 1 }); add('ai', 'rrNet', 'R/R bersih biaya', 'num', 'x', { daily: 1 });
  F.FIELDS = fl; F.GROUPS = G; F.byKey = Object.fromEntries(fl.map((x) => [x.k, x]));

  // ---------- Feature computation ----------
  F.compute = (cd, opts = {}) => {
    const { t, o, h, l, c, v } = cd; const n = c.length; const last = n - 1;
    if (n < 30) return null;
    const intraday = !!opts.intraday;
    const f = {}; const se = {};
    const E = {}; for (const p of [5, 9, 20, 21, 50, 100, 200]) E[p] = I.ema(c, p);
    const SM = {}; for (const p of [5, 9, 20, 50, 100, 150, 200]) SM[p] = I.sma(c, p);
    const P = R.P; const atr = I.atr(h, l, c, 14), rsi = I.rsi(c, P.rsiLen), mac = I.macd(c), dx = I.adx(h, l, c), st = I.stoch(h, l, c), bb = I.bb(c);
    const obv = I.obv(c, v), adl = I.adl(h, l, c, v), cmf = I.cmf(h, l, c, v), mfi = I.mfi(h, l, c, v);
    const vAvg20 = I.sma(v, P.rvolLen), vAvg5 = I.sma(v, 5);
    const vwap = intraday ? I.vwapSession(t, h, l, c, v) : I.vwapRolling(h, l, c, v, 20);
    Object.assign(se, { ema20: E[20], ema50: E[50], ema200: E[200], vwap, rsi, macd: mac, atr, obv, bb });

    const A = atr[last] || (h[last] - l[last]) || c[last] * 0.02;
    const core = (i) => {
      const r = { close: c[i], rsi: rsi[i], macd: mac.macd[i], macdSignal: mac.signal[i], macdHist: mac.hist[i], vwap: vwap[i], stochK: st.k[i], stochD: st.d[i] };
      for (const p in E) r['ema' + p] = E[p][i]; for (const p in SM) r['sma' + p] = SM[p][i];
      return r;
    };
    Object.assign(f, core(last)); const fp = core(last - 1);

    f.chg1d = ((c[last] - c[last - 1]) / c[last - 1]) * 100;
    f.gapPct = ((o[last] - c[last - 1]) / c[last - 1]) * 100; f.gapUp = f.gapPct > 1 && l[last] > h[last - 1]; f.gapDown = f.gapPct < -1 && h[last] < l[last - 1];
    f.bullCandle = c[last] > o[last]; f.closeLoc = h[last] === l[last] ? 0.5 : (c[last] - l[last]) / (h[last] - l[last]);
    const hi20 = Math.max(...h.slice(-21, -1)), lo20 = Math.min(...l.slice(-21, -1));
    f.newHigh20 = h[last] > hi20; f.newLow20 = l[last] < lo20;

    f.aboveEma20 = c[last] > E[20][last]; f.aboveEma50 = c[last] > E[50][last]; f.aboveEma200 = I.ok(E[200][last]) ? c[last] > E[200][last] : false;
    f.emaStackBull = c[last] > E[20][last] && E[20][last] > E[50][last] && (!I.ok(E[200][last]) || E[50][last] > E[200][last]);
    f.emaStackBear = c[last] < E[20][last] && E[20][last] < E[50][last] && (!I.ok(E[200][last]) || E[50][last] < E[200][last]);
    f.distEma20 = ((c[last] - E[20][last]) / E[20][last]) * 100; f.distEma50 = ((c[last] - E[50][last]) / E[50][last]) * 100; f.distEma200 = E[200] && Number.isFinite(E[200][last]) ? ((c[last] - E[200][last]) / E[200][last]) * 100 : NaN;
    f.sma200Rising = I.ok(SM[200][last - 21]) && SM[200][last] > SM[200][last - 21];
    f.adx = dx.adx[last]; f.diBull = dx.pdi[last] > dx.mdi[last];

    f.rsiRising = rsi[last] > rsi[last - 3];
    const crossed = (a, b, dir, k) => { for (let i = last; i > last - k; i--) { if (dir > 0 ? a[i] > b[i] && a[i - 1] <= b[i - 1] : a[i] < b[i] && a[i - 1] >= b[i - 1]) return true; } return false; };
    f.macdCrossUp = crossed(mac.macd, mac.signal, 1, 3); f.macdCrossDown = crossed(mac.macd, mac.signal, -1, 3);
    f.stochCrossUp = crossed(st.k, st.d, 1, 3) && Math.min(st.k[last - 1], st.k[last - 2], st.k[last - 3]) < 25;
    const roc5 = I.roc(c, 5), roc10 = I.roc(c, 10);
    f.roc10 = roc10[last]; f.momAccel = roc5[last] - roc5[last - 5]; f.momAccelUp = f.momAccel > 0 && roc5[last] > 0;

    f.atr = A; f.atrPct = (A / c[last]) * 100; f.bbWidth = bb.width[last] * 100; f.pctB = bb.pctB[last];
    f.bbWidthPctl = I.percentile(bb.width.slice(-120), bb.width[last]); f.bbSqueeze = f.bbWidthPctl <= P.sqzPctl;
    const rng = h.map((x, i) => x - l[i]); const avgRng = I.sma(rng, 20);
    f.rangeExpansion = rng[last] > 1.8 * avgRng[last - 1]; f.volExpansion = atr[last] > 1.25 * atr[last - 10] || f.rangeExpansion;

    f.volume = v[last]; f.rvol = vAvg20[last - 1] ? v[last] / vAvg20[last - 1] : NaN; f.volSpike = f.rvol >= P.volSpike;
    f.volTrend = vAvg5[last] / vAvg20[last]; f.volContraction = f.volTrend < 0.7;
    let up = 0, dn = 0; for (let i = n - 20; i < n; i++) { if (c[i] > c[i - 1]) up += v[i]; else if (c[i] < c[i - 1]) dn += v[i]; }
    f.upDownVol = dn ? up / dn : 3;
    f.obvRising = I.slope(obv.map((x) => x + 1e12), 20) > 0; f.obvNewHigh = obv[last] >= Math.max(...obv.slice(-20));
    f.cmf = cmf[last]; f.mfi = mfi[last]; f.adRising = adl[last] > adl[last - 10];
    f.value = c[last] * v[last]; let sv = 0; for (let i = n - 20; i < n; i++) sv += c[i] * v[i]; f.avgValue20 = sv / 20;

    f.aboveVwap = c[last] > vwap[last]; f.vwapReclaim = c[last] > vwap[last] && c[last - 1] <= vwap[last - 1];
    const vp = I.volumeProfile(h, l, c, v, intraday ? 300 : 120); if (vp) { f.poc = vp.poc; f.aboveVah = c[last] > vp.vah; f.nearPoc = Math.abs(c[last] - vp.poc) <= A; }

    // ---- structure ----
    const piv = S.pivots(h, l, P.pivotLen, P.pivotLen);
    const sw = S.swingTrend(piv.filter((p) => p.conf <= last));
    f.swingTrend = sw.trend; f.hhhl = sw.trend === 1; f.lhll = sw.trend === -1;
    const bc = S.bosChoch(c, piv); const ev = bc.events;
    const recent = (type, dir) => ev.some((e) => e.i > last - P.bosRecent && e.type === type && e.dir === dir);
    f.bosBull = recent('BOS', 1); f.bosBear = recent('BOS', -1); f.chochBull = recent('CHoCH', 1); f.chochBear = recent('CHoCH', -1);
    const lastBull = [...ev].reverse().find((e) => e.dir === 1); f.barsSinceBosBull = lastBull ? last - lastBull.i : 999;
    const lastBear = [...ev].reverse().find((e) => e.dir === -1); f.barsSinceBosBear = lastBear ? last - lastBear.i : 999;
    const lastCh = [...ev].reverse().find((e) => e.dir === 1 && e.type === 'CHoCH'); f.barsSinceChochBull = lastCh ? last - lastCh.i : 999;

    const lv = S.levels(piv, A, c[last], last); const sup = lv.supports[0], res = lv.resistances[0];
    f.distSupport = sup ? ((c[last] - sup.price) / c[last]) * 100 : NaN; f.distResist = res ? ((res.price - c[last]) / c[last]) * 100 : NaN;
    f.nearSupport = sup ? c[last] - sup.price <= A : false; f.nearResist = res ? res.price - c[last] <= A : false;
    // breakout: close crosses a level that was resistance as of 4 bars ago, with volume
    let brk = null, bdn = null;
    for (let i = last - P.boRecent + 1; i <= last; i++) {
      const lvPrev = S.levels(piv, atr[i - 1] || A, c[i - 1], i - 1);
      const r0 = lvPrev.resistances[0], s0 = lvPrev.supports[0];
      if (r0 && c[i] > r0.price && c[i - 1] <= r0.price && v[i] >= P.boVol * (vAvg20[i - 1] || 0)) brk = { i, level: r0.price, rvol: v[i] / vAvg20[i - 1] };
      if (s0 && c[i] < s0.price && c[i - 1] >= s0.price) bdn = { i, level: s0.price };
    }
    f.breakout = !!brk; f.breakdown = !!bdn;
    // retest: a breakout 3–15 bars ago, price came back to level and holds above
    let rt = null;
    for (let i = last - P.retestWin; i <= last - 3; i++) {
      if (i < 2) continue;
      const lvPrev = S.levels(piv, atr[i - 1] || A, c[i - 1], i - 1); const r0 = lvPrev.resistances[0];
      if (r0 && c[i] > r0.price && c[i - 1] <= r0.price && v[i] >= 1.2 * (vAvg20[i - 1] || 0)) {
        const minAfter = Math.min(...l.slice(i + 1));
        if (minAfter <= r0.price + 0.5 * A && minAfter >= r0.price - 0.6 * A && c[last] > r0.price && c[last] - r0.price <= 2 * A) rt = { i, level: r0.price };
      }
    }
    f.retestHold = !!rt;
    const r15 = S.rangeStats(h, l, last, 15), r30 = S.rangeStats(h, l, last, 30);
    f.consolidation = r15.pct <= Math.max(3 * f.atrPct, 8);
    f.compression = f.bbSqueeze && atr[last] < 0.85 * (I.sma(atr.map((x) => x || 0), 50)[last] || Infinity);
    f.baseFormation = !intraday && r30.pct <= 18 && c[last] >= r30.lo + 0.5 * (r30.hi - r30.lo) && f.volTrend < 1.1;
    const eqH = S.equalLevels(piv.filter((p) => p.conf <= last), A, 'H'), eqL = S.equalLevels(piv.filter((p) => p.conf <= last), A, 'L');
    f.equalHighs = !!eqH && eqH.price > c[last]; f.equalLows = !!eqL && eqL.price < c[last];
    const sweeps = S.sweeps(h, l, c, piv, n - 60);
    const swRecent = (d) => sweeps.filter((x) => x.dir === d && x.i > last - P.sweepRecent);
    f.sweepBull = swRecent(1).length > 0; f.sweepBear = swRecent(-1).length > 0;
    const lsB = [...sweeps].reverse().find((x) => x.dir === 1), lsS = [...sweeps].reverse().find((x) => x.dir === -1);
    f.barsSinceSweepBull = lsB ? last - lsB.i : 999; f.barsSinceSweepBear = lsS ? last - lsS.i : 999;
    f.stopHunt = [...swRecent(1), ...swRecent(-1)].some((x) => v[x.i] >= 1.5 * (vAvg20[x.i - 1] || Infinity));

    // ---- SMC ----
    const fv = S.fvg(h, l, c, atr); const openBull = fv.filter((g) => g.dir === 1 && g.status !== 'filled' && g.hi < c[last] + A && g.i > n - P.fvgLookback);
    const openBear = fv.filter((g) => g.dir === -1 && g.status !== 'filled' && g.lo > c[last] - A && g.i > n - P.fvgLookback);
    const nearBull = openBull.sort((a, b) => b.hi - a.hi)[0];
    f.fvgBullOpen = !!nearBull && nearBull.hi <= c[last] && (c[last] - nearBull.hi) <= 3 * A;
    f.fvgBullNew = fv.some((g) => g.dir === 1 && g.i > last - P.fvgRecent); f.fvgBearNew = fv.some((g) => g.dir === -1 && g.i > last - P.fvgRecent);
    const since = (arr) => (arr.length ? last - arr[arr.length - 1].i : 999);
    f.barsSinceFvgBull = since(fv.filter((g) => g.dir === 1)); f.barsSinceFvgBear = since(fv.filter((g) => g.dir === -1));
    f.fvgBullTap = openBull.some((g) => l[last] <= g.hi && c[last] >= g.lo); f.fvgBearOpen = openBear.length > 0;
    f.distFvgBull = nearBull ? Math.max(0, ((c[last] - nearBull.hi) / c[last]) * 100) : NaN;
    const obs = S.orderBlocks(o, h, l, c, ev);
    const activeOb = obs.filter((b) => b.status !== 'breaker' && b.i > n - 150);
    f.obBullNear = activeOb.some((b) => b.dir === 1 && l[last] <= b.hi + 0.5 * A && c[last] >= b.lo);
    f.obBearNear = activeOb.some((b) => b.dir === -1 && h[last] >= b.lo - 0.5 * A && c[last] <= b.hi);
    f.breakerBull = obs.some((b) => b.dir === -1 && b.status === 'breaker' && b.breakI > last - 20 && c[last] > b.hi);
    let dU = false, dD = false, lastDU = 999; for (let i = Math.max(2, last - 60); i <= last; i++) { const d = S.displacement(o, h, l, c, atr, i); if (d > 0) lastDU = last - i; if (i > last - P.fvgRecent) { if (d > 0) dU = true; if (d < 0) dD = true; } }
    f.barsSinceDispBull = lastDU;
    f.displacementBull = dU; f.displacementBear = dD;
    f.bosFvg = (f.bosBull || f.chochBull || ev.some((e) => e.dir === 1 && e.i > last - 8)) && fv.some((g) => g.dir === 1 && g.i > last - 8 && g.status !== 'filled');
    f.sweepReversal = sweeps.some((x) => x.dir === 1 && x.i > last - 5) && c[last] > o[last] && (f.chochBull || c[last] > h[last - 1]);
    const lh = [...piv].reverse().find((p) => p.type === 'H' && p.conf <= last), ll = [...piv].reverse().find((p) => p.type === 'L' && p.conf <= last);
    if (lh && ll && lh.price > ll.price) { f.pdPos = Math.min(1.5, Math.max(-0.5, (c[last] - ll.price) / (lh.price - ll.price))); f.discount = f.pdPos < 0.5; f.premium = f.pdPos > 0.5; }

    // ---- divergence ----
    const pivC = piv.filter((p) => p.conf <= last);
    const dR = S.divergence(pivC, rsi, n), dM = S.divergence(pivC, mac.hist, n), dO = S.divergence(pivC, obv, n);
    f.rsiDivBull = dR.bull; f.rsiDivBear = dR.bear; f.macdDivBull = dM.bull; f.macdDivBear = dM.bear; f.pvDivBull = dO.bull; f.pvDivBear = dO.bear;

    // anchored VWAP from last major swing low
    const anchor = [...pivC].reverse().find((p) => p.type === 'L' && last - p.i >= 5);
    if (anchor) { const av = I.avwap(h, l, c, v, anchor.i); f.avwap = av[last]; f.aboveAvwap = c[last] > av[last]; se.avwap = av; se.avwapFrom = anchor.i; }

    // trend strength composite
    f.trendStrength = Math.round(Math.max(0, Math.min(100, (f.emaStackBull ? 35 : f.aboveEma50 ? 18 : 0) + Math.min(30, (f.adx || 0)) * (f.diBull ? 1 : 0.3) + (f.hhhl ? 20 : f.swingTrend === 0 ? 8 : 0) + (f.sma200Rising ? 15 : 0))));

    // ---- BEI limits for the next session ----
    const lim = R.A ? R.A.limits(c[last]) : null; const limPrev = R.A ? R.A.limits(c[last - 1]) : null;
    if (lim) { f.ara = lim.ara; f.arb = lim.arb; }
    if (limPrev && !intraday) { f.atAra = c[last] >= limPrev.ara; f.atArb = c[last] <= limPrev.arb; f.distAraPrev = ((limPrev.ara - c[last]) / c[last]) * 100; }

    // ---- daily-only: performance, 52w ----
    if (opts.daily) {
      const perf = (k) => (n > k ? ((c[last] - c[last - k]) / c[last - k]) * 100 : NaN);
      f.perf1d = perf(1); f.perf1w = perf(5); f.perf1m = perf(21); f.perf3m = perf(63); f.perf6m = perf(126); f.perf1y = perf(250);
      const k52 = Math.min(n - 1, 250); const hi52 = Math.max(...h.slice(-k52 - 1, -1)), lo52 = Math.min(...l.slice(-k52 - 1, -1));
      f.hi52 = Math.max(hi52, h[last]); f.lo52 = Math.min(lo52, l[last]);
      f.newHigh52 = h[last] > hi52; f.newLow52 = l[last] < lo52;
      f.dist52wHigh = ((f.hi52 - c[last]) / f.hi52) * 100; f.dist52wLow = ((c[last] - f.lo52) / f.lo52) * 100;
      f.rsRaw = 0.4 * (perf(63) || 0) + 0.2 * (perf(126) || 0) + 0.2 * (perf(189) || 0) + 0.2 * (perf(250) || 0);
      if (opts.ihsg && opts.ihsg.c.length > 130) {
        const ic = opts.ihsg.c, il = ic.length - 1; const ip = (k) => ((ic[il] - ic[il - k]) / ic[il - k]) * 100;
        f.rsIhsg1m = f.perf1m - ip(21); f.rsIhsg3m = f.perf3m - ip(63); f.rsIhsg6m = f.perf6m - ip(126);
      }
    }
    return { n, f, fp, se, st: { piv, ev, fvg: fv, obs, levels: lv, sweeps, eqH, eqL, vp, brk, bdn, rt, sw, nearBull, anchor } };
  };

  // Resample daily → weekly
  F.toWeekly = (cd) => {
    const out = { t: [], o: [], h: [], l: [], c: [], v: [] }; let wk = null;
    for (let i = 0; i < cd.t.length; i++) {
      const d = new Date((cd.t[i] + 7 * 3600) * 1000); const day = (d.getUTCDay() + 6) % 7; const monday = Math.floor((cd.t[i] + 7 * 3600) / 86400) - day;
      if (monday !== wk) { wk = monday; out.t.push(cd.t[i]); out.o.push(cd.o[i]); out.h.push(cd.h[i]); out.l.push(cd.l[i]); out.c.push(cd.c[i]); out.v.push(cd.v[i]); }
      else { const k = out.t.length - 1; out.h[k] = Math.max(out.h[k], cd.h[i]); out.l[k] = Math.min(out.l[k], cd.l[i]); out.c[k] = cd.c[i]; out.v[k] += cd.v[i]; }
    }
    return out;
  };

  R.F = F;
})((typeof window !== 'undefined' ? window : global).RB);
