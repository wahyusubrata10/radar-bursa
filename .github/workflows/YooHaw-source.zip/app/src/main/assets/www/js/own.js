/* Yoo Haw — ownership (KSEI ≥1% shareholders, published monthly by BEI), month-over-month changes, investor network. */
(function (R) {
  const { D } = R; const O = { months: [], cur: null, prev: null, loading: false, err: null, source: null };
  const TYPES = { CP: 'Korporasi', ID: 'Individu', IB: 'Bank/institusi', MF: 'Reksa dana', SC: 'Sekuritas', IS: 'Asuransi', PF: 'Dana pensiun', FD: 'Yayasan', OT: 'Lainnya' };
  O.TYPES = TYPES;

  // ---------- PDF parsing (layout used by KSEI: DATE | SHARE_CODE | ISSUER | INVESTOR | TYPE | L/A | NATIONALITY | DOMICILE | SCRIPLESS | SCRIP | TOTAL | %) ----------
  const DATE = /^\d{1,2}-[A-Za-z]{3}-\d{4}$/, CODE = /^[A-Z0-9]{4}$/, NUM = /^[\d.]+$/, PCT = /^\d+([.,]\d+)?$/, TYP = /^(CP|ID|IB|MF|SC|IS|PF|FD|OT)$/, LF = /^[LA]$/;
  O.parseItems = (pages) => {
    const rows = []; let last = null;
    for (const items of pages) {
      // group text items into lines by y
      const lines = []; for (const it of items.slice().sort((a, b) => b.y - a.y || a.x - b.x)) { const l = lines[lines.length - 1]; if (l && Math.abs(l.y - it.y) <= 1.6) l.items.push(it); else lines.push({ y: it.y, items: [it] }); }
      // column anchors on this page: investor-name start = most common x of the first name-like item after the issuer
      const xs = {}; for (const l of lines) { const its = l.items.sort((a, b) => a.x - b.x); if (!DATE.test(its[0].s)) continue; for (const it of its) if (it.x > 120 && it.x < 330 && !TYP.test(it.s)) { const k = Math.round(it.x / 4) * 4; xs[k] = (xs[k] || 0) + 1; } }
      const xInv = +Object.entries(xs).sort((a, b) => b[1] - a[1])[0]?.[0] || 165;
      const tx = []; for (const l of lines) for (const i of l.items) if (TYP.test(i.s.trim()) && i.x > xInv + 80) tx.push(i.x); tx.sort((a, b) => a - b);
      const xType = tx.length ? tx[Math.floor(tx.length / 2)] : 430;
      for (const l of lines) {
        const its = l.items.sort((a, b) => a.x - b.x); const toks = its.map((i) => i.s.trim()).filter(Boolean);
        if (!toks.length || /^DATE$/.test(toks[0])) continue;
        if (DATE.test(toks[0]) && CODE.test(toks[1] || '')) {
          const nums = its.filter((i) => NUM.test(i.s.trim()) && i.x > 590); const pct = its[its.length - 1];
          if (!PCT.test(pct.s.trim()) || nums.length < 3) { last = null; continue; }
          const band = (lo, hi) => its.filter((i, k) => k > 1 && i.x >= lo && i.x < hi);
          const issuer = band(0, xInv - 2).map((i) => i.s.trim()).join(' '), investor = band(xInv - 2, xType - 8).map((i) => i.s.trim()).join(' ');
          const tI = its.find((i) => Math.abs(i.x - xType) < 12 && TYP.test(i.s.trim())); const lfI = its.find((i) => i.x > xType + 15 && i.x < xType + 55 && LF.test(i.s.trim()));
          const rest = its.filter((i) => i.x >= xType + 55 && i.x < 600 && !NUM.test(i.s.trim()));
          const dom = rest.filter((i) => i.x >= 545).map((i) => i.s.trim()).join(' '), nat = rest.filter((i) => i.x < 545).map((i) => i.s.trim()).join(' ');
          const n = (x) => +x.replace(/\./g, '');
          last = { d: toks[0], code: toks[1], issuer, inv: investor, type: tI ? tI.s.trim() : '', lf: lfI ? lfI.s.trim() : '', nat, dom, shares: n(nums[nums.length - 1].s.trim()), pct: +pct.s.trim().replace(',', '.') };
          rows.push(last);
        } else if (last && its[0].x > 60) { // wrapped continuation of a long name
          for (const i of its) { if (i.x >= xInv - 2 && i.x < xInv + 240) last.inv += ' ' + i.s.trim(); else if (i.x < xInv - 2) last.issuer += ' ' + i.s.trim(); }
        }
      }
    }
    return rows;
  };
  O.parsePdf = async (buf, onProg) => {
    const pdfjs = window.pdfjsLib; if (!pdfjs) throw new Error('Pembaca PDF tidak tersedia');
    if (!pdfjs.GlobalWorkerOptions.workerSrc) pdfjs.GlobalWorkerOptions.workerSrc = 'js/pdf.worker.min.js';
    const doc = await pdfjs.getDocument({ data: new Uint8Array(buf), isEvalSupported: false }).promise; const pages = [];
    for (let p = 1; p <= doc.numPages; p++) { const pg = await doc.getPage(p); const tc = await pg.getTextContent(); pages.push(tc.items.filter((i) => i.str && i.str.trim()).map((i) => ({ s: i.str, x: i.transform[4], y: i.transform[5] }))); onProg && onProg(p, doc.numPages); }
    return O.parseItems(pages);
  };
  O.parseCsv = (txt) => {
    const lines = txt.trim().split(/\r?\n/); const head = lines.shift().split(',').map((h) => h.trim().toLowerCase()); const ix = (k) => head.indexOf(k);
    const split = (l) => { const out = []; let cur = '', q = false; for (const ch of l) { if (ch === '"') q = !q; else if (ch === ',' && !q) { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out; };
    return lines.map((l) => { const c = split(l); return { d: c[ix('date')], code: c[ix('share_code')], issuer: c[ix('issuer_name')], inv: c[ix('investor_name')], type: c[ix('investor_type')], lf: c[ix('local_foreign')], nat: c[ix('nationality')], dom: c[ix('domicile')], shares: +c[ix('total_holding_shares')], pct: +c[ix('percentage')] }; }).filter((r) => r.code && r.pct > 0);
  };

  // ---------- discovery of the monthly file ----------
  const IDX = ['https://www.idx.co.id', 'https://www.idx.id'];
  const findPdfs = (obj, out = []) => {
    if (typeof obj === 'string') { if (/\.pdf(\?|$)/i.test(obj)) out.push(obj); return out; }
    if (Array.isArray(obj)) { obj.forEach((x) => findPdfs(x, out)); return out; }
    if (obj && typeof obj === 'object') for (const k in obj) findPdfs(obj[k], out); return out;
  };
  O.discover = async () => {
    const cands = [];
    for (const base of IDX) {
      const urls = [
        `${base}/primary/ListedCompany/GetAnnouncement?kodeEmiten=&emitenType=*&indexFrom=0&pageSize=20&dateFrom=&dateTo=&lang=id&keyword=${encodeURIComponent('Pemegang Saham di atas 1%')}`,
        `${base}/primary/NewsAnnouncement/GetAllAnnouncement?keywords=${encodeURIComponent('Pemegang Saham di atas 1%')}&pageNumber=1&pageSize=20&lang=id`,
      ];
      for (const u of urls) { try { const j = await D.get(u); const reps = (j && (j.Replies || j.Items || j.data || j.Results)) || [];
        const list = Array.isArray(reps) ? reps : []; for (const r of list) { const txt = JSON.stringify(r); if (!/di atas 1|above 1%|1 persen/i.test(txt)) continue; const dt = (txt.match(/20\d\d-\d\d-\d\dT[\d:]+/) || [''])[0]; for (const p of findPdfs(r)) cands.push({ url: p.startsWith('http') ? p : base + p, dt }); } } catch (e) {} }
      if (cands.length) break;
    }
    // newest first; prefer data attachments over the exchange cover page
    cands.sort((a, b) => (b.dt || '').localeCompare(a.dt || '') || (/persen|dks|kepemilikan/i.test(b.url) - /persen|dks|kepemilikan/i.test(a.url)));
    return cands;
  };
  const GH = 'https://api.github.com/repos/aryakdaniswara/idx-stock-ownership/contents/data';
  O.loadFromGithub = async () => {
    const list = await D.get(GH); const f = list.filter((x) => /\.csv$/.test(x.name)).sort((a, b) => b.name.localeCompare(a.name))[0]; if (!f) throw new Error('Dataset cadangan kosong');
    return { rows: O.parseCsv(await D.get(f.download_url, 'text')), src: 'Dataset publik KSEI (GitHub, cadangan)' };
  };

  // ---------- storage & loading ----------
  const monthKey = (rows) => { const d = rows[0] && rows[0].d; const t = Date.parse(d); return isNaN(t) ? d : new Date(t).toISOString().slice(0, 10); };
  O.save = async (rows, src) => { const k = monthKey(rows); const idx = D.lsGet('rb.ownIdx', []); if (!idx.includes(k)) { idx.push(k); idx.sort(); } D.lsSet('rb.ownIdx', idx.slice(-6)); await D.cacheSet('own|' + k, { rows, src }); return k; };
  O.load = async ({ force, onProg } = {}) => {
    if (O.loading) return; O.loading = true; O.err = null;
    try {
      if (D.settings.provider === 'demo') throw new Error('Data kepemilikan hanya diambil di aplikasi Android');
      const idx = D.lsGet('rb.ownIdx', []); const lastCheck = D.lsGet('rb.ownCheck', 0);
      if (force || !idx.length || Date.now() - lastCheck > 3 * 864e5) {
        D.lsSet('rb.ownCheck', Date.now()); let got = false;
        try { const c = await O.discover(); onProg && onProg('Mengunduh data kepemilikan dari BEI…');
          for (const x of c.slice(0, 6)) { try { const buf = await D.get(x.url, 'buf'); const rows = await O.parsePdf(buf, (p, n) => onProg && onProg(`Membaca PDF halaman ${p}/${n}`)); if (rows.length > 500) { await O.save(rows, 'KSEI via BEI (PDF resmi)'); got = true; break; } } catch (e) {} } } catch (e) {}
        if (!got && !idx.length) { try { const g = await O.loadFromGithub(); await O.save(g.rows, g.src); } catch (e) {} }
      }
      await O.useLatest();
      if (!O.cur) throw new Error('Data kepemilikan belum bisa diambil. Unduh PDF "Pemegang Saham di atas 1% (KSEI)" dari idx.co.id lalu impor lewat tombol Impor.');
    } catch (e) { O.err = e.message; } finally { O.loading = false; }
  };
  O.useLatest = async () => {
    const idx = D.lsGet('rb.ownIdx', []); if (!idx.length) return;
    const a = await D.cacheGet('own|' + idx[idx.length - 1], 1e12); const b = idx.length > 1 ? await D.cacheGet('own|' + idx[idx.length - 2], 1e12) : null;
    if (a) { O.cur = O.build(a.rows, idx[idx.length - 1]); O.source = a.src; } if (b) O.prev = O.build(b.rows, idx[idx.length - 2]);
  };
  O.importFile = async (file) => {
    const buf = await file.arrayBuffer(); const rows = /\.csv$/i.test(file.name) ? O.parseCsv(new TextDecoder().decode(buf)) : await O.parsePdf(buf);
    if (rows.length < 100) throw new Error('File tidak dikenali sebagai data kepemilikan KSEI'); const k = await O.save(rows, 'Impor manual: ' + file.name); await O.useLatest(); return k;
  };

  // ---------- aggregation ----------
  const norm = (s) => (s || '').toUpperCase().replace(/[.,]/g, ' ').replace(/\b(PT|TBK|LTD|LIMITED|INC|CORP|CO|PTE|THE)\b/g, ' ').replace(/\s+/g, ' ').trim();
  O.norm = norm;
  O.build = (rows, date) => {
    const byCode = new Map(), byInv = new Map(), issuerToCode = new Map();
    for (const r of rows) {
      r.key = norm(r.inv); (byCode.get(r.code) || byCode.set(r.code, []).get(r.code)).push(r); (byInv.get(r.key) || byInv.set(r.key, { name: r.inv, type: r.type, lf: r.lf, rows: [] }).get(r.key)).rows.push(r);
      issuerToCode.set(norm(r.issuer), r.code);
    }
    for (const arr of byCode.values()) arr.sort((a, b) => b.pct - a.pct);
    // investor that is itself a listed company → its ticker (e.g. "SARATOGA INVESTAMA SEDAYA TBK PT" → SRTG)
    for (const [k, v] of byInv) v.code = issuerToCode.get(k) || null;
    return { date, rows, byCode, byInv };
  };
  O.stock = (code) => {
    if (!O.cur) return null; const rows = O.cur.byCode.get(code) || []; const prevRows = O.prev ? O.prev.byCode.get(code) || [] : null;
    const sum = (a, f) => a.reduce((s, x) => s + (f ? (f(x) ? x.pct : 0) : x.pct), 0);
    const byType = {}; for (const r of rows) byType[r.type] = (byType[r.type] || 0) + r.pct;
    const big5 = sum(rows, (r) => r.pct >= 5);
    const out = { rows, total1: sum(rows), foreign: sum(rows, (r) => r.lf === 'A'), local: sum(rows, (r) => r.lf === 'L'), byType, big5, floatEst: Math.max(0, 100 - big5), changes: [] };
    if (prevRows) {
      const pm = new Map(prevRows.map((r) => [r.key || norm(r.inv), r])); const cm = new Map(rows.map((r) => [r.key, r]));
      for (const r of rows) { const p = pm.get(r.key); if (!p) out.changes.push({ r, kind: 'baru', d: r.pct }); else if (Math.abs(r.pct - p.pct) >= 0.01) out.changes.push({ r, kind: r.pct > p.pct ? 'tambah' : 'kurang', d: r.pct - p.pct, dShares: r.shares - p.shares }); }
      for (const p of prevRows) if (!cm.has(p.key || norm(p.inv))) out.changes.push({ r: p, kind: 'keluar', d: -p.pct });
      out.changes.sort((a, b) => Math.abs(b.d) - Math.abs(a.d));
    }
    return out;
  };
  // market-wide month-over-month movers (who is accumulating / exiting)
  O.marketChanges = () => {
    if (!O.cur || !O.prev) return [];
    const out = []; for (const code of O.cur.byCode.keys()) { const s = O.stock(code); for (const c of s.changes) out.push(Object.assign({ code }, c)); }
    return out.sort((a, b) => Math.abs(b.d) - Math.abs(a.d));
  };
  O.investor = (key) => O.cur && O.cur.byInv.get(key);
  O.search = (q) => {
    if (!O.cur) return []; const Q = norm(q); if (Q.length < 2) return [];
    const res = []; for (const [k, v] of O.cur.byInv) if (k.includes(Q)) res.push({ key: k, name: v.name, n: v.rows.length, type: v.type, lf: v.lf });
    return res.sort((a, b) => b.n - a.n).slice(0, 40);
  };
  // ego network around a stock or investor (depth 2), capped for readability
  O.network = (center, kind, cap = 36) => {
    const nodes = new Map(), links = []; const addN = (id, label, type, extra) => { if (!nodes.has(id)) nodes.set(id, Object.assign({ id, label, type }, extra || {})); return nodes.get(id); };
    if (!O.cur) return { nodes: [], links: [] };
    const stockNode = (code) => addN('S:' + code, code, 'stock'); const invNode = (k) => { const v = O.cur.byInv.get(k); return addN('I:' + k, v ? v.name : k, v && v.code ? 'company' : v && v.type === 'ID' ? 'person' : 'inv', { code: v && v.code, itype: v && v.type, lf: v && v.lf }); };
    const visitStock = (code, depth) => { const rows = (O.cur.byCode.get(code) || []).slice(0, depth === 0 ? 14 : 5); stockNode(code); for (const r of rows) { if (nodes.size >= cap) break; invNode(r.key); links.push({ a: 'I:' + r.key, b: 'S:' + code, w: r.pct }); if (depth === 0) visitInv(r.key, 1); } };
    const visitInv = (key, depth) => { const v = O.cur.byInv.get(key); if (!v) return; invNode(key); const rows = v.rows.slice().sort((a, b) => b.pct - a.pct).slice(0, depth === 0 ? 16 : 5); for (const r of rows) { if (nodes.size >= cap) break; stockNode(r.code); links.push({ a: 'I:' + key, b: 'S:' + r.code, w: r.pct }); if (depth === 0) visitStock(r.code, 1); } if (v.code) { stockNode(v.code); links.push({ a: 'I:' + key, b: 'S:' + v.code, w: 100, same: true }); } };
    if (kind === 'stock') visitStock(center, 0); else visitInv(center, 0);
    const uniq = new Map(); for (const l of links) { const k = l.a + '>' + l.b; if (!uniq.has(k) && nodes.has(l.a) && nodes.has(l.b)) uniq.set(k, l); }
    return { nodes: [...nodes.values()], links: [...uniq.values()] };
  };
  R.O = O;
})((typeof window !== 'undefined' ? window : global).RB);
