/* Yoo Haw — morning brief, evening recap and the background job runner (?job=morning|evening|alerts). */
(function (R) {
  const { D, A, I, E, M, X, PK, AL, TG, N } = R; const ok = I.ok; const JB = {};
  const pct = (x, d = 2) => (ok(x) ? `${x >= 0 ? '+' : '−'}${Math.abs(x).toFixed(d).replace('.', ',')}%` : '—');
  const esc = (s) => TG.esc(s); const today = () => new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10);
  const say = (title, body, target) => { try { window.AndroidBridge && window.AndroidBridge.notifyTo ? window.AndroidBridge.notifyTo(title, body, target) : window.AndroidBridge && window.AndroidBridge.notify(title, body); } catch (e) {} };

  // ---------------- morning brief ----------------
  JB.brief = () => {
    if (!E.snap) return null; const reg = M.regime; const v = PK.verdict(); const all = PK.all();
    const pass = all.filter((s) => s.pickCat !== 'risk' && PK.passes(s));
    const g = (sym) => M.get(sym); const sp = g('Y:^GSPC'), eido = g('Y:EIDO'), idr = g('Y:IDR=X');
    const overnight = [sp && `S&P 500 ${pct(sp.p1d)}`, eido && `EIDO ${pct(eido.p1d)}`, idr && `USD/IDR ${pct(idr.p1d)}`].filter(Boolean).join(' · ');
    const items = (pass.length ? pass : all.filter((s) => s.pickCat !== 'risk')).slice(0, 30).map((s) => { const pl = PK.plain(s); return { sym: s.sym, type: s.plan.type, score: s.f.score, entry: s.plan.entry, invalid: s.plan.invalid, t1: s.plan.targets[0], reason: pl.reasons[0] || '', risk: pl.risk, pass: PK.passes(s) }; });
    const ih = E.snap.ihsg.cd, L = ih.c.length - 1;
    const b = { t: Date.now(), date: today(), regime: reg ? { score: reg.score, label: reg.label } : null, ihsg: { c: ih.c[L], chg: ((ih.c[L] - ih.c[L - 1]) / ih.c[L - 1]) * 100 }, overnight, verdict: v, items, nPass: pass.length };
    b.title = v.noBuy ? `Picks pagi · Hari ini lebih baik tidak beli` : `Picks pagi · ${pass.length} kandidat · pasar ${reg ? reg.label.toLowerCase() : '—'}`;
    b.body = v.noBuy ? v.text : (pass.length ? `Teratas: ${items.slice(0, 4).map((x) => `${x.sym} (${x.type.split(' (')[0]})`).join(', ')}.` : v.text) + (overnight ? ` Semalam: ${overnight}.` : '');
    return b;
  };
  JB.briefTG = (b) => {
    const lines = [`<b>☀️ Yoo Haw · Picks pagi ${b.date}</b>`, `Kondisi pasar: <b>${esc(b.regime ? b.regime.label : '—')}</b> (${b.regime ? b.regime.score : '—'}/100) · IHSG ${A.fmt(b.ihsg.c)} (${pct(b.ihsg.chg)})`];
    if (b.overnight) lines.push(`Semalam: ${esc(b.overnight)}`); lines.push('');
    if (b.verdict.noBuy) lines.push(`⛔ <b>${esc(b.verdict.text)}</b>`, '');
    b.items.slice(0, 12).forEach((x, i) => lines.push(`${i + 1}. <b>${x.sym}</b> · ${esc(x.type)} · skor ${x.score}${x.pass ? '' : ' (pantau)'}`, `   Entry ${A.fmt(x.entry[0])}–${A.fmt(x.entry[1])} · Invalidasi ${A.fmt(x.invalid)} · T1 ${x.t1 ? A.fmt(x.t1) : '—'}`, `   ✓ ${esc(x.reason)}`, `   ⚠ ${esc(x.risk)}`));
    if (b.items.length > 12) lines.push(`…dan ${b.items.length - 12} kandidat lain di aplikasi.`);
    lines.push('', '<i>Data tertunda/EOD · analisis otomatis berbasis aturan · bukan rekomendasi investasi</i>');
    return lines.join('\n');
  };

  // ---------------- evening recap ----------------
  JB.recap = () => {
    if (!E.snap) return null; const all = [...E.snap.stocks.values()]; const ih = E.snap.ihsg.cd, L = ih.c.length - 1; const ichg = ((ih.c[L] - ih.c[L - 1]) / ih.c[L - 1]) * 100;
    const up = all.filter((x) => x.f.chg1d > 0).length, dn = all.filter((x) => x.f.chg1d < 0).length;
    const g = all.slice().sort((a, b) => b.f.chg1d - a.f.chg1d); const secs = E.snap.sectors.slice().sort((a, b) => b.p1d - a.p1d);
    const flow = all.map((s) => { const tf = X.tradeFlow(s.cd, 2); return { sym: s.sym, v: tf.bars[tf.bars.length - 1].delta }; }).sort((a, b) => b.v - a.v);
    const ff = X.ff ? { net: X.ff.market[X.ff.market.length - 1].net, d: X.ff.asOf } : null;
    const port = E.P.list().map((p) => { const s = E.getStock(p.sym); if (!s) return null; const a = E.P.assess(s, p); return { sym: p.sym, action: a.action, tone: a.tone, chg: s.f.chg1d, rp: p.lots ? s.f.close * p.lots * 100 * (s.f.chg1d / (100 + s.f.chg1d)) : NaN }; }).filter(Boolean);
    const portRp = port.reduce((a, x) => a + (ok(x.rp) ? x.rp : 0), 0);
    const wl = D.lsGet('rb.watch', []).map((sym) => E.getStock(sym)).filter(Boolean).sort((a, b) => Math.abs(b.f.chg1d) - Math.abs(a.f.chg1d)).slice(0, 5).map((s) => ({ sym: s.sym, chg: s.f.chg1d }));
    const br = D.lsGet('rb.brief', null); const morning = br && br.date === today() ? br.items.slice(0, 8).map((x) => { const s = E.getStock(x.sym); return s ? { sym: x.sym, chg: s.f.chg1d } : null; }).filter(Boolean) : [];
    const tomorrow = all.filter((s) => s.plan.bias > 0 && s.plan.type.startsWith('Early') && E.pickPass(s)).slice(0, 4).map((s) => s.sym);
    const nearAlerts = AL.active().map((a) => { const s = E.getStock(a.sym); if (!s) return null; const d = ((a.price - s.f.close) / s.f.close) * 100; return Math.abs(d) <= 2 ? { sym: a.sym, op: a.op, price: a.price, d } : null; }).filter(Boolean);
    const r = { t: Date.now(), date: today(), ihsg: { c: ih.c[L], chg: ichg }, up, dn, gainers: g.slice(0, 3).map((s) => ({ sym: s.sym, chg: s.f.chg1d })), losers: g.slice(-3).reverse().map((s) => ({ sym: s.sym, chg: s.f.chg1d })),
      bestSec: secs[0] && { name: secs[0].name, chg: secs[0].p1d }, worstSec: secs[secs.length - 1] && { name: secs[secs.length - 1].name, chg: secs[secs.length - 1].p1d }, inflow: flow.slice(0, 3), outflow: flow.slice(-3).reverse(), ff, port, portRp, wl, morning, tomorrow, nearAlerts, regime: M.regime ? { score: M.regime.score, label: M.regime.label } : null };
    const act = port.filter((x) => x.tone === 'dn');
    r.title = `Rangkuman sore · IHSG ${pct(ichg)}`;
    r.body = `${up} naik, ${dn} turun. Terbaik: ${r.gainers.map((x) => `${x.sym} ${pct(x.chg, 1)}`).join(', ')}.${port.length ? ` Portofolio: ${ok(portRp) && portRp ? A.fmtRp(portRp) + ' hari ini' : port.length + ' posisi'}${act.length ? `, perlu tindakan: ${act.map((x) => x.sym).join(', ')}` : ''}.` : ''}`;
    return r;
  };
  JB.recapTG = (r) => {
    const L = [`<b>🌇 Yoo Haw · Rangkuman ${r.date}</b>`, `IHSG ${A.fmt(r.ihsg.c)} (<b>${pct(r.ihsg.chg)}</b>) · ${r.up} naik / ${r.dn} turun${r.regime ? ` · pasar ${esc(r.regime.label.toLowerCase())}` : ''}`,
      `Sektor terbaik: ${esc(r.bestSec ? r.bestSec.name : '—')} ${r.bestSec ? pct(r.bestSec.chg, 1) : ''} · terburuk: ${esc(r.worstSec ? r.worstSec.name : '—')} ${r.worstSec ? pct(r.worstSec.chg, 1) : ''}`, '',
      `📈 Naik: ${r.gainers.map((x) => `${x.sym} ${pct(x.chg, 1)}`).join(', ')}`, `📉 Turun: ${r.losers.map((x) => `${x.sym} ${pct(x.chg, 1)}`).join(', ')}`,
      `💰 Inflow: ${r.inflow.map((x) => `${x.sym} ${esc(A.fmtRp(x.v))}`).join(', ')}`, `💸 Outflow: ${r.outflow.map((x) => `${x.sym} ${esc(A.fmtRp(x.v))}`).join(', ')}`];
    if (r.ff) L.push(`🌏 Asing ${r.ff.d.slice(6)}/${r.ff.d.slice(4, 6)}: ${esc(A.fmtRp(r.ff.net))}`);
    if (r.port.length) { L.push('', `<b>Portofolio</b>${r.portRp ? ` (${esc(A.fmtRp(r.portRp))} hari ini)` : ''}`); r.port.forEach((x) => L.push(`• ${x.sym} ${pct(x.chg, 1)} — ${esc(x.action)}`)); }
    if (r.morning.length) L.push('', `Picks pagi tadi: ${r.morning.map((x) => `${x.sym} ${pct(x.chg, 1)}`).join(', ')}`);
    if (r.wl.length) L.push(`Watchlist: ${r.wl.map((x) => `${x.sym} ${pct(x.chg, 1)}`).join(', ')}`);
    if (r.tomorrow.length || r.nearAlerts.length) L.push('', '<b>Pantau besok</b>');
    if (r.tomorrow.length) L.push(`Calon breakout: ${r.tomorrow.join(', ')}`);
    r.nearAlerts.forEach((a) => L.push(`🔔 ${a.sym} tinggal ${Math.abs(a.d).toFixed(1).replace('.', ',')}% dari alert ${a.op === '<=' ? '≤' : '≥'} ${A.fmt(a.price)}`));
    L.push('', '<i>Data tertunda/EOD · bukan rekomendasi investasi</i>'); return L.join('\n');
  };

  // ---------------- jobs ----------------
  JB.run = async (job, scan) => {
    if (job === 'alerts') { const w = D.wib(); if (!(w.day >= 1 && w.day <= 5 && w.min >= 540 && w.min <= 975)) return; if (!AL.needsBackground()) return; await AL.check(); return; }
    await scan();
    try { await M.load({ force: true }); } catch (e) {}
    if (job === 'morning') {
      try { await PK.loadEvidence(); if (PK.evidenceStale()) await PK.buildEvidence(); } catch (e) {}
      const b = JB.brief(); if (!b) return; D.lsSet('rb.brief', b); say(b.title, b.body, 'picks');
      if (TG.on('pagi')) { try { await TG.send(JB.briefTG(b)); } catch (e) {} }
    }
    if (job === 'evening') {
      try { await X.loadForeign({ days: 30 }); } catch (e) {}
      E.logPicks();
      const r = JB.recap(); if (!r) return; D.lsSet('rb.recap', r); say(r.title, r.body, 'recap');
      if (TG.on('sore')) { try { await TG.send(JB.recapTG(r)); } catch (e) {} }
    }
  };
  R.JB = JB;
})((typeof window !== 'undefined' ? window : global).RB);
