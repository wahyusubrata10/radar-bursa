/* Yoo Haw — market structure & smart-money concepts (rule-based, deterministic). */
(function (R) {
  const S = {};
  const I = R.I;
  // Detector parameters (editable from Screener → Pengaturan detektor)
  R.PDEF = { pivotLen: 3, fvgMinAtr: 0.15, fvgRecent: 3, fvgLookback: 120, bosRecent: 5, sweepLookback: 40, sweepRecent: 3, obLookback: 12, dispAtr: 1.3,
    boVol: 1.3, boRecent: 3, retestWin: 15, eqTol: 0.15, sqzPctl: 20, divRecent: 15, rsiLen: 14, rvolLen: 20, volSpike: 2 };
  let saved = {}; try { saved = JSON.parse(localStorage.getItem('rb.params') || '{}'); } catch (e) {}
  R.P = Object.assign({}, R.PDEF, saved);
  const P = () => R.P;

  // Confirmed fractal pivots. A pivot at i is only known at i+right (no look-ahead).
  S.pivots = (h, l, left = 3, right = 3) => {
    const out = [];
    for (let i = left; i < h.length - right; i++) {
      let isH = true, isL = true;
      for (let j = i - left; j <= i + right; j++) {
        if (j === i) continue;
        if (j < i ? h[j] >= h[i] : h[j] > h[i]) isH = false;
        if (j < i ? l[j] <= l[i] : l[j] < l[i]) isL = false;
      }
      if (isH) out.push({ i, type: 'H', price: h[i], conf: i + right });
      if (isL) out.push({ i, type: 'L', price: l[i], conf: i + right });
    }
    // label HH/LH/HL/LL
    let lastH = null, lastL = null;
    for (const p of out) {
      if (p.type === 'H') { p.label = lastH ? (p.price > lastH.price ? 'HH' : 'LH') : 'H'; lastH = p; }
      else { p.label = lastL ? (p.price > lastL.price ? 'HL' : 'LL') : 'L'; lastL = p; }
    }
    return out;
  };

  S.swingTrend = (piv) => {
    const hs = piv.filter((p) => p.type === 'H').slice(-2), ls = piv.filter((p) => p.type === 'L').slice(-2);
    if (hs.length < 2 || ls.length < 2) return { trend: 0, label: 'Belum jelas' };
    const hh = hs[1].price > hs[0].price, hl = ls[1].price > ls[0].price;
    if (hh && hl) return { trend: 1, label: 'Uptrend (HH + HL)' };
    if (!hh && !hl) return { trend: -1, label: 'Downtrend (LH + LL)' };
    return { trend: 0, label: hh ? 'Transisi (HH + LL)' : 'Sideways (LH + HL)' };
  };

  // BOS / CHoCH from close breaking last confirmed swing
  S.bosChoch = (c, piv) => {
    const ev = []; let trend = 0, sh = null, sl = null, k = 0;
    const byConf = [...piv].sort((a, b) => a.conf - b.conf);
    for (let i = 0; i < c.length; i++) {
      while (k < byConf.length && byConf[k].conf <= i) { const p = byConf[k++]; if (p.type === 'H') sh = { ...p, broken: false }; else sl = { ...p, broken: false }; }
      if (sh && !sh.broken && c[i] > sh.price) { ev.push({ i, dir: 1, type: trend === -1 ? 'CHoCH' : 'BOS', level: sh.price, from: sh.i }); sh.broken = true; trend = 1; }
      if (sl && !sl.broken && c[i] < sl.price) { ev.push({ i, dir: -1, type: trend === 1 ? 'CHoCH' : 'BOS', level: sl.price, from: sl.i }); sl.broken = true; trend = -1; }
    }
    return { events: ev, trend };
  };

  // Fair value gaps with mitigation tracking
  S.fvg = (h, l, c, atr, minAtr) => {
    if (minAtr === undefined) minAtr = P().fvgMinAtr;
    return fvgImpl(h, l, c, atr, minAtr);
  };
  const fvgImpl = (h, l, c, atr, minAtr) => {
    const out = [];
    for (let i = 2; i < c.length; i++) {
      const a = atr[i] || 0;
      if (l[i] > h[i - 2] && l[i] - h[i - 2] >= minAtr * a) out.push({ i, dir: 1, lo: h[i - 2], hi: l[i], status: 'open' });
      if (h[i] < l[i - 2] && l[i - 2] - h[i] >= minAtr * a) out.push({ i, dir: -1, lo: h[i], hi: l[i - 2], status: 'open' });
    }
    for (const g of out) {
      for (let j = g.i + 1; j < c.length; j++) {
        if (g.dir === 1) { if (l[j] <= g.lo) { g.status = 'filled'; g.fillI = j; break; } if (l[j] <= g.hi && g.status === 'open') { g.status = 'partial'; g.touchI = j; } }
        else { if (h[j] >= g.hi) { g.status = 'filled'; g.fillI = j; break; } if (h[j] >= g.lo && g.status === 'open') { g.status = 'partial'; g.touchI = j; } }
      }
    }
    return out;
  };

  S.displacement = (o, h, l, c, atr, i) => {
    const body = Math.abs(c[i] - o[i]), rng = h[i] - l[i];
    if (!atr[i] || rng === 0) return 0;
    if (body >= P().dispAtr * atr[i] && body / rng >= 0.6) return c[i] > o[i] ? 1 : -1;
    return 0;
  };

  // Order blocks: last opposite candle before the impulse that produced a BOS/CHoCH
  S.orderBlocks = (o, h, l, c, events) => {
    const out = [];
    for (const e of events) {
      for (let k = e.i - 1; k >= Math.max(0, e.i - P().obLookback); k--) {
        if (e.dir === 1 && c[k] < o[k]) { out.push({ i: k, dir: 1, lo: l[k], hi: Math.max(o[k], c[k]), from: e }); break; }
        if (e.dir === -1 && c[k] > o[k]) { out.push({ i: k, dir: -1, lo: Math.min(o[k], c[k]), hi: h[k], from: e }); break; }
      }
    }
    for (const b of out) {
      b.status = 'fresh';
      for (let j = b.from.i + 1; j < c.length; j++) {
        if (b.dir === 1) { if (c[j] < b.lo) { b.status = 'breaker'; b.breakI = j; break; } if (l[j] <= b.hi) b.status = 'mitigated'; }
        else { if (c[j] > b.hi) { b.status = 'breaker'; b.breakI = j; break; } if (h[j] >= b.lo) b.status = 'mitigated'; }
      }
    }
    return out;
  };

  // Support/resistance by clustering pivots (only pivots confirmed before `upto`)
  S.levels = (piv, atrNow, price, upto) => {
    const pts = piv.filter((p) => p.conf <= upto).map((p) => ({ price: p.price, i: p.i }));
    const tol = Math.max(atrNow * 0.5, price * 0.004); const cl = [];
    pts.sort((a, b) => a.price - b.price);
    for (const p of pts) {
      const last = cl[cl.length - 1];
      if (last && p.price - last.max <= tol) { last.members.push(p); last.max = p.price; }
      else cl.push({ members: [p], max: p.price });
    }
    const lv = cl.map((x) => ({ price: x.members.reduce((s, m) => s + m.price, 0) / x.members.length, touches: x.members.length, lastI: Math.max(...x.members.map((m) => m.i)) }));
    return {
      supports: lv.filter((x) => x.price < price).sort((a, b) => b.price - a.price),
      resistances: lv.filter((x) => x.price > price).sort((a, b) => a.price - b.price),
      all: lv,
    };
  };

  S.equalLevels = (piv, atrNow, type) => {
    const ps = piv.filter((p) => p.type === type).slice(-6);
    for (let a = ps.length - 1; a > 0; a--) for (let b = a - 1; b >= 0; b--) if (Math.abs(ps[a].price - ps[b].price) <= P().eqTol * atrNow) return { price: (ps[a].price + ps[b].price) / 2, i1: ps[b].i, i2: ps[a].i };
    return null;
  };

  // Liquidity sweep: wick through a confirmed swing then close back inside
  S.sweeps = (h, l, c, piv, from) => {
    const out = [];
    for (let i = Math.max(from, 1); i < c.length; i++) {
      const swL = piv.filter((p) => p.type === 'L' && p.conf < i && i - p.i <= P().sweepLookback);
      const swH = piv.filter((p) => p.type === 'H' && p.conf < i && i - p.i <= P().sweepLookback);
      for (const p of swL) if (l[i] < p.price && c[i] > p.price && Math.min(...l.slice(p.i + 1, i)) >= p.price) { out.push({ i, dir: 1, level: p.price }); break; }
      for (const p of swH) if (h[i] > p.price && c[i] < p.price && Math.max(...h.slice(p.i + 1, i)) <= p.price) { out.push({ i, dir: -1, level: p.price }); break; }
    }
    return out;
  };

  // Divergence between price pivots and an oscillator
  S.divergence = (piv, osc, n) => {
    const res = { bull: false, bear: false };
    const ls = piv.filter((p) => p.type === 'L').slice(-2), hs = piv.filter((p) => p.type === 'H').slice(-2);
    if (ls.length === 2 && n - 1 - ls[1].i <= P().divRecent && ls[1].price < ls[0].price && osc[ls[1].i] > osc[ls[0].i]) res.bull = true;
    if (hs.length === 2 && n - 1 - hs[1].i <= P().divRecent && hs[1].price > hs[0].price && osc[hs[1].i] < osc[hs[0].i]) res.bear = true;
    return res;
  };

  S.rangeStats = (h, l, end, n) => {
    let hi = -Infinity, lo = Infinity;
    for (let i = Math.max(0, end - n + 1); i <= end; i++) { hi = Math.max(hi, h[i]); lo = Math.min(lo, l[i]); }
    return { hi, lo, pct: ((hi - lo) / lo) * 100 };
  };

  R.S = S;
})((typeof window !== 'undefined' ? window : global).RB);
