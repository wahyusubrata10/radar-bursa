/* Yoo Haw — UI */
(function (R) {
  const { D, E, F, A, I, N, M, B } = R; const ok = I.ok; const Sc = E.Sc, Rd = E.Rd;
  const $ = (s, el = document) => el.querySelector(s);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const px = (x) => A.fmt(x);
  const pct = (x, d = 2) => (ok(x) ? `<span class="${x > 0 ? 'up' : x < 0 ? 'dn' : 'mut'}">${x > 0 ? '+' : ''}${x.toFixed(d)}%</span>` : '<span class="mut">—</span>');
  const num = (x, d = 2) => (ok(x) ? Number(x).toLocaleString('id-ID', { maximumFractionDigits: d, minimumFractionDigits: 0 }) : '—');
  const scoreCls = (s) => (s >= 70 ? 's-hi' : s >= 55 ? 's-md' : 's-lo');
  const fmtField = (k, v) => {
    const d = F.byKey[k]; if (v === true) return 'Ya'; if (v === false) return 'Tidak'; if (!ok(v)) return '—';
    if (!d) return num(v); if (d.u === 'Rp') return Math.abs(v) >= 1e6 ? A.fmtRp(v) : px(v); if (d.u === '%') return `${num(v, 1)}%`; if (d.u === 'x') return `${num(v, 2)}x`; return num(v, 2);
  };
  const toast = (m) => { const t = $('#toast'); t.textContent = m; t.hidden = false; clearTimeout(toast.h); toast.h = setTimeout(() => (t.hidden = true), 2600); };

  const st = { tab: 'market', mkList: 'gain', tree: D.lsGet('rb.lastTree', null) || JSON.parse(JSON.stringify(Sc.PRESETS[0].tree)), presetId: D.lsGet('rb.lastPreset', 'momentum'), sort: 'score', dir: -1, results: null, running: false, pickCat: 'mom', radarView: 'live', radarFilter: 'all', bandarSide: 1, showBuilder: false, showCfg: false, scope: 'all', scrMin: 0, presetTf: 'D' };
  const watch = () => D.lsGet('rb.watch', ['BBCA', 'BBRI', 'TLKM', 'ASII']);
  const setWatch = (w) => D.lsSet('rb.watch', w);

  // ---------------- boot & scan ----------------
  function setProg(p) { $('#prog i').style.width = p == null ? '0' : Math.round(p * 100) + '%'; }
  function updateStatus() {
    const p = $('#statusPill'); const s = E.snap; $('#demoBar').hidden = D.settings.provider !== 'demo';
    if (!s) { p.textContent = E.scanning ? 'Memuat data…' : 'Belum ada data'; p.className = 'pill'; return; }
    const stt = s.status; const ih = s.ihsg.cd; const t = new Date((ih.t[ih.t.length - 1] > (s.ihsg.meta.asOf || 0) ? ih.t[ih.t.length - 1] : s.ihsg.meta.asOf) * 1000 || s.asOf);
    const sameDay = new Date().toDateString() === t.toDateString();
    const lbl = stt === 'simulated' ? 'Simulasi' : stt === 'realtime' ? 'Real-time' : stt === 'eod' ? 'EOD' : `Tertunda${s.ihsg.meta.delayMin ? ` ~${s.ihsg.meta.delayMin} mnt` : ''}`;
    p.textContent = `${lbl} · ${sameDay ? t.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : t.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}`;
    p.className = 'pill ' + (stt === 'simulated' ? 'sim' : stt === 'realtime' ? 'live' : 'delay');
  }
  async function scan(force) {
    if (E.scanning) return; updateStatus(); setProg(0.02);
    try { await E.scan({ force, onProg: (d, n) => { setProg(d / n); spSet && spSet(`Memindai ${d} dari ${n} saham`, 0.1 + 0.85 * (d / n)); } }); if (E.snap.failed) toast(`${E.snap.stocks.size} saham dimuat, ${E.snap.failed} gagal`); }
    catch (e) { toast('Gagal memuat data: ' + e.message); }
    setProg(null); updateStatus(); render();
  }

  // ---------------- tabs ----------------
  document.querySelectorAll('#tabs button').forEach((b) => b.addEventListener('click', () => { st.tab = b.dataset.tab; document.querySelectorAll('#tabs button').forEach((x) => x.classList.toggle('on', x === b)); render(); window.scrollTo(0, 0); }));
  $('#btnRefresh').onclick = () => scan(true);
  $('#btnSearch').onclick = () => openSearch();
  $('#btnSettings').onclick = openSettings; $('#statusPill').onclick = openSettings;
  const view = $('#view');
  function render() { ({ market: rMarket, screener: rScreener, picks: rPicks, news: rNews, radar: rRadar, watch: rWatch }[st.tab])(); }
  const needSnap = () => (E.snap ? '' : `<div class="empty"><b>${E.scanning ? 'Memuat data pasar…' : 'Data belum dimuat'}</b>${E.scanning ? 'Memindai ' + D.universe().length + ' saham.' : '<button class="btn pri" data-act="scan">Muat data</button>'}</div>`);
  view.addEventListener('click', (e) => {
    const ext = e.target.closest('a[data-ext]'); if (ext) { e.preventDefault(); return openExt(ext.href); }
    const ai = e.target.closest('[data-ai]'); if (ai) return runAI(ai.dataset.ai);
    const rd = e.target.closest('[data-read]'); if (rd) return openReader(rd.dataset.read);
    if (e.target.closest('summary')) return;
    const t = e.target.closest('[data-sym],[data-act]'); if (!t) return;
    if (t.dataset.act === 'scan') return scan(true);
    if (t.dataset.act === 'search') return openSearch();
    if (t.dataset.act === 'ihsg') return openStock('^JKSE');
    if (t.dataset.sym && !t.dataset.act) openStock(t.dataset.sym);
  });
  const stockRow = (s, extra) => {
    const f = s.f; return `<button class="row" data-sym="${s.sym}"><span><span class="sym">${s.sym}</span> <span class="chip">${esc(s.plan.type.split(' (')[0].split(' — ')[0])}</span></span>
      <span class="px">${px(f.close)}</span><span class="score ${scoreCls(f.score)}">${f.score}</span>
      <span class="sub">${esc(s.sector)}${extra ? ' · ' + extra : ''}</span><span class="chg">${pct(f.chg1d)}</span><span></span></button>`;
  };

  // ---------------- MARKET ----------------
  let mkChart = null;
  function rMarket() {
    if (!E.snap) { view.innerHTML = needSnap(); return; }
    const s = E.snap, all = [...s.stocks.values()]; const ih = s.ihsg.cd, L = ih.c.length - 1; const ichg = ((ih.c[L] - ih.c[L - 1]) / ih.c[L - 1]) * 100;
    const upN = all.filter((x) => x.f.chg1d > 0).length, dnN = all.filter((x) => x.f.chg1d < 0).length, flat = all.length - upN - dnN;
    const a50 = Math.round((all.filter((x) => x.f.aboveEma50).length / all.length) * 100), a200 = Math.round((all.filter((x) => x.f.aboveEma200).length / all.length) * 100);
    const nh = all.filter((x) => x.f.newHigh52).length, nl = all.filter((x) => x.f.newLow52).length;
    const maxAbs = Math.max(...s.sectors.map((x) => Math.abs(x.p1m)), 1);
    const lists = { gain: ['Top gainer', (a, b) => b.f.chg1d - a.f.chg1d], lose: ['Top loser', (a, b) => a.f.chg1d - b.f.chg1d], rvol: ['RVOL tertinggi', (a, b) => b.f.rvol - a.f.rvol], val: ['Nilai transaksi', (a, b) => b.f.value - a.f.value], score: ['Skor setup', (a, b) => b.f.score - a.f.score] };
    if (s.ffState.status !== 'unavailable') Object.assign(lists, { fbuy: ['Foreign net buy', (a, b) => (b.f.fNet1d || 0) - (a.f.fNet1d || 0)], fsell: ['Foreign net sell', (a, b) => (a.f.fNet1d || 0) - (b.f.fNet1d || 0)] });
    const cur = lists[st.mkList] || lists.gain; const top = all.slice().sort(cur[1]).slice(0, 12);
    if (!M.data && !M.loading && !M.err) M.load().then(() => { if (st.tab === 'market') rMarket(); }).catch((e) => { M.err = e.message; });
    const SC = [['p3m', '3 bln'], ['p1m', '1 bln'], ['p1w', '1 mgg'], ['p1d', 'Hari ini']]; const sk = st.secSort || 'p1m';
    const secs = s.sectors.slice().sort((a, b) => b[sk] - a[sk]);
    view.innerHTML = `<button class="searchbar" data-act="search"><span>⌕</span>Cari kode atau nama emiten</button>
      ${regimeCard()}
      <button class="card ihsgc" data-act="ihsg" style="margin-top:10px"><div class="hero"><div><div class="l">IHSG · ${D.STATUS[s.ihsg.meta.status] || ''} · ${new Date((ih.t[L] + 25200) * 1000).toLocaleDateString('id-ID', { timeZone: 'UTC', weekday: 'short', day: 'numeric', month: 'short' })}</div><div class="v">${num(ih.c[L], 2)}</div></div><div style="text-align:right">${pct(ichg)}<div class="l">${pct(((ih.c[L] - ih.c[Math.max(0, L - 21)]) / ih.c[Math.max(0, L - 21)]) * 100, 1)} 1 bln</div></div></div><div id="mkChart" class="mini"></div><div class="sm" style="color:var(--info);margin-top:6px">Ketuk untuk analisis lengkap IHSG ›</div></button>
      <h2>Kesehatan pasar</h2>
      <div class="card"><div class="rowx sm"><span class="up">${upN} naik</span><span class="sp"></span><span class="mut">${flat} tetap</span><span class="sp"></span><span class="dn">${dnN} turun</span></div>
        <div class="breadth"><i style="width:${(upN / all.length) * 100}%;background:var(--up)"></i><i style="width:${(flat / all.length) * 100}%;background:var(--s3)"></i><i style="width:${(dnN / all.length) * 100}%;background:var(--dn)"></i></div>
        <div class="kv"><div><b>${a50}%</b><span>di atas EMA 50</span></div><div><b>${a200}%</b><span>di atas EMA 200</span></div><div><b><span class="up">${nh}</span> / <span class="dn">${nl}</span></b><span>new high / low 52 mgg</span></div></div>
        <div class="note">Dihitung dari ${all.length} saham dalam daftar pantau aplikasi.</div></div>
      <h2>Performa sektor</h2>
      <div class="card sect"><div class="secrow sech"><span>Sektor</span>${SC.map(([k, l]) => `<button data-ss="${k}" class="${k === sk ? 'on' : ''}">${l}${k === sk ? ' ↓' : ''}</button>`).join('')}</div>
        ${secs.map((x) => `<button class="secrow" data-sec="${esc(x.name)}"><span>${esc(x.name)} <span class="mut sm">${st.secOpen === x.name ? '▴' : '▾'}</span></span>${SC.map(([k]) => `<span class="${k === sk ? 'b' : ''}">${pct(x[k], 1)}</span>`).join('')}</button>
          ${st.secOpen === x.name ? `<div class="secm">${x.members.slice().sort((a, b) => b.f.perf1d - a.f.perf1d).map((m) => `<button class="secrow" data-sym="${m.sym}"><span><b>${m.sym}</b> <span class="mut sm">RS ${m.f.rsRating}</span></span>${SC.map(([k]) => `<span>${pct(m.f[{ p3m: 'perf3m', p1m: 'perf1m', p1w: 'perf1w', p1d: 'perf1d' }[k]], 1)}</span>`).join('')}</button>`).join('')}</div>` : ''}`).join('')}
        <div class="note">Rata-rata perubahan harga saham anggota sektor dalam daftar pantau. Ketuk judul kolom untuk mengurutkan, ketuk sektor untuk melihat anggotanya.</div></div>
      <h2>Penggerak</h2>
      <div class="seg" id="mkSeg">${Object.entries(lists).map(([k, v]) => `<button data-k="${k}" class="${k === st.mkList ? 'on' : ''}">${v[0]}</button>`).join('')}</div>
      <div class="list" style="margin-top:8px">${top.map((x) => stockRow(x, st.mkList === 'rvol' ? `RVOL ${num(x.f.rvol, 1)}x` : st.mkList === 'val' ? A.fmtRp(x.f.value) : st.mkList.startsWith('f') ? `Asing ${A.fmtRp(x.f.fNet1d)}` : '')).join('')}</div>
      <div class="note">Foreign flow: ${esc(D.STATUS[s.ffState.status])} — ${esc(s.ffState.note)}.</div>
      ${macroHtml()}`;
    $('#mkSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) { st.mkList = b.dataset.k; rMarket(); } };
    view.querySelectorAll('[data-mx]').forEach((b) => (b.onclick = () => { st.mxOpen = st.mxOpen === b.dataset.mx ? null : b.dataset.mx; rMarket(); }));
    view.querySelectorAll('[data-ss]').forEach((b) => (b.onclick = () => { st.secSort = b.dataset.ss; rMarket(); }));
    view.querySelectorAll('[data-sec]').forEach((b) => (b.onclick = () => { st.secOpen = st.secOpen === b.dataset.sec ? null : b.dataset.sec; rMarket(); }));
    const mr = $('#mxR'); if (mr) mr.onclick = () => { M.err = null; M.load({ force: true }).then(() => st.tab === 'market' && rMarket()).catch((e) => toast(e.message)); };
    drawMini($('#mkChart'), ih);
  }
  function drawMini(el, cd) {
    if (!window.LightweightCharts) return; try { if (mkChart) mkChart.remove(); } catch (e) {}
    mkChart = LightweightCharts.createChart(el, { height: 120, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: '#5E7187', fontFamily: 'IBM Plex Sans' }, grid: { vertLines: { visible: false }, horzLines: { visible: false } }, rightPriceScale: { visible: false }, timeScale: { visible: false }, handleScroll: false, handleScale: false, crosshair: { vertLine: { visible: false }, horzLine: { visible: false } } });
    const s = mkChart.addAreaSeries({ lineColor: '#E9B949', topColor: 'rgba(233,185,73,.25)', bottomColor: 'rgba(233,185,73,0)', lineWidth: 2, priceLineVisible: false, lastValueVisible: false });
    const n = cd.c.length, k = Math.max(0, n - 130); s.setData(cd.t.slice(k).map((t, i) => ({ time: t + 25200, value: cd.c[k + i] }))); mkChart.timeScale().fitContent();
  }

  // ---------------- SCREENER ----------------
  function fieldOptions(sel, onlyNum) {
    let html = '', g = null;
    for (const d of F.FIELDS) { if (onlyNum && d.t !== 'num') continue; if (d.g !== g) { if (g) html += '</optgroup>'; html += `<optgroup label="${esc(d.g)}">`; g = d.g; } html += `<option value="${d.k}" ${d.k === sel ? 'selected' : ''}>${esc(d.label)}</option>`; }
    return html + '</optgroup>';
  }
  function nodeHtml(n, path) {
    if (n.g) {
      return `<div class="grp ${n.g === 'OR' ? 'or' : ''} ${n.not ? 'not' : ''}" data-path="${path}"><div class="grp-h">
        <button class="tg logic" data-a="logic">${n.g === 'AND' ? 'DAN' : 'ATAU'}</button><button class="tg ${n.not ? 'on' : ''}" data-a="not">BUKAN</button><span class="sp"></span>
        <button class="tg" data-a="addc">+ Kondisi</button><button class="tg" data-a="addg">+ Grup</button>${path ? '<button class="x" data-a="del" aria-label="Hapus grup">✕</button>' : ''}</div>
        ${n.c.map((c, i) => nodeHtml(c, path === '' ? String(i) : path + '.' + i)).join('')}</div>`;
    }
    const d = F.byKey[n.f] || F.FIELDS[0]; const isB = d.t === 'bool';
    const ops = isB ? [['true', 'ya'], ['false', 'tidak']] : [['>', '>'], ['>=', '≥'], ['<', '<'], ['<=', '≤'], ['between', 'antara'], ['crossAbove', 'cross ↑'], ['crossBelow', 'cross ↓']];
    const tfSel = d.daily ? '<span class="chip">Harian</span>' : `<select data-k="tf">${Object.entries(D.TF).map(([k, v]) => `<option value="${k}" ${k === (n.tf || 'D') ? 'selected' : ''}>${v}</option>`).join('')}</select>`;
    let rhs = '';
    if (!isB) {
      if (n.op === 'between') rhs = `<input type="number" step="any" data-k="v" value="${n.v ?? ''}"><span class="mut">–</span><input type="number" step="any" data-k="v2" value="${n.v2 ?? ''}">`;
      else rhs = `<select data-k="rk"><option value="v" ${!n.rf ? 'selected' : ''}>angka</option><option value="f" ${n.rf ? 'selected' : ''}>field</option></select>` + (n.rf ? `<select data-k="rf" style="max-width:150px">${fieldOptions(n.rf, true)}</select>` : `<input type="number" step="any" data-k="v" value="${n.v ?? ''}">`);
    }
    return `<div class="leaf" data-path="${path}"><select class="fsel" data-k="f">${fieldOptions(n.f)}</select>${tfSel}<select data-k="op">${ops.map(([k, v]) => `<option value="${k}" ${k === n.op ? 'selected' : ''}>${v}</option>`).join('')}</select>${rhs}<button class="x" data-a="del" aria-label="Hapus kondisi">✕</button></div>`;
  }
  const getNode = (path) => { let n = st.tree; if (path === '') return { n }; const ps = path.split('.').map(Number); let parent = null, idx = -1; for (const i of ps) { parent = n; idx = i; n = n.c[i]; } return { n, parent, idx }; };
  const saveTree = () => { D.lsSet('rb.lastTree', st.tree); D.lsSet('rb.lastPreset', st.presetId); };
  function rScreener() {
    const saved = D.lsGet('rb.screens', []);
    const sortOpts = [['score', 'Setup Score'], ...F.FIELDS.filter((d) => d.t === 'num' && d.k !== 'score').map((d) => [d.k, d.label])];
    view.innerHTML = `${cfgHtml()}
      <h2>Preset profesional</h2>
      <div class="presets">${Sc.PRESETS.map((p) => `<button class="preset ${p.id === st.presetId ? 'on' : ''}" data-pid="${p.id}"><b>${esc(p.name)}</b><span>${esc(p.desc)}</span></button>`).join('')}</div>
      ${saved.length ? `<h2>Screener tersimpan</h2><div class="seg">${saved.map((x, i) => `<button data-saved="${i}">${esc(x.name)}</button>`).join('')}</div>` : ''}
      <h2 class="rowx">Kondisi <span class="sp"></span><button class="btn" id="tgB" style="padding:5px 10px;font-size:12px">${st.showBuilder ? 'Sembunyikan' : 'Ubah kondisi'}</button></h2>
      <div id="builder" ${st.showBuilder ? '' : 'hidden'}>${nodeHtml(st.tree, '')}
        <div class="note">DAN: semua harus terpenuhi · ATAU: salah satu · BUKAN: membalik grup. Kondisi non-harian (1m–1H, mingguan) dimuat hanya untuk saham yang lolos filter harian.</div></div>
      ${st.showBuilder ? '' : `<div class="card sm mut">${esc(treeText(st.tree))}</div>`}
      <div class="rowx" style="margin-top:10px"><button class="btn pri" id="run" ${st.running || !E.snap ? 'disabled' : ''}>${st.running ? 'Memindai…' : 'Jalankan screener'}</button><button class="btn" id="save">Simpan</button><button class="btn" id="btS">Backtest</button><span class="sp"></span><button class="btn" id="newT">Kosongkan</button></div>
      <div id="stage" class="note"></div>
      <div id="results"></div>`;
    renderResults(sortOpts);
    view.querySelectorAll('[data-pid]').forEach((b) => (b.onclick = () => { const p = Sc.PRESETS.find((x) => x.id === b.dataset.pid); st.presetId = p.id; st.tree = JSON.parse(JSON.stringify(p.tree)); if (st.presetTf !== 'D') applyTf(st.tree, st.presetTf); st.sort = p.sort || 'score'; st.dir = p.dir || -1; saveTree(); runScreener(); }));
    view.querySelectorAll('[data-saved]').forEach((b) => (b.onclick = () => { const x = saved[+b.dataset.saved]; st.tree = JSON.parse(JSON.stringify(x.tree)); st.presetId = null; st.sort = x.sort || 'score'; saveTree(); runScreener(); }));
    $('#tgB').onclick = () => { st.showBuilder = !st.showBuilder; rScreener(); };
    bindCfg();
    $('#run').onclick = runScreener;
    $('#btS').onclick = () => openBacktest({ mode: 'tree', preset: 'current' });
    $('#newT').onclick = () => { st.tree = Sc.blank(); st.presetId = null; st.showBuilder = true; st.results = null; saveTree(); rScreener(); };
    $('#save').onclick = () => { const name = prompt('Nama screener', st.presetId ? Sc.PRESETS.find((p) => p.id === st.presetId).name + ' (custom)' : 'Screener saya'); if (!name) return; const arr = D.lsGet('rb.screens', []); arr.push({ name, tree: st.tree, sort: st.sort }); D.lsSet('rb.screens', arr); toast('Screener disimpan'); rScreener(); };
    const b = $('#builder');
    b.addEventListener('click', (e) => {
      const t = e.target.closest('[data-a]'); if (!t) return; const path = t.closest('[data-path]').dataset.path; const { n, parent, idx } = getNode(path);
      if (t.dataset.a === 'logic') n.g = n.g === 'AND' ? 'OR' : 'AND';
      if (t.dataset.a === 'not') n.not = !n.not;
      if (t.dataset.a === 'addc') n.c.push({ f: 'rsi', op: '>', v: 50, tf: 'D' });
      if (t.dataset.a === 'addg') n.c.push({ g: 'OR', c: [{ f: 'bosBull', op: 'true', tf: 'D' }] });
      if (t.dataset.a === 'del' && parent) parent.c.splice(idx, 1);
      st.presetId = null; saveTree(); rScreener();
    });
    b.addEventListener('change', (e) => {
      const el = e.target; const path = el.closest('[data-path]').dataset.path; const { n } = getNode(path); const k = el.dataset.k;
      if (k === 'f') { n.f = el.value; const d = F.byKey[n.f]; n.op = d.t === 'bool' ? 'true' : '>'; delete n.rf; n.v = d.t === 'bool' ? undefined : 0; if (d.daily) n.tf = 'D'; }
      else if (k === 'rk') { if (el.value === 'f') { n.rf = 'ema50'; delete n.v; } else { delete n.rf; n.v = 0; } }
      else if (k === 'v' || k === 'v2') n[k] = el.value === '' ? undefined : parseFloat(el.value);
      else n[k] = el.value;
      st.presetId = null; saveTree(); if (k !== 'v' && k !== 'v2') rScreener();
    });
  }
  function treeText(n) {
    if (n.g) { const inner = n.c.map(treeText).join(n.g === 'AND' ? ' DAN ' : ' ATAU '); return (n.not ? 'BUKAN ' : '') + (n.c.length > 1 ? `(${inner})` : inner); }
    const d = F.byKey[n.f]; const tf = d && !d.daily ? ` [${D.TF[n.tf || 'D']}]` : '';
    if (n.op === 'true') return d.label + tf; if (n.op === 'false') return 'tidak ' + d.label + tf;
    const r = n.rf ? F.byKey[n.rf].label : n.op === 'between' ? `${n.v}–${n.v2}` : (d.u === 'Rp' && Math.abs(n.v) >= 1e6 ? A.fmtRp(n.v) : n.v);
    return `${d.label}${tf} ${Sc.OPS[n.op]} ${r}`;
  }
  async function runScreener() {
    if (!E.snap) return toast('Data pasar belum dimuat'); st.running = true; rScreener();
    try { const stage = (m) => { const el = $('#stage'); if (el) el.textContent = m; }; st.results = await Sc.run(st.tree, { onProg: (d, n) => setProg(d / n), onStage: stage, scope: st.scope, minValue: st.scrMin * 1e9 }); }
    catch (e) { toast('Screener gagal: ' + e.message); }
    st.running = false; setProg(null); if (st.tab === 'screener') rScreener();
  }
  function renderResults(sortOpts) {
    const box = $('#results'); if (!box) return; if (!st.results) { box.innerHTML = E.snap ? '' : needSnap(); return; }
    const k = st.sort; const res = st.results.slice().sort((a, b) => { const x = a.f[k], y = b.f[k]; if (!ok(x)) return 1; if (!ok(y)) return -1; return (x - y) * st.dir; });
    box.innerHTML = `<div class="res-h"><b>${res.length} saham</b><span class="sp"></span><select id="sortSel">${sortOpts.map(([v, l]) => `<option value="${v}" ${v === k ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select><button class="tg" id="dirB">${st.dir < 0 ? '↓' : '↑'}</button></div>
      ${res.length ? `<div class="list">${res.slice(0, 120).map((s) => stockRow(s, k !== 'score' ? `${F.byKey[k] ? F.byKey[k].label : k}: ${fmtField(k, s.f[k])}` : `RS ${s.f.rsRating}`)).join('')}</div>` : '<div class="empty"><b>Tidak ada saham yang lolos</b>Longgarkan salah satu kondisi atau coba preset lain.</div>'}`;
    $('#sortSel').onchange = (e) => { st.sort = e.target.value; renderResults(sortOpts); };
    $('#dirB').onclick = () => { st.dir *= -1; renderResults(sortOpts); };
  }

  // ---------------- SCREENER SETTINGS ----------------
  const PARAM_UI = [
    ['Struktur & swing', [['pivotLen', 'Kekuatan swing (bar kiri/kanan)', 'bar', 1, 10, 1]]],
    ['Fair value gap', [['fvgMinAtr', 'Ukuran gap minimum', '×ATR', 0, 2, 0.05], ['fvgRecent', '"FVG baru" jika terbentuk dalam', 'bar', 1, 60, 1], ['fvgLookback', 'FVG dianggap masih aktif hingga', 'bar', 10, 500, 10]]],
    ['BOS / CHoCH', [['bosRecent', '"BOS/CHoCH baru" jika terjadi dalam', 'bar', 1, 60, 1]]],
    ['Likuiditas', [['sweepLookback', 'Umur maks. swing yang disapu', 'bar', 5, 200, 5], ['sweepRecent', '"Sweep baru" jika terjadi dalam', 'bar', 1, 60, 1], ['eqTol', 'Toleransi equal high/low', '×ATR', 0.02, 1, 0.01]]],
    ['Order block & displacement', [['obLookback', 'Cari candle order block mundur', 'bar', 2, 50, 1], ['dispAtr', 'Body displacement minimum', '×ATR', 0.5, 4, 0.1]]],
    ['Breakout', [['boVol', 'Volume breakout minimum', '×rata2', 1, 5, 0.1], ['boRecent', '"Breakout baru" jika terjadi dalam', 'bar', 1, 30, 1], ['retestWin', 'Retest dicari hingga', 'bar', 5, 60, 1]]],
    ['Indikator', [['rsiLen', 'Periode RSI', 'bar', 2, 50, 1], ['rvolLen', 'Periode rata-rata volume (RVOL)', 'bar', 5, 100, 1], ['volSpike', 'Volume spike minimum', '×', 1.2, 10, 0.1], ['sqzPctl', 'BB squeeze jika lebar di bawah persentil', '', 5, 50, 1], ['divRecent', 'Divergence dicari dalam', 'bar', 5, 60, 1]]],
  ];
  const applyTf = (n, tf) => { if (n.g) n.c.forEach((c) => applyTf(c, tf)); else if (!(F.byKey[n.f] && F.byKey[n.f].daily)) n.tf = tf; };
  function cfgHtml() {
    const custom = Object.keys(R.PDEF).filter((k) => R.P[k] !== R.PDEF[k]).length;
    const scopeLbl = st.scope === 'all' ? 'Semua saham' : st.scope === 'watch' ? 'Watchlist' : st.scope;
    const head = `<button class="card cfgh" id="cfgT"><span><b>Pengaturan screener</b><span class="sm mut">Timeframe ${D.TF[st.presetTf]} · ${esc(scopeLbl)}${st.scrMin ? ` · ≥ Rp${st.scrMin} M/hari` : ''} · parameter ${custom ? custom + ' diubah' : 'default'}</span></span><span class="mut">${st.showCfg ? '▴' : '▾'}</span></button>`;
    if (!st.showCfg) return head;
    const secs = E.snap ? E.snap.sectors.map((x) => x.name) : Object.values(D.SECTORS);
    return head + `<div class="card cfg">
      <div class="sm mut">Timeframe untuk kondisi teknikal, struktur & SMC</div>
      <div class="seg" id="cfgTf" style="margin:6px 0">${Object.entries(D.TF).map(([k, v]) => `<button data-tf="${k}" class="${k === st.presetTf ? 'on' : ''}">${v}</button>`).join('')}</div>
      <div class="rowx"><button class="btn" id="cfgApply">Terapkan ke semua kondisi aktif</button></div>
      <div class="note">Dipakai otomatis saat memilih preset. Contoh: pilih 1 jam lalu preset "FVG Setup" → FVG dicari di chart 1 jam. Field yang hanya ada di harian (RS, fundamental, 52 minggu, bandar, skor) tetap harian. Tiap kondisi juga bisa diberi timeframe sendiri di "Ubah kondisi".</div>
      <div class="fld"><label>Cakupan saham</label><select id="cfgScope" class="selx"><option value="all">Semua saham</option><option value="watch" ${st.scope === 'watch' ? 'selected' : ''}>Watchlist</option>${secs.map((x) => `<option ${st.scope === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></div>
      <div class="fld"><label>Likuiditas minimum</label><input type="number" id="cfgMin" value="${st.scrMin}" min="0" step="0.5"><span class="sm mut">M Rp/hari</span></div>
      ${PARAM_UI.map(([g, arr]) => `<div class="pg">${esc(g)}</div>${arr.map(([k, l, u, mn, mx, stp]) => `<div class="fld"><label>${esc(l)}${R.P[k] !== R.PDEF[k] ? ' <span class="gold">•</span>' : ''}</label><input type="number" data-p="${k}" value="${R.P[k]}" min="${mn}" max="${mx}" step="${stp}"><span class="sm mut" style="min-width:40px">${u}</span></div>`).join('')}`).join('')}
      <div class="rowx" style="margin-top:10px"><button class="btn pri" id="cfgSave">Simpan & hitung ulang</button><button class="btn" id="cfgReset">Kembalikan default</button></div>
      <div class="note">Parameter berlaku untuk semua timeframe, halaman saham, AI Picks, dan radar. Untuk jendela berbeda per kondisi, pakai field "Bar sejak …" (mis. Bar sejak FVG bullish ≤ 10 di 1 jam).</div></div>`;
  }
  function bindCfg() {
    $('#cfgT').onclick = () => { st.showCfg = !st.showCfg; rScreener(); };
    if (!st.showCfg) return;
    $('#cfgTf').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; st.presetTf = b.dataset.tf; rScreener(); };
    $('#cfgApply').onclick = () => { applyTf(st.tree, st.presetTf); st.presetId = null; saveTree(); toast(`Kondisi memakai timeframe ${D.TF[st.presetTf]}`); runScreener(); };
    $('#cfgScope').onchange = (e) => { st.scope = e.target.value; };
    $('#cfgMin').onchange = (e) => { st.scrMin = Math.max(0, parseFloat(e.target.value) || 0); };
    $('#cfgSave').onclick = () => {
      view.querySelectorAll('[data-p]').forEach((el) => { const v = parseFloat(el.value); if (ok(v)) R.P[el.dataset.p] = Math.min(+el.max, Math.max(+el.min, v)); });
      for (const k of ['pivotLen', 'fvgRecent', 'fvgLookback', 'bosRecent', 'sweepLookback', 'sweepRecent', 'obLookback', 'boRecent', 'retestWin', 'rsiLen', 'rvolLen', 'divRecent', 'sqzPctl']) R.P[k] = Math.round(R.P[k]);
      D.lsSet('rb.params', R.P); E.recompute(); toast('Parameter diterapkan'); st.showCfg = false; if (st.results) runScreener(); else rScreener();
    };
    $('#cfgReset').onclick = () => { R.P = Object.assign({}, R.PDEF); D.lsSet('rb.params', R.P); E.recompute(); toast('Parameter kembali ke default'); rScreener(); };
  }

  // ---------------- NEWS ----------------
  const nw = { filter: 'all', watchOnly: false, sort: 'new', busy: new Set() };
  const openExt = (u) => { if (window.AndroidBridge) AndroidBridge.openUrl(u); else window.open(u, '_blank'); };
  const awCls = (a) => (a.veryEarly ? 'aw-x' : a.level === 'early' ? 'aw-e' : a.level === 'spreading' ? 'aw-s' : 'aw-k');
  function storyCard(s) {
    const a = s.aw; const imps = s.ai && s.ai.dampak && s.ai.dampak.length ? s.ai.dampak : s.impacts; const summ = s.ai && s.ai.ringkasan ? s.ai.ringkasan : N.ruleSummary(s);
    return `<div class="card story"><div class="rowx"><span class="aw ${awCls(a)}">${esc(a.label)}</span><span class="awm" title="Skor kesadaran ${a.score}/100"><i style="width:${Math.max(4, a.score)}%"></i></span><span class="sp"></span><span class="sm mut">${N.ago(s.first)}</span></div>
      <button class="st-t" data-read="${s.id}">${esc(s.title)}</button>
      <div class="rowx sm"><span class="chip">${esc(s.cat.name)}</span><span class="mut">${s.nSources} sumber</span>${a.priced ? `<span class="chip ${s.reaction && s.reaction.status === 'untested' ? 'y' : 'b'}">${esc(a.priced)}</span>` : ''}</div>
      <p class="st-s">${esc(summ)} <span class="sm mut">— ${s.ai ? 'ringkasan AI' : 'ringkasan otomatis'}</span></p>
      ${imps.length ? `<div class="pg" style="margin-top:4px">Perkiraan dampak ke emiten</div><div class="imp">${imps.slice(0, 6).map((x) => `<button class="impr" data-sym="${x.sym}"><span class="${x.dir > 0 ? 'up' : x.dir < 0 ? 'dn' : 'mut'} arr">${x.dir > 0 ? '▲' : x.dir < 0 ? '▼' : '◆'}</span><span><b>${x.sym}</b> <span class="chip">${esc(x.mag)}${x.direct ? '' : ' · tidak langsung'}</span><span class="sm mut" style="display:block">${esc(x.why)}</span></span></button>`).join('')}</div>` : ''}
      <details class="why"><summary>Kenapa "${esc(a.label.toLowerCase())}" · sumber (${s.items.length})</summary><div class="sm mut" style="margin:6px 0">${esc(a.why.join(' · '))}</div>${s.items.map((it) => `<a data-ext href="${esc(it.link)}" class="srcl"><span class="mut">${esc(it.src)} · ${N.ago(it.date)}</span><br>${esc(it.title)}</a>`).join('')}</details>
      <div class="rowx" style="margin-top:8px"><button class="btn" data-read="${s.id}">Baca berita</button>${N.llmReady() && !s.ai ? `<button class="btn" data-ai="${s.id}" ${nw.busy.has(s.id) ? 'disabled' : ''}>${nw.busy.has(s.id) ? 'Meringkas…' : 'Analisis AI'}</button>` : ''}</div></div>`;
  }
  const findStory = (id) => N.stories.find((x) => x.id === id) || (sp.stories || []).find((x) => x.id === id);
  async function runAI(id) {
    const s = findStory(id); if (!s || nw.busy.has(id)) return; nw.busy.add(id); refreshNewsViews();
    try { s.ai = await N.llm(s); } catch (e) { toast('AI gagal: ' + e.message); }
    nw.busy.delete(id); refreshNewsViews();
  }
  N.onUpdate = () => refreshNewsViews();
  const rdr = { id: null };
  async function openReader(id) {
    const s = findStory(id); if (!s) return; rdr.id = id; const el = $('#reader'); el.hidden = false; document.body.style.overflow = 'hidden'; el.scrollTop = 0; drawReader(s, null);
    if (s.full) { drawReader(s, { paras: s.full, url: s.url, site: s.site }); return; }
    try { const art = await N.read(s.items[0].link); N.enrich(s, art); if (rdr.id === id) drawReader(s, art); refreshNewsViews(); }
    catch (e) { if (rdr.id === id) drawReader(s, { err: e.message }); }
  }
  function closeReader() { $('#reader').hidden = true; rdr.id = null; if ($('#stock').hidden && $('#bt').hidden) document.body.style.overflow = ''; }
  function drawReader(s, art) {
    const el = $('#reader'); const a = s.aw; const link = (art && art.url) || s.url || s.items[0].link; const imps = s.ai && s.ai.dampak && s.ai.dampak.length ? s.ai.dampak : s.impacts;
    el.innerHTML = `<div class="sh-h"><button class="icon" id="rdBack" aria-label="Kembali">←</button><span class="sm mut" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc((art && art.site) || s.site || s.items[0].src)}</span><button class="tg" id="rdOpen">Buka di browser</button></div>
      <div class="sh-b reader"><div class="rowx"><span class="aw ${awCls(a)}">${esc(a.label)}</span><span class="chip">${esc(s.cat.name)}</span><span class="sp"></span><span class="sm mut">${N.ago(s.first)} · ${s.nSources} sumber</span></div>
        <h1 class="rd-t">${esc(s.title)}</h1>
        <div class="card"><div class="pg" style="margin:0 0 4px">${s.ai ? 'Ringkasan AI' : 'Ringkasan'}</div><p class="st-s" style="margin:0">${esc(s.ai && s.ai.ringkasan ? s.ai.ringkasan : N.ruleSummary(s))}</p>
          ${imps.length ? `<div class="pg">Perkiraan dampak ke emiten</div><div class="imp">${imps.slice(0, 8).map((x) => `<button class="impr" data-sym="${x.sym}"><span class="${x.dir > 0 ? 'up' : x.dir < 0 ? 'dn' : 'mut'} arr">${x.dir > 0 ? '▲' : x.dir < 0 ? '▼' : '◆'}</span><span><b>${x.sym}</b> <span class="chip">${esc(x.mag)}${x.direct ? '' : ' · tidak langsung'}</span><span class="sm mut" style="display:block">${esc(x.why)}</span></span></button>`).join('')}</div>` : ''}
          ${a.priced ? `<div class="note">${esc(a.priced)} · ${esc(a.why.join(' · '))}</div>` : `<div class="note">${esc(a.why.join(' · '))}</div>`}
          ${N.llmReady() && !s.ai ? `<button class="btn" data-ai="${s.id}" style="margin-top:6px" ${nw.busy.has(s.id) ? 'disabled' : ''}>${nw.busy.has(s.id) ? 'Meringkas…' : 'Analisis dengan AI'}</button>` : ''}</div>
        <div class="rd-body">${!art ? '<div class="empty"><b>Memuat artikel…</b></div>' : art.err ? `<div class="empty"><b>Isi artikel tidak bisa ditampilkan</b>${esc(art.err)}. Ketuk "Buka di browser" untuk membaca di situs aslinya.</div>` : art.paras.map((p) => `<p>${esc(p)}</p>`).join('') + `<div class="note">Sumber: ${esc(art.site || '')}. Teks diambil dari halaman asli untuk dibaca di aplikasi.</div>`}</div>
        ${s.items.length > 1 ? `<h2>Liputan lain (${s.items.length - 1})</h2>${s.items.slice(1).map((it) => `<a data-ext href="${esc(it.link)}" class="srcl"><span class="mut">${esc(it.src)} · ${N.ago(it.date)}</span><br>${esc(it.title)}</a>`).join('')}` : ''}</div>`;
    $('#rdBack').onclick = closeReader;
    $('#rdOpen').onclick = async () => { let u = link; try { u = await N.resolve(link); } catch (e) {} openExt(u); };
    el.onclick = (e) => { const x = e.target.closest('a[data-ext]'); if (x) { e.preventDefault(); return openExt(x.href); } const ai = e.target.closest('[data-ai]'); if (ai) return runAI(ai.dataset.ai).then(() => rdr.id === s.id && drawReader(s, art)); const b = e.target.closest('[data-sym]'); if (b) { closeReader(); openStock(b.dataset.sym); } };
  }
  function refreshNewsViews() { if (st.tab === 'news') rNews(); if (!$('#stock').hidden && sp.sec === 'news') drawSection(); }
  function rNews() {
    if (!N.last && !N.loading && !N.err) { N.load({ onProg: (d, n) => setProg(d / n) }).then(() => { setProg(null); if (st.tab === 'news') rNews(); }); }
    else if (N.last && Date.now() - N.last > 10 * 60e3 && !N.loading) N.load().then(() => st.tab === 'news' && rNews());
    const w = new Set(watch());
    let list = N.stories.slice();
    if (nw.filter === 'early') list = list.filter((x) => x.aw.level === 'early'); else if (nw.filter !== 'all') list = list.filter((x) => x.aw.level === nw.filter);
    if (nw.watchOnly) list = list.filter((x) => x.impacts.some((i) => w.has(i.sym)));
    const impW = (x) => x.impacts.reduce((a, i) => a + (i.direct ? 2 : 1) * (i.mag === 'kuat' ? 3 : i.mag === 'sedang' ? 2 : 1) * (i.dir ? 1 : 0.5), 0);
    list.sort(nw.sort === 'early' ? (a, b) => a.aw.score - b.aw.score || b.first - a.first : nw.sort === 'impact' ? (a, b) => impW(b) - impW(a) : (a, b) => b.first - a.first);
    const cnt = (lv) => N.stories.filter((x) => x.aw.level === lv).length;
    view.innerHTML = `<div class="seg" id="nwSeg">${[['all', 'Semua', N.stories.length], ['early', 'Belum banyak tahu', cnt('early')], ['spreading', 'Mulai menyebar', cnt('spreading')], ['known', 'Sudah ramai', cnt('known')]].map(([k, v, c]) => `<button data-f="${k}" class="${k === nw.filter ? 'on' : ''}">${v} ${c ? `<span class="mut">${c}</span>` : ''}</button>`).join('')}</div>
      <div class="rowx" style="margin:10px 0 4px"><select id="nwSort" class="selx"><option value="new">Terbaru</option><option value="early" ${nw.sort === 'early' ? 'selected' : ''}>Paling awal (belum ramai)</option><option value="impact" ${nw.sort === 'impact' ? 'selected' : ''}>Dampak terbesar</option></select><button class="tg ${nw.watchOnly ? 'on' : ''}" id="nwW">Watchlist</button><span class="sp"></span><button class="btn" id="nwR" style="padding:6px 10px">${N.loading ? 'Memuat…' : 'Perbarui'}</button></div>
      <div class="note">${N.last ? `Diperbarui ${new Date(N.last).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} · ${N.stories.length} cerita${N.failed ? ` · ${N.failed} sumber gagal` : ''}` : ''}</div>
      ${N.err ? `<div class="empty"><b>Berita tidak bisa dimuat</b>${esc(N.err)}</div>` : !N.last ? '<div class="empty"><b>Mengumpulkan berita…</b>Google News, CNBC Indonesia, dan berita per emiten watchlist & penggerak hari ini.</div>' : list.length ? list.slice(0, 60).map(storyCard).join('') : '<div class="empty"><b>Tidak ada cerita di filter ini</b>Coba filter lain atau perbarui.</div>'}
      <details class="why card" style="margin-top:12px"><summary>Cara membaca label</summary><div class="sm" style="margin-top:6px;line-height:1.55">
        <b>Sangat awal / Belum banyak yang tahu</b> — sedikit sumber, baru terbit, dan harga/volume emiten belum bereaksi (atau terbit setelah bursa tutup).<br><b>Mulai menyebar</b> — sumber bertambah atau harga mulai bergerak.<br><b>Sudah banyak yang tahu</b> — diberitakan luas dan/atau harga sudah bereaksi kuat; peluang biasanya sudah sebagian besar priced-in.<br><br>
        Skor dihitung dari jumlah sumber, umur berita, serta pergerakan harga (dalam ATR) dan RVOL sejak jam terbit. Informasi yang benar-benar belum diketahui publik adalah informasi orang dalam dan ilegal untuk ditransaksikan; aplikasi hanya menilai berita publik.</div></details>`;
    $('#nwSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) { nw.filter = b.dataset.f; rNews(); } };
    $('#nwSort').onchange = (e) => { nw.sort = e.target.value; rNews(); };
    $('#nwW').onclick = () => { nw.watchOnly = !nw.watchOnly; rNews(); };
    $('#nwR').onclick = () => { if (N.loading) return; N.load({ force: true, onProg: (d, n) => setProg(d / n) }).then(() => { setProg(null); rNews(); }); rNews(); };
  }


  // ---------------- REGIME & MACRO ----------------
  function regimeCard() {
    const r = M.regime; if (!r) return '';
    const col = r.score >= 60 ? 'var(--up)' : r.score >= 40 ? 'var(--gold)' : 'var(--dn)'; const pr = E.pickRules();
    return `<div class="card regime"><div class="rowx"><div><div class="sm mut">Kondisi pasar</div><div class="rg-l" style="color:${col}">${r.label}</div></div><span class="sp"></span><div class="rg-s" style="border-color:${col}">${r.score}</div></div>
      <div class="comp" style="margin-top:10px">${r.comp.map((c) => `<span>${esc(c.label)}</span><div class="bar ${c.s < 50 ? 'lo' : ''}"><i style="width:${c.s}%"></i></div><span>${c.s}</span>`).join('')}</div>
      <details class="why"><summary>Dasar penilaian</summary><ul class="why">${r.comp.map((c) => `<li class="${c.s >= 50 ? 'p' : 'm'}">${esc(c.label)}: ${esc(c.why)}</li>`).join('')}</ul>${M.data ? '' : '<div class="note">Data makro belum dimuat — skor memakai IHSG & breadth saja.</div>'}</details>
      ${pr.label && D.settings.regimeFilter ? `<div class="note" style="color:${col}">${esc(pr.label)}.</div>` : ''}</div>`;
  }
  function macroHtml() {
    if (!M.data) return `<h2>Makro & komoditas</h2><div class="card sm mut">${M.err ? 'Gagal memuat: ' + esc(M.err) : 'Memuat harga komoditas & makro…'}</div>`;
    const groups = ['Komoditas', 'Makro', 'Global', 'Tambahan'];
    return `<h2 class="rowx">Makro & komoditas <span class="sp"></span><button class="tg" id="mxR">Perbarui</button></h2>${groups.map((g) => { const items = M.data.items.filter((x) => x.g === g); if (!items.length) return '';
      return `<div class="pg" style="margin:10px 2px 6px">${g}</div><div class="list">${items.map((it) => {
        if (it.err) return `<div class="row" style="grid-template-columns:1fr auto"><span>${esc(it.name)}<div class="sub">Tidak tersedia dari Yahoo</div></span><span class="mut">—</span></div>`;
        const lag = it.linked.filter((x) => x.lagging); const open = st.mxOpen === it.sym;
        return `<button class="row" data-mx="${it.sym}" style="grid-template-columns:1fr auto auto"><span>${esc(it.name)}${lag.length ? ` <span class="chip y">${lag.length} emiten belum ikut</span>` : ''}</span><span class="px">${num(it.last, it.last < 20 ? 3 : 2)}</span><span class="chg">${pct(it.p1d)}</span>
          <span class="sub">1M ${fmtP(it.p1w)} · 1B ${fmtP(it.p1m)} · 3B ${fmtP(it.p3m)} · ${it.up50 ? 'di atas' : 'di bawah'} EMA 50</span><span></span><span class="mut sm">${open ? '▴' : it.linked.length ? '▾' : ''}</span></button>
          ${open ? `<div class="mxd">${it.note ? `<div class="note">${esc(it.note)}</div>` : ''}${it.linked.length ? `<table class="t"><tr><td class="mut sm">Emiten</td><td class="mut sm">Korelasi 6 bln · perf 1B</td></tr>${it.linked.map((x) => `<tr data-sym="${x.sym}"><td><b>${x.sym}</b>${x.lagging ? ' <span class="chip y">belum ikut</span>' : ''}</td><td>${ok(x.r) ? x.r.toFixed(2) : '—'}${x.lag ? ' <span class="mut sm">(H+1)</span>' : ''} · ${pct(x.p1m, 1)}</td></tr>`).join('')}</table><div class="note">Korelasi return harian 6 bulan. "(H+1)": saham bereaksi sehari setelah komoditas. "Belum ikut": komoditas bergerak ≥5% sebulan dengan korelasi ≥0,3 tapi saham belum mengikuti — kandidat catch-up, perlu konfirmasi teknikal.</div>` : '<div class="note">Indikator makro/global — dipakai di skor kondisi pasar.</div>'}</div>` : ''}`; }).join('')}</div>`; }).join('')}
      <div class="note">Sumber Yahoo Finance (tertunda/EOD). Nikel LME & CPO Bursa Malaysia tidak tersedia gratis; tambah simbol lain di Pengaturan.</div>`;
  }
  const fmtP = (x) => (ok(x) ? `${x > 0 ? '+' : ''}${x.toFixed(1)}%` : '—');

  // ---------------- BACKTEST ----------------
  const bt = { cfg: { mode: 'tree', preset: 'current', cat: 'swing', nStocks: 40, period: 252, step: 2, hold: 20, entry: 'open', regimeFilter: false }, prog: null };
  function openBacktest(init) {
    Object.assign(bt.cfg, init || {}); const el = $('#bt'); el.hidden = false; document.body.style.overflow = 'hidden'; drawBt();
  }
  function closeBt() { $('#bt').hidden = true; document.body.style.overflow = ''; if (B.running) B.abort = true; }
  function drawBt() {
    const el = $('#bt'), c = bt.cfg, r = B.last && B.last.cfgKey === cfgKey() ? B.last : null;
    const targets = [['tree:current', 'Kondisi screener saat ini'], ...Sc.PRESETS.map((p) => ['tree:' + p.id, 'Preset: ' + p.name]), ...E.PICK_CATS.map((x) => ['cat:' + x.id, 'AI Picks: ' + x.name])];
    const cur = c.mode === 'cat' ? 'cat:' + c.cat : 'tree:' + c.preset;
    const sel = (id, opts, v) => `<select id="${id}" class="selx">${opts.map(([k, l]) => `<option value="${k}" ${String(k) === String(v) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
    el.innerHTML = `<div class="sh-h"><button class="icon" id="btBack" aria-label="Kembali">←</button><b>Backtest</b></div><div class="sh-b">
      <div class="card"><div class="fld"><label>Yang diuji</label>${sel('btT', targets, cur)}</div>
        <div class="fld"><label>Periode uji</label>${sel('btP', [[126, '6 bulan'], [252, '1 tahun'], [504, '2 tahun'], [756, '3 tahun']], c.period)}</div>
        <div class="fld"><label>Saham (terlikuid)</label>${sel('btN', [[20, '20 saham'], [40, '40 saham'], [80, '80 saham'], [150, 'Semua']], c.nStocks)}</div>
        <div class="fld"><label>Entry</label>${sel('btE', [['open', 'Open hari berikutnya'], ['limit', 'Limit di area entry (maks 5 hari)']], c.entry)}</div>
        <div class="fld"><label>Tahan maksimal</label>${sel('btH', [[10, '10 hari'], [20, '20 hari'], [40, '40 hari']], c.hold)}</div>
        <div class="fld"><label>Cek sinyal tiap</label>${sel('btS', [[1, '1 hari (teliti)'], [2, '2 hari (cepat)']], c.step)}</div>
        <div class="fld"><input type="checkbox" class="sw" id="btR" ${c.regimeFilter ? 'checked' : ''}><label>Lewati sinyal saat pasar risk-off</label></div>
        <div class="rowx" style="margin-top:10px"><button class="btn pri" id="btGo" ${B.running ? 'disabled' : ''}>${B.running ? 'Berjalan…' : 'Jalankan backtest'}</button>${B.running ? '<button class="btn" id="btX">Batalkan</button>' : ''}<span class="sp"></span><span class="sm mut" id="btMsg">${bt.prog ? esc(bt.prog) : ''}</span></div>
        <div class="note">Exit: invalidasi (stop) atau target 1 dari rencana trading, atau keluar di close setelah batas hari. Sudah termasuk biaya beli ${D.settings.feeBuy}% & jual ${D.settings.feeSell}%. Setiap titik uji hanya memakai data sampai hari itu (tanpa melihat masa depan).</div></div>
      ${r ? btResult(r) : ''}</div>`;
    $('#btBack').onclick = closeBt;
    const read = () => { const [m, v] = $('#btT').value.split(':'); c.mode = m; if (m === 'cat') c.cat = v; else c.preset = v; c.period = +$('#btP').value; c.nStocks = +$('#btN').value; c.entry = $('#btE').value; c.hold = +$('#btH').value; c.step = +$('#btS').value; c.regimeFilter = $('#btR').checked; };
    el.querySelectorAll('select,input').forEach((x) => (x.onchange = () => { read(); drawBt(); }));
    $('#btGo').onclick = runBt; const x = $('#btX'); if (x) x.onclick = () => (B.abort = true);
    el.querySelectorAll('[data-sym]').forEach((b) => (b.onclick = () => { closeBt(); openStock(b.dataset.sym); }));
    if (r && window.LightweightCharts && r.curve.length > 1) { const ch = LightweightCharts.createChart($('#btCurve'), { height: 160, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: '#8EA0B5', fontFamily: 'IBM Plex Sans', fontSize: 11 }, grid: { vertLines: { visible: false }, horzLines: { color: 'rgba(42,59,82,.35)' } }, rightPriceScale: { borderColor: '#2A3B52' }, timeScale: { borderColor: '#2A3B52' }, handleScroll: false, handleScale: false });
      const ls = ch.addBaselineSeries({ baseValue: { type: 'price', price: 0 }, topLineColor: '#22B07D', bottomLineColor: '#E5484D', topFillColor1: 'rgba(34,176,125,.2)', topFillColor2: 'rgba(34,176,125,0)', bottomFillColor1: 'rgba(229,72,77,0)', bottomFillColor2: 'rgba(229,72,77,.2)', priceLineVisible: false, lastValueVisible: true });
      const pts = []; let last = 0; for (const p of r.curve) { const t = Math.floor(p.t / 86400) * 86400; if (t <= last) { pts[pts.length - 1].value = p.v; continue; } pts.push({ time: t, value: p.v }); last = t; } ls.setData(pts); ch.timeScale().fitContent(); }
  }
  const cfgKey = () => JSON.stringify(bt.cfg) + (bt.cfg.preset === 'current' ? JSON.stringify(st.tree) : '') + JSON.stringify(R.P);
  async function runBt() {
    const c = bt.cfg; const tree = c.mode === 'tree' ? (c.preset === 'current' ? st.tree : Sc.PRESETS.find((p) => p.id === c.preset).tree) : null;
    const key = cfgKey(); bt.prog = 'Menyiapkan…'; drawBt(); setProg(0.01);
    try { const r = await B.run(Object.assign({}, c, { tree }), (d, n, msg) => { setProg(d / n); bt.prog = msg; const m = $('#btMsg'); if (m) m.textContent = msg; }); r.cfgKey = key; bt.prog = null; }
    catch (e) { bt.prog = e.message; }
    setProg(null); if (!$('#bt').hidden) drawBt();
  }
  function btResult(r) {
    const k = (v, l, cls) => `<div><b class="${cls || ''}">${v}</b><span>${l}</span></div>`; const pc = (x) => (ok(x) ? `${(x * 100).toFixed(1)}%` : '—');
    const tbl2 = (rows, label) => rows.length ? `<table class="t"><tr><td class="mut sm">${label}</td><td class="mut sm">Trade · win · rata-rata R</td></tr>${rows.map((x) => `<tr><td>${esc(x.k)}</td><td>${x.n} · ${pc(x.win)} · <span class="${x.avgR > 0 ? 'up' : 'dn'}">${x.avgR.toFixed(2)}R</span></td></tr>`).join('')}</table>` : '';
    const warn = []; if (r.n < 30) warn.push(`Hanya ${r.n} trade — sampel terlalu kecil untuk disimpulkan.`);
    if (r.dropped.length) warn.push(`Kondisi tidak bisa diuji historis dan dilewati: ${[...new Set(r.dropped.map((d) => (F.byKey[d.f] || {}).label || d.f))].join(', ')} (fundamental/foreign/sektor/intraday tidak punya riwayat gratis).`);
    if (D.settings.provider === 'demo') warn.push('Mode simulasi — angka ini dari data acak, bukan hasil nyata.');
    const verdict = r.n < 30 ? 'Belum cukup data' : r.avgR > 0.15 && r.pf > 1.2 ? 'Ada edge positif' : r.avgR > 0 ? 'Edge tipis' : 'Tidak ada edge';
    return `<h2>Hasil · ${new Date(r.from * 1000).toLocaleDateString('id-ID', { month: 'short', year: 'numeric' })} – ${new Date(r.to * 1000).toLocaleDateString('id-ID', { month: 'short', year: 'numeric' })}</h2>
      <div class="card"><div class="rowx"><b style="font-size:16px">${verdict}</b><span class="sp"></span><span class="sm mut">${r.nStocks} saham · ${r.evals.toLocaleString('id-ID')} titik uji</span></div>
      <div class="kv">${k(r.n, 'trade')}${k(pc(r.winRate), 'win rate')}${k((r.avgR >= 0 ? '+' : '') + r.avgR.toFixed(2) + 'R', 'rata-rata per trade', r.avgR > 0 ? 'up' : 'dn')}${k(ok(r.pf) ? (r.pf === Infinity ? '∞' : r.pf.toFixed(2)) : '—', 'profit factor')}${k(pc(r.avgRet), 'return/trade')}${k(pc(r.alpha), 'vs IHSG/trade', r.alpha > 0 ? 'up' : 'dn')}${k(r.maxDD.toFixed(1) + 'R', 'max drawdown', 'dn')}${k(r.avgBars.toFixed(1), 'hari ditahan')}${k((r.totalR >= 0 ? '+' : '') + r.totalR.toFixed(1) + 'R', 'total')}</div>
      ${warn.map((w) => `<div class="note" style="color:var(--gold)">${esc(w)}</div>`).join('')}
      <div class="sm mut" style="margin-top:10px">Kurva ekuitas (kumulatif R, 1R = risiko per trade)</div><div id="btCurve" style="height:160px"></div>
      <div class="note">Acuan: rata-rata return 10 hari semua saham di semua titik uji = ${pc(r.base10)}.</div></div>
      <h2>Apakah Setup Score bekerja?</h2><div class="card">${tbl2(r.byScore, 'Skor saat sinyal')}<div class="note">Jika skor tinggi menghasilkan R lebih besar, skornya punya daya pembeda. Jika tidak, jangan terlalu mengandalkan skor untuk strategi ini.</div></div>
      <h2>Per kondisi pasar</h2><div class="card">${tbl2(r.byRegime, 'Regime saat sinyal')}</div>
      ${r.byType.length > 1 ? `<h2>Per jenis setup</h2><div class="card">${tbl2(r.byType, 'Setup')}</div>` : ''}
      <h2>Cara keluar</h2><div class="card">${tbl2(r.byExit, 'Exit')}</div>
      <h2>Trade terakhir</h2><div class="list">${r.trades.slice().sort((a, b) => b.d - a.d).slice(0, 40).map((t) => `<button class="row" data-sym="${t.sym}"><span class="sym">${t.sym}</span><span class="px ${t.R > 0 ? 'up' : 'dn'}">${t.R >= 0 ? '+' : ''}${t.R.toFixed(2)}R</span><span class="chg">${pc(t.ret)}</span><span class="sub">${new Date(t.d * 1000).toLocaleDateString('id-ID')} · ${esc(t.out)} · ${t.bars} hari · skor ${t.score}</span><span></span><span></span></button>`).join('')}</div>
      <div class="note">Hasil masa lalu tidak menjamin hasil masa depan. Backtest belum memperhitungkan slippage antrean, ARA/ARB beruntun, dan suspensi.</div>`;
  }

  // ---------------- TRACK RECORD ----------------
  function trackHtml() {
    const log = D.lsGet('rb.picklog', []); if (!log.length) return `<div class="empty"><b>Belum ada catatan</b>${D.settings.provider === 'demo' ? 'Track record hanya dicatat dengan data asli di aplikasi Android.' : 'Setiap hari AI Picks dicatat otomatis, lalu dievaluasi dengan harga sesudahnya. Hasil pertama terlihat setelah beberapa hari.'}</div>`;
    const ev = log.map(E.evalPick).sort((a, b) => b.t - a.t); const closed = ev.filter((x) => ok(x.R) && !x.open && x.status !== 'Aktif');
    const by = E.PICK_CATS.map((c) => { const a = closed.filter((x) => x.cat === c.id); return { c, n: a.length, win: a.filter((x) => x.R > 0).length / (a.length || 1), avgR: a.length ? a.reduce((s, x) => s + x.R, 0) / a.length : NaN }; });
    const all = closed.length ? closed.reduce((s, x) => s + x.R, 0) / closed.length : NaN;
    return `<div class="card"><div class="kv"><div><b>${log.length}</b><span>pick tercatat</span></div><div><b>${closed.length}</b><span>sudah selesai</span></div><div><b class="${all > 0 ? 'up' : 'dn'}">${ok(all) ? (all >= 0 ? '+' : '') + all.toFixed(2) + 'R' : '—'}</b><span>rata-rata</span></div></div>
      <table class="t" style="margin-top:8px">${by.map((x) => `<tr><td>${x.c.name}</td><td>${x.n ? `${x.n} · ${(x.win * 100).toFixed(0)}% · <span class="${x.avgR > 0 ? 'up' : 'dn'}">${x.avgR.toFixed(2)}R</span>` : '<span class="mut">belum ada</span>'}</td></tr>`).join('')}</table>
      <div class="note">Data nyata ke depan (out-of-sample): entry limit di area entry maks 5 hari, keluar di invalidasi/target 1/20 hari, sudah termasuk biaya.</div></div>
      <div class="list" style="margin-top:10px">${ev.slice(0, 60).map((x) => `<button class="row" data-sym="${x.sym}"><span><span class="sym">${x.sym}</span> <span class="chip">${esc((E.PICK_CATS.find((c) => c.id === x.cat) || {}).name || x.cat)}</span></span><span class="px ${x.R > 0 ? 'up' : x.R < 0 ? 'dn' : 'mut'}">${ok(x.R) ? (x.R >= 0 ? '+' : '') + x.R.toFixed(2) + 'R' : '—'}</span><span></span><span class="sub">${x.d} · ${esc(x.status)} · skor ${x.score}</span><span></span><span></span></button>`).join('')}</div>`;
  }
  // ---------------- AI PICKS ----------------
  function planCard(s, weak) {
    const p = s.plan, f = s.f; const pos = (s.scoreObj.comp.flatMap((c) => c.reasons.filter((r) => r[1]).map((r) => r[0]))).slice(0, 5);
    const inv = A.invalidators(f, p, s.ff).slice(0, 4);
    return `<div class="card pick ${weak ? 'weak' : ''}">${weak ? '<div class="sm" style="color:var(--gold);margin-bottom:6px">Belum lolos syarat kondisi pasar saat ini — perlakukan sebagai watchlist, bukan entry.</div>' : ''}<div class="top"><button class="sym" data-sym="${s.sym}" style="background:none;border:0;padding:0">${s.sym}</button><span class="chip y">${esc(p.type)}</span>${f.ppk ? '<span class="chip r">PPK/FCA</span>' : ''}<span class="sp"></span><span class="score ${scoreCls(f.score)}">${f.score}</span></div>
      <div class="rowx sm" style="margin-top:4px"><span>${px(f.close)} ${pct(f.chg1d)}</span><span class="mut">· ${esc(s.sector)}</span><span class="sp"></span><span class="chip ${p.status.startsWith('Harga') ? 'g' : 'b'}">${esc(p.status)}</span></div>
      <div class="pgrid"><div class="ent"><span>Area entry</span><b>${px(p.entry[0])}–${px(p.entry[1])}</b></div><div class="inv"><span>Invalidasi</span><b>${px(p.invalid)}</b></div><div><span>R/R (bersih)</span><b>${ok(p.rr) ? `${p.rr}x <span class="sm mut">(${ok(p.rrNet) ? p.rrNet : '—'}x)</span>` : '—'}</b></div>
        <div><span>Support</span><b>${p.support.map(px).join(' · ') || '—'}</b></div><div><span>Resistance</span><b>${p.resistance.map(px).join(' · ') || '—'}</b></div><div class="tgt"><span>Target</span><b>${p.targets.map(px).join(' · ') || '—'}</b></div></div>
      <ul class="why">${[...p.why, ...pos].slice(0, 5).map((r) => `<li class="p">${esc(r)}</li>`).join('')}${inv.map((r) => `<li class="m">${esc(r)}</li>`).join('')}</ul></div>`;
  }
  function rPicks() {
    if (!E.snap) { view.innerHTML = needSnap(); return; }
    const segs = `<div class="seg" id="pkSeg">${E.PICK_CATS.map((c) => `<button data-c="${c.id}" class="${c.id === st.pickCat ? 'on' : ''}">${c.name}</button>`).join('')}<button data-c="track" class="${st.pickCat === 'track' ? 'on' : ''}">Track record</button></div>`;
    if (st.pickCat === 'track') { view.innerHTML = segs + '<div style="margin-top:10px"></div>' + trackHtml(); $('#pkSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) { st.pickCat = b.dataset.c; rPicks(); } }; return; }
    const list = E.picks(st.pickCat); const pr = E.pickRules();
    const nPass = list.filter((x) => st.pickCat === 'risk' || E.pickPass(x)).length;
    view.innerHTML = `${segs}
      ${pr.label ? `<div class="card sm" style="margin-top:10px;border-color:${M.regime && M.regime.score < 40 ? 'var(--dn)' : 'var(--gold)'}">Pasar ${esc(M.regime ? M.regime.label.toLowerCase() : '')}: kandidat yang memenuhi syarat ketat (skor ≥ ${pr.minScore}, R/R bersih ≥ ${pr.minRR}) ditaruh paling atas. Yang belum memenuhi tetap ditampilkan dengan tanda dan risikonya lebih tinggi. <span class="mut">${nPass} dari ${list.length} lolos.</span></div>` : ''}
      <div class="rowx" style="margin-top:8px"><span class="sp"></span><button class="tg" id="pkBt">Backtest kategori ini</button></div>
      <div class="note">Dibuat otomatis dari data ${new Date(E.snap.asOf).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' })}. Skor menilai kualitas setup, bukan peluang profit. Bukan rekomendasi investasi.</div>
      ${list.length ? list.map((x) => planCard(x, st.pickCat !== 'risk' && !E.pickPass(x))).join('') : '<div class="empty"><b>Belum ada kandidat di kategori ini</b>Kondisi pasar hari ini belum memunculkan setup yang memenuhi syarat likuiditas dan R/R.</div>'}`;
    $('#pkSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) { st.pickCat = b.dataset.c; rPicks(); } };
    $('#pkBt').onclick = () => openBacktest({ mode: 'cat', cat: st.pickCat, entry: 'limit' });
  }

  // ---------------- RADAR ----------------
  Rd.listeners.add(() => { if (st.tab === 'radar' && st.radarView === 'live') rRadar(); });
  function rRadar() {
    const seg = `<div class="seg" id="rdSeg">${[['live', 'Live radar'], ['alert', 'Spike alert'], ['bandar', 'Bandar radar']].map(([k, v]) => `<button data-v="${k}" class="${k === st.radarView ? 'on' : ''}">${v}</button>`).join('')}</div>`;
    let body = '';
    if (st.radarView === 'live') {
      const bull = new Set(['pct', 'rvol', 'volAccel', 'breakout', 'newHigh', 'gapUp', 'accel', 'ubuy', 'acc', 'volx']);
      let evs = Rd.list(); if (st.radarFilter === 'bull') evs = evs.filter((e) => bull.has(e.type) && (e.type !== 'pct' || e.chg > 0)); if (st.radarFilter === 'bear') evs = evs.filter((e) => !bull.has(e.type) || (e.type === 'pct' && e.chg < 0));
      body = `<div class="card" style="margin-top:10px"><div class="rowx"><button class="btn ${Rd.running ? 'dng' : 'pri'}" id="rdGo">${Rd.running ? 'Hentikan radar' : 'Mulai radar'}</button><span class="sp"></span><span class="sm mut">${Rd.progress ? `Memindai ${Rd.progress[0]}/${Rd.progress[1]}` : Rd.last ? 'Update ' + new Date(Rd.last).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'Belum berjalan'}</span></div>
        <div class="note">Memantau ${Rd.symbols().length} saham tiap ${D.settings.radarInterval} detik pakai candle 5 menit (${D.settings.provider === 'yahoo' ? 'tertunda ±10 mnt dari Yahoo' : D.prov().name}). Diurutkan berdasarkan signifikansi.</div></div>
        <div class="seg" id="rdF" style="margin-top:10px">${[['all', 'Semua'], ['bull', 'Bullish'], ['bear', 'Bearish']].map(([k, v]) => `<button data-f="${k}" class="${k === st.radarFilter ? 'on' : ''}">${v}</button>`).join('')}</div>
        <div class="list" style="margin-top:8px">${evs.length ? evs.slice(0, 80).map((e) => `<button class="ev" data-sym="${e.sym}"><span class="tm">${new Date(e.t * 1000).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}<div class="sigb"><i style="width:${e.sig}%"></i></div></span><span><b>${e.sym}</b> <span class="chip ${/down|Low|usell|dist|breakdown/i.test(e.type) || (e.type === 'pct' && e.chg < 0) ? 'r' : 'g'}">${Rd.TYPES[e.type]}</span><div class="sm mut">${esc(e.txt)}</div></span><span style="text-align:right"><b>${px(e.px)}</b><div class="sm">${pct(e.chg)}</div></span></button>`).join('') : `<div class="empty"><b>${Rd.running ? 'Belum ada kejadian signifikan' : 'Radar belum berjalan'}</b>${Rd.running ? 'Kejadian muncul di sini begitu terdeteksi.' : 'Tekan Mulai radar untuk memantau pasar.'}</div>`}</div>`;
    } else if (st.radarView === 'alert') {
      const r = Rd.rules; const fld = (k, label, unit) => `<div class="fld"><input type="checkbox" class="sw" data-r="${k}" ${r[k].on ? 'checked' : ''}><label>${label}</label>${unit ? `<input type="number" step="any" data-rv="${k}" value="${r[k].v}"><span class="sm mut">${unit}</span>` : ''}</div>`;
      body = `<div class="card" style="margin-top:10px"><div class="fld"><input type="checkbox" class="sw" id="rNotif" ${r.notify ? 'checked' : ''}><label>Notifikasi Android</label></div>
        <div class="fld"><label>Cakupan</label><select id="rScope" style="background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:5px"><option value="liquid" ${r.scope === 'liquid' ? 'selected' : ''}>70 terlikuid + watchlist</option><option value="watchlist" ${r.scope === 'watchlist' ? 'selected' : ''}>Watchlist saja</option><option value="all" ${r.scope === 'all' ? 'selected' : ''}>Semua (lebih lambat)</option></select></div></div>
        <h2>Pemicu alert</h2><div class="card">${fld('pct', 'Harga bergerak ≥', '%')}${fld('rvol', 'Relative volume ≥', 'x')}${fld('volAccel', 'Akselerasi volume ≥', 'x')}${fld('breakout', 'Breakout / breakdown level harian')}${fld('newHigh', 'New high / low 52 minggu')}${fld('gap', 'Gap pembukaan ≥', '%')}${fld('accel', 'Akselerasi momentum')}${fld('volx', 'Ekspansi volatilitas')}${fld('ubuy', 'Unusual buying / akumulasi intraday')}${fld('usell', 'Unusual selling / distribusi intraday')}${fld('fvg', 'FVG baru (5 mnt)')}${fld('bos', 'BOS / CHoCH (5 mnt)')}${fld('sweep', 'Liquidity sweep (5 mnt)')}${fld('foreign', 'Foreign net harian ≥', 'M Rp')}</div>
        <div class="note">Alert berjalan selama aplikasi terbuka dan layar menyala (radar menjaga layar tetap aktif). Data Yahoo tertunda ±10 menit; pasang provider real-time di Pengaturan untuk alert instan.</div>`;
    } else {
      if (!E.snap) body = needSnap();
      else {
        const side = st.bandarSide; const all = [...E.snap.stocks.values()].filter((s) => s.f.avgValue20 >= 3e8).sort((a, b) => side > 0 ? b.bandar.acc - b.bandar.dis - (a.bandar.acc - a.bandar.dis) : b.bandar.dis - b.bandar.acc - (a.bandar.dis - a.bandar.acc)).slice(0, 25);
        body = `<div class="seg" id="bdSide" style="margin-top:10px"><button data-s="1" class="${side > 0 ? 'on' : ''}">Akumulasi</button><button data-s="-1" class="${side < 0 ? 'on' : ''}">Distribusi</button></div>
          <div class="note">Deteksi berbasis bukti harga–volume${E.snap.ffState.status !== 'unavailable' ? ' dan foreign flow' : ''}. Bukan label "bandar": setiap saham menampilkan bukti dan tingkat kepercayaannya. Data broker summary tidak tersedia dari sumber gratis.</div>
          ${all.map((s) => { const b = s.bandar; const evs = b.evidence.filter((e) => e.present && e.side === side).slice(0, 3);
            return `<div class="card"><div class="rowx"><button class="sym" data-sym="${s.sym}" style="background:none;border:0;padding:0">${s.sym}</button><span class="chip ${side > 0 ? 'g' : 'r'}">${esc(b.label)}</span><span class="sp"></span><span class="sm mut">Kepercayaan ${b.confLabel}</span></div>
              <div class="comp" style="margin-top:8px"><span>Akumulasi</span><div class="bar"><i style="width:${b.acc}%;background:var(--up)"></i></div><span>${b.acc}</span><span>Distribusi</span><div class="bar"><i style="width:${b.dis}%;background:var(--dn)"></i></div><span>${b.dis}</span></div>
              ${evs.map((e) => `<div class="evid on ${side > 0 ? 'acc' : 'dis'}"><i></i><span>${esc(e.txt)}</span></div>`).join('')}</div>`; }).join('')}`;
      }
    }
    view.innerHTML = seg + body;
    $('#rdSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) { st.radarView = b.dataset.v; rRadar(); } };
    const go = $('#rdGo'); if (go) go.onclick = () => { if (Rd.running) Rd.stop(); else { if (!E.snap) toast('Memuat data harian dulu untuk konteks level…'); Rd.start(); } rRadar(); };
    const rf = $('#rdF'); if (rf) rf.onclick = (e) => { const b = e.target.closest('button'); if (b) { st.radarFilter = b.dataset.f; rRadar(); } };
    const bs = $('#bdSide'); if (bs) bs.onclick = (e) => { const b = e.target.closest('button'); if (b) { st.bandarSide = +b.dataset.s; rRadar(); } };
    view.querySelectorAll('[data-r]').forEach((el) => (el.onchange = () => { Rd.rules[el.dataset.r].on = el.checked; Rd.saveRules(); }));
    view.querySelectorAll('[data-rv]').forEach((el) => (el.onchange = () => { Rd.rules[el.dataset.rv].v = parseFloat(el.value) || 0; Rd.saveRules(); }));
    const rn = $('#rNotif'); if (rn) rn.onchange = () => { Rd.rules.notify = rn.checked; Rd.saveRules(); };
    const sc = $('#rScope'); if (sc) sc.onchange = () => { Rd.rules.scope = sc.value; Rd.saveRules(); };
  }

  // ---------------- WATCHLIST ----------------
  function rWatch() {
    const w = watch();
    view.innerHTML = `<div class="rowx"><input id="wIn" placeholder="Tambah kode saham, mis. BBRI" autocapitalize="characters" style="flex:1;background:var(--s1);border:1px solid var(--line);border-radius:10px;padding:10px 12px"><button class="btn pri" id="wAdd">Tambah</button></div>
      <div class="list" style="margin-top:10px">${w.length ? w.map((sym) => { const s = E.snap && E.snap.stocks.get(sym); return s ? stockRow(s, `${esc(s.plan.status)}`) : `<button class="row" data-sym="${sym}"><span class="sym">${sym}</span><span class="px mut">—</span><span></span><span class="sub">Di luar daftar pindai · ketuk untuk analisis</span></button>`; }).join('') : '<div class="empty"><b>Watchlist kosong</b>Tambahkan kode saham untuk dipantau radar dan dibuka cepat.</div>'}</div>
      ${w.length ? '<div class="note">Hapus saham dari watchlist lewat tombol bintang di halaman saham.</div>' : ''}`;
    const add = () => { const v = $('#wIn').value.trim().toUpperCase().replace(/\.JK$/, ''); if (!/^[A-Z0-9]{3,5}$/.test(v)) return toast('Kode saham tidak valid'); const ww = watch(); if (!ww.includes(v)) { ww.push(v); setWatch(ww); } rWatch(); };
    $('#wAdd').onclick = add; $('#wIn').onkeydown = (e) => { if (e.key === 'Enter') add(); };
  }

  // ---------------- SEARCH ----------------
  function openSearch() {
    const el = $('#search'); el.hidden = false; document.body.style.overflow = 'hidden';
    el.innerHTML = `<div class="sh-h"><button class="icon" id="srBack" aria-label="Kembali">←</button><input id="srIn" class="srin" placeholder="Kode atau nama, mis. BBRI / Telkom" autocomplete="off" autocapitalize="characters" spellcheck="false"></div><div class="sh-b" id="srRes"></div>`;
    const inp = $('#srIn'); $('#srBack').onclick = closeSearch; drawSearch('');
    inp.oninput = () => drawSearch(inp.value); inp.onkeydown = (e) => { if (e.key === 'Enter') { const first = $('#srRes [data-go]'); if (first) first.click(); } };
    setTimeout(() => inp.focus(), 60);
    $('#srRes').onclick = (e) => { const b = e.target.closest('[data-go]'); if (!b) return; const sym = b.dataset.go; const rec = D.lsGet('rb.recent', []).filter((x) => x !== sym); rec.unshift(sym); D.lsSet('rb.recent', rec.slice(0, 10)); closeSearch(); openStock(sym); };
  }
  function closeSearch() { $('#search').hidden = true; if ($('#stock').hidden) document.body.style.overflow = ''; }
  function drawSearch(q) {
    q = q.trim(); const Q = q.toUpperCase(), ql = q.toLowerCase(); const box = $('#srRes'); const snap = E.snap;
    const row = (sym, name, sub) => { const x = snap && snap.stocks.get(sym); return `<button class="row" data-go="${sym}"><span><span class="sym">${sym === '^JKSE' ? 'IHSG' : sym}</span></span><span class="px">${x ? px(x.f.close) : ''}</span><span class="chg">${x ? pct(x.f.chg1d) : ''}</span><span class="sub">${esc(name || '')}${sub ? ' · ' + esc(sub) : ''}</span><span></span><span></span></button>`; };
    const uni = D.universe(); const nameOf = (sym) => (snap && snap.stocks.get(sym) && snap.stocks.get(sym).meta.name) || '';
    if (!q) { const rec = D.lsGet('rb.recent', []); box.innerHTML = `${row('^JKSE', 'Indeks Harga Saham Gabungan', 'indeks')}${rec.length ? `<h2>Terakhir dicari</h2><div class="list">${rec.map((r) => row(r, nameOf(r), D.sectorOf(r))).join('')}</div>` : ''}<div class="note">Bisa mencari saham apa pun di BEI dengan mengetik kode 4 huruf, termasuk yang tidak ada di daftar pantau.</div>`; return; }
    const hits = uni.filter((u) => u.sym.startsWith(Q) || nameOf(u.sym).toLowerCase().includes(ql) || (ql.length >= 3 && u.sector.toLowerCase().includes(ql)))
      .sort((a, b) => (b.sym === Q) - (a.sym === Q) || (b.sym.startsWith(Q)) - (a.sym.startsWith(Q)) || a.sym.localeCompare(b.sym)).slice(0, 30);
    const ihsg = /^(ihsg|jkse|indeks|composite)/i.test(q) ? row('^JKSE', 'Indeks Harga Saham Gabungan', 'indeks') : '';
    const direct = /^[A-Z]{4}$/.test(Q) && !uni.some((u) => u.sym === Q) ? `<button class="row" data-go="${Q}"><span><span class="sym">${Q}</span></span><span class="px sm" style="color:var(--info)">Buka ›</span><span></span><span class="sub">Di luar daftar pantau — dianalisis langsung</span><span></span><span></span></button>` : '';
    box.innerHTML = ihsg || direct || hits.length ? `<div class="list">${ihsg}${direct}${hits.map((u) => row(u.sym, nameOf(u.sym), u.sector)).join('')}</div>` : `<div class="empty"><b>Tidak ditemukan</b>Ketik kode 4 huruf (mis. BREN) untuk membuka saham di luar daftar pantau.</div>`;
  }

  // ---------------- STOCK PAGE ----------------
  const sp = { sym: null, tf: 'D', sec: 'sum', chart: null, data: null, F: null, overlays: { ema: true, lv: true, smc: true, plan: true } };
  const SECS_IDX = [['isum', 'Ringkasan'], ['breadth', 'Breadth'], ['movers', 'Penggerak'], ['tech', 'Teknikal'], ['struct', 'Struktur'], ['stats', 'Statistik & musiman'], ['global', 'Global & makro']];
  const SECS = [['sum', 'Ringkasan AI'], ['tech', 'Teknikal'], ['struct', 'Struktur'], ['smc', 'Smart Money & Flow'], ['vol', 'Volume'], ['fund', 'Fundamental'], ['val', 'Valuasi'], ['news', 'Berita'], ['risk', 'Risiko']];
  async function openStock(sym) {
    const el = $('#stock'); el.hidden = false; document.body.style.overflow = 'hidden'; sp.sym = sym; sp.tf = 'D'; sp.sec = 'sum'; sp.stories = null; sp.storiesErr = null; el.scrollTop = 0;
    el.innerHTML = `<div class="sh-h"><button class="icon" id="skBack" aria-label="Kembali">←</button><b class="sym">${sym}</b><span class="sp"></span></div><div class="sh-b"><div class="empty"><b>Memuat ${sym}…</b></div></div>`;
    $('#skBack').onclick = closeStock;
    try {
      let s = E.snap && E.snap.stocks.get(sym); sp.isIndex = sym === '^JKSE';
      if (sp.isIndex) {
        const r = E.snap ? E.snap.ihsg : await D.candles('^JKSE', 'D'); const F0 = F.compute(r.cd, { daily: true }); if (!F0) throw new Error('Data IHSG kosong');
        s = { sym, sector: 'Indeks', meta: Object.assign({}, r.meta, { name: 'Indeks Harga Saham Gabungan' }), cd: r.cd, F: F0, f: F0.f, plan: { bias: 0 } }; sp.sec = 'isum';
        sp.data = s; sp.F = s.F; sp.cd = s.cd; sp.meta = s.meta; drawStock(); return;
      }
      if (!s) { const r = await D.candles(sym, 'D'); const ih = E.snap ? E.snap.ihsg.cd : (await D.candles('^JKSE', 'D')).cd; s = E.analyzeDaily({ sym, sector: D.sectorOf(sym), meta: r.meta, cd: r.cd }, ih, null); if (!s) throw new Error('Riwayat harga terlalu pendek'); s.f.rsRating = NaN; E.finish(s); }
      sp.data = s; sp.F = s.F; sp.cd = s.cd; sp.meta = s.meta; drawStock();
      D.fundamentals(sym).then((fu) => { if (fu && sp.sym === sym) { E.applyFund(s, fu); E.finish(s); if (['fund', 'val', 'sum', 'risk'].includes(sp.sec)) drawSection(); } }).catch((e) => { s.fundErr = e.message; if (sp.sec === 'fund' || sp.sec === 'val') drawSection(); });
      D.news(sym).then((n) => { s.news = n; E.finish(s); if (sp.sym === sym && (sp.sec === 'news' || sp.sec === 'sum')) drawSection(); }).catch((e) => { s.news = { items: [], err: e.message }; });
    } catch (e) { el.querySelector('.sh-b').innerHTML = `<div class="empty"><b>Data ${sym} tidak bisa dimuat</b>${esc(e.message)}. Periksa kode saham atau koneksi.</div>`; }
  }
  function closeStock() { $('#stock').hidden = true; document.body.style.overflow = ''; try { sp.chart && sp.chart.remove(); } catch (e) {} sp.chart = null; if (st.tab === 'watch') rWatch(); }
  function drawStock() {
    const s = sp.data, f = s.f, el = $('#stock'); const inW = watch().includes(s.sym); const meta = sp.meta; const px = sp.isIndex ? (x) => num(x, 2) : A.fmt; const secs = sp.isIndex ? SECS_IDX : SECS;
    el.innerHTML = `<div class="sh-h stk-h"><button class="icon" id="skBack" aria-label="Kembali">←</button><div style="min-width:0;flex:1"><b class="sym">${sp.isIndex ? 'IHSG' : s.sym}</b><div class="nm">${esc(meta.name || '')} · ${esc(s.sector)}</div></div>${sp.isIndex ? '' : `<button class="icon" id="skStar" aria-label="Watchlist" style="color:${inW ? 'var(--gold)' : 'var(--mut)'}">${inW ? '★' : '☆'}</button>`}</div>
      <div class="sh-b"><div class="stk-px"><b>${px(f.close)}</b>${pct(f.chg1d)}<span class="sp"></span><span class="chip ${meta.status === 'simulated' ? 'r' : meta.status === 'realtime' ? 'g' : 'y'}">${D.STATUS[meta.status]} · ${esc(meta.source)}</span></div>
      ${sp.isIndex ? `<div class="sm mut" style="margin-top:4px">Sesi ${new Date((s.cd.t[s.cd.t.length - 1] + 25200) * 1000).toLocaleDateString('id-ID', { timeZone: 'UTC', weekday: 'long', day: 'numeric', month: 'long' })} · O ${px(s.cd.o[s.cd.o.length - 1])} · H ${px(s.cd.h[s.cd.h.length - 1])} · L ${px(s.cd.l[s.cd.l.length - 1])}</div>` : ''}
      ${(() => { const L = sp.isIndex ? null : A.limits(f.close); return L ? `<div class="sm mut" style="margin-top:4px">Batas sesi berikutnya: ARB <span class="dn">${px(L.arb)}</span> (−${num(L.arbPct, 0)}%) · ARA <span class="up">${px(L.ara)}</span> (+${num(L.araPct, 0)}%)${f.ppk ? ' · <span class="chip r">Papan Pemantauan Khusus</span>' : ''}</div>` : ''; })()}
      <div class="seg" id="tfSeg" style="margin-top:10px">${Object.entries(D.TF).map(([k, v]) => `<button data-tf="${k}" class="${k === sp.tf ? 'on' : ''}">${v}</button>`).join('')}</div>
      <div id="chart" class="chart"></div>
      <div class="seg" id="ovSeg" style="margin-top:6px">${[['ema', 'EMA'], ['lv', 'S/R'], ['smc', 'FVG/OB/BOS'], ...(sp.isIndex ? [] : [['plan', 'Rencana']])].map(([k, v]) => `<button data-ov="${k}" class="${sp.overlays[k] ? 'on' : ''}">${v}</button>`).join('')}</div>
      <div class="tabs2"><div class="seg" id="secSeg">${secs.map(([k, v]) => `<button data-s="${k}" class="${k === sp.sec ? 'on' : ''}">${v}</button>`).join('')}</div></div>
      <div id="sec"></div></div>`;
    $('#skBack').onclick = closeStock;
    if ($('#skStar')) $('#skStar').onclick = () => { let w = watch(); w = w.includes(s.sym) ? w.filter((x) => x !== s.sym) : [...w, s.sym]; setWatch(w); drawStock(); };
    $('#tfSeg').onclick = async (e) => { const b = e.target.closest('button'); if (!b) return; sp.tf = b.dataset.tf; $('#tfSeg').querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
      try { if (sp.tf === 'D') { sp.F = s.F; sp.cd = s.cd; } else { const r = await D.candles(s.sym, sp.tf); sp.cd = r.cd; sp.F = F.compute(r.cd, { intraday: !['D', 'W'].includes(sp.tf) }); if (!sp.F) throw new Error('Data terlalu pendek'); } drawChart(); if (['tech', 'struct', 'smc', 'vol'].includes(sp.sec)) drawSection(); }
      catch (err) { toast('Timeframe gagal dimuat: ' + err.message); } };
    $('#ovSeg').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; sp.overlays[b.dataset.ov] = !sp.overlays[b.dataset.ov]; b.classList.toggle('on'); drawChart(); };
    $('#secSeg').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; sp.sec = b.dataset.s; $('#secSeg').querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); drawSection(); };
    $('#sec').addEventListener('click', (e) => { const a = e.target.closest('a[data-ext]'); if (a) { e.preventDefault(); return openExt(a.href); } const ai = e.target.closest('[data-ai]'); if (ai) return runAI(ai.dataset.ai); const rd = e.target.closest('[data-read]'); if (rd) return openReader(rd.dataset.read); const b = e.target.closest('[data-sym]'); if (b && b.dataset.sym !== sp.sym) openStock(b.dataset.sym); });
    drawChart(); drawSection();
  }
  function drawChart() {
    const el = $('#chart'); if (!el || !window.LightweightCharts) return; try { sp.chart && sp.chart.remove(); } catch (e) {}
    const cd = sp.cd, Fx = sp.F, intraday = !['D', 'W'].includes(sp.tf); const n = cd.c.length; const k0 = Math.max(0, n - (intraday ? 400 : 260));
    const ch = LightweightCharts.createChart(el, { height: 300, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: '#8EA0B5', fontFamily: 'IBM Plex Sans', fontSize: 11 }, grid: { vertLines: { color: 'rgba(42,59,82,.35)' }, horzLines: { color: 'rgba(42,59,82,.35)' } }, rightPriceScale: { borderColor: '#2A3B52' }, timeScale: { borderColor: '#2A3B52', timeVisible: intraday, secondsVisible: false }, crosshair: { mode: 0 }, localization: { priceFormatter: (p) => (sp.isIndex ? num(p, 2) : A.fmt(p)) } });
    sp.chart = ch; const T = (i) => cd.t[i] + 25200;
    const cs = ch.addCandlestickSeries({ upColor: '#22B07D', downColor: '#E5484D', borderVisible: false, wickUpColor: '#22B07D', wickDownColor: '#E5484D' });
    const rows = []; for (let i = k0; i < n; i++) rows.push({ time: T(i), open: cd.o[i], high: cd.h[i], low: cd.l[i], close: cd.c[i] }); cs.setData(rows);
    const vs = ch.addHistogramSeries({ priceScaleId: 'vol', priceFormat: { type: 'volume' }, lastValueVisible: false, priceLineVisible: false });
    ch.priceScale('vol').applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });
    vs.setData(rows.map((r, j) => ({ time: r.time, value: cd.v[k0 + j], color: r.close >= r.open ? 'rgba(34,176,125,.35)' : 'rgba(229,72,77,.35)' })));
    if (sp.overlays.ema) for (const [k, c] of [['ema20', '#5AA9FF'], ['ema50', '#E9B949'], ['ema200', '#B48CFF']]) { const ser = Fx.se[k]; if (!ser) continue; const ls = ch.addLineSeries({ color: c, lineWidth: 1, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false }); ls.setData(rows.map((r, j) => ({ time: r.time, value: ser[k0 + j] })).filter((x) => ok(x.value))); }
    const line = (price, color, title, style = 2) => ok(price) && cs.createPriceLine({ price, color, lineWidth: 1, lineStyle: style, axisLabelVisible: true, title });
    if (sp.overlays.lv) { Fx.st.levels.supports.slice(0, 2).forEach((x) => line(x.price, '#22B07D', 'S')); Fx.st.levels.resistances.slice(0, 2).forEach((x) => line(x.price, '#E5484D', 'R')); }
    const mk = [];
    if (sp.overlays.smc) {
      for (const e of Fx.st.ev) if (e.i >= k0) mk.push({ time: T(e.i), position: e.dir > 0 ? 'belowBar' : 'aboveBar', color: e.type === 'CHoCH' ? '#E9B949' : e.dir > 0 ? '#22B07D' : '#E5484D', shape: e.dir > 0 ? 'arrowUp' : 'arrowDown', text: e.type });
      for (const w of Fx.st.sweeps) if (w.i >= k0) mk.push({ time: T(w.i), position: w.dir > 0 ? 'belowBar' : 'aboveBar', color: '#5AA9FF', shape: 'circle', text: 'sweep' });
      const nb = Fx.st.nearBull; if (nb) { line(nb.hi, '#5AA9FF', 'FVG', 1); line(nb.lo, '#5AA9FF', '', 1); }
      const ob = Fx.st.obs.filter((b) => b.dir === 1 && b.status !== 'breaker').pop(); if (ob && ob.i >= k0) { line(ob.hi, '#B48CFF', 'OB', 3); line(ob.lo, '#B48CFF', '', 3); }
    }
    if (sp.overlays.plan && sp.tf === 'D' && sp.data.plan.bias > 0) { const p = sp.data.plan; line(p.entry[1], '#E9B949', 'Entry', 0); line(p.entry[0], '#E9B949', '', 0); line(p.invalid, '#E5484D', 'Invalid', 0); p.targets.slice(0, 2).forEach((t, i) => line(t, '#22B07D', 'T' + (i + 1), 0)); }
    mk.sort((a, b) => a.time - b.time); cs.setMarkers(mk);
    ch.timeScale().setVisibleLogicalRange({ from: rows.length - (intraday ? 120 : 110), to: rows.length + 3 });
  }
  const tbl = (rows) => `<table class="t">${rows.filter(Boolean).map(([a, b]) => `<tr><td>${a}</td><td>${b}</td></tr>`).join('')}</table>`;
  const yn = (b, good = true) => (b ? `<span class="${good ? 'up' : 'dn'}">Ya</span>` : '<span class="mut">Tidak</span>');
  function scoreAnatomy(so) {
    const C = 2 * Math.PI * 42; const v = so.total;
    return `<div class="card"><div class="anat"><div class="ring"><svg width="96" height="96"><circle cx="48" cy="48" r="42" fill="none" stroke="#24344A" stroke-width="7"/><circle cx="48" cy="48" r="42" fill="none" stroke="#E9B949" stroke-width="7" stroke-linecap="round" stroke-dasharray="${(C * v) / 100} ${C}"/></svg><b>${v}</b><span>${so.grade}</span></div>
      <div class="comp">${so.comp.map((c) => `<span>${esc(c.label)}</span><div class="bar ${c.score < 50 ? 'lo' : ''}"><i style="width:${ok(c.score) ? c.score : 0}%"></i></div><span>${ok(c.score) ? c.score : '—'}</span>`).join('')}</div></div>
      <details class="why"><summary>Kenapa skornya ${v}?</summary><ul class="why">${so.comp.flatMap((c) => c.reasons.map((r) => `<li class="${r[1] ? 'p' : 'm'}">${esc(c.label)}: ${esc(r[0])}</li>`)).join('')}</ul></details>
      <div class="note">Skor setup menilai kualitas kondisi teknikal & fundamental. Ini bukan probabilitas profit.</div></div>`;
  }
  function drawSection() {
    const box = $('#sec'); if (!box) return; const s = sp.data, f = s.f, Fx = sp.F, g = Fx.f, stc = Fx.st; const tfl = D.TF[sp.tf]; let h = '';
    const px = sp.isIndex ? (x) => num(x, 2) : A.fmt;
    if (sp.isIndex && !['tech', 'struct'].includes(sp.sec)) { box.innerHTML = indexSection(sp.sec, s); bindIndexSection(s); return; }
    switch (sp.sec) {
      case 'sum': h = `<div class="card ai">${esc(A.summary(s.sym, s.F, s.plan, s.bandar, s.fund))}</div><h2>Anatomi skor</h2>${scoreAnatomy(s.scoreObj)}<h2>Rencana trading (harian)</h2>${planCard(s)}`; break;
      case 'tech': h = `<div class="note">Timeframe: ${tfl}</div><div class="card">${tbl([
        ['EMA 20 / 50 / 200', `${px(g.ema20)} · ${px(g.ema50)} · ${px(g.ema200)}`], ['Susunan EMA', g.emaStackBull ? '<span class="up">Bertingkat naik</span>' : g.emaStackBear ? '<span class="dn">Bertingkat turun</span>' : 'Campuran'],
        ['SMA 50 / 150 / 200', `${px(g.sma50)} · ${px(g.sma150)} · ${px(g.sma200)}`], ['RSI 14', `${num(g.rsi, 1)} ${g.rsiRising ? '↑' : '↓'}`], ['MACD / signal / hist', `${num(g.macd, 1)} / ${num(g.macdSignal, 1)} / ${num(g.macdHist, 1)}`],
        ['MACD cross (3 bar)', g.macdCrossUp ? '<span class="up">Golden cross</span>' : g.macdCrossDown ? '<span class="dn">Death cross</span>' : '—'], ['ADX · +DI>−DI', `${num(g.adx, 1)} · ${yn(g.diBull)}`],
        ['Stochastic %K / %D', `${num(g.stochK, 1)} / ${num(g.stochD, 1)}`], ['Bollinger %B · lebar', `${num(g.pctB, 2)} · ${num(g.bbWidth, 1)}% (persentil ${num(g.bbWidthPctl, 0)})`], ['ATR 14', `${px(g.atr)} (${num(g.atrPct, 1)}%)`],
        ['VWAP', `${px(g.vwap)} ${g.aboveVwap ? '<span class="up">di atas</span>' : '<span class="dn">di bawah</span>'}`], ['Anchored VWAP (swing low)', ok(g.avwap) ? `${px(g.avwap)} ${g.aboveAvwap ? '<span class="up">di atas</span>' : '<span class="dn">di bawah</span>'}` : '—'],
        ['MFI 14 · CMF 20', `${num(g.mfi, 0)} · ${num(g.cmf, 2)}`], ['Divergence RSI', g.rsiDivBull ? '<span class="up">Bullish</span>' : g.rsiDivBear ? '<span class="dn">Bearish</span>' : 'Tidak ada'],
        ['Divergence MACD', g.macdDivBull ? '<span class="up">Bullish</span>' : g.macdDivBear ? '<span class="dn">Bearish</span>' : 'Tidak ada'], ['Divergence harga–OBV', g.pvDivBull ? '<span class="up">Bullish</span>' : g.pvDivBear ? '<span class="dn">Bearish</span>' : 'Tidak ada'],
        sp.tf === 'D' && ['Performa 1M / 1B / 3B', `${pct(f.perf1w, 1)} ${pct(f.perf1m, 1)} ${pct(f.perf3m, 1)}`], sp.tf === 'D' && ['Performa 6B / 1T', `${pct(f.perf6m, 1)} ${pct(f.perf1y, 1)}`],
        sp.tf === 'D' && ['RS Rating · vs IHSG 3B', `${ok(f.rsRating) ? f.rsRating : '—'} · ${pct(f.rsIhsg3m, 1)}`], sp.tf === 'D' && ['RS vs sektor 3B', pct(f.rsSector3m, 1)],
        sp.tf === 'D' && ['Range 52 minggu', `${px(f.lo52)} – ${px(f.hi52)} (${num(f.dist52wHigh, 1)}% di bawah high)`]])}</div>`; break;
      case 'struct': { const pv = stc.piv.filter((p) => p.conf <= sp.cd.c.length - 1).slice(-6).reverse(); const evs = stc.ev.slice(-5).reverse();
        h = `<div class="note">Timeframe: ${tfl}</div><div class="card">${tbl([['Struktur', esc(stc.sw.label)], ['Swing terakhir', pv.map((p) => `<span class="${p.label === 'HH' || p.label === 'HL' ? 'up' : p.label === 'LH' || p.label === 'LL' ? 'dn' : 'mut'}">${p.label}</span> ${px(p.price)}`).join('<br>') || '—'],
          ['BOS / CHoCH terakhir', evs.map((e) => `${e.type} ${e.dir > 0 ? '<span class="up">bullish</span>' : '<span class="dn">bearish</span>'} ${px(e.level)} <span class="mut">(${sp.cd.c.length - 1 - e.i} bar lalu)</span>`).join('<br>') || '—'],
          ['Support', stc.levels.supports.slice(0, 3).map((x) => `${px(x.price)} <span class="mut">(${x.touches}x)</span>`).join('<br>') || '—'], ['Resistance', stc.levels.resistances.slice(0, 3).map((x) => `${px(x.price)} <span class="mut">(${x.touches}x)</span>`).join('<br>') || '—'],
          ['Breakout / retest', stc.brk ? `Breakout ${px(stc.brk.level)} (RVOL ${num(stc.brk.rvol, 1)}x)` : stc.rt ? `Retest ${px(stc.rt.level)} bertahan` : '—'],
          ['Konsolidasi · kompresi · base', `${yn(g.consolidation)} · ${yn(g.compression)} · ${yn(g.baseFormation)}`], ['Range expansion', yn(g.rangeExpansion)],
          ['Equal highs / lows', `${stc.eqH ? px(stc.eqH.price) : '—'} / ${stc.eqL ? px(stc.eqL.price) : '—'}`], ['Liquidity sweep terakhir', (() => { const w = stc.sweeps[stc.sweeps.length - 1]; return w ? `${w.dir > 0 ? 'Bawah' : 'Atas'} ${px(w.level)} <span class="mut">(${sp.cd.c.length - 1 - w.i} bar lalu)</span>` : '—'; })()],
          ['Stop hunt (sweep + volume)', yn(g.stopHunt)], ['Premium / discount', ok(g.pdPos) ? `${g.pdPos > 0.5 ? 'Premium' : 'Discount'} (${num(g.pdPos * 100, 0)}% dari dealing range)` : '—']])}</div>`; break; }
      case 'smc': { const L = sp.cd.c.length - 1; const fv = stc.fvg.filter((x) => x.status !== 'filled' && x.i > L - 120).slice(-6).reverse(); const obs = stc.obs.slice(-5).reverse(); const b = s.bandar;
        h = `<div class="note">Timeframe: ${tfl}</div><h2>Fair value gap</h2><div class="card">${fv.length ? tbl(fv.map((x) => [`${x.dir > 0 ? '<span class="up">Bullish</span>' : '<span class="dn">Bearish</span>'} <span class="mut">${L - x.i} bar lalu</span>`, `${px(x.lo)}–${px(x.hi)} · ${x.status === 'open' ? 'terbuka' : 'termitigasi sebagian'}`])) : '<span class="mut">Tidak ada FVG aktif.</span>'}</div>
          <h2>Order block & breaker</h2><div class="card">${obs.length ? tbl(obs.map((x) => [`${x.dir > 0 ? '<span class="up">OB bullish</span>' : '<span class="dn">OB bearish</span>'} <span class="mut">${L - x.i} bar lalu</span>`, `${px(x.lo)}–${px(x.hi)} · ${x.status === 'fresh' ? 'belum disentuh' : x.status === 'mitigated' ? 'sudah dimitigasi' : 'jadi breaker'}`])) : '<span class="mut">Tidak ada order block terdeteksi.</span>'}
          ${tbl([['Displacement naik / turun (3 bar)', `${yn(g.displacementBull)} / ${yn(g.displacementBear, false)}`], ['BOS + FVG bullish', yn(g.bosFvg)], ['Sweep + reversal', yn(g.sweepReversal)]])}</div>
          <h2>Foreign flow</h2><div class="card">${s.ff ? tbl([['Net 1 hari', A.fmtRp(s.ff.net1d)], ['Net 5 hari', A.fmtRp(s.ff.net5d)], ['Hari beruntun net buy', s.ff.streak]]) : `<span class="mut">${esc(D.ffState.note)}</span>`}<div class="note">Status: ${esc(D.STATUS[D.ffState.status])}. ${esc(D.ffState.status !== 'unavailable' ? D.ffState.note : '')}</div></div>
          <h2>Bandar radar (harian)</h2><div class="card"><div class="rowx"><b>${esc(b.label)}</b><span class="sp"></span><span class="chip">Kepercayaan ${b.confLabel}</span></div>
          <div class="comp" style="margin:8px 0"><span>Akumulasi</span><div class="bar"><i style="width:${b.acc}%;background:var(--up)"></i></div><span>${b.acc}</span><span>Distribusi</span><div class="bar"><i style="width:${b.dis}%;background:var(--dn)"></i></div><span>${b.dis}</span></div>
          ${b.evidence.filter((e) => e.side !== 0 || !e.available).map((e) => `<div class="evid ${!e.available ? 'na' : e.present ? 'on ' + (e.side > 0 ? 'acc' : 'dis') : ''}"><i></i><span>${esc(e.txt)}${!e.available ? ' — tidak tersedia' : e.present ? '' : ' <span class="mut">(tidak terpenuhi)</span>'}</span></div>`).join('')}</div>`; break; }
      case 'vol': { const vp = stc.vp; const mx = vp ? Math.max(...vp.bins.map((x) => x.vol)) : 1;
        h = `<div class="note">Timeframe: ${tfl}</div><div class="card">${tbl([['Volume terakhir', num(g.volume, 0)], ['Relative volume', `${num(g.rvol, 2)}x`], ['Tren volume (avg5/avg20)', `${num(g.volTrend, 2)}x ${g.volContraction ? '<span class="mut">(menyusut)</span>' : ''}`],
          ['Up / down volume (20)', `${num(g.upDownVol, 2)}x`], ['OBV', `${g.obvRising ? '<span class="up">menanjak</span>' : '<span class="dn">melemah</span>'}${g.obvNewHigh ? ' · new high' : ''}`], ['A/D line', g.adRising ? '<span class="up">naik</span>' : '<span class="dn">turun</span>'],
          ['CMF 20 · MFI 14', `${num(g.cmf, 2)} · ${num(g.mfi, 0)}`], ['Nilai transaksi', `${A.fmtRp(g.value)} (rata-rata ${A.fmtRp(g.avgValue20)})`], vp && ['POC · VAH · VAL', `${px(vp.poc)} · ${px(vp.vah)} · ${px(vp.val)}`]])}</div>
          ${vp ? `<h2>Volume profile</h2><div class="card">${vp.bins.slice().reverse().filter((_, i) => i % 2 === 0).map((x) => `<div class="comp" style="grid-template-columns:64px 1fr"><span class="mut">${px(x.price)}</span><div class="bar"><i style="width:${(x.vol / mx) * 100}%;background:${Math.abs(x.price - vp.poc) < (vp.vah - vp.val) / 15 ? 'var(--gold)' : x.price <= vp.vah && x.price >= vp.val ? '#3d6a9c' : 'var(--s3)'}"></i></div></div>`).join('')}<div class="note">Emas = POC, biru = value area 70%.</div></div>` : ''}`; break; }
      case 'fund': { const fu = s.fund;
        h = fu ? `<div class="card">${tbl([['Pertumbuhan pendapatan (YoY)', pct(fu.revGrowth, 1)], ['Pertumbuhan laba (YoY)', pct(fu.epsGrowth, 1)], ['Pertumbuhan laba kuartalan', pct(fu.epsQGrowth, 1)], ['Akselerasi laba', fu.earningsAccel === undefined ? '—' : yn(fu.earningsAccel)],
          ['ROE · ROA', `${num(fu.roe, 1)}% · ${num(fu.roa, 1)}%`], ['ROIC (estimasi)', ok(fu.roic) ? num(fu.roic, 1) + '%' : '—'], ['Gross · operating · net margin', `${num(fu.grossMargin, 1)}% · ${num(fu.opMargin, 1)}% · ${num(fu.netMargin, 1)}%`],
          ['Debt to equity', ok(fu.der) ? num(fu.der, 0) + '%' : '—'], ['Current ratio', num(fu.currentRatio, 2)], ['Arus kas operasi', A.fmtRp(fu.ocf)], ['Free cash flow', A.fmtRp(fu.fcf)], ['FCF yield', ok(fu.fcfYield) ? num(fu.fcfYield, 1) + '%' : '—'],
          ['Skor kualitas', ok(f.qualityScore) ? `<b>${f.qualityScore}</b>/100` : '—']])}
          <div class="note">Sumber: ${esc(fu.source)} (${esc(D.STATUS[fu.status])}, laporan terakhir)${fu.currency && fu.currency !== 'IDR' ? `. Laporan dalam ${fu.currency}, nilai Rp dikonversi kurs terkini` : ''}. Rasio bank (DER, FCF) tidak dipakai dalam skor kualitas.</div></div>
          ${fu.quarterly ? `<h2>Laba kuartalan</h2><div class="card">${tbl(fu.quarterly.map((q) => [esc(q.d), `${A.fmtRp(q.earn)} <span class="mut">/ pendapatan ${A.fmtRp(q.rev)}</span>`]))}</div>` : ''}`
          : `<div class="empty"><b>${s.fundErr ? 'Data fundamental tidak tersedia' : 'Memuat fundamental…'}</b>${esc(s.fundErr || '')}</div>`; break; }
      case 'val': { const fu = s.fund; const sec = E.snap && E.snap.sectors.find((x) => x.name === s.sector);
        h = fu ? `<div class="card">${tbl([['P/E', ok(fu.pe) ? num(fu.pe, 1) + 'x' : '—'], ['P/B', ok(fu.pb) ? num(fu.pb, 2) + 'x' : '—'], ['EV/EBITDA', ok(fu.evEbitda) ? num(fu.evEbitda, 1) + 'x' : '—'], ['Dividend yield', ok(fu.divYield) ? num(fu.divYield, 2) + '%' : '—'],
          ['Kapitalisasi pasar', A.fmtRp(fu.marketCap)], ['P/E vs median sektor', ok(f.peVsSector) ? `${num(f.peVsSector, 2)}x <span class="mut">(median ${num(sec && sec.medPe, 1)}x)</span>` : '<span class="mut">butuh data fundamental sektor — jalankan preset fundamental</span>'],
          ['P/B vs median sektor', ok(f.pbVsSector) ? `${num(f.pbVsSector, 2)}x <span class="mut">(median ${num(sec && sec.medPb, 2)}x)</span>` : '—'], ['Valuasi vs rata-rata historis', '<span class="mut">Tidak tersedia dari sumber gratis</span>']])}</div>`
          : `<div class="empty"><b>${s.fundErr ? 'Data valuasi tidak tersedia' : 'Memuat valuasi…'}</b>${esc(s.fundErr || '')}</div>`; break; }
      case 'news': {
        if (!sp.stories && !sp.storiesErr) { h = '<div class="empty"><b>Memuat berita…</b></div>'; const sym = s.sym; N.forSymbol(sym).then((x) => { if (sp.sym === sym) { sp.stories = x; if (sp.sec === 'news') drawSection(); } }).catch((e) => { if (sp.sym === sym) { sp.storiesErr = e.message; if (sp.sec === 'news') drawSection(); } }); break; }
        if (sp.storiesErr) { h = `<div class="empty"><b>Berita tidak tersedia</b>${esc(sp.storiesErr)}</div>`; break; }
        h = sp.stories.length ? sp.stories.map((x) => storyCard(x)).join('') + '<div class="note">Label kesadaran pasar: jumlah sumber, umur berita, dan reaksi harga/volume sejak berita terbit.</div>' : '<div class="empty"><b>Tidak ada berita 7 hari terakhir</b></div>'; break; }
      case 'newsOld': { const nw = s.news;
        h = !nw ? '<div class="empty"><b>Memuat berita…</b></div>' : nw.items && nw.items.length ? `<div class="list">${nw.items.map((x) => `<a data-ext href="${esc(x.link)}" class="row" style="text-decoration:none;color:inherit;grid-template-columns:10px 1fr"><span style="width:8px;height:8px;border-radius:50%;background:${x.s > 0 ? 'var(--up)' : x.s < 0 ? 'var(--dn)' : 'var(--s3)'}"></span><span>${esc(x.title)}<div class="sm mut">${esc(x.src || '')} · ${x.date ? new Date(x.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }) : ''}</div></span></a>`).join('')}</div><div class="note">Sumber: Google News. Titik warna = sentimen kata kunci judul (kasar, bukan analisis isi).</div>`
          : `<div class="empty"><b>Tidak ada berita</b>${esc(nw.err || (D.settings.provider === 'demo' ? 'Berita tidak tersedia di mode simulasi.' : 'Belum ada berita terbaru untuk saham ini.'))}</div>`; break; }
      case 'risk': { const cd = s.cd; let peak = -Infinity, mdd = 0; for (let i = Math.max(0, cd.c.length - 250); i < cd.c.length; i++) { peak = Math.max(peak, cd.c[i]); mdd = Math.min(mdd, (cd.c[i] - peak) / peak); }
        h = `<div class="card">${tbl([['Volatilitas (ATR harian)', `${num(f.atrPct, 2)}%`], ['Beta', ok(f.beta) ? num(f.beta, 2) : '—'], ['Max drawdown 1 tahun', pct(mdd * 100, 1)], ['Jarak ke invalidasi', s.plan.bias > 0 ? `${num(s.plan.riskPct, 1)}%` : '—'],
          ['Likuiditas', `${A.fmtRp(f.avgValue20)}/hari ${f.avgValue20 < 1e9 ? '<span class="dn">(tipis)</span>' : ''}`], ['Posisi di range 52 mgg', ok(f.hi52) ? `${num(((f.close - f.lo52) / (f.hi52 - f.lo52)) * 100, 0)}%` : '—'], ['Bukti distribusi', `${s.bandar.dis}/100`]])}</div>
          <h2>Sensitivitas makro</h2><div class="card">${(() => { const sv = M.sensitivity(s); return sv.length ? tbl(sv.map((x) => [esc(x.name), `korelasi ${x.r.toFixed(2)}${x.lag ? ' (H+1)' : ''} · beta ${num(x.beta, 2)}`])) + '<div class="note">Korelasi return harian 6 bulan terhadap komoditas/makro. Beta 0,5 = saham cenderung bergerak 0,5% saat instrumen bergerak 1%.</div>' : `<span class="mut">${M.data ? 'Tidak ada hubungan yang terukur.' : 'Data makro belum dimuat (buka tab Pasar).'}</span>`; })()}</div>
          <h2>Yang bisa membatalkan setup</h2><div class="card"><ul class="why">${A.invalidators(f, s.plan, s.ff).map((r) => `<li class="m">${esc(r)}</li>`).join('')}</ul></div>`; break; }
    }
    box.innerHTML = h;
  }

  // ---------------- IHSG ANALYSIS (index page) ----------------
  const ix = { movers: null, moversBusy: false, d5: null, d5Busy: false, mvPeriod: 'p1d' };
  const n2 = (x) => num(x, 2);
  const dkey = (t) => Math.floor((t + 25200) / 86400);
  function breadthSeries(days = 80) {
    const snap = E.snap; if (!snap) return null; const ih = snap.ihsg.cd; const keys = ih.t.slice(-days).map(dkey); const pos = new Map(keys.map((k, i) => [k, i]));
    const z = () => new Array(keys.length).fill(0); const a50 = z(), a20 = z(), tot = z(), adv = z(), dec = z(), nh = z(), nl = z();
    for (const st of snap.stocks.values()) { const cd = st.cd, c = cd.c; const e50 = I.ema(c, 50), e20 = I.ema(c, 20);
      for (let i = Math.max(251, c.length - days - 5); i < c.length; i++) { const k = pos.get(dkey(cd.t[i])); if (k === undefined) continue; tot[k]++; if (c[i] > e50[i]) a50[k]++; if (c[i] > e20[i]) a20[k]++; if (c[i] > c[i - 1]) adv[k]++; else if (c[i] < c[i - 1]) dec[k]++;
        let hi = -Infinity, lo = Infinity; for (let j = i - 250; j < i; j++) { if (cd.h[j] > hi) hi = cd.h[j]; if (cd.l[j] < lo) lo = cd.l[j]; } if (cd.h[i] > hi) nh[k]++; if (cd.l[i] < lo) nl[k]++; } }
    const ad = []; let cum = 0; const ratio = keys.map((_, i) => (adv[i] + dec[i] ? ((adv[i] - dec[i]) / (adv[i] + dec[i])) * 1000 : 0));
    keys.forEach((_, i) => { cum += adv[i] - dec[i]; ad.push(cum); }); const e19 = I.ema(ratio, 19), e39 = I.ema(ratio, 39);
    return { t: ih.t.slice(-days), close: ih.c.slice(-days), p50: a50.map((x, i) => (tot[i] ? (x / tot[i]) * 100 : NaN)), p20: a20.map((x, i) => (tot[i] ? (x / tot[i]) * 100 : NaN)), adv, dec, ad, nh, nl, mco: e19.map((x, i) => x - e39[i]) };
  }
  function indexSection(sec, s) {
    const f = s.f, stc = s.F.st, ih = s.cd, L = ih.c.length - 1; const px = n2;
    const perf = (k) => (L >= k ? ((ih.c[L] - ih.c[L - k]) / ih.c[L - k]) * 100 : NaN);
    const y0 = ih.t.findIndex((t) => new Date((t + 25200) * 1000).getUTCFullYear() === new Date((ih.t[L] + 25200) * 1000).getUTCFullYear()); const ytd = y0 > 0 ? ((ih.c[L] - ih.c[y0 - 1]) / ih.c[y0 - 1]) * 100 : NaN;
    switch (sec) {
      case 'isum': {
        const S = stc.levels.supports, Rr = stc.levels.resistances; const ev = stc.ev[stc.ev.length - 1]; const b = breadthSeries(30); const bl = b ? b.p50.length - 1 : -1; const r = M.regime;
        const trend = f.hhhl ? 'dalam uptrend (higher high & higher low)' : f.lhll ? 'dalam downtrend (lower high & lower low)' : 'bergerak sideways/transisi';
        const ema = `${f.close > f.ema20 ? 'di atas' : 'di bawah'} EMA 20, ${f.close > f.ema50 ? 'di atas' : 'di bawah'} EMA 50, dan ${f.close > f.ema200 ? 'di atas' : 'di bawah'} EMA 200`;
        const lines = [`IHSG ${trend}, posisi ${ema}.`];
        if (ev && L - ev.i <= 15) lines.push(`${ev.type} ${ev.dir > 0 ? 'bullish' : 'bearish'} terjadi ${L - ev.i} sesi lalu di ${px(ev.level)}.`);
        lines.push(`RSI ${num(f.rsi, 0)}${f.rsi < 30 ? ' (jenuh jual)' : f.rsi > 70 ? ' (jenuh beli)' : ''}, volatilitas harian rata-rata ${num(f.atrPct, 2)}%.`);
        if (b) lines.push(`Breadth: ${num(b.p50[bl], 0)}% saham di atas EMA 50; ${b.adv[bl]} naik vs ${b.dec[bl]} turun di sesi terakhir.`);
        if (f.rsiDivBull || f.macdDivBull) lines.push('Ada bullish divergence — tekanan jual mulai melemah.'); if (f.rsiDivBear || f.macdDivBear) lines.push('Ada bearish divergence — momentum naik melemah.');
        const s1 = S[0], s2 = S[1], r1 = Rr[0], r2 = Rr[1]; const d = (x) => (x ? `${(((x.price - f.close) / f.close) * 100 >= 0 ? '+' : '')}${num(((x.price - f.close) / f.close) * 100, 1)}%` : '');
        return `<div class="card ai">${esc(lines.join(' '))}</div>
          <h2>Skenario & level kunci</h2><div class="card"><table class="t">
            <tr><td><span class="up">Bullish</span></td><td>${r1 ? `Close di atas <b>${px(r1.price)}</b> (${d(r1)}) membuka jalan ke ${r2 ? px(r2.price) + ' (' + d(r2) + ')' : 'high berikutnya'}` : 'Tidak ada resistance dekat — di area high'}</td></tr>
            <tr><td><span class="dn">Bearish</span></td><td>${s1 ? `Tembus <b>${px(s1.price)}</b> (${d(s1)}) membuka risiko ke ${s2 ? px(s2.price) + ' (' + d(s2) + ')' : 'low berikutnya'}` : 'Tidak ada support dekat'}</td></tr>
            <tr><td><span class="gold">Netral</span></td><td>${s1 && r1 ? `Bergerak di rentang ${px(s1.price)}–${px(r1.price)} selama keduanya bertahan` : '—'}</td></tr></table>
            <div class="note">Level dari kluster swing high/low. Skenario adalah peta kemungkinan, bukan prediksi.</div></div>
          ${regimeCard()}
          <h2>Kinerja</h2><div class="card"><div class="kv">${[['1 mgg', perf(5)], ['1 bln', perf(21)], ['3 bln', perf(63)], ['YTD', ytd], ['1 thn', perf(250)], ['Dari high 52 mgg', -f.dist52wHigh]].map(([l, v]) => `<div><b>${pct(v, 1)}</b><span>${l}</span></div>`).join('')}</div></div>`;
      }
      case 'breadth': {
        const b = breadthSeries(80); if (!b) return '<div class="empty"><b>Data belum dimuat</b></div>'; const i = b.p50.length - 1;
        const hi20 = Math.max(...b.close.slice(-20)), adHi = Math.max(...b.ad.slice(-20)); const div = b.close[i] >= hi20 * 0.995 && b.ad[i] < adHi * 0.98 ? 'IHSG dekat high 20 hari tetapi A/D line tidak ikut — kenaikan ditopang sedikit saham (biasanya big cap). Waspadai pelemahan.' : b.close[i] <= Math.min(...b.close.slice(-20)) * 1.005 && b.ad[i] > Math.min(...b.ad.slice(-20)) * 1.02 ? 'IHSG dekat low 20 hari tetapi A/D line tidak ikut turun — tekanan jual mulai menyempit (potensi pembalikan).' : 'Tidak ada divergence breadth yang menonjol.';
        const mco = b.mco[i];
        return `<div class="card"><div class="kv"><div><b>${num(b.p50[i], 0)}%</b><span>di atas EMA 50</span></div><div><b>${num(b.p20[i], 0)}%</b><span>di atas EMA 20</span></div><div><b><span class="up">${b.adv[i]}</span>/<span class="dn">${b.dec[i]}</span></b><span>naik / turun</span></div><div><b><span class="up">${b.nh[i]}</span>/<span class="dn">${b.nl[i]}</span></b><span>new high / low</span></div><div><b class="${mco >= 0 ? 'up' : 'dn'}">${num(mco, 0)}</b><span>McClellan osc.</span></div><div><b>${b.p50[i] < 20 ? 'Ekstrem' : b.p50[i] > 80 ? 'Jenuh' : 'Normal'}</b><span>${b.p50[i] < 20 ? 'jenuh jual luas' : b.p50[i] > 80 ? 'jenuh beli luas' : 'partisipasi'}</span></div></div>
          <div class="note">${esc(div)} McClellan ${mco > 0 ? 'positif: momentum partisipasi naik' : 'negatif: lebih banyak saham melemah'}. Di bawah 20% saham di atas EMA 50 historisnya sering dekat dasar jangka pendek.</div></div>
          <h2>% saham di atas EMA 50 / EMA 20</h2><div class="card"><div id="ixB1" style="height:170px"></div></div>
          <h2>A/D line vs IHSG</h2><div class="card"><div id="ixB2" style="height:170px"></div><div class="note">Emas = IHSG (kiri), biru = kumulatif saham naik dikurangi turun (kanan). Dihitung dari ${E.snap.stocks.size} saham dalam daftar pantau.</div></div>`;
      }
      case 'movers': {
        if (!ix.movers) return `<div class="empty"><b>${ix.moversBusy ? 'Menghitung bobot kapitalisasi…' : 'Menyiapkan'}</b>Mengambil kapitalisasi pasar 50 saham terbesar (sekali sehari).</div>`;
        const per = ix.mvPeriod; const key = { p1d: 'perf1d', p1w: 'perf1w', p1m: 'perf1m' }[per]; const ihChg = { p1d: perf(1), p1w: perf(5), p1m: perf(21) }[per]; const k = { p1d: 1, p1w: 5, p1m: 21 }[per]; const base = ih.c[L - k];
        const rows = ix.movers.map((m) => Object.assign({}, m, { pts: base * m.w * 0.8 * ((m.st.f[key] || 0) / 100) })); const pos = rows.filter((r) => r.pts > 0).sort((a, b) => b.pts - a.pts).slice(0, 8), neg = rows.filter((r) => r.pts < 0).sort((a, b) => a.pts - b.pts).slice(0, 8);
        const mx = Math.max(...rows.map((r) => Math.abs(r.pts)), 0.01); const bySec = {}; rows.forEach((r) => (bySec[r.st.sector] = (bySec[r.st.sector] || 0) + r.pts));
        const line = (r) => `<button class="secrow mv" data-sym="${r.st.sym}"><span><b>${r.st.sym}</b> <span class="mut sm">${num(r.w * 100, 1)}%</span></span><div class="bar"><i style="width:${(Math.abs(r.pts) / mx) * 100}%;background:${r.pts > 0 ? 'var(--up)' : 'var(--dn)'}"></i></div><span class="${r.pts > 0 ? 'up' : 'dn'}">${r.pts > 0 ? '+' : ''}${num(r.pts, 1)}</span><span>${pct(r.st.f[key], 1)}</span></button>`;
        return `<div class="seg" id="mvSeg">${[['p1d', 'Hari ini'], ['p1w', '1 minggu'], ['p1m', '1 bulan']].map(([k2, l]) => `<button data-mv="${k2}" class="${k2 === per ? 'on' : ''}">${l}</button>`).join('')}</div>
          <div class="note">IHSG ${pct(ihChg, 2)} (${ihChg >= 0 ? '+' : ''}${num((ih.c[L] - base), 1)} poin). Kolom: bobot · kontribusi poin (perkiraan) · perubahan saham.</div>
          <h2>Pendorong</h2><div class="card">${pos.map(line).join('') || '<span class="mut">—</span>'}</div>
          <h2>Penekan</h2><div class="card">${neg.map(line).join('') || '<span class="mut">—</span>'}</div>
          <h2>Per sektor</h2><div class="card"><table class="t">${Object.entries(bySec).sort((a, b) => b[1] - a[1]).map(([k2, v]) => `<tr><td>${esc(k2)}</td><td class="${v >= 0 ? 'up' : 'dn'}">${v >= 0 ? '+' : ''}${num(v, 1)} poin</td></tr>`).join('')}</table>
          <div class="note">Perkiraan: bobot = kapitalisasi pasar saham / total 50 saham terbesar × 80% (porsi perkiraan mereka di IHSG). Bukan angka resmi BEI.</div></div>`;
      }
      case 'stats': {
        if (!ix.d5) return `<div class="empty"><b>${ix.d5Busy ? 'Mengunduh riwayat 5 tahun…' : 'Menyiapkan'}</b></div>`;
        const cd = ix.d5; const n = cd.c.length; const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des']; const DOW = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
        const mon = {}; let prevKey = null, startC = null, lastC = null; const dt = (t) => new Date((t + 25200) * 1000);
        for (let i = 0; i < n; i++) { const d = dt(cd.t[i]); const k = d.getUTCFullYear() * 12 + d.getUTCMonth(); if (k !== prevKey) { if (prevKey !== null && startC) (mon[prevKey % 12] = mon[prevKey % 12] || []).push((lastC - startC) / startC); startC = i > 0 ? cd.c[i - 1] : cd.o[i]; prevKey = k; } lastC = cd.c[i]; }
        const curM = dt(cd.t[n - 1]).getUTCMonth(); const dow = {}; for (let i = 1; i < n; i++) (dow[dt(cd.t[i]).getUTCDay()] = dow[dt(cd.t[i]).getUTCDay()] || []).push((cd.c[i] - cd.c[i - 1]) / cd.c[i - 1]);
        const avg = (a) => a.reduce((x, y) => x + y, 0) / a.length; const winp = (a) => a.filter((x) => x > 0).length / a.length;
        const rets = []; for (let i = 1; i < n; i++) rets.push(Math.log(cd.c[i] / cd.c[i - 1])); const vol = (i) => { const w = rets.slice(i - 20, i); const m = avg(w); return Math.sqrt(avg(w.map((x) => (x - m) ** 2)) * 252) * 100; };
        const vols = []; for (let i = 20; i <= rets.length; i++) vols.push(vol(i)); const vNow = vols[vols.length - 1]; const vPct = I.percentile(vols, vNow);
        const todayChg = (cd.c[n - 1] - cd.c[n - 2]) / cd.c[n - 2]; const lo = todayChg <= -0.015, hiD = todayChg >= 0.015; const cond = []; for (let i = 1; i < n - 5; i++) { const c0 = (cd.c[i] - cd.c[i - 1]) / cd.c[i - 1]; if (lo ? c0 <= -0.015 : hiD ? c0 >= 0.015 : Math.abs(c0) < 0.005) cond.push((cd.c[i + 5] - cd.c[i]) / cd.c[i]); }
        let peak = -Infinity, ddNow = 0; for (const c of cd.c) peak = Math.max(peak, c); ddNow = (cd.c[n - 1] - peak) / peak;
        const mrow = (m) => { const a = mon[m] || []; return a.length ? `<tr class="${m === curM ? 'hl' : ''}"><td>${MON[m]}${m === curM ? ' (bulan ini)' : ''}</td><td><span class="${avg(a) >= 0 ? 'up' : 'dn'}">${avg(a) >= 0 ? '+' : ''}${num(avg(a) * 100, 1)}%</span> · naik ${num(winp(a) * 100, 0)}% · ${a.length} thn</td></tr>` : ''; };
        return `<h2>Pola musiman (5 tahun)</h2><div class="card"><table class="t">${[...Array(12).keys()].map(mrow).join('')}</table><div class="note">Rata-rata return IHSG per bulan kalender dan persentase tahun yang naik. Sampel 5 tahun kecil — pakai sebagai konteks, bukan sinyal.</div></div>
          <h2>Hari perdagangan</h2><div class="card"><table class="t">${[1, 2, 3, 4, 5].map((d) => dow[d] ? `<tr><td>${DOW[d]}</td><td><span class="${avg(dow[d]) >= 0 ? 'up' : 'dn'}">${num(avg(dow[d]) * 100, 2)}%</span> · naik ${num(winp(dow[d]) * 100, 0)}%</td></tr>` : '').join('')}</table></div>
          <h2>Volatilitas & drawdown</h2><div class="card">${tbl([['Volatilitas 20 hari (tahunan)', `${num(vNow, 1)}% · persentil ${num(vPct, 0)} (5 thn)`], ['Jarak dari high 5 tahun', pct(ddNow * 100, 1)], [`Setelah hari seperti ini (${lo ? 'turun ≥1,5%' : hiD ? 'naik ≥1,5%' : 'datar <0,5%'})`, cond.length ? `5 hari berikutnya rata-rata ${pct(avg(cond) * 100, 2)} · naik ${num(winp(cond) * 100, 0)}% (${cond.length} kejadian)` : '—']])}</div>`;
      }
      case 'global': {
        if (!M.data) return `<div class="empty"><b>${M.loading ? 'Memuat data global…' : 'Data global belum dimuat'}</b></div>`;
        const sv = M.sensitivity(s); const keys = ['Y:^GSPC', 'Y:^HSI', 'Y:000001.SS', 'Y:EIDO', 'Y:IDR=X', 'Y:DX-Y.NYB', 'Y:^TNX', 'Y:^VIX', 'Y:BZ=F', 'Y:GC=F'];
        return `<h2>Korelasi dengan IHSG (6 bulan)</h2><div class="card">${tbl(sv.map((x) => [esc(x.name), `${x.r >= 0 ? '+' : ''}${x.r.toFixed(2)}${x.lag ? ' (H+1)' : ''} · beta ${num(x.beta, 2)}`]))}<div class="note">"(H+1)": IHSG bereaksi sehari setelahnya — mis. Wall Street tutup malam hari, IHSG merespons pagi berikutnya. Korelasi negatif USD/IDR berarti rupiah melemah biasanya bersamaan dengan IHSG turun.</div></div>
          <h2>Pasar global & makro</h2><div class="card">${tbl(keys.map((k2) => M.get(k2)).filter(Boolean).map((x) => [esc(x.name), `${num(x.last, x.last < 20 ? 3 : 2)} · ${pct(x.p1d, 2)} · 1B ${pct(x.p1m, 1)}`]))}</div>`;
      }
    }
    return '';
  }
  function bindIndexSection(s) {
    const box = $('#sec');
    if (sp.sec === 'breadth' && window.LightweightCharts) { const b = breadthSeries(80); if (!b) return; const T = b.t.map((t) => t + 25200);
      const opt = (h) => ({ height: h, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: '#8EA0B5', fontFamily: 'IBM Plex Sans', fontSize: 11 }, grid: { vertLines: { visible: false }, horzLines: { color: 'rgba(42,59,82,.35)' } }, rightPriceScale: { borderColor: '#2A3B52' }, leftPriceScale: { borderColor: '#2A3B52' }, timeScale: { borderColor: '#2A3B52' }, handleScroll: false, handleScale: false });
      const c1 = LightweightCharts.createChart($('#ixB1'), opt(170)); const l50 = c1.addLineSeries({ color: '#E9B949', lineWidth: 2, priceLineVisible: false }); const l20 = c1.addLineSeries({ color: '#5AA9FF', lineWidth: 1, priceLineVisible: false });
      l50.setData(T.map((t, i) => ({ time: t, value: b.p50[i] })).filter((x) => ok(x.value))); l20.setData(T.map((t, i) => ({ time: t, value: b.p20[i] })).filter((x) => ok(x.value)));
      [20, 50, 80].forEach((v) => l50.createPriceLine({ price: v, color: 'rgba(142,160,181,.35)', lineWidth: 1, lineStyle: 2, axisLabelVisible: false })); c1.timeScale().fitContent();
      const c2 = LightweightCharts.createChart($('#ixB2'), Object.assign(opt(170), { leftPriceScale: { visible: true, borderColor: '#2A3B52' } })); const li = c2.addLineSeries({ color: '#E9B949', lineWidth: 2, priceScaleId: 'left', priceLineVisible: false, priceFormat: { type: 'custom', formatter: (p) => num(p, 0) } }); const la = c2.addLineSeries({ color: '#5AA9FF', lineWidth: 2, priceScaleId: 'right', priceLineVisible: false });
      li.setData(T.map((t, i) => ({ time: t, value: b.close[i] }))); la.setData(T.map((t, i) => ({ time: t, value: b.ad[i] }))); c2.timeScale().fitContent(); }
    if (sp.sec === 'movers') {
      const sg = $('#mvSeg'); if (sg) sg.onclick = (e) => { const b = e.target.closest('[data-mv]'); if (b) { ix.mvPeriod = b.dataset.mv; drawSection(); } };
      if (!ix.movers && !ix.moversBusy && E.snap) { ix.moversBusy = true; const top = [...E.snap.stocks.values()].sort((a, b) => b.f.avgValue20 - a.f.avgValue20).slice(0, 50);
        E.ensureFundamentals(top.map((x) => x.sym)).catch(() => {}).then(() => { const withCap = top.filter((x) => x.f.marketCap > 0); const tot = withCap.reduce((a, x) => a + x.f.marketCap, 0);
          ix.movers = withCap.map((x) => ({ st: x, w: x.f.marketCap / tot })); ix.moversBusy = false; if (sp.isIndex && sp.sec === 'movers') drawSection(); }); }
    }
    if (sp.sec === 'stats' && !ix.d5 && !ix.d5Busy) { ix.d5Busy = true; D.candles('^JKSE', 'D5').then((r) => { ix.d5 = r.cd; }).catch((e) => toast('Riwayat gagal dimuat: ' + e.message)).finally(() => { ix.d5Busy = false; if (sp.isIndex && sp.sec === 'stats') drawSection(); }); }
    if (sp.sec === 'global' && !M.data && !M.loading) M.load().then(() => { if (sp.isIndex && sp.sec === 'global') drawSection(); }).catch(() => {});
  }

  // ---------------- SETTINGS ----------------
  function openSettings() {
    const el = $('#settings'); el.hidden = false; document.body.style.overflow = 'hidden'; const s = D.settings;
    const provOpts = Object.entries(D.providers).filter(([k]) => D.native || k === 'demo').map(([k, p]) => `<option value="${k}" ${k === s.provider ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
    el.innerHTML = `<div class="sh-h"><button class="icon" id="stBack" aria-label="Kembali">←</button><b>Pengaturan</b></div><div class="sh-b">
      <h2>Sumber data</h2><div class="card"><div class="fld"><label>Provider harga</label><select id="sProv" style="background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px">${provOpts}</select></div>
        <div id="custBox" ${s.provider === 'custom' ? '' : 'hidden'}><div class="fld"><label>URL dasar API</label><input id="sBase" value="${esc(s.customBase)}" placeholder="https://api.contoh.com/v1" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div>
        <div class="fld"><label>API key</label><input id="sKey" type="password" value="${esc(s.customKey)}" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div></div>
        <div class="fld"><input type="checkbox" class="sw" id="sFF" ${s.foreign ? 'checked' : ''}><label>Foreign flow (IDX, EOD)</label></div><div class="fld"><input type="checkbox" class="sw" id="sNews" ${s.news ? 'checked' : ''}><label>Berita (Google News)</label></div></div>
      <h2>Ringkasan berita AI (opsional)</h2><div class="card"><div class="fld"><label>Penyedia</label><select id="sAi" style="background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px;max-width:58%"><option value="none" ${s.aiProv === 'none' ? 'selected' : ''}>Tanpa AI (ringkasan otomatis)</option><option value="gemini" ${s.aiProv === 'gemini' ? 'selected' : ''}>Google Gemini</option><option value="openai" ${s.aiProv === 'openai' ? 'selected' : ''}>OpenAI-compatible (Groq, OpenRouter…)</option></select></div>
        <div id="aiBox" ${s.aiProv === 'none' ? 'hidden' : ''}><div class="fld"><label>API key</label><input id="sAiKey" type="password" value="${esc(s.aiKey)}" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div>
        <div class="fld"><label>Model</label><input id="sAiModel" value="${esc(s.aiModel)}" placeholder="${s.aiProv === 'openai' ? 'llama-3.3-70b-versatile' : 'gemini-2.5-flash'}" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div>
        <div class="fld" id="aiBaseF" ${s.aiProv === 'openai' ? '' : 'hidden'}><label>URL dasar</label><input id="sAiBase" value="${esc(s.aiBase)}" placeholder="https://api.groq.com/openai/v1" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div></div>
        <div class="note">Pakai API key milikmu (Gemini dan Groq punya kuota gratis). Judul & cuplikan berita dikirim ke penyedia hanya saat kamu menekan tombol ringkas. Tanpa AI, ringkasan & dampak dibuat dengan aturan.</div>
        <div style="padding-top:6px"><label class="sm mut">RSS berita tambahan (satu URL per baris)</label><textarea id="sRss" rows="2" style="width:100%;margin-top:4px;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:8px">${esc(s.rssExtra)}</textarea></div></div>
      <h2>Aturan BEI & biaya</h2><div class="card"><div class="fld"><label>Biaya beli (%)</label><input type="number" step="0.01" id="sFb" value="${s.feeBuy}"></div><div class="fld"><label>Biaya jual (%)</label><input type="number" step="0.01" id="sFs" value="${s.feeSell}"></div>
        <div style="padding-top:8px"><label class="sm mut">Saham Papan Pemantauan Khusus / FCA (dikecualikan dari AI Picks & backtest)</label><textarea id="sPpk" rows="2" placeholder="Salin daftar dari idx.co.id, pisahkan spasi/koma" style="width:100%;margin-top:4px;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:8px">${esc(s.ppkList)}</textarea></div>
        <div class="note">ARA/ARB mengikuti Kep-00136/BEI/09-2026: s.d. 31 Des 2026 ARA 35/25/20% dan ARB 15%; mulai 1 Jan 2027 simetris (ARB 35/25/20%). Harga Rp1–10: ±Rp1. Daftar PPK tidak tersedia lewat API gratis, jadi diisi manual.</div></div>
      <h2>Kondisi pasar & makro</h2><div class="card"><div class="fld"><input type="checkbox" class="sw" id="sReg" ${s.regimeFilter ? 'checked' : ''}><label>Perketat AI Picks saat pasar netral/risk-off</label></div>
        <div style="padding-top:8px"><label class="sm mut">Instrumen tambahan (satu per baris: simbolYahoo|Nama|EMITEN1,EMITEN2)</label><textarea id="sMacro" rows="2" placeholder="SB=F|Gula|" style="width:100%;margin-top:4px;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:8px">${esc(s.macroExtra)}</textarea></div></div>
      <h2>Pemindaian</h2><div class="card"><div class="fld"><label>Interval radar (detik)</label><input type="number" id="sInt" value="${s.radarInterval}"></div><div class="fld"><label>Koneksi paralel</label><input type="number" id="sConc" value="${s.concurrency}"></div>
        <div class="fld"><label>Likuiditas minimum AI Picks (miliar Rp/hari)</label><input type="number" id="sMin" value="${s.minValue / 1e9}"></div>
        <div style="padding-top:8px"><label class="sm mut">Saham tambahan (pisahkan spasi/koma)</label><textarea id="sExtra" rows="2" style="width:100%;margin-top:4px;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:8px">${esc(s.extraTickers)}</textarea></div></div>
      <div class="rowx" style="margin-top:12px"><button class="btn pri" id="sSave">Simpan & muat ulang</button><button class="btn" id="sClear">Hapus cache</button></div>
      <h2>Status data</h2><div class="card sm">${tbl([['Harga intraday', D.settings.provider === 'yahoo' ? 'Tertunda (±10 mnt, Yahoo)' : D.settings.provider === 'demo' ? 'Simulasi' : 'Sesuai provider'], ['Harga harian', 'Tertunda saat bursa buka, EOD setelah tutup'], ['Fundamental', 'Laporan terakhir (Yahoo)'], ['Foreign flow', `${D.STATUS[D.ffState.status]} — ${esc(D.ffState.note)}`], ['Akumulasi/distribusi, ROIC, sentimen berita', 'Estimasi dari data di atas'], ['Broker summary', 'Tidak tersedia (sumber berbayar)']])}</div>
      <div class="note">Grafik memakai <a data-ext href="https://www.tradingview.com/">TradingView</a> Lightweight Charts™. Aplikasi tidak pernah mengarang data pasar. Jika sumber gagal, field ditampilkan kosong. Semua analisis adalah alat bantu, bukan rekomendasi investasi.${E.snap && E.snap.failedSyms.length ? ` Gagal dimuat: ${E.snap.failedSyms.join(', ')}.` : ''}</div></div>`;
    $('#stBack').onclick = () => { el.hidden = true; document.body.style.overflow = ''; };
    el.onclick = (e) => { const x = e.target.closest('a[data-ext]'); if (x) { e.preventDefault(); openExt(x.href); } };
    $('#sProv').onchange = (e) => ($('#custBox').hidden = e.target.value !== 'custom');
    $('#sAi').onchange = (e) => { $('#aiBox').hidden = e.target.value === 'none'; $('#aiBaseF').hidden = e.target.value !== 'openai'; };
    $('#sClear').onclick = async () => { await D.clearCache(); toast('Cache dihapus'); };
    $('#sSave').onclick = () => {
      Object.assign(s, { provider: $('#sProv').value, customBase: $('#sBase').value.trim(), customKey: $('#sKey').value.trim(), foreign: $('#sFF').checked, news: $('#sNews').checked, radarInterval: Math.max(30, +$('#sInt').value || 120), concurrency: Math.min(12, Math.max(1, +$('#sConc').value || 6)), minValue: Math.max(0, +$('#sMin').value || 0) * 1e9, extraTickers: $('#sExtra').value, aiProv: $('#sAi').value, aiKey: $('#sAiKey').value.trim(), aiModel: $('#sAiModel').value.trim(), aiBase: $('#sAiBase').value.trim(), rssExtra: $('#sRss').value, feeBuy: Math.max(0, parseFloat($('#sFb').value) || 0), feeSell: Math.max(0, parseFloat($('#sFs').value) || 0), ppkList: $('#sPpk').value.toUpperCase(), regimeFilter: $('#sReg').checked, macroExtra: $('#sMacro').value });
      M.data = null; M.err = null;
      D.saveSettings(); el.hidden = true; document.body.style.overflow = ''; if (Rd.running) { Rd.stop(); Rd.start(); } scan(true);
    };
  }

  // Android back button
  window.__onBack = () => {
    if (!$('#search').hidden) { closeSearch(); return true; }
    if (!$('#reader').hidden) { closeReader(); return true; }
    if (!$('#bt').hidden) { closeBt(); return true; }
    if (!$('#settings').hidden) { $('#settings').hidden = true; document.body.style.overflow = ''; return true; }
    if (!$('#stock').hidden) { closeStock(); return true; }
    if (st.tab !== 'market') { $('#tabs button[data-tab="market"]').click(); return true; }
    return false;
  };
  setInterval(() => { if (D.marketOpen() && !E.scanning && E.snap && Date.now() - E.snap.asOf > 5 * 60e3 && document.visibilityState !== 'hidden') scan(false); }, 60e3);

  // ---------------- splash ----------------
  const SP = { t0: Date.now(), done: false };
  const spSet = (msg, p) => { if (SP.done) return; const m = $('#spMsg'), b = $('#spBar'); if (m && msg) m.textContent = msg; if (b && p != null) b.style.width = Math.max(8, Math.min(100, p * 100)) + '%'; };
  const spHide = () => { if (SP.done) return; SP.done = true; const el = $('#splash'); if (!el) return; spSet(null, 1); const wait = Math.max(0, 2100 - (Date.now() - SP.t0));
    setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 500); }, wait); };
  setTimeout(spHide, 9000); // never block the app longer than this; the header progress bar keeps going
  render(); spSet(D.settings.provider === 'demo' ? 'Mode simulasi' : 'Menghubungkan ke data pasar', 0.08);
  scan(false).finally(spHide);
  R.UI = { openStock, st };
})(window.RB);
