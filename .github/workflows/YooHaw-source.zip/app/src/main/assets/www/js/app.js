/* Yoo Haw — UI */
(function (R) {
  const { D, E, F, A, I, N, M, B, O, X, PK, AL, TG, JB, RK, GR, HM } = R; const ok = I.ok; const Sc = E.Sc, Rd = E.Rd;
  const $ = (s, el = document) => el.querySelector(s);
  const cssv = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim() || '#888888';
  const hexA = (hex, a) => { let h = hex.replace('#', ''); if (h.length === 3) h = h.split('').map((c) => c + c).join(''); const n = parseInt(h, 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; };
  const COL = { get up() { return cssv('--up'); }, get dn() { return cssv('--dn'); }, get mut() { return cssv('--mut'); }, get line() { return cssv('--line'); }, get grid() { return hexA(cssv('--line'), 0.45); }, upA: (a) => hexA(cssv('--up'), a), dnA: (a) => hexA(cssv('--dn'), a) };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const px = (x) => A.fmt(x);
  const pct = (x, d = 2) => (ok(x) ? `<span class="${x > 0 ? 'up' : x < 0 ? 'dn' : 'mut'}">${x > 0 ? '+' : ''}${x.toFixed(d)}%</span>` : '<span class="mut">—</span>');
  const num = (x, d = 2) => (ok(x) ? Number(x).toLocaleString('id-ID', { maximumFractionDigits: d, minimumFractionDigits: 0 }) : '—');
  const scoreCls = (s) => (s >= 70 ? 's-hi' : s >= 55 ? 's-md' : 's-lo');
  const fmtField = (k, v) => {
    const d = F.byKey[k]; if (v === true) return 'Ya'; if (v === false) return 'Tidak'; if (!ok(v)) return '—';
    if (!d) return num(v); if (d.u === 'Rp') return Math.abs(v) >= 1e6 ? A.fmtRp(v) : px(v); if (d.u === '%') return `${num(v, 1)}%`; if (d.u === 'x') return `${num(v, 2)}x`; return num(v, 2);
  };
  const skel = (n = 3, h) => `${h ? `<h2>${h}</h2>` : ''}${Array.from({ length: n }, (_, i) => `<div class="card skel"><i style="width:${[55, 80, 40][i % 3]}%"></i><i></i><i style="width:${[70, 45, 90][i % 3]}%"></i></div>`).join('')}`;
  const emptyState = (title, why, actions = []) => `<div class="empty es"><b>${title}</b><span>${why || ''}</span>${actions.length ? `<div class="rowx" style="justify-content:center;margin-top:12px">${actions.map(([l, a], i) => `<button class="btn ${i === 0 ? 'pri' : ''}" data-act="${a}">${l}</button>`).join('')}</div>` : ''}</div>`;
  const stamp = (txt) => `<span class="stamp">${esc(txt)}</span>`;
  const when = (ms) => { if (!ms) return '—'; const d = new Date(ms); const today = new Date().toDateString() === d.toDateString(); return today ? d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }) + ' ' + d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }); };
  // ---- motion: every layer enters and leaves with an animation; "leaving" layers count as closed ----
  const noMotion = () => R.MO.reduced();
  const isOpen = (el) => !!el && !el.hidden && !el.classList.contains('leaving');
  // layers are driven by spring physics (js/motion.js): interruptible, and they accept finger velocity
  function showLayer(el, opts) { if (!el) return; clearTimeout(el._lt); R.MO.open(el, opts); }
  function hideLayer(el, opts) { if (!el || el.hidden) return; R.MO.close(el, opts); }
  const hap = (k = 'tap') => { try { window.AndroidBridge && window.AndroidBridge.haptic && window.AndroidBridge.haptic(k); } catch (e) {} };
  const toast = (m) => { const t = $('#toast'); t.textContent = m; t.hidden = false; clearTimeout(toast.h); toast.h = setTimeout(() => (t.hidden = true), 2600); };

  const st = { tab: 'market', mkList: 'gain', tree: D.lsGet('rb.lastTree', null) || JSON.parse(JSON.stringify(Sc.PRESETS[0].tree)), presetId: D.lsGet('rb.lastPreset', 'momentum'), sort: 'score', dir: -1, results: null, running: false, pickCat: 'mom', radarView: 'live', radarFilter: 'all', bandarSide: 1, showBuilder: false, showCfg: false, scope: 'all', scrMin: 0, presetTf: 'D' };
  const watch = () => D.lsGet('rb.watch', ['BBCA', 'BBRI', 'TLKM', 'ASII']);
  const setWatch = (w) => D.lsSet('rb.watch', w);

  // ---------------- look: theme, text size, colour-blind ----------------
  function applyLook() {
    const S = D.settings, root = document.documentElement; root.dataset.theme = S.theme || 'dark'; root.dataset.cb = S.cb ? '1' : '0'; root.dataset.motion = S.motion === 'off' ? 'off' : 'on'; root.dataset.lite = S.lite ? '1' : '0';
    const z = { S: 90, M: 100, L: 115, XL: 130 }[S.textSize || 'M'];
    if (window.AndroidBridge && window.AndroidBridge.textZoom) { try { window.AndroidBridge.textZoom(z); } catch (e) {} } else root.style.fontSize = '';
    if (!window.AndroidBridge) document.body.style.zoom = z / 100;
    const mt = document.querySelector('meta[name=theme-color]'); if (mt) mt.content = cssv('--bg');
    try { window.AndroidBridge && window.AndroidBridge.barColor && window.AndroidBridge.barColor(cssv('--bg'), S.theme === 'light'); } catch (e) {}
  }
  applyLook();

  function syncSchedule() {
    const S = D.settings; const cfg = { morning: S.morning ? S.morningAt : '', evening: S.evening ? S.eveningAt : '', alerts: !!S.bgAlerts && AL.needsBackground() };
    try { window.AndroidBridge && window.AndroidBridge.schedule && window.AndroidBridge.schedule(JSON.stringify(cfg)); } catch (e) {}
  }

  // ---------------- boot & scan ----------------
  function setProg(p) { $('#prog i').style.width = p == null ? '0' : Math.round(p * 100) + '%'; }
  function updateStatus() {
    const p = $('#statusPill'); const s = E.snap; $('#demoBar').hidden = D.settings.provider !== 'demo';
    if (!s) { p.textContent = E.scanning ? 'Memuat data…' : 'Belum ada data'; p.className = 'pill'; return; }
    const stt = s.status; const ih = s.ihsg.cd; const t = new Date((ih.t[ih.t.length - 1] > (s.ihsg.meta.asOf || 0) ? ih.t[ih.t.length - 1] : s.ihsg.meta.asOf) * 1000 || s.asOf);
    const sameDay = new Date().toDateString() === t.toDateString();
    const lbl = stt === 'simulated' ? 'Simulasi' : stt === 'realtime' ? 'Real-time' : stt === 'eod' ? 'EOD' : `Tertunda${s.ihsg.meta.delayMin ? ` ~${s.ihsg.meta.delayMin} mnt` : ''}`;
    p.textContent = `${lbl} · ${sameDay ? t.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : t.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}`;
    p.className = 'pill ' + (stt === 'simulated' ? 'sim' : stt === 'realtime' ? 'live' : 'delay');
  }
  async function scan(force) {
    if (E.scanning) return; updateStatus(); setProg(0.02);
    try { await E.scan({ force, onProg: (d, n) => { setProg(d / n); spSet && spSet(`Memindai ${d} dari ${n} saham`, 0.1 + 0.85 * (d / n)); } }); if (E.snap.failed) toast(`${E.snap.stocks.size} saham dimuat, ${E.snap.failed} gagal`); }
    catch (e) { toast('Gagal memuat data: ' + e.message); }
    setProg(null); updateStatus(); render();
  }

  // ---------------- tabs ----------------
  document.querySelectorAll('#tabs button').forEach((b) => b.addEventListener('click', () => { if (st.tab !== b.dataset.tab) hap(); else if (window.scrollY > 0) { window.scrollTo({ top: 0, behavior: noMotion() ? 'auto' : 'smooth' }); return; } st.tab = b.dataset.tab; document.querySelectorAll('#tabs button').forEach((x) => x.classList.toggle('on', x === b)); moveTabInd(); render(); }));
  // indicator above the active tab icon, moved by a gentle spring
  const tabInd = document.createElement('i'); tabInd.className = 'tab-ind'; $('#tabs').appendChild(tabInd); let indSp = null;
  // the indicator slides horizontally under the bottom bar, or vertically along the side rail on wide screens
  const isRail = () => window.matchMedia && window.matchMedia('(min-width: 900px)').matches;
  function moveTabInd() {
    const b = $('#tabs button.on'); if (!b) return; const rail = isRail(); const L = 22;
    const pos = rail ? b.offsetTop + b.offsetHeight / 2 - L / 2 : b.offsetLeft + b.offsetWidth / 2 - L / 2;
    const put = (v) => { tabInd._x = v; tabInd.style.transform = rail ? `translate3d(0,${v}px,0)` : `translate3d(${v}px,0,0)`; };
    const axisChanged = tabInd._rail !== rail; tabInd._rail = rail;
    if (noMotion() || axisChanged || !tabInd.classList.contains('ready') || tabInd._x === undefined) { if (indSp) indSp.stop(); put(pos); return; }
    if (indSp && !indSp.done) { indSp.retarget(pos); return; }
    indSp = R.MO.spring({ from: tabInd._x, to: pos, k: 360, ratio: 0.78, onUpdate: put });
  }
  window.addEventListener('resize', moveTabInd); moveTabInd(); setTimeout(() => { tabInd.classList.add('ready'); moveTabInd(); }, 50);
  const syncModeT = () => document.querySelectorAll('#btnMode button').forEach((b) => b.classList.toggle('on', (b.dataset.m === 'lite') === !!D.settings.lite));
  $('#btnMode').onclick = (e) => { const b = e.target.closest('[data-m]'); if (!b) return; const lite = b.dataset.m === 'lite'; if (!!D.settings.lite === lite) return;
    D.settings.lite = lite; D.saveSettings(); applyLook(); syncModeT(); hap('confirm'); toast(lite ? 'Mode Lite: ringkas & langsung ke inti' : 'Mode Pro: semua detail');
    render(true); if (isOpen($('#stock')) && sp.data) { sp.full = false; drawStock(); } };
  syncModeT();
  // automatic refresh: when the app comes back to the foreground with stale data (pull down still refreshes manually)
  document.addEventListener('visibilitychange', () => { if (document.hidden || JOB || E.scanning || !E.snap) return; const age = Date.now() - E.snap.asOf; const lim = D.marketOpen() ? 4 * 60e3 : 60 * 60e3; if (age > lim && !(D.settings.saver && age < 6 * 3600e3)) scan(false); });
  $('#btnSearch').onclick = () => openSearch();
  $('#btnSettings').onclick = openSettings; $('#statusPill').onclick = openSettings;
  // Each tab keeps its own pane: switching tabs shows the existing content instantly (scroll position kept)
  // and only re-renders when the underlying data changed.
  const root = $('#view'); let view = root; const panes = {}; const scrollPos = {};
  const pane = (tab) => { if (!panes[tab]) { const d = document.createElement('div'); d.className = 'pane'; d.dataset.tab = tab; d.hidden = true; root.appendChild(d); panes[tab] = d; } return panes[tab]; };
  let uiVer = 0; { const ls0 = D.lsSet; D.lsSet = (k, v) => { uiVer++; return ls0(k, v); }; const ss0 = D.saveSettings; D.saveSettings = () => { uiVer++; return ss0(); }; }
  const dataStamp = () => [E.snap && E.snap.asOf, E.scanning ? 1 : 0, N.last, N.err, M.data && M.data.asOf, X.ff && X.ff.asOf, O.cur && O.cur.date, PK.evid && PK.evid.asOf, Rd.last, Rd.running, uiVer].join('|');
  const TABFN = { market: () => rMarket(), screener: () => rScreener(), picks: () => rPicks(), news: () => rNews(), radar: () => rRadar(), watch: () => rWatch() };
  const TAB_TITLE = { market: 'Pasar', screener: 'Screener', picks: 'AI Picks', news: 'Berita', radar: 'Radar', watch: 'Portofolio' };
  const lt = $('#lt'), ltH = lt.querySelector('h1'), hdrT = $('#hdrT'), brandB = $('.brand b');
  let ltTick = false;
  function collapseTitle() { ltTick = false; const p = Math.max(0, Math.min(1, window.scrollY / 44));
    ltH.style.transform = p ? `translate3d(0,${(-p * 10).toFixed(1)}px,0) scale(${(1 - p * 0.14).toFixed(3)})` : ''; ltH.style.opacity = String(1 - p);
    hdrT.style.opacity = String(p); hdrT.style.transform = `translate3d(0,${((1 - p) * 6).toFixed(1)}px,0)`; brandB.style.opacity = String(1 - p); }
  window.addEventListener('scroll', () => { if (!ltTick) { ltTick = true; (window.requestAnimationFrame || setTimeout)(collapseTitle); } }, { passive: true });
  function render(force) {
    const tab = st.tab, p = pane(tab), wasHidden = p.hidden; ltH.textContent = TAB_TITLE[tab]; hdrT.textContent = TAB_TITLE[tab];
    for (const k in panes) if (k !== tab && !panes[k].hidden) { scrollPos[k] = window.scrollY; panes[k].hidden = true; }
    view = p; p.hidden = false;
    if (force || p.dataset.stamp !== dataStamp() || !p.childElementCount) { TABFN[tab](); p.classList.remove('fresh'); void p.offsetWidth; if (!noMotion()) { p.classList.add('fresh'); clearTimeout(p._ft); p._ft = setTimeout(() => p.classList.remove('fresh'), 700); } }
    else if (wasHidden && !noMotion()) { p.classList.remove('show'); void p.offsetWidth; p.classList.add('show'); }
    if (wasHidden) window.scrollTo(0, scrollPos[tab] || 0);
    collapseTitle(); rollAll(p);
  }
  const needSnap = () => (E.snap ? '' : E.scanning ? skel(4) : emptyState('Data pasar belum dimuat', 'Koneksi ke sumber data gagal atau belum dicoba. Periksa internet, lalu muat ulang.', [['Muat ulang', 'scan'], ['Pengaturan', 'settings']]));
  // ---- One delegated handler for generic actions, active on EVERY screen (main view and all sheets). ----
  // Screen-specific handlers only deal with their own attributes, so a button works the same wherever it appears.
  document.addEventListener('click', (e) => {
    const shb = e.target.closest('[data-share]'); if (shb) { e.preventDefault(); e.stopPropagation(); const sym = shb.dataset.share; const s0 = E.getStock(sym) || (sp.data && sp.data.sym === sym ? sp.data : null); return s0 ? shareStock(s0) : E.ensureStock(sym).then(shareStock).catch((err) => toast(err.message)); }
    const t = e.target.closest('[data-act]'); if (!t) return; const a = t.dataset.act; e.stopPropagation();
    if (a === 'scan') return scan(true);
    if (a === 'search') return openSearch();
    if (a === 'settings') return openSettings();
    if (a === 'dash') { st.dashEdit = !st.dashEdit; hap(); return rMarket(); }
    if (a === 'dash-done') { st.dashEdit = false; hap('confirm'); return rMarket(); }
    if (a.startsWith('tab:')) return $(`#tabs button[data-tab="${a.slice(4)}"]`).click();
    if (a === 'port-add') { st.pw = 'port'; st.portForm = {}; return rWatch(); }
    if (a === 'regime-off') { D.settings.regimeFilter = false; D.saveSettings(); toast('Filter kondisi pasar dimatikan'); return render(); }
    if (a.startsWith('pick:')) { st.pickCat = a.slice(5); return rPicks(); }
    if (a === 'loosen') { st.showBuilder = true; return rScreener(); }
    if (a === 'news-retry') { N.err = null; N.last = null; return rNews(); }
    if (a === 'ihsg') return openStock('^JKSE');
    if (a === 'flow-total') { st.flowSrc = 'total'; return rRadar(); }
  });
  root.addEventListener('click', (e) => {
    const ext = e.target.closest('a[data-ext]'); if (ext) { e.preventDefault(); return openExt(ext.href); }
    const ai = e.target.closest('[data-ai]'); if (ai) return runAI(ai.dataset.ai);
    const rd = e.target.closest('[data-read]'); if (rd) return openReader(rd.dataset.read);
    if (e.target.closest('summary,[data-act],[data-share]')) return;
    const t = e.target.closest('[data-sym],[data-ms]'); if (!t) return;
    if (t.dataset.ms) return openMS(t.dataset.ms);
    if (t.dataset.sym) openStock(t.dataset.sym);
  });
  const gBadge = (s) => (s.goreng && s.goreng.level !== 'Rendah' ? ` <span class="chip ${s.goreng.level === 'Tinggi' ? 'r' : 'y'}" title="Risiko saham gorengan">⚠ ${s.goreng.level === 'Tinggi' ? 'rawan goreng' : 'waspada'}</span>` : '');
  const stockRow = (s, extra) => {
    const f = s.f; return `<button class="row" data-sym="${s.sym}"><span><span class="sym">${s.sym}</span> <span class="chip">${esc(s.plan.type.split(' (')[0].split(' — ')[0])}</span>${gBadge(s)}</span>
      <span class="px" data-roll="px:${s.sym}">${px(f.close)}</span><span class="score ${scoreCls(f.score)}">${f.score}</span>
      <span class="sub">${esc(s.sector)}${extra ? ' · ' + extra : ''}</span><span class="chg">${pct(f.chg1d)}</span><span></span></button>`;
  };

  // ---------------- MARKET ----------------
  let mkChart = null;
  function rMarket() {
    if (!E.snap) { view.innerHTML = needSnap(); return; }
    const s = E.snap, all = [...s.stocks.values()]; const ih = s.ihsg.cd, L = ih.c.length - 1; const ichg = ((ih.c[L] - ih.c[L - 1]) / ih.c[L - 1]) * 100;
    const upN = all.filter((x) => x.f.chg1d > 0).length, dnN = all.filter((x) => x.f.chg1d < 0).length, flat = all.length - upN - dnN;
    const a50 = Math.round((all.filter((x) => x.f.aboveEma50).length / all.length) * 100), a200 = Math.round((all.filter((x) => x.f.aboveEma200).length / all.length) * 100);
    const nh = all.filter((x) => x.f.newHigh52).length, nl = all.filter((x) => x.f.newLow52).length;
    const maxAbs = Math.max(...s.sectors.map((x) => Math.abs(x.p1m)), 1);
    const lists = { gain: ['Top gainer', (a, b) => b.f.chg1d - a.f.chg1d], lose: ['Top loser', (a, b) => a.f.chg1d - b.f.chg1d], rvol: ['RVOL tertinggi', (a, b) => b.f.rvol - a.f.rvol], val: ['Nilai transaksi', (a, b) => b.f.value - a.f.value], score: ['Skor setup', (a, b) => b.f.score - a.f.score] };
    if (s.ffState.status !== 'unavailable') Object.assign(lists, { fbuy: ['Foreign net buy', (a, b) => (b.f.fNet1d || 0) - (a.f.fNet1d || 0)], fsell: ['Foreign net sell', (a, b) => (a.f.fNet1d || 0) - (b.f.fNet1d || 0)] });
    const cur = lists[st.mkList] || lists.gain; const top = all.slice().sort(cur[1]).slice(0, 12);
    if (!M.data && !M.loading && !M.err && !D.settings.saver) M.load().then(() => { if (st.tab === 'market') rMarket(); }).catch((e) => { M.err = e.message; });
    const SC = [['p3m', '3 bln'], ['p1m', '1 bln'], ['p1w', '1 mgg'], ['p1d', 'Hari ini']]; const sk = st.secSort || 'p1m';
    const secs = s.sectors.slice().sort((a, b) => b[sk] - a[sk]);
    view.innerHTML = `<div class="rowx" style="margin-bottom:10px;flex-wrap:nowrap"><button class="searchbar" data-act="search" style="margin:0;flex:1"><span>⌕</span>Cari kode atau nama emiten</button><button class="icon" data-act="dash" aria-label="Atur dashboard" title="Atur dashboard">📌</button></div>
      ${pinsHtml()}
      ${todayCard()}
      ${regimeCard()}
      <button class="card ihsgc" data-act="ihsg" style="margin-top:10px"><div class="hero"><div><div class="l">IHSG · ${D.STATUS[s.ihsg.meta.status] || ''} · ${new Date((ih.t[L] + 25200) * 1000).toLocaleDateString('id-ID', { timeZone: 'UTC', weekday: 'short', day: 'numeric', month: 'short' })}</div><div class="v" data-roll="ihsg">${num(ih.c[L], 2)}</div></div><div style="text-align:right">${pct(ichg)}<div class="l">${pct(((ih.c[L] - ih.c[Math.max(0, L - 21)]) / ih.c[Math.max(0, L - 21)]) * 100, 1)} 1 bln</div></div></div><div id="mkChart" class="mini"></div><div class="sm" style="color:var(--info);margin-top:6px">Ketuk untuk analisis lengkap IHSG ›</div></button>
      <div class="pro"><h2>Struktur pasar</h2>
      <div class="tiles">${[['rot', '◴', 'Rotasi sektor', 'Sektor memimpin, melemah, membaik'], ['ff', '⇄', 'Asing vs domestik', 'Aliran dana asing harian'], ['own', '◧', 'Kepemilikan & inventory', 'Pemegang ≥1% dan perubahannya'], ['net', '⌘', 'Jaringan pemilik', 'Grup, konglomerat, investor'], ['brk', '▤', 'Aktivitas broker', 'Broker teraktif hari ini'], ['heat', '▦', 'Heatmap pasar', 'Siapa memimpin, siapa ambruk'], ['grp', '⛬', 'Grup & tema', 'Konglomerasi, BUMN, tema sektor']].map(([k, ic, t, d]) => `<button class="tile" data-ms="${k}"><span class="ic">${ic}</span><b>${t}</b><span>${d}</span></button>`).join('')}</div>
      <h2>Kesehatan pasar</h2>
      <div class="card"><div class="rowx sm"><button class="tg up" data-brd="up">${upN} naik ›</button><span class="sp"></span><span class="mut">${flat} tetap</span><span class="sp"></span><button class="tg dn" data-brd="dn">${dnN} turun ›</button></div>
        <div class="breadth"><i style="width:${(upN / all.length) * 100}%;background:var(--up)"></i><i style="width:${(flat / all.length) * 100}%;background:var(--s3)"></i><i style="width:${(dnN / all.length) * 100}%;background:var(--dn)"></i></div>
        <div class="kv kvt"><button data-brd="ema50"><b>${a50}%</b><span>di atas EMA 50 ›</span></button><button data-brd="ema200"><b>${a200}%</b><span>di atas EMA 200 ›</span></button><button data-brd="nh"><b><span class="up">${nh}</span> / <span class="dn">${nl}</span></b><span>new high / low 52 mgg ›</span></button></div>
        <div class="note">Dihitung dari ${all.length} saham dalam daftar pantau aplikasi.</div></div>
      <h2>Performa sektor</h2>
      <div class="card sect"><div class="secrow sech"><span>Sektor</span>${SC.map(([k, l]) => `<button data-ss="${k}" class="${k === sk ? 'on' : ''}">${l}${k === sk ? ' ↓' : ''}</button>`).join('')}</div>
        ${secs.map((x) => `<button class="secrow" data-sec="${esc(x.name)}"><span>${esc(x.name)} <span class="mut sm">${st.secOpen === x.name ? '▴' : '▾'}</span></span>${SC.map(([k]) => `<span class="${k === sk ? 'b' : ''}">${pct(x[k], 1)}</span>`).join('')}</button>
          ${st.secOpen === x.name ? `<div class="secm">${x.members.slice().sort((a, b) => b.f.perf1d - a.f.perf1d).map((m) => `<button class="secrow" data-sym="${m.sym}"><span><b>${m.sym}</b> <span class="mut sm">RS ${m.f.rsRating}</span></span>${SC.map(([k]) => `<span>${pct(m.f[{ p3m: 'perf3m', p1m: 'perf1m', p1w: 'perf1w', p1d: 'perf1d' }[k]], 1)}</span>`).join('')}</button>`).join('')}</div>` : ''}`).join('')}
        <div class="note">Rata-rata perubahan harga saham anggota sektor dalam daftar pantau. Ketuk judul kolom untuk mengurutkan, ketuk sektor untuk melihat anggotanya.</div></div>
      </div><h2>Penggerak</h2>
      <div class="seg" id="mkSeg">${Object.entries(lists).map(([k, v]) => `<button data-k="${k}" class="${k === st.mkList ? 'on' : ''}">${v[0]}</button>`).join('')}</div>
      <div class="list" style="margin-top:8px">${top.map((x) => stockRow(x, st.mkList === 'rvol' ? `RVOL ${num(x.f.rvol, 1)}x` : st.mkList === 'val' ? A.fmtRp(x.f.value) : st.mkList.startsWith('f') ? `Asing ${A.fmtRp(x.f.fNet1d)}` : '')).join('')}</div>
      <div class="note">Foreign flow: ${esc(D.STATUS[s.ffState.status])} — ${esc(s.ffState.note)}.</div>
      <div class="pro">${macroHtml()}</div>`;
    $('#mkSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) { st.mkList = b.dataset.k; rMarket(); } };
    view.querySelectorAll('[data-mx]').forEach((b) => (b.onclick = () => { st.mxOpen = st.mxOpen === b.dataset.mx ? null : b.dataset.mx; rMarket(); }));
    bindPins();
    view.querySelectorAll('[data-ss]').forEach((b) => (b.onclick = () => { st.secSort = b.dataset.ss; rMarket(); }));
    view.querySelectorAll('[data-sec]').forEach((b) => (b.onclick = () => { st.secOpen = st.secOpen === b.dataset.sec ? null : b.dataset.sec; rMarket(); }));
    const mr = $('#mxR'); if (mr) mr.onclick = () => { M.err = null; M.load({ force: true }).then(() => st.tab === 'market' && rMarket()).catch((e) => toast(e.message)); };
    drawMini($('#mkChart'), ih);
  }
  function drawMini(el, cd) {
    if (!window.LightweightCharts) return; try { if (mkChart) mkChart.remove(); } catch (e) {}
    mkChart = LightweightCharts.createChart(el, { localization: { locale: 'id-ID' }, height: 120, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: '#5E7187', fontFamily: 'IBM Plex Sans' }, grid: { vertLines: { visible: false }, horzLines: { visible: false } }, rightPriceScale: { visible: false }, timeScale: { visible: false }, handleScroll: false, handleScale: false, crosshair: { vertLine: { visible: false }, horzLine: { visible: false } } });
    const s = mkChart.addAreaSeries({ lineColor: '#E9B949', topColor: 'rgba(233,185,73,.25)', bottomColor: 'rgba(233,185,73,0)', lineWidth: 2, priceLineVisible: false, lastValueVisible: false });
    const n = cd.c.length, k = Math.max(0, n - 130); s.setData(cd.t.slice(k).map((t, i) => ({ time: t + 25200, value: cd.c[k + i] }))); mkChart.timeScale().fitContent();
  }

  // ---------------- SCREENER ----------------
  function fieldOptions(sel, onlyNum) {
    let html = '', g = null;
    for (const d of F.FIELDS) { if (onlyNum && d.t !== 'num') continue; if (d.g !== g) { if (g) html += '</optgroup>'; html += `<optgroup label="${esc(d.g)}">`; g = d.g; } html += `<option value="${d.k}" ${d.k === sel ? 'selected' : ''}>${esc(d.label)}</option>`; }
    return html + '</optgroup>';
  }
  function nodeHtml(n, path) {
    if (n.g) {
      return `<div class="grp ${n.g === 'OR' ? 'or' : ''} ${n.not ? 'not' : ''}" data-path="${path}"><div class="grp-h">
        <button class="tg logic" data-a="logic">${n.g === 'AND' ? 'DAN' : 'ATAU'}</button><button class="tg ${n.not ? 'on' : ''}" data-a="not">BUKAN</button><span class="sp"></span>
        <button class="tg" data-a="addc">+ Kondisi</button><button class="tg" data-a="addg">+ Grup</button>${path ? '<button class="x" data-a="del" aria-label="Hapus grup">✕</button>' : ''}</div>
        ${n.c.map((c, i) => nodeHtml(c, path === '' ? String(i) : path + '.' + i)).join('')}</div>`;
    }
    const d = F.byKey[n.f] || F.FIELDS[0]; const isB = d.t === 'bool';
    const ops = isB ? [['true', 'ya'], ['false', 'tidak']] : [['>', '>'], ['>=', '≥'], ['<', '<'], ['<=', '≤'], ['between', 'antara'], ['crossAbove', 'cross ↑'], ['crossBelow', 'cross ↓']];
    const tfSel = d.daily ? '<span class="chip">Harian</span>' : `<select data-k="tf">${Object.entries(D.TF).map(([k, v]) => `<option value="${k}" ${k === (n.tf || 'D') ? 'selected' : ''}>${v}</option>`).join('')}</select>`;
    let rhs = '';
    if (!isB) {
      if (n.op === 'between') rhs = `<input type="number" step="any" data-k="v" value="${n.v ?? ''}"><span class="mut">–</span><input type="number" step="any" data-k="v2" value="${n.v2 ?? ''}">`;
      else rhs = `<select data-k="rk"><option value="v" ${!n.rf ? 'selected' : ''}>angka</option><option value="f" ${n.rf ? 'selected' : ''}>field</option></select>` + (n.rf ? `<select data-k="rf" style="max-width:150px">${fieldOptions(n.rf, true)}</select>` : `<input type="number" step="any" data-k="v" value="${n.v ?? ''}">`);
    }
    return `<div class="leaf" data-path="${path}"><select class="fsel" data-k="f">${fieldOptions(n.f)}</select>${tfSel}<select data-k="op">${ops.map(([k, v]) => `<option value="${k}" ${k === n.op ? 'selected' : ''}>${v}</option>`).join('')}</select>${rhs}<button class="x" data-a="del" aria-label="Hapus kondisi">✕</button></div>`;
  }
  const getNode = (path) => { let n = st.tree; if (path === '') return { n }; const ps = path.split('.').map(Number); let parent = null, idx = -1; for (const i of ps) { parent = n; idx = i; n = n.c[i]; } return { n, parent, idx }; };
  const saveTree = () => { D.lsSet('rb.lastTree', st.tree); D.lsSet('rb.lastPreset', st.presetId); };
  function rScreener() {
    const saved = D.lsGet('rb.screens', []);
    const sortOpts = [['score', 'Setup Score'], ...F.FIELDS.filter((d) => d.t === 'num' && d.k !== 'score').map((d) => [d.k, d.label])];
    view.innerHTML = `<div class="pro">${cfgHtml()}</div>
      <h2>${D.settings.lite ? 'Pilih strategi' : 'Preset profesional'}</h2>
      <div class="presets">${Sc.PRESETS.map((p) => `<button class="preset ${p.id === st.presetId ? 'on' : ''}" data-pid="${p.id}"><b>${esc(p.name)}</b><span>${esc(p.desc)}</span></button>`).join('')}</div>
      ${saved.length ? `<h2>Screener tersimpan</h2><div class="seg">${saved.map((x, i) => `<button data-saved="${i}">${esc(x.name)}</button>`).join('')}</div>` : ''}
      <h2 class="rowx pro">Kondisi <span class="sp"></span><button class="btn" id="tgB" style="padding:5px 10px;font-size:12px">${st.showBuilder ? 'Sembunyikan' : 'Ubah kondisi'}</button></h2>
      <div id="builder" class="pro" ${st.showBuilder ? '' : 'hidden'}>${nodeHtml(st.tree, '')}
        <div class="note">DAN: semua harus terpenuhi · ATAU: salah satu · BUKAN: membalik grup. Kondisi non-harian (1m–1H, mingguan) dimuat hanya untuk saham yang lolos filter harian.</div></div>
      ${st.showBuilder ? '' : `<div class="card sm mut pro">${esc(treeText(st.tree))}</div>`}
      <div class="rowx" style="margin-top:10px"><button class="btn pri" id="run" ${st.running || !E.snap ? 'disabled' : ''}>${st.running ? 'Memindai…' : 'Jalankan screener'}</button><button class="btn" id="save">Simpan</button><button class="btn" id="btS">Backtest</button><span class="sp"></span><button class="btn" id="newT">Kosongkan</button></div>
      <div id="stage" class="note"></div>
      <div id="results"></div>`;
    renderResults(sortOpts);
    view.querySelectorAll('[data-pid]').forEach((b) => (b.onclick = () => { const p = Sc.PRESETS.find((x) => x.id === b.dataset.pid); st.presetId = p.id; st.tree = JSON.parse(JSON.stringify(p.tree)); if (st.presetTf !== 'D') applyTf(st.tree, st.presetTf); st.sort = p.sort || 'score'; st.dir = p.dir || -1; saveTree(); runScreener(); }));
    view.querySelectorAll('[data-saved]').forEach((b) => (b.onclick = () => { const x = saved[+b.dataset.saved]; st.tree = JSON.parse(JSON.stringify(x.tree)); st.presetId = null; st.sort = x.sort || 'score'; saveTree(); runScreener(); }));
    $('#tgB').onclick = () => { st.showBuilder = !st.showBuilder; rScreener(); };
    bindCfg();
    $('#run').onclick = runScreener;
    $('#btS').onclick = () => openBacktest({ mode: 'tree', preset: 'current' });
    $('#newT').onclick = () => { st.tree = Sc.blank(); st.presetId = null; st.showBuilder = true; st.results = null; saveTree(); rScreener(); };
    $('#save').onclick = () => { const name = prompt('Nama screener', st.presetId ? Sc.PRESETS.find((p) => p.id === st.presetId).name + ' (custom)' : 'Screener saya'); if (!name) return; const arr = D.lsGet('rb.screens', []); arr.push({ name, tree: st.tree, sort: st.sort }); D.lsSet('rb.screens', arr); toast('Screener disimpan'); rScreener(); };
    const b = $('#builder');
    b.addEventListener('click', (e) => {
      const t = e.target.closest('[data-a]'); if (!t) return; const path = t.closest('[data-path]').dataset.path; const { n, parent, idx } = getNode(path);
      if (t.dataset.a === 'logic') n.g = n.g === 'AND' ? 'OR' : 'AND';
      if (t.dataset.a === 'not') n.not = !n.not;
      if (t.dataset.a === 'addc') n.c.push({ f: 'rsi', op: '>', v: 50, tf: 'D' });
      if (t.dataset.a === 'addg') n.c.push({ g: 'OR', c: [{ f: 'bosBull', op: 'true', tf: 'D' }] });
      if (t.dataset.a === 'del' && parent) parent.c.splice(idx, 1);
      st.presetId = null; saveTree(); rScreener();
    });
    b.addEventListener('change', (e) => {
      const el = e.target; const path = el.closest('[data-path]').dataset.path; const { n } = getNode(path); const k = el.dataset.k;
      if (k === 'f') { n.f = el.value; const d = F.byKey[n.f]; n.op = d.t === 'bool' ? 'true' : '>'; delete n.rf; n.v = d.t === 'bool' ? undefined : 0; if (d.daily) n.tf = 'D'; }
      else if (k === 'rk') { if (el.value === 'f') { n.rf = 'ema50'; delete n.v; } else { delete n.rf; n.v = 0; } }
      else if (k === 'v' || k === 'v2') n[k] = el.value === '' ? undefined : parseFloat(el.value);
      else n[k] = el.value;
      st.presetId = null; saveTree(); if (k !== 'v' && k !== 'v2') rScreener();
    });
  }
  function treeText(n) {
    if (n.g) { const inner = n.c.map(treeText).join(n.g === 'AND' ? ' DAN ' : ' ATAU '); return (n.not ? 'BUKAN ' : '') + (n.c.length > 1 ? `(${inner})` : inner); }
    const d = F.byKey[n.f]; const tf = d && !d.daily ? ` [${D.TF[n.tf || 'D']}]` : '';
    if (n.op === 'true') return d.label + tf; if (n.op === 'false') return 'tidak ' + d.label + tf;
    const r = n.rf ? F.byKey[n.rf].label : n.op === 'between' ? `${n.v}–${n.v2}` : (d.u === 'Rp' && Math.abs(n.v) >= 1e6 ? A.fmtRp(n.v) : n.v);
    return `${d.label}${tf} ${Sc.OPS[n.op]} ${r}`;
  }
  async function runScreener() {
    if (!E.snap) return toast('Data pasar belum dimuat'); st.running = true; rScreener();
    try { const stage = (m) => { const el = $('#stage'); if (el) el.textContent = m; }; st.results = await Sc.run(st.tree, { onProg: (d, n) => setProg(d / n), onStage: stage, scope: st.scope, minValue: st.scrMin * 1e9 }); }
    catch (e) { toast('Screener gagal: ' + e.message); }
    st.running = false; setProg(null); if (st.tab === 'screener') rScreener();
  }
  function renderResults(sortOpts) {
    const box = $('#results'); if (!box) return; if (!st.results) { box.innerHTML = E.snap ? '' : needSnap(); return; }
    const k = st.sort; const res = st.results.slice().sort((a, b) => { const x = a.f[k], y = b.f[k]; if (!ok(x)) return 1; if (!ok(y)) return -1; return (x - y) * st.dir; });
    box.innerHTML = `<div class="res-h"><b>${res.length} saham</b><span class="sp"></span><select id="sortSel">${sortOpts.map(([v, l]) => `<option value="${v}" ${v === k ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select><button class="tg" id="dirB">${st.dir < 0 ? '↓' : '↑'}</button></div>
      ${res.length ? `<div class="list">${res.slice(0, 120).map((s) => stockRow(s, k !== 'score' ? `${F.byKey[k] ? F.byKey[k].label : k}: ${fmtField(k, s.f[k])}` : `RS ${s.f.rsRating}`)).join('')}</div>` : emptyState('Tidak ada saham yang lolos', 'Kombinasi kondisinya terlalu ketat untuk data hari ini. Longgarkan salah satu angka, ganti DAN menjadi ATAU, atau coba preset lain.', [['Ubah kondisi', 'loosen']])}`;
    $('#sortSel').onchange = (e) => { st.sort = e.target.value; renderResults(sortOpts); };
    $('#dirB').onclick = () => { st.dir *= -1; renderResults(sortOpts); };
  }

  // ---------------- SCREENER SETTINGS ----------------
  const PARAM_UI = [
    ['Struktur & swing', [['pivotLen', 'Kekuatan swing (bar kiri/kanan)', 'bar', 1, 10, 1]]],
    ['Fair value gap', [['fvgMinAtr', 'Ukuran gap minimum', '×ATR', 0, 2, 0.05], ['fvgRecent', '"FVG baru" jika terbentuk dalam', 'bar', 1, 60, 1], ['fvgLookback', 'FVG dianggap masih aktif hingga', 'bar', 10, 500, 10]]],
    ['BOS / CHoCH', [['bosRecent', '"BOS/CHoCH baru" jika terjadi dalam', 'bar', 1, 60, 1]]],
    ['Likuiditas', [['sweepLookback', 'Umur maks. swing yang disapu', 'bar', 5, 200, 5], ['sweepRecent', '"Sweep baru" jika terjadi dalam', 'bar', 1, 60, 1], ['eqTol', 'Toleransi equal high/low', '×ATR', 0.02, 1, 0.01]]],
    ['Order block & displacement', [['obLookback', 'Cari candle order block mundur', 'bar', 2, 50, 1], ['dispAtr', 'Body displacement minimum', '×ATR', 0.5, 4, 0.1]]],
    ['Breakout', [['boVol', 'Volume breakout minimum', '×rata2', 1, 5, 0.1], ['boRecent', '"Breakout baru" jika terjadi dalam', 'bar', 1, 30, 1], ['retestWin', 'Retest dicari hingga', 'bar', 5, 60, 1]]],
    ['Indikator', [['rsiLen', 'Periode RSI', 'bar', 2, 50, 1], ['rvolLen', 'Periode rata-rata volume (RVOL)', 'bar', 5, 100, 1], ['volSpike', 'Volume spike minimum', '×', 1.2, 10, 0.1], ['sqzPctl', 'BB squeeze jika lebar di bawah persentil', '', 5, 50, 1], ['divRecent', 'Divergence dicari dalam', 'bar', 5, 60, 1]]],
  ];
  const applyTf = (n, tf) => { if (n.g) n.c.forEach((c) => applyTf(c, tf)); else if (!(F.byKey[n.f] && F.byKey[n.f].daily)) n.tf = tf; };
  function cfgHtml() {
    const custom = Object.keys(R.PDEF).filter((k) => R.P[k] !== R.PDEF[k]).length;
    const scopeLbl = st.scope === 'all' ? 'Semua saham' : st.scope === 'watch' ? 'Watchlist' : st.scope;
    const head = `<button class="card cfgh" id="cfgT"><span><b>Pengaturan screener</b><span class="sm mut">Timeframe ${D.TF[st.presetTf]} · ${esc(scopeLbl)}${st.scrMin ? ` · ≥ Rp${st.scrMin} M/hari` : ''} · parameter ${custom ? custom + ' diubah' : 'default'}</span></span><span class="mut">${st.showCfg ? '▴' : '▾'}</span></button>`;
    if (!st.showCfg) return head;
    const secs = E.snap ? E.snap.sectors.map((x) => x.name) : Object.values(D.SECTORS);
    return head + `<div class="card cfg">
      <div class="sm mut">Timeframe untuk kondisi teknikal, struktur & SMC</div>
      <div class="seg" id="cfgTf" style="margin:6px 0">${Object.entries(D.TF).map(([k, v]) => `<button data-tf="${k}" class="${k === st.presetTf ? 'on' : ''}">${v}</button>`).join('')}</div>
      <div class="rowx"><button class="btn" id="cfgApply">Terapkan ke semua kondisi aktif</button></div>
      <div class="note">Dipakai otomatis saat memilih preset. Contoh: pilih 1 jam lalu preset "FVG Setup" → FVG dicari di chart 1 jam. Field yang hanya ada di harian (RS, fundamental, 52 minggu, bandar, skor) tetap harian. Tiap kondisi juga bisa diberi timeframe sendiri di "Ubah kondisi".</div>
      <div class="fld"><label>Cakupan saham</label><select id="cfgScope" class="selx"><option value="all">Semua saham</option><option value="watch" ${st.scope === 'watch' ? 'selected' : ''}>Watchlist</option>${secs.map((x) => `<option ${st.scope === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></div>
      <div class="fld"><label>Likuiditas minimum</label><input type="number" id="cfgMin" value="${st.scrMin}" min="0" step="0.5"><span class="sm mut">M Rp/hari</span></div>
      ${PARAM_UI.map(([g, arr]) => `<div class="pg">${esc(g)}</div>${arr.map(([k, l, u, mn, mx, stp]) => `<div class="fld"><label>${esc(l)}${R.P[k] !== R.PDEF[k] ? ' <span class="gold">•</span>' : ''}</label><input type="number" data-p="${k}" value="${R.P[k]}" min="${mn}" max="${mx}" step="${stp}"><span class="sm mut" style="min-width:40px">${u}</span></div>`).join('')}`).join('')}
      <div class="rowx" style="margin-top:10px"><button class="btn pri" id="cfgSave">Simpan & hitung ulang</button><button class="btn" id="cfgReset">Kembalikan default</button></div>
      <div class="note">Parameter berlaku untuk semua timeframe, halaman saham, AI Picks, dan radar. Untuk jendela berbeda per kondisi, pakai field "Bar sejak …" (mis. Bar sejak FVG bullish ≤ 10 di 1 jam).</div></div>`;
  }
  function bindCfg() {
    $('#cfgT').onclick = () => { st.showCfg = !st.showCfg; rScreener(); };
    if (!st.showCfg) return;
    $('#cfgTf').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; st.presetTf = b.dataset.tf; rScreener(); };
    $('#cfgApply').onclick = () => { applyTf(st.tree, st.presetTf); st.presetId = null; saveTree(); toast(`Kondisi memakai timeframe ${D.TF[st.presetTf]}`); runScreener(); };
    $('#cfgScope').onchange = (e) => { st.scope = e.target.value; };
    $('#cfgMin').onchange = (e) => { st.scrMin = Math.max(0, parseFloat(e.target.value) || 0); };
    $('#cfgSave').onclick = () => {
      view.querySelectorAll('[data-p]').forEach((el) => { const v = parseFloat(el.value); if (ok(v)) R.P[el.dataset.p] = Math.min(+el.max, Math.max(+el.min, v)); });
      for (const k of ['pivotLen', 'fvgRecent', 'fvgLookback', 'bosRecent', 'sweepLookback', 'sweepRecent', 'obLookback', 'boRecent', 'retestWin', 'rsiLen', 'rvolLen', 'divRecent', 'sqzPctl']) R.P[k] = Math.round(R.P[k]);
      D.lsSet('rb.params', R.P); E.recompute(); toast('Parameter diterapkan'); st.showCfg = false; if (st.results) runScreener(); else rScreener();
    };
    $('#cfgReset').onclick = () => { R.P = Object.assign({}, R.PDEF); D.lsSet('rb.params', R.P); E.recompute(); toast('Parameter kembali ke default'); rScreener(); };
  }

  // ---------------- NEWS ----------------
  const nw = { filter: 'all', watchOnly: false, sort: 'new', busy: new Set() };
  const openExt = (u) => { if (window.AndroidBridge) AndroidBridge.openUrl(u); else window.open(u, '_blank'); };
  const awCls = (a) => (a.veryEarly ? 'aw-x' : a.level === 'early' ? 'aw-e' : a.level === 'spreading' ? 'aw-s' : 'aw-k');
  function storyCard(s) {
    const a = s.aw; const imps = s.ai && s.ai.dampak && s.ai.dampak.length ? s.ai.dampak : s.impacts; const summ = s.ai && s.ai.ringkasan ? s.ai.ringkasan : N.ruleSummary(s);
    return `<div class="card story"><div class="rowx"><span class="aw ${awCls(a)}">${esc(a.label)}</span><span class="awm" title="Skor kesadaran ${a.score}/100"><i style="width:${Math.max(4, a.score)}%"></i></span><span class="sp"></span><span class="sm mut">${N.ago(s.first)}</span></div>
      <button class="st-t" data-read="${s.id}">${esc(s.title)}</button>
      <div class="rowx sm"><span class="chip">${esc(s.cat.name)}</span><span class="mut">${s.nSources} sumber</span>${a.priced ? `<span class="chip ${s.reaction && s.reaction.status === 'untested' ? 'y' : 'b'}">${esc(a.priced)}</span>` : ''}</div>
      <p class="st-s">${esc(summ)} <span class="sm mut">— ${s.ai ? 'ringkasan AI' : 'ringkasan otomatis'}</span></p>
      ${imps.length ? `<div class="pg" style="margin-top:4px">Perkiraan dampak ke emiten</div><div class="imp">${imps.slice(0, 6).map((x) => `<button class="impr" data-sym="${x.sym}"><span class="${x.dir > 0 ? 'up' : x.dir < 0 ? 'dn' : 'mut'} arr">${x.dir > 0 ? '▲' : x.dir < 0 ? '▼' : '◆'}</span><span><b>${x.sym}</b> <span class="chip">${esc(x.mag)}${x.direct ? '' : ' · tidak langsung'}</span><span class="sm mut" style="display:block">${esc(x.why)}</span></span></button>`).join('')}</div>` : ''}
      <details class="why"><summary>Kenapa "${esc(a.label.toLowerCase())}" · sumber (${s.items.length})</summary><div class="sm mut" style="margin:6px 0">${esc(a.why.join(' · '))}</div>${s.items.map((it) => `<a data-ext href="${esc(it.link)}" class="srcl"><span class="mut">${esc(it.src)} · ${N.ago(it.date)}</span><br>${esc(it.title)}</a>`).join('')}</details>
      <div class="rowx" style="margin-top:8px"><button class="btn" data-read="${s.id}">Baca berita</button>${N.llmReady() && !s.ai ? `<button class="btn" data-ai="${s.id}" ${nw.busy.has(s.id) ? 'disabled' : ''}>${nw.busy.has(s.id) ? 'Meringkas…' : 'Analisis AI'}</button>` : ''}</div></div>`;
  }
  const findStory = (id) => N.stories.find((x) => x.id === id) || (sp.stories || []).find((x) => x.id === id);
  async function runAI(id) {
    const s = findStory(id); if (!s || nw.busy.has(id)) return; nw.busy.add(id); refreshNewsViews();
    try { s.ai = await N.llm(s); } catch (e) { toast('AI gagal: ' + e.message); }
    nw.busy.delete(id); refreshNewsViews();
  }
  N.onUpdate = () => refreshNewsViews();
  const rdr = { id: null };
  async function openReader(id) {
    const s = findStory(id); if (!s) return; rdr.id = id; const el = $('#reader'); showLayer(el); el.scrollTop = 0; drawReader(s, null);
    if (s.full) { drawReader(s, { paras: s.full, url: s.url, site: s.site }); return; }
    try { const art = await N.read(s.items[0].link); N.enrich(s, art); if (rdr.id === id) drawReader(s, art); refreshNewsViews(); }
    catch (e) { if (rdr.id === id) drawReader(s, { err: e.message }); }
  }
  function closeReader() { hideLayer($('#reader')); rdr.id = null; }
  function drawReader(s, art) {
    const el = $('#reader'); const a = s.aw; const link = (art && art.url) || s.url || s.items[0].link; const imps = s.ai && s.ai.dampak && s.ai.dampak.length ? s.ai.dampak : s.impacts;
    el.innerHTML = `<div class="sh-h"><button class="icon" id="rdBack" aria-label="Kembali">←</button><span class="sm mut" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc((art && art.site) || s.site || s.items[0].src)}</span><button class="tg" id="rdOpen">Buka di browser</button></div>
      <div class="sh-b reader"><div class="rowx"><span class="aw ${awCls(a)}">${esc(a.label)}</span><span class="chip">${esc(s.cat.name)}</span><span class="sp"></span><span class="sm mut">${N.ago(s.first)} · ${s.nSources} sumber</span></div>
        <h1 class="rd-t">${esc(s.title)}</h1>
        <div class="card"><div class="pg" style="margin:0 0 4px">${s.ai ? 'Ringkasan AI' : 'Ringkasan'}</div><p class="st-s" style="margin:0">${esc(s.ai && s.ai.ringkasan ? s.ai.ringkasan : N.ruleSummary(s))}</p>
          ${imps.length ? `<div class="pg">Perkiraan dampak ke emiten</div><div class="imp">${imps.slice(0, 8).map((x) => `<button class="impr" data-sym="${x.sym}"><span class="${x.dir > 0 ? 'up' : x.dir < 0 ? 'dn' : 'mut'} arr">${x.dir > 0 ? '▲' : x.dir < 0 ? '▼' : '◆'}</span><span><b>${x.sym}</b> <span class="chip">${esc(x.mag)}${x.direct ? '' : ' · tidak langsung'}</span><span class="sm mut" style="display:block">${esc(x.why)}</span></span></button>`).join('')}</div>` : ''}
          ${a.priced ? `<div class="note">${esc(a.priced)} · ${esc(a.why.join(' · '))}</div>` : `<div class="note">${esc(a.why.join(' · '))}</div>`}
          ${N.llmReady() && !s.ai ? `<button class="btn" data-ai="${s.id}" style="margin-top:6px" ${nw.busy.has(s.id) ? 'disabled' : ''}>${nw.busy.has(s.id) ? 'Meringkas…' : 'Analisis dengan AI'}</button>` : ''}</div>
        <div class="rd-body">${!art ? '<div class="empty"><b>Memuat artikel…</b></div>' : art.err ? `<div class="empty"><b>Isi artikel tidak bisa ditampilkan</b>${esc(art.err)}. Ketuk "Buka di browser" untuk membaca di situs aslinya.</div>` : art.paras.map((p) => `<p>${esc(p)}</p>`).join('') + `<div class="note">Sumber: ${esc(art.site || '')}. Teks diambil dari halaman asli untuk dibaca di aplikasi.</div>`}</div>
        ${s.items.length > 1 ? `<h2>Liputan lain (${s.items.length - 1})</h2>${s.items.slice(1).map((it) => `<a data-ext href="${esc(it.link)}" class="srcl"><span class="mut">${esc(it.src)} · ${N.ago(it.date)}</span><br>${esc(it.title)}</a>`).join('')}` : ''}</div>`;
    $('#rdBack').onclick = closeReader;
    $('#rdOpen').onclick = async () => { let u = link; try { u = await N.resolve(link); } catch (e) {} openExt(u); };
    el.onclick = (e) => { const x = e.target.closest('a[data-ext]'); if (x) { e.preventDefault(); return openExt(x.href); } const ai = e.target.closest('[data-ai]'); if (ai) return runAI(ai.dataset.ai).then(() => rdr.id === s.id && drawReader(s, art)); const b = e.target.closest('[data-sym]'); if (b) { closeReader(); openStock(b.dataset.sym); } };
  }
  function refreshNewsViews() { if (st.tab === 'news') rNews(); if (isOpen($('#stock')) && sp.sec === 'news') drawSection(); }
  function rNews() {
    if (!N.last && !N.loading && !N.err) { N.load({ onProg: (d, n) => setProg(d / n) }).then(() => { setProg(null); if (st.tab === 'news') rNews(); }); }
    else if (N.last && Date.now() - N.last > 10 * 60e3 && !N.loading) N.load().then(() => st.tab === 'news' && rNews());
    const w = new Set(watch());
    let list = N.stories.slice();
    if (nw.filter === 'early') list = list.filter((x) => x.aw.level === 'early'); else if (nw.filter !== 'all') list = list.filter((x) => x.aw.level === nw.filter);
    if (nw.watchOnly) list = list.filter((x) => x.impacts.some((i) => w.has(i.sym)));
    const impW = (x) => x.impacts.reduce((a, i) => a + (i.direct ? 2 : 1) * (i.mag === 'kuat' ? 3 : i.mag === 'sedang' ? 2 : 1) * (i.dir ? 1 : 0.5), 0);
    list.sort(nw.sort === 'early' ? (a, b) => a.aw.score - b.aw.score || b.first - a.first : nw.sort === 'impact' ? (a, b) => impW(b) - impW(a) : (a, b) => b.first - a.first);
    const cnt = (lv) => N.stories.filter((x) => x.aw.level === lv).length;
    view.innerHTML = `<div class="seg" id="nwSeg">${[['all', 'Semua', N.stories.length], ['early', 'Belum banyak tahu', cnt('early')], ['spreading', 'Mulai menyebar', cnt('spreading')], ['known', 'Sudah ramai', cnt('known')]].map(([k, v, c]) => `<button data-f="${k}" class="${k === nw.filter ? 'on' : ''}">${v} ${c ? `<span class="mut">${c}</span>` : ''}</button>`).join('')}</div>
      <div class="rowx" style="margin:10px 0 4px"><select id="nwSort" class="selx"><option value="new">Terbaru</option><option value="early" ${nw.sort === 'early' ? 'selected' : ''}>Paling awal (belum ramai)</option><option value="impact" ${nw.sort === 'impact' ? 'selected' : ''}>Dampak terbesar</option></select><button class="tg ${nw.watchOnly ? 'on' : ''}" id="nwW">Watchlist</button><span class="sp"></span><button class="btn" id="nwR" style="padding:6px 10px">${N.loading ? 'Memuat…' : 'Perbarui'}</button></div>
      <div class="note">${N.last ? `${stamp('Diperbarui ' + when(N.last))} ${N.stories.length} cerita${N.failed ? ` · ${N.failed} sumber gagal` : ''}` : ''}</div>
      ${N.err ? emptyState('Berita tidak bisa dimuat', esc(N.err), D.native ? [['Coba lagi', 'news-retry']] : []) : !N.last ? skel(4) : list.length ? list.slice(0, 60).map(storyCard).join('') : '<div class="empty"><b>Tidak ada cerita di filter ini</b>Coba filter lain atau perbarui.</div>'}
      <details class="why card" style="margin-top:12px"><summary>Cara membaca label</summary><div class="sm" style="margin-top:6px;line-height:1.55">
        <b>Sangat awal / Belum banyak yang tahu</b> — sedikit sumber, baru terbit, dan harga/volume emiten belum bereaksi (atau terbit setelah bursa tutup).<br><b>Mulai menyebar</b> — sumber bertambah atau harga mulai bergerak.<br><b>Sudah banyak yang tahu</b> — diberitakan luas dan/atau harga sudah bereaksi kuat; peluang biasanya sudah sebagian besar priced-in.<br><br>
        Skor dihitung dari jumlah sumber, umur berita, serta pergerakan harga (dalam ATR) dan RVOL sejak jam terbit. Informasi yang benar-benar belum diketahui publik adalah informasi orang dalam dan ilegal untuk ditransaksikan; aplikasi hanya menilai berita publik.</div></details>`;
    $('#nwSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) { nw.filter = b.dataset.f; rNews(); } };
    $('#nwSort').onchange = (e) => { nw.sort = e.target.value; rNews(); };
    $('#nwW').onclick = () => { nw.watchOnly = !nw.watchOnly; rNews(); };
    $('#nwR').onclick = () => { if (N.loading) return; N.load({ force: true, onProg: (d, n) => setProg(d / n) }).then(() => { setProg(null); rNews(); }); rNews(); };
  }


  // ---------------- REGIME & MACRO ----------------
  function regimeCard() {
    const r = M.regime; if (!r) return '';
    const col = r.score >= 60 ? 'var(--up)' : r.score >= 40 ? 'var(--gold)' : 'var(--dn)'; const pr = E.pickRules();
    return `<div class="card regime"><div class="rowx"><div><div class="sm mut">Kondisi pasar ${stamp('dihitung ' + when(E.snap && E.snap.asOf))}</div><div class="rg-l" style="color:${col}">${r.label}</div></div><span class="sp"></span><div class="rg-s" style="border-color:${col}">${r.score}</div></div>
      <div class="comp rgc" style="margin-top:10px">${r.comp.map((c, i) => `<button class="rcl" data-rc="${i}">${esc(c.label)}</button><div class="bar ${c.s < 50 ? 'lo' : ''}" data-rc="${i}"><i style="width:${c.s}%"></i></div><button class="rcv" data-rc="${i}">${c.s}</button>`).join('')}</div>
      <details class="why pro"><summary>Dasar penilaian</summary><ul class="why">${r.comp.map((c) => `<li class="${c.s >= 50 ? 'p' : 'm'}">${esc(c.label)}: ${esc(c.why)}</li>`).join('')}</ul>${M.data ? '' : '<div class="note">Data makro belum dimuat — skor memakai IHSG & breadth saja.</div>'}</details>
      ${pr.label && D.settings.regimeFilter ? `<div class="note" style="color:${col}">${esc(pr.label)}.</div>` : ''}</div>`;
  }
  function macroHtml() {
    if (!M.data) return `<h2>Makro & komoditas</h2>${M.err ? `<div class="card sm mut">Gagal memuat: ${esc(M.err)}</div>` : D.settings.saver && !M.loading ? '<div class="card sm mut">Mode hemat data aktif. <button class="tg" id="mxR">Muat makro</button></div>' : skel(2)}`;
    const groups = ['Komoditas', 'Makro', 'Global', 'Tambahan'];
    return `<h2 class="rowx">Makro & komoditas <span class="sp"></span>${stamp('Yahoo · ' + when(M.data.asOf))}<button class="tg" id="mxR">Perbarui</button></h2>${groups.map((g) => { const items = M.data.items.filter((x) => x.g === g); if (!items.length) return '';
      return `<div class="pg" style="margin:10px 2px 6px">${g}</div><div class="list">${items.map((it) => {
        if (it.err) return `<div class="row" style="grid-template-columns:1fr auto"><span>${esc(it.name)}<div class="sub">Tidak tersedia dari Yahoo</div></span><span class="mut">—</span></div>`;
        const lag = it.linked.filter((x) => x.lagging); const open = st.mxOpen === it.sym;
        return `<button class="row" data-mx="${it.sym}" style="grid-template-columns:1fr auto auto"><span>${esc(it.name)}${lag.length ? ` <span class="chip y">${lag.length} emiten belum ikut</span>` : ''}</span><span class="px">${num(it.last, it.last < 20 ? 3 : 2)}</span><span class="chg">${pct(it.p1d)}</span>
          <span class="sub">1M ${fmtP(it.p1w)} · 1B ${fmtP(it.p1m)} · 3B ${fmtP(it.p3m)} · ${it.up50 ? 'di atas' : 'di bawah'} EMA 50</span><span></span><span class="mut sm">${open ? '▴' : it.linked.length ? '▾' : ''}</span></button>
          ${open ? `<div class="mxd">${it.note ? `<div class="note">${esc(it.note)}</div>` : ''}${it.linked.length ? `<table class="t"><tr><td class="mut sm">Emiten</td><td class="mut sm">Korelasi 6 bln · perf 1B</td></tr>${it.linked.map((x) => `<tr data-sym="${x.sym}"><td><b>${x.sym}</b>${x.lagging ? ' <span class="chip y">belum ikut</span>' : ''}</td><td>${ok(x.r) ? x.r.toFixed(2) : '—'}${x.lag ? ' <span class="mut sm">(H+1)</span>' : ''} · ${pct(x.p1m, 1)}</td></tr>`).join('')}</table><div class="note">Korelasi return harian 6 bulan. "(H+1)": saham bereaksi sehari setelah komoditas. "Belum ikut": komoditas bergerak ≥5% sebulan dengan korelasi ≥0,3 tapi saham belum mengikuti — kandidat catch-up, perlu konfirmasi teknikal.</div>` : '<div class="note">Indikator makro/global — dipakai di skor kondisi pasar.</div>'}</div>` : ''}`; }).join('')}</div>`; }).join('')}
      <div class="note">Sumber Yahoo Finance (tertunda/EOD). Nikel LME & CPO Bursa Malaysia tidak tersedia gratis; tambah simbol lain di Pengaturan.</div>`;
  }
  const fmtP = (x) => (ok(x) ? `${x > 0 ? '+' : ''}${x.toFixed(1)}%` : '—');

  // ---------------- BACKTEST ----------------
  const bt = { cfg: { mode: 'tree', preset: 'current', cat: 'swing', nStocks: 40, period: 252, step: 2, hold: 20, entry: 'open', regimeFilter: false }, prog: null };
  function openBacktest(init) {
    Object.assign(bt.cfg, init || {}); const el = $('#bt'); showLayer(el); drawBt();
  }
  function closeBt() { hideLayer($('#bt')); if (B.running && B.owner === 'user') B.abort = true; }
  function drawBt() {
    const el = $('#bt'), c = bt.cfg, r = B.last && B.last.cfgKey === cfgKey() ? B.last : null;
    const targets = [['tree:current', 'Kondisi screener saat ini'], ...Sc.PRESETS.map((p) => ['tree:' + p.id, 'Preset: ' + p.name]), ...E.PICK_CATS.map((x) => ['cat:' + x.id, 'AI Picks: ' + x.name])];
    const cur = c.mode === 'cat' ? 'cat:' + c.cat : 'tree:' + c.preset;
    const sel = (id, opts, v) => `<select id="${id}" class="selx">${opts.map(([k, l]) => `<option value="${k}" ${String(k) === String(v) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
    el.innerHTML = `<div class="sh-h"><button class="icon" id="btBack" aria-label="Kembali">←</button><b>Backtest</b></div><div class="sh-b">
      <div class="card"><div class="fld"><label>Yang diuji</label>${sel('btT', targets, cur)}</div>
        <div class="fld"><label>Periode uji</label>${sel('btP', [[126, '6 bulan'], [252, '1 tahun'], [504, '2 tahun'], [756, '3 tahun']], c.period)}</div>
        <div class="fld"><label>Saham (terlikuid)</label>${sel('btN', [[20, '20 saham'], [40, '40 saham'], [80, '80 saham'], [150, 'Semua']], c.nStocks)}</div>
        <div class="fld"><label>Entry</label>${sel('btE', [['open', 'Open hari berikutnya'], ['limit', 'Limit di area entry (maks 5 hari)']], c.entry)}</div>
        <div class="fld"><label>Tahan maksimal</label>${sel('btH', [[10, '10 hari'], [20, '20 hari'], [40, '40 hari']], c.hold)}</div>
        <div class="fld"><label>Cek sinyal tiap</label>${sel('btStep', [[1, '1 hari (teliti)'], [2, '2 hari (cepat)']], c.step)}</div>
        <div class="fld"><input type="checkbox" class="sw" id="btR" ${c.regimeFilter ? 'checked' : ''}><label>Lewati sinyal saat pasar risk-off</label></div>
        <div class="rowx" style="margin-top:10px">${B.running && B.owner === 'user' ? '<button class="btn dng" id="btX">■ Stop backtest</button>' : '<button class="btn pri" id="btGo">Jalankan backtest</button>'}<span class="sp"></span><span class="sm mut" id="btMsg">${bt.prog ? esc(bt.prog) : ''}</span></div>
        <div class="note">Exit: invalidasi (stop) atau target 1 dari rencana trading, atau keluar di close setelah batas hari. Sudah termasuk biaya beli ${D.settings.feeBuy}% & jual ${D.settings.feeSell}%. Setiap titik uji hanya memakai data sampai hari itu (tanpa melihat masa depan).</div></div>
      ${r ? btResult(r) : ''}</div>`;
    $('#btBack').onclick = closeBt;
    const read = () => { const [m, v] = $('#btT').value.split(':'); c.mode = m; if (m === 'cat') c.cat = v; else c.preset = v; c.period = +$('#btP').value; c.nStocks = +$('#btN').value; c.entry = $('#btE').value; c.hold = +$('#btH').value; c.step = +$('#btStep').value; c.regimeFilter = $('#btR').checked; };
    el.querySelectorAll('select,input').forEach((x) => (x.onchange = () => { read(); drawBt(); }));
    const go = $('#btGo'); if (go) go.onclick = runBt; const x = $('#btX'); if (x) x.onclick = () => { B.abort = true; x.disabled = true; x.textContent = 'Menghentikan…'; };
    el.querySelectorAll('[data-sym]').forEach((b) => (b.onclick = () => { closeBt(); openStock(b.dataset.sym); }));
    if (r && window.LightweightCharts && r.curve.length > 1) { const ch = LightweightCharts.createChart($('#btCurve'), { localization: { locale: 'id-ID' }, height: 160, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: COL.mut, fontFamily: 'IBM Plex Sans', fontSize: 11 }, grid: { vertLines: { visible: false }, horzLines: { color: COL.grid } }, rightPriceScale: { borderColor: COL.line }, timeScale: { borderColor: COL.line }, handleScroll: false, handleScale: false });
      const ls = ch.addBaselineSeries({ baseValue: { type: 'price', price: 0 }, topLineColor: COL.up, bottomLineColor: COL.dn, topFillColor1: COL.upA(.2), topFillColor2: COL.upA(0), bottomFillColor1: COL.dnA(0), bottomFillColor2: COL.dnA(.2), priceLineVisible: false, lastValueVisible: true });
      const pts = []; let last = 0; for (const p of r.curve) { const t = Math.floor(p.t / 86400) * 86400; if (t <= last) { pts[pts.length - 1].value = p.v; continue; } pts.push({ time: t, value: p.v }); last = t; } ls.setData(pts); ch.timeScale().fitContent(); }
  }
  const cfgKey = () => JSON.stringify(bt.cfg) + (bt.cfg.preset === 'current' ? JSON.stringify(st.tree) : '') + JSON.stringify(R.P);
  async function runBt() {
    const c = bt.cfg; const tree = c.mode === 'tree' ? (c.preset === 'current' ? st.tree : Sc.PRESETS.find((p) => p.id === c.preset).tree) : null;
    const key = cfgKey(); bt.prog = 'Menyiapkan…'; setProg(0.01);
    await B.preempt();
    const run = B.run(Object.assign({}, c, { tree }), (d, n, msg) => { setProg(d / n); bt.prog = msg; const m = $('#btMsg'); if (m) m.textContent = msg; });
    drawBt();
    try { const r = await run; r.cfgKey = key; bt.prog = null; }
    catch (e) { bt.prog = e.message === 'Dibatalkan' ? 'Backtest dihentikan.' : e.message; }
    setProg(null); if (isOpen($('#bt'))) drawBt();
    // resume the background evidence study that this run pre-empted
    if (!PK.evid && !PK.evidBusy) { st.evidTry = 0; if (st.tab === 'picks') rPicks(); }
  }
  function btResult(r) {
    const k = (v, l, cls) => `<div><b class="${cls || ''}">${v}</b><span>${l}</span></div>`; const pc = (x) => (ok(x) ? `${(x * 100).toFixed(1)}%` : '—');
    const tbl2 = (rows, label) => rows.length ? `<table class="t"><tr><td class="mut sm">${label}</td><td class="mut sm">Trade · win · rata-rata R</td></tr>${rows.map((x) => `<tr><td>${esc(x.k)}</td><td>${x.n} · ${pc(x.win)} · <span class="${x.avgR > 0 ? 'up' : 'dn'}">${x.avgR.toFixed(2)}R</span></td></tr>`).join('')}</table>` : '';
    const warn = []; if (r.n < 30) warn.push(`Hanya ${r.n} trade — sampel terlalu kecil untuk disimpulkan.`);
    if (r.dropped.length) warn.push(`Kondisi tidak bisa diuji historis dan dilewati: ${[...new Set(r.dropped.map((d) => (F.byKey[d.f] || {}).label || d.f))].join(', ')} (fundamental/foreign/sektor/intraday tidak punya riwayat gratis).`);
    if (D.settings.provider === 'demo') warn.push('Mode simulasi — angka ini dari data acak, bukan hasil nyata.');
    const verdict = r.n < 30 ? 'Belum cukup data' : r.avgR > 0.15 && r.pf > 1.2 ? 'Ada edge positif' : r.avgR > 0 ? 'Edge tipis' : 'Tidak ada edge';
    return `<h2>Hasil · ${new Date(r.from * 1000).toLocaleDateString('id-ID', { month: 'short', year: 'numeric' })} – ${new Date(r.to * 1000).toLocaleDateString('id-ID', { month: 'short', year: 'numeric' })}</h2>
      <div class="card"><div class="rowx"><b style="font-size:16px">${verdict}</b><span class="sp"></span><span class="sm mut">${r.nStocks} saham · ${r.evals.toLocaleString('id-ID')} titik uji</span></div>
      <div class="kv">${k(r.n, 'trade')}${k(pc(r.winRate), 'win rate')}${k((r.avgR >= 0 ? '+' : '') + r.avgR.toFixed(2) + 'R', 'rata-rata per trade', r.avgR > 0 ? 'up' : 'dn')}${k(ok(r.pf) ? (r.pf === Infinity ? '∞' : r.pf.toFixed(2)) : '—', 'profit factor')}${k(pc(r.avgRet), 'return/trade')}${k(pc(r.alpha), 'vs IHSG/trade', r.alpha > 0 ? 'up' : 'dn')}${k(r.maxDD.toFixed(1) + 'R', 'max drawdown', 'dn')}${k(r.avgBars.toFixed(1), 'hari ditahan')}${k((r.totalR >= 0 ? '+' : '') + r.totalR.toFixed(1) + 'R', 'total')}</div>
      ${warn.map((w) => `<div class="note" style="color:var(--gold)">${esc(w)}</div>`).join('')}
      <div class="sm mut" style="margin-top:10px">Kurva ekuitas (kumulatif R, 1R = risiko per trade)</div><div id="btCurve" style="height:160px"></div>
      <div class="note">Acuan: rata-rata return 10 hari semua saham di semua titik uji = ${pc(r.base10)}.</div></div>
      <h2>Apakah Setup Score bekerja?</h2><div class="card">${tbl2(r.byScore, 'Skor saat sinyal')}<div class="note">Jika skor tinggi menghasilkan R lebih besar, skornya punya daya pembeda. Jika tidak, jangan terlalu mengandalkan skor untuk strategi ini.</div></div>
      <h2>Per kondisi pasar</h2><div class="card">${tbl2(r.byRegime, 'Regime saat sinyal')}</div>
      ${r.byType.length > 1 ? `<h2>Per jenis setup</h2><div class="card">${tbl2(r.byType, 'Setup')}</div>` : ''}
      <h2>Cara keluar</h2><div class="card">${tbl2(r.byExit, 'Exit')}</div>
      <h2>Trade terakhir</h2><div class="list">${r.trades.slice().sort((a, b) => b.d - a.d).slice(0, 40).map((t) => `<button class="row" data-sym="${t.sym}"><span class="sym">${t.sym}</span><span class="px ${t.R > 0 ? 'up' : 'dn'}">${t.R >= 0 ? '+' : ''}${t.R.toFixed(2)}R</span><span class="chg">${pc(t.ret)}</span><span class="sub">${new Date(t.d * 1000).toLocaleDateString('id-ID')} · ${esc(t.out)} · ${t.bars} hari · skor ${t.score}</span><span></span><span></span></button>`).join('')}</div>
      <div class="note">Hasil masa lalu tidak menjamin hasil masa depan. Backtest belum memperhitungkan slippage antrean, ARA/ARB beruntun, dan suspensi.</div>`;
  }

  // ---------------- TRACK RECORD ----------------
  function trackHtml() {
    const log = D.lsGet('rb.picklog', []); if (!log.length) return `<div class="empty"><b>Belum ada catatan</b>${D.settings.provider === 'demo' ? 'Track record hanya dicatat dengan data asli di aplikasi Android.' : 'Setiap hari AI Picks dicatat otomatis, lalu dievaluasi dengan harga sesudahnya. Hasil pertama terlihat setelah beberapa hari.'}</div>`;
    const ev = log.map(E.evalPick).sort((a, b) => b.t - a.t); const closed = ev.filter((x) => ok(x.R) && !x.open && x.status !== 'Aktif');
    const by = E.PICK_CATS.map((c) => { const a = closed.filter((x) => x.cat === c.id); return { c, n: a.length, win: a.filter((x) => x.R > 0).length / (a.length || 1), avgR: a.length ? a.reduce((s, x) => s + x.R, 0) / a.length : NaN }; });
    const all = closed.length ? closed.reduce((s, x) => s + x.R, 0) / closed.length : NaN;
    return `<div class="card"><div class="kv"><div><b>${log.length}</b><span>pick tercatat</span></div><div><b>${closed.length}</b><span>sudah selesai</span></div><div><b class="${all > 0 ? 'up' : 'dn'}">${ok(all) ? (all >= 0 ? '+' : '') + all.toFixed(2) + 'R' : '—'}</b><span>rata-rata</span></div></div>
      <table class="t" style="margin-top:8px">${by.map((x) => `<tr><td>${x.c.name}</td><td>${x.n ? `${x.n} · ${(x.win * 100).toFixed(0)}% · <span class="${x.avgR > 0 ? 'up' : 'dn'}">${x.avgR.toFixed(2)}R</span>` : '<span class="mut">belum ada</span>'}</td></tr>`).join('')}</table>
      <div class="note">Data nyata ke depan (out-of-sample): entry limit di area entry maks 5 hari, keluar di invalidasi/target 1/20 hari, sudah termasuk biaya.</div></div>
      <div class="list" style="margin-top:10px">${ev.slice(0, 60).map((x) => `<button class="row" data-sym="${x.sym}"><span><span class="sym">${x.sym}</span> <span class="chip">${esc((E.PICK_CATS.find((c) => c.id === x.cat) || {}).name || x.cat)}</span></span><span class="px ${x.R > 0 ? 'up' : x.R < 0 ? 'dn' : 'mut'}">${ok(x.R) ? (x.R >= 0 ? '+' : '') + x.R.toFixed(2) + 'R' : '—'}</span><span></span><span class="sub">${x.d} · ${esc(x.status)} · skor ${x.score}</span><span></span><span></span></button>`).join('')}</div>`;
  }
  // ---------------- AI PICKS ----------------
  function planCard(s, weak) {
    const p = s.plan, f = s.f; const pos = (s.scoreObj.comp.flatMap((c) => c.reasons.filter((r) => r[1]).map((r) => r[0]))).slice(0, 5);
    const inv = A.invalidators(f, p, s.ff).slice(0, 4); const pl = PK.plain(s); const owned = E.P.list().some((x) => x.sym === s.sym);
    return `<div class="card pick ${weak ? 'weak' : ''}">${weak ? '<div class="sm" style="color:var(--gold);margin-bottom:6px">Belum lolos syarat kondisi pasar saat ini — perlakukan sebagai watchlist, bukan entry.</div>' : ''}<div class="top"><button class="sym" data-sym="${s.sym}" style="background:none;border:0;padding:0">${s.sym}</button><span class="chip y">${esc(p.type)}</span>${f.ppk ? '<span class="chip r">PPK/FCA</span>' : ''}${gBadge(s)}<span class="sp"></span><button class="icon sh" data-share="${s.sym}" aria-label="Bagikan">⇪</button><span class="score ${scoreCls(f.score)}">${f.score}</span></div>
      <div class="rowx sm" style="margin-top:4px"><span>${px(f.close)} ${pct(f.chg1d)}</span><span class="mut">· ${esc(s.sector)}</span><span class="sp"></span><span class="chip ${p.status.startsWith('Harga') ? 'g' : 'b'}">${esc(p.status)}</span></div>
      <div class="keyl"><div class="ent"><span>Area entry</span><b>${px(p.entry[0])}–${px(p.entry[1])}</b></div><div class="inv"><span>Invalidasi</span><b>${px(p.invalid)}</b></div><div class="tgt"><span>Target 1</span><b>${p.targets[0] ? px(p.targets[0]) : '—'}</b></div></div>
      <div class="pgrid sec"><div><span>R/R · bersih</span><b>${ok(p.rr) ? `${p.rr}x · ${ok(p.rrNet) ? p.rrNet : '—'}x` : '—'}</b></div><div><span>Target lanjutan</span><b>${p.targets.slice(1).map(px).join(' · ') || '—'}</b></div><div><span>Support · resistance</span><b>${p.support[0] ? px(p.support[0]) : '—'} · ${p.resistance[0] ? px(p.resistance[0]) : '—'}</b></div></div>
      ${(() => { if (p.bias <= 0 || !p.targets || !p.targets[0]) return ''; const em = X.expectedMove(s.cd); if (!em) return ''; const pr = em.touch(p.targets[0], 20); return `<div class="sm mut tp" style="margin:-4px 0 6px">Peluang sentuh target 1 dalam 20 hari ≈ <b style="color:var(--tx)">${num(pr * 100, 0)}%</b> (dari volatilitas, bukan arah)</div>`; })()}
      <div class="plain"><div class="pg" style="margin-top:2px">Kenapa saham ini</div><ol>${pl.reasons.map((r) => `<li>${esc(r)}</li>`).join('')}</ol><div class="prisk"><b>Risiko:</b> ${esc(pl.risk)}</div></div>
      ${p.bias > 0 ? `<div class="evid2"><span class="pg">Bukti historis</span><span data-ev="${s.sym}">${esc(PK.evid ? PK.evidenceText(s, PK.stockEv.get(s.sym + '|' + p.type)) || 'Menghitung…' : 'Menghitung bukti historis…')}</span></div>` : ''}
      <details class="why"><summary>Detail teknikal</summary><ul class="why">${[...p.why, ...pos].slice(0, 5).map((r) => `<li class="p">${esc(r)}</li>`).join('')}${inv.map((r) => `<li class="m">${esc(r)}</li>`).join('')}</ul></details>
      <div class="rowx" style="margin-top:8px"><button class="btn ${owned ? '' : 'pri'}" data-buy="${s.sym}">${owned ? '✓ Ada di portofolio · ubah' : '✓ Saya beli'}</button><span class="sp"></span><button class="tg" data-sym="${s.sym}">Detail ›</button></div></div>`;
  }
  st.pickCat = st.pickCat === 'mom' ? 'all' : st.pickCat; st.pickN = 20;
  function briefCard() {
    const v = PK.verdict(); const b = D.lsGet('rb.brief', null); const isToday = b && b.date === new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10);
    const reg = M.regime;
    return `<div class="card brief ${v.noBuy ? 'nobuy' : ''}"><div class="rowx"><b>${v.noBuy ? '⛔ Hari ini lebih baik tidak beli' : '☀️ Picks hari ini'}</b><span class="sp"></span>${isToday ? stamp('Disiapkan ' + when(b.t)) : stamp('Data ' + when(E.snap.asOf))}</div>
      <div class="sm" style="margin-top:6px;line-height:1.5">${esc(v.text)}${reg ? ` Kondisi pasar ${esc(reg.label.toLowerCase())} (${reg.score}/100).` : ''}${isToday && b.overnight ? ` Semalam: ${esc(b.overnight)}.` : ''}</div>
      ${D.settings.morning ? '' : '<div class="note">Aktifkan "Picks pagi" di Pengaturan agar daftar ini disiapkan otomatis setiap hari bursa dan dikirim sebagai notifikasi.</div>'}</div>`;
  }
  function rPicks() {
    if (D.settings.lite && st.pickCat !== 'all') st.pickCat = 'all';
    if (!E.snap) { view.innerHTML = needSnap(); return; }
    const cats = [['all', 'Semua'], ...E.PICK_CATS.map((c) => [c.id, c.name]), ['track', 'Track record']];
    const segs = `<div class="seg" id="pkSeg">${cats.map(([k, l]) => `<button data-c="${k}" class="${k === st.pickCat ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    if (st.pickCat === 'track') { view.innerHTML = segs + '<div style="margin-top:10px"></div>' + trackHtml(); $('#pkSeg').onclick = (e) => { const b2 = e.target.closest('button'); if (b2) { st.pickCat = b2.dataset.c; st.pickN = 20; rPicks(); } }; return; }
    const list = st.pickCat === 'all' ? PK.all() : E.picks(st.pickCat).map((x) => Object.assign(x, { pickCat: st.pickCat }));
    const nPass = list.filter((x) => PK.passes(x)).length; const shown = list.slice(0, st.pickN);
    // evidence: at most one attempt per minute, and re-render only when new evidence actually arrived (never loop)
    if (!PK.evid && !PK.evidBusy && !B.userPending && !B.running && Date.now() - (st.evidTry || 0) > 60e3) {
      st.evidTry = Date.now();
      PK.loadEvidence().then((ev) => {
        if (ev && !PK.evidenceStale()) { if (st.tab === 'picks') rPicks(); return; }
        if (B.running || B.userPending) return;
        const before = PK.evid;
        PK.buildEvidence((d, n) => { const el = $('#evMsg'); if (el) el.textContent = 'Menghitung bukti historis… ' + Math.round((d / n) * 100) + '%'; })
          .then((r) => { if (r && r !== before && st.tab === 'picks') rPicks(); });
      });
    }
    view.innerHTML = `${segs}${briefCard()}
      <div class="rowx" style="margin-top:8px"><span class="sm mut">${nPass} lolos syarat ketat · ${list.length} kandidat</span><span class="sp"></span><button class="tg" id="pkBt">Backtest</button></div>
      ${PK.evidBusy ? '<div class="note" id="evMsg">Menghitung bukti historis…</div>' : ''}
      ${shown.length ? shown.map((x) => planCard(x, !PK.passes(x))).join('') : emptyState('Belum ada kandidat di kategori ini', 'Tidak ada saham yang memenuhi syarat setup, likuiditas minimum, dan R/R bersih ≥ 1 hari ini. Coba kategori lain, atau longgarkan likuiditas minimum di Pengaturan.', [['Lihat semua', 'pick:all'], ['Pengaturan', 'settings']])}
      ${list.length > shown.length ? `<div class="rowx" style="justify-content:center;margin-top:10px"><button class="btn" id="pkMore">Tampilkan ${Math.min(20, list.length - shown.length)} lagi (${list.length - shown.length} tersisa)</button></div>` : ''}
      <div class="note">Skor menilai kualitas setup, bukan peluang profit. Bukti historis dihitung dari data masa lalu dan tidak menjamin hasil ke depan. Bukan rekomendasi investasi.</div>`;
    $('#pkSeg').onclick = (e) => { const b2 = e.target.closest('button'); if (b2) { st.pickCat = b2.dataset.c; st.pickN = 20; rPicks(); } };
    $('#pkBt').onclick = () => openBacktest(st.pickCat === 'all' ? { mode: 'cat', cat: 'swing', entry: 'limit' } : { mode: 'cat', cat: st.pickCat, entry: 'limit' });
    const more = $('#pkMore'); if (more) more.onclick = () => { st.pickN += 20; rPicks(); };
    loadStockEvidence();
  }
  // per-stock historical evidence, computed lazily for the cards on screen
  function loadStockEvidence() {
    const els = [...document.querySelectorAll('[data-ev]')].filter((el) => !el.dataset.done);
    (async () => { for (const el of els) { const s0 = E.getStock(el.dataset.ev); if (!s0 || !document.body.contains(el)) continue; const se = await PK.stockEvidence(s0); el.dataset.done = '1'; el.textContent = PK.evidenceText(s0, se) || 'Bukti historis belum tersedia.'; } })();
  }
  // ---- "Saya beli" sheet ----
  function openBuy(sym) {
    const s0 = E.getStock(sym) || (sp.data && sp.data.sym === sym ? sp.data : null); if (!s0) return; const p = s0.plan; const el = $('#buy'); hap();
    const mid = p.bias > 0 ? A.rt((p.entry[0] + p.entry[1]) / 2) : s0.f.close; const has = E.P.list().find((x) => x.sym === sym);
    el.innerHTML = `<div class="bs-bd" data-close></div><div class="bs-p"><div class="bs-h"><b>Saya beli ${sym}</b><span class="sp"></span><button class="icon" data-close aria-label="Tutup">✕</button></div>
      <div class="fld"><label>Harga beli</label><input id="byPx" type="number" inputmode="decimal" value="${mid}"></div>
      <div class="fld"><label>Jumlah lot <span class="sm mut">(opsional)</span></label><input id="byLot" type="number" inputmode="numeric" value="${has && has.lots ? has.lots : ''}" placeholder="—"></div>
      ${p.bias > 0 ? `<div class="note">Rencana ${esc(p.type)} ikut disimpan: invalidasi ${px(p.invalid)}, target ${p.targets.map(px).join(' · ')}. Portofolio akan memberi tahu saat target tersentuh atau rencana batal.</div>` : '<div class="note">Belum ada rencana trading aktif untuk saham ini; posisi tetap dinilai otomatis.</div>'}
      <div class="rowx" style="margin-top:10px"><button class="btn pri" id="bySave">Simpan ke portofolio</button></div></div>`;
    showLayer(el);
    el.onclick = (e) => { if (e.target.closest('[data-close]')) hideLayer(el); };
    $('#bySave').onclick = () => { const price = parseFloat($('#byPx').value), lots = parseFloat($('#byLot').value); if (!(price > 0)) return toast('Isi harga beli'); PK.buy(s0, price, lots); hideLayer(el); hap('confirm'); toast(`${sym} masuk portofolio`); if (st.tab === 'watch') rWatch(); if (st.tab === 'picks') rPicks(); };
  }
  function openAlertSheet(sym) {
    const el = $('#buy'); hap(); const draw = () => { const mine = AL.forSym(sym);
      el.innerHTML = `<div class="bs-bd" data-close></div><div class="bs-p"><div class="bs-h"><b>🔔 Alert ${sym}</b><span class="sp"></span><button class="icon" data-close aria-label="Tutup">✕</button></div>${alertForm(sym).replace('<div class="card pform" id="alForm"><b style="font-family:var(--fd)">Alert harga baru</b>', '<div class="pform" id="alForm">')}${mine.length ? `<div class="list" style="margin-top:10px">${mine.map(alertRow).join('')}</div>` : ''}</div>`;
      showLayer(el); bindAlertForm(el, () => { draw(); if (isOpen($('#stock')) && sp.sym === sym) { const b3 = $('#skBell'); if (b3) b3.style.color = AL.forSym(sym).some((x) => x.on) ? 'var(--gold)' : 'var(--mut)'; } }); };
    draw(); el.onclick = (e) => { if (e.target.closest('[data-close]')) hideLayer(el); };
  }
  document.addEventListener('click', (e) => { const b2 = e.target.closest('[data-buy]'); if (b2) { e.preventDefault(); e.stopPropagation(); openBuy(b2.dataset.buy); } });

  // ---------------- RADAR ----------------
  Rd.listeners.add(() => { if (st.tab === 'radar' && st.radarView === 'live') rRadar(); });
  function rRadar() {
    if (D.settings.lite && ['alert', 'bandar'].includes(st.radarView)) st.radarView = 'live';
    const seg = `<div class="seg" id="rdSeg">${[['live', 'Live radar'], ['flow', 'Inflow / Outflow'], ['alert', 'Spike alert'], ['bandar', 'Bandar radar']].map(([k, v]) => `<button data-v="${k}" class="${k === st.radarView ? 'on' : ''}">${v}</button>`).join('')}</div>`;
    let body = '';
    if (st.radarView === 'live') {
      const bull = new Set(['pct', 'rvol', 'volAccel', 'breakout', 'newHigh', 'gapUp', 'accel', 'ubuy', 'acc', 'volx']);
      let evs = Rd.list(); if (st.radarFilter === 'bull') evs = evs.filter((e) => bull.has(e.type) && (e.type !== 'pct' || e.chg > 0)); if (st.radarFilter === 'bear') evs = evs.filter((e) => !bull.has(e.type) || (e.type === 'pct' && e.chg < 0));
      body = `<div class="card" style="margin-top:10px"><div class="rowx"><button class="btn ${Rd.running ? 'dng' : 'pri'}" id="rdGo">${Rd.running ? 'Hentikan radar' : 'Mulai radar'}</button><span class="sp"></span><span class="sm mut">${Rd.progress ? `Memindai ${Rd.progress[0]}/${Rd.progress[1]}` : Rd.last ? 'Update ' + new Date(Rd.last).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'Belum berjalan'}</span></div>
        <div class="note">Memantau ${Rd.symbols().length} saham tiap ${D.settings.radarInterval} detik pakai candle 5 menit (${D.settings.provider === 'yahoo' ? 'tertunda ±10 mnt dari Yahoo' : D.prov().name}). Diurutkan berdasarkan signifikansi.</div></div>
        <div class="seg" id="rdF" style="margin-top:10px">${[['all', 'Semua'], ['bull', 'Bullish'], ['bear', 'Bearish']].map(([k, v]) => `<button data-f="${k}" class="${k === st.radarFilter ? 'on' : ''}">${v}</button>`).join('')}</div>
        <div class="list" style="margin-top:8px">${evs.length ? evs.slice(0, 80).map((e) => `<button class="ev" data-sym="${e.sym}"><span class="tm">${new Date(e.t * 1000).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}<div class="sigb"><i style="width:${e.sig}%"></i></div></span><span><b>${e.sym}</b> <span class="chip ${/down|Low|usell|dist|breakdown/i.test(e.type) || (e.type === 'pct' && e.chg < 0) ? 'r' : 'g'}">${Rd.TYPES[e.type]}</span><div class="sm mut">${esc(e.txt)}</div></span><span style="text-align:right"><b>${px(e.px)}</b><div class="sm">${pct(e.chg)}</div></span></button>`).join('') : `<div class="empty"><b>${Rd.running ? 'Belum ada kejadian signifikan' : 'Radar belum berjalan'}</b>${Rd.running ? 'Kejadian muncul di sini begitu terdeteksi.' : 'Tekan Mulai radar untuk memantau pasar.'}</div>`}</div>`;
    } else if (st.radarView === 'flow') { body = flowRadar();
    } else if (st.radarView === 'alert') {
      const r = Rd.rules; const fld = (k, label, unit) => `<div class="fld"><input type="checkbox" class="sw" data-r="${k}" ${r[k].on ? 'checked' : ''}><label>${label}</label>${unit ? `<input type="number" step="any" data-rv="${k}" value="${r[k].v}"><span class="sm mut">${unit}</span>` : ''}</div>`;
      body = `<div class="card" style="margin-top:10px"><div class="fld"><input type="checkbox" class="sw" id="rNotif" ${r.notify ? 'checked' : ''}><label>Notifikasi Android</label></div>
        <div class="fld"><label>Cakupan</label><select id="rScope" style="background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:5px"><option value="liquid" ${r.scope === 'liquid' ? 'selected' : ''}>70 terlikuid + watchlist</option><option value="watchlist" ${r.scope === 'watchlist' ? 'selected' : ''}>Watchlist saja</option><option value="all" ${r.scope === 'all' ? 'selected' : ''}>Semua (lebih lambat)</option></select></div></div>
        <h2>Pemicu alert</h2><div class="card">${fld('pct', 'Harga bergerak ≥', '%')}${fld('rvol', 'Relative volume ≥', 'x')}${fld('volAccel', 'Akselerasi volume ≥', 'x')}${fld('breakout', 'Breakout / breakdown level harian')}${fld('newHigh', 'New high / low 52 minggu')}${fld('gap', 'Gap pembukaan ≥', '%')}${fld('accel', 'Akselerasi momentum')}${fld('volx', 'Ekspansi volatilitas')}${fld('ubuy', 'Unusual buying / akumulasi intraday')}${fld('usell', 'Unusual selling / distribusi intraday')}${fld('fvg', 'FVG baru (5 mnt)')}${fld('bos', 'BOS / CHoCH (5 mnt)')}${fld('sweep', 'Liquidity sweep (5 mnt)')}${fld('foreign', 'Foreign net harian ≥', 'M Rp')}</div>
        <div class="note">Alert berjalan selama aplikasi terbuka dan layar menyala (radar menjaga layar tetap aktif). Data Yahoo tertunda ±10 menit; pasang provider real-time di Pengaturan untuk alert instan.</div>`;
    } else {
      if (!E.snap) body = needSnap();
      else {
        const side = st.bandarSide; const all = [...E.snap.stocks.values()].filter((s) => s.f.avgValue20 >= 3e8).sort((a, b) => side > 0 ? b.bandar.acc - b.bandar.dis - (a.bandar.acc - a.bandar.dis) : b.bandar.dis - b.bandar.acc - (a.bandar.dis - a.bandar.acc)).slice(0, 25);
        body = `<div class="seg" id="bdSide" style="margin-top:10px"><button data-s="1" class="${side > 0 ? 'on' : ''}">Akumulasi</button><button data-s="-1" class="${side < 0 ? 'on' : ''}">Distribusi</button></div>
          <div class="note">Deteksi berbasis bukti harga–volume${E.snap.ffState.status !== 'unavailable' ? ' dan foreign flow' : ''}. Bukan label "bandar": setiap saham menampilkan bukti dan tingkat kepercayaannya. Data broker summary tidak tersedia dari sumber gratis.</div>
          ${all.map((s) => { const b = s.bandar; const evs = b.evidence.filter((e) => e.present && e.side === side).slice(0, 3);
            return `<div class="card"><div class="rowx"><button class="sym" data-sym="${s.sym}" style="background:none;border:0;padding:0">${s.sym}</button><span class="chip ${side > 0 ? 'g' : 'r'}">${esc(b.label)}</span><span class="sp"></span><span class="sm mut">Kepercayaan ${b.confLabel}</span></div>
              <div class="comp" style="margin-top:8px"><span>Akumulasi</span><div class="bar"><i style="width:${b.acc}%;background:var(--up)"></i></div><span>${b.acc}</span><span>Distribusi</span><div class="bar"><i style="width:${b.dis}%;background:var(--dn)"></i></div><span>${b.dis}</span></div>
              ${evs.map((e) => `<div class="evid on ${side > 0 ? 'acc' : 'dis'}"><i></i><span>${esc(e.txt)}</span></div>`).join('')}</div>`; }).join('')}`;
      }
    }
    view.innerHTML = seg + body;
    $('#rdSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) { st.radarView = b.dataset.v; rRadar(); } };
    view.querySelectorAll('[data-fl]').forEach((b) => (b.onclick = () => { const [k, v] = b.dataset.fl.split(':'); st[k] = v; hap(); rRadar(); }));
    const go = $('#rdGo'); if (go) go.onclick = () => { if (Rd.running) Rd.stop(); else { if (!E.snap) toast('Memuat data harian dulu untuk konteks level…'); Rd.start(); } rRadar(); };
    const rf = $('#rdF'); if (rf) rf.onclick = (e) => { const b = e.target.closest('button'); if (b) { st.radarFilter = b.dataset.f; rRadar(); } };
    const bs = $('#bdSide'); if (bs) bs.onclick = (e) => { const b = e.target.closest('button'); if (b) { st.bandarSide = +b.dataset.s; rRadar(); } };
    view.querySelectorAll('[data-r]').forEach((el) => (el.onchange = () => { Rd.rules[el.dataset.r].on = el.checked; Rd.saveRules(); }));
    view.querySelectorAll('[data-rv]').forEach((el) => (el.onchange = () => { Rd.rules[el.dataset.rv].v = parseFloat(el.value) || 0; Rd.saveRules(); }));
    const rn = $('#rNotif'); if (rn) rn.onchange = () => { Rd.rules.notify = rn.checked; Rd.saveRules(); };
    const sc = $('#rScope'); if (sc) sc.onchange = () => { Rd.rules.scope = sc.value; Rd.saveRules(); };
  }

  // ---------------- INFLOW / OUTFLOW RADAR ----------------
  Object.assign(st, { flowSrc: 'total', flowPer: '1', flowDir: 'all', flowKey: 'nom', flowAll: '0' });
  function flowRows() {
    const per = +st.flowPer; const stocks = [...(E.snap ? E.snap.stocks.values() : []), ...E.extra.values()];
    const rows = [];
    for (const s1 of stocks) {
      let v = NaN;
      if (st.flowSrc === 'total') { const tf = X.tradeFlow(s1.cd, per + 1); v = tf.bars.slice(-per).reduce((a, b) => a + b.delta, 0); }
      else { const p = X.ff && X.ff.per.get(s1.sym); if (p) v = per === 1 ? p.n1 : per === 5 ? p.n5 : p.n20; }
      if (!ok(v) || !s1.f.avgValue20) continue;
      const n = s1.cd.c.length - 1; const chg = n >= per ? ((s1.cd.c[n] - s1.cd.c[n - per]) / s1.cd.c[n - per]) * 100 : NaN;
      rows.push({ s: s1, v, int: (v / (s1.f.avgValue20 * per)) * 100, chg });
    }
    const key = st.flowKey === 'int' ? 'int' : 'v';
    let out = st.flowDir === 'in' ? rows.filter((r) => r.v > 0) : st.flowDir === 'out' ? rows.filter((r) => r.v < 0) : rows;
    out.sort((a, b) => (st.flowDir === 'out' ? a[key] - b[key] : b[key] - a[key]));
    return { rows: out, all: rows };
  }
  function flowRadar() {
    const pick = (k, opts) => `<div class="seg fl">${opts.map(([v, l]) => `<button data-fl="${k}:${v}" class="${String(st[k]) === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    const ctrl = `<div class="flc">${pick('flowSrc', [['total', 'Semua transaksi'], ['foreign', 'Asing']])}${pick('flowPer', [['1', 'Hari ini'], ['5', '5 hari'], ['20', '20 hari']])}${pick('flowDir', [['all', 'Semua'], ['in', 'Inflow'], ['out', 'Outflow']])}${pick('flowKey', [['nom', 'Nilai'], ['int', 'Intensitas']])}</div>`;
    if (!E.snap) return ctrl + needSnap();
    if (st.flowSrc === 'foreign' && !X.ff) { if (!X.ffBusy && !X.ffErr) X.loadForeign().then(() => st.tab === 'radar' && st.radarView === 'flow' && rRadar()); return ctrl + (X.ffErr ? emptyState('Data asing belum tersedia', esc(X.ffErr), [['Pakai semua transaksi', 'flow-total']]) : `<div class="note" style="text-align:center">Mengambil ringkasan perdagangan IDX…</div>${skel(4)}`); }
    const { rows, all } = flowRows(); const sumIn = all.filter((r) => r.v > 0).reduce((a, r) => a + r.v, 0), sumOut = all.filter((r) => r.v < 0).reduce((a, r) => a + r.v, 0);
    const mx = Math.max(...rows.map((r) => Math.abs(st.flowKey === 'int' ? r.int : r.v)), 1e-9);
    const bySec = {}; all.forEach((r) => (bySec[r.s.sector] = (bySec[r.s.sector] || 0) + r.v)); const secs = Object.entries(bySec).sort((a, b) => b[1] - a[1]); const smx = Math.max(...secs.map((x) => Math.abs(x[1])), 1);
    const lbl = { 1: 'hari ini', 5: '5 hari', 20: '20 hari' }[st.flowPer]; const shown = st.flowAll === '1' ? rows : rows.slice(0, 40);
    const src = st.flowSrc === 'total' ? `${stamp('Perkiraan dari harga & volume · ' + when(E.snap.asOf))}` : `${stamp('IDX EOD ' + X.ff.asOf.slice(6) + '/' + X.ff.asOf.slice(4, 6))}`;
    return ctrl + `<div class="note">${src}</div>
      <div class="card"><div class="kv"><div><b class="up">${A.fmtRp(sumIn)}</b><span>total inflow ${lbl}</span></div><div><b class="dn">${A.fmtRp(sumOut)}</b><span>total outflow ${lbl}</span></div><div><b class="${sumIn + sumOut >= 0 ? 'up' : 'dn'}">${A.fmtRp(sumIn + sumOut)}</b><span>net</span></div></div>
        <div class="pg">Per sektor</div>${secs.map(([k, v]) => `<div class="secrow" style="grid-template-columns:118px 1fr 80px"><span>${esc(k)}</span><div class="bar"><i style="${v >= 0 ? 'left:50%' : 'right:50%'};width:${(Math.abs(v) / smx) * 50}%;background:${v >= 0 ? 'var(--up)' : 'var(--dn)'}"></i></div><span style="text-align:right" class="${v >= 0 ? 'up' : 'dn'}">${A.fmtRp(v)}</span></div>`).join('')}</div>
      <h2>${st.flowDir === 'out' ? 'Outflow terbesar' : st.flowDir === 'in' ? 'Inflow terbesar' : 'Peringkat aliran dana'} · ${lbl}</h2>
      <div class="list">${shown.map((r, i) => { const val = st.flowKey === 'int' ? r.int : r.v; return `<button class="row flr" data-sym="${r.s.sym}"><span><span class="rk">${i + 1}</span><span class="sym">${r.s.sym}</span></span><span class="px ${r.v >= 0 ? 'up' : 'dn'}">${A.fmtRp(r.v)}</span><span class="chg">${pct(r.chg, 1)}</span><span class="sub">${esc(r.s.sector)} · intensitas ${r.int >= 0 ? '+' : ''}${num(r.int, 0)}% dari rata-rata transaksi</span><span class="fb"><i style="width:${(Math.abs(val) / mx) * 100}%;background:${val >= 0 ? 'var(--up)' : 'var(--dn)'}"></i></span><span></span></button>`; }).join('') || emptyState('Tidak ada data', '')}</div>
      ${rows.length > 40 ? `<div class="rowx" style="justify-content:center;margin-top:8px"><button class="btn" data-fl="flowAll:${st.flowAll === '1' ? '0' : '1'}">${st.flowAll === '1' ? 'Tampilkan 40 teratas' : `Tampilkan semua (${rows.length})`}</button></div>` : ''}
      <div class="note">${st.flowSrc === 'total' ? 'Inflow/outflow semua transaksi = perkiraan nilai beli dikurangi nilai jual dari posisi close dalam range candle × volume (bukan data per transaksi).' : 'Aliran asing = nilai beli asing dikurangi jual asing (IDX), termasuk pasar negosiasi.'} Intensitas = aliran dibanding rata-rata nilai transaksi harian saham itu — berguna untuk membandingkan saham kecil dan besar.</div>`;
  }

  // ---------------- WATCHLIST ----------------
  // ---------------- PORTFOLIO & WATCHLIST ----------------
  const P = E.P; st.pw = st.pw || 'port'; st.portForm = null; const pending = new Set();
  const toneCls = { up: 'g', dn: 'r', gold: 'y' };
  function rWatch() {
    const nA = AL.active().length;
    const seg = `<div class="seg" id="pwSeg"><button data-pw="port" class="${st.pw === 'port' ? 'on' : ''}">Portofolio</button><button data-pw="watch" class="${st.pw === 'watch' ? 'on' : ''}">Watchlist</button><button data-pw="alert" class="${st.pw === 'alert' ? 'on' : ''}">Alert${nA ? ` <span class="mut">${nA}</span>` : ''}</button></div>`;
    if (st.pw === 'watch') rWatchList(seg); else if (st.pw === 'alert') rAlerts(seg); else rPort(seg);
    $('#pwSeg').onclick = (e) => { const b = e.target.closest('[data-pw]'); if (b) { st.pw = b.dataset.pw; rWatch(); } };
  }
  function need(sym) { if (E.getStock(sym) || pending.has(sym)) return; pending.add(sym); E.ensureStock(sym).catch(() => {}).finally(() => { pending.delete(sym); if (st.tab === 'watch') rWatch(); }); }
  function portForm() {
    const f = st.portForm; if (!f) return '';
    return `<div class="card pform"><b style="font-family:var(--fd)">${f.edit ? 'Ubah posisi ' + esc(f.sym) : 'Tambah posisi'}</b>
      <div class="fld"><label>Kode saham</label><input id="pfSym" value="${esc(f.sym || '')}" ${f.edit ? 'disabled' : ''} placeholder="BBRI" autocapitalize="characters" maxlength="4"></div>
      <div class="fld"><label>Harga rata-rata <span class="mut sm">(opsional)</span></label><input id="pfAvg" type="number" inputmode="decimal" value="${f.avg || ''}" placeholder="—"></div>
      <div class="fld"><label>Jumlah lot <span class="mut sm">(opsional)</span></label><input id="pfLot" type="number" inputmode="numeric" value="${f.lots || ''}" placeholder="—"></div>
      <div class="fld"><label>Catatan <span class="mut sm">(opsional)</span></label><input id="pfNote" value="${esc(f.note || '')}" placeholder="mis. swing, target 2 minggu"></div>
      <div class="rowx" style="margin-top:10px"><button class="btn pri" id="pfSave">Simpan</button><button class="btn" id="pfCancel">Batal</button></div>
      <div class="note">Tanpa harga rata-rata, indikator tetap berjalan dari sisi teknikal; dengan harga rata-rata, untung/rugi ikut dipertimbangkan.</div></div>`;
  }
  function rPort(seg) {
    const list = P.list(); const rows = [];
    for (const pos of list) { const s0 = E.getStock(pos.sym); if (!s0) { need(pos.sym); rows.push({ pos, st: null }); continue; } rows.push({ pos, st: s0, a: P.assess(s0, pos) }); }
    rows.sort((x, y) => (x.a ? x.a.sev : 9) - (y.a ? y.a.sev : 9));
    const withVal = rows.filter((r) => r.a && ok(r.a.value)); const tv = withVal.reduce((s2, r) => s2 + r.a.value, 0); const tc = withVal.filter((r) => ok(r.a.cost)).reduce((s2, r) => s2 + r.a.cost, 0);
    const tvc = withVal.filter((r) => ok(r.a.cost)).reduce((s2, r) => s2 + r.a.value, 0); const today = withVal.reduce((s2, r) => s2 + r.a.value * (r.st.f.chg1d / (100 + r.st.f.chg1d)), 0);
    const counts = {}; rows.forEach((r) => r.a && (counts[r.a.action] = (counts[r.a.action] || 0) + 1));
    const bySec = {}; withVal.forEach((r) => (bySec[r.st.sector] = (bySec[r.st.sector] || 0) + r.a.value)); const secs = Object.entries(bySec).sort((x, y) => y[1] - x[1]);
    const conc = secs.length && tv ? secs[0][1] / tv : 0;
    const card = ({ pos, st: s1, a }) => {
      if (!s1) return `<div class="card"><div class="rowx"><span class="sym">${pos.sym}</span><span class="sp"></span><span class="sm mut">${pending.has(pos.sym) ? 'Menganalisis…' : 'Data tidak ditemukan'}</span></div></div>`;
      const f = s1.f;
      return `<div class="card pos" data-sym="${pos.sym}"><div class="rowx"><span class="sym">${pos.sym}</span><span class="act ${toneCls[a.tone]}">${a.action}</span><span class="sp"></span><b data-roll="pp:${pos.sym}">${px(f.close)}</b> ${pct(f.chg1d)}</div>
        <div class="sm" style="margin:6px 0 2px">${esc(a.why)}</div>
        ${a.pl ? `<div class="rowx sm" style="margin-top:4px"><span class="mut">Rata-rata ${px(pos.avg)}${pos.lots ? ` · ${num(pos.lots, 0)} lot` : ''}</span><span class="sp"></span><b class="${a.pl.pct >= 0 ? 'up' : 'dn'}">${a.pl.pct >= 0 ? '+' : ''}${num(a.pl.pct, 2)}%${ok(a.pl.rp) ? ` · ${A.fmtRp(a.pl.rp)}` : ''}</b></div>` : pos.lots ? `<div class="sm mut">${num(pos.lots, 0)} lot · ${A.fmtRp(a.value)}</div>` : ''}
        <div class="keyl" style="margin-top:8px"><div class="inv"><span>Stop pengaman</span><b>${px(a.stop)}</b><i class="sm mut">${num(((a.stop - f.close) / f.close) * 100, 1)}%</i></div><div class="tgt"><span>Target berikutnya</span><b>${px(a.target)}</b><i class="sm mut">+${num(((a.target - f.close) / f.close) * 100, 1)}%</i></div><div><span>Setup</span><b class="sm">${esc(s1.plan.type.split(' (')[0].split(' — ')[0])}</b><i class="sm mut">skor ${f.score}</i></div></div>
        <details class="why"><summary>Alasan (${a.reasons.length})</summary><ul class="why">${a.reasons.map(([t, g]) => `<li class="${g ? 'p' : 'm'}">${esc(t)}</li>`).join('') || '<li class="m">Tidak ada sinyal kuat</li>'}</ul></details>
        ${pos.note ? `<div class="sm mut" style="margin-top:4px">📝 ${esc(pos.note)}</div>` : ''}
        <div class="rowx" style="margin-top:8px"><button class="tg" data-pe="${pos.sym}">Ubah</button><button class="tg" data-pd="${pos.sym}">Hapus</button><span class="sp"></span><span class="sm" style="color:var(--info)">Detail ›</span></div></div>`;
    };
    view.innerHTML = `${seg}
      ${list.length ? `<div class="card" style="margin-top:10px">${tv ? `<div class="kv"><div><b>${A.fmtRp(tv)}</b><span>nilai portofolio</span></div><div><b class="${tvc - tc >= 0 ? 'up' : 'dn'}">${tc ? `${tvc - tc >= 0 ? '+' : ''}${num(((tvc - tc) / tc) * 100, 2)}%` : '—'}</b><span>${tc ? A.fmtRp(tvc - tc) : 'isi harga rata-rata'}</span></div><div><b class="${today >= 0 ? 'up' : 'dn'}">${A.fmtRp(today)}</b><span>perubahan hari ini</span></div></div>` : ''}
        <div class="rowx sm" style="margin-top:${tv ? 10 : 0}px;flex-wrap:wrap;gap:6px">${Object.entries(counts).map(([k, v]) => `<span class="act ${toneCls[rows.find((r) => r.a && r.a.action === k).a.tone]}">${v} ${k}</span>`).join('')}</div>
        ${secs.length > 1 ? `<div class="stack">${secs.map(([k, v], i) => `<i style="width:${(v / tv) * 100}%;background:${['#E9B949', '#5AA9FF', COL.up, '#B48CFF', '#FF9B70', '#7FDBCA', '#F78FB3'][i % 7]}"></i>`).join('')}</div><div class="legend">${secs.map(([k, v], i) => `<span style="--c:${['#E9B949', '#5AA9FF', COL.up, '#B48CFF', '#FF9B70', '#7FDBCA', '#F78FB3'][i % 7]}">${esc(k)} ${num((v / tv) * 100, 0)}%</span>`).join('')}</div>` : ''}
        ${conc > 0.5 && secs.length ? `<div class="note" style="color:var(--gold)">${num(conc * 100, 0)}% nilai portofolio ada di sektor ${esc(secs[0][0])} — risiko terkonsentrasi.</div>` : ''}
        ${M.regime && M.regime.score < 40 ? `<div class="note" style="color:var(--dn)">Pasar risk-off: disiplin pada stop pengaman, hindari menambah posisi yang sinyalnya campuran.</div>` : ''}</div>` : ''}
      <div class="rowx" style="margin:10px 0"><span class="sp"></span><button class="btn pri" data-act="port-add">+ Tambah posisi</button></div>
      ${portForm()}
      ${list.length ? rows.map(card).join('') : st.portForm ? '' : emptyState('Portofolio masih kosong', 'Tambahkan saham yang kamu pegang. Yoo Haw akan menilai setiap posisi setiap hari: tahan, tambah, ambil sebagian, kurangi, atau jual, lengkap dengan stop pengaman dan target berikutnya.', [['+ Tambah posisi', 'port-add']])}
      ${list.length ? '<div class="note">Indikator dihitung otomatis dari struktur harga, tren, bukti akumulasi/distribusi, kondisi pasar, dan untung/rugi posisimu. Data tersimpan di HP ini. Bukan nasihat keuangan.</div>' : ''}`;
    const sv = $('#pfSave'); if (sv) sv.onclick = () => { const sym = ($('#pfSym').value || '').trim().toUpperCase().replace(/\.JK$/, ''); if (!/^[A-Z0-9]{4}$/.test(sym)) return toast('Kode saham harus 4 huruf');
      const avg = parseFloat($('#pfAvg').value), lots = parseFloat($('#pfLot').value); P.upsert({ sym, avg: avg > 0 ? avg : null, lots: lots > 0 ? lots : null, note: $('#pfNote').value.trim() }); st.portForm = null; toast(`${sym} disimpan`); hap('confirm'); rWatch(); };
    const cc = $('#pfCancel'); if (cc) cc.onclick = () => { st.portForm = null; rWatch(); };
    view.querySelectorAll('[data-pe]').forEach((b2) => (b2.onclick = (e) => { e.stopPropagation(); const p0 = P.list().find((x) => x.sym === b2.dataset.pe); st.portForm = Object.assign({ edit: true }, p0); rWatch(); window.scrollTo(0, 0); }));
    view.querySelectorAll('[data-pd]').forEach((b2) => (b2.onclick = (e) => { e.stopPropagation(); if (confirm(`Hapus ${b2.dataset.pd} dari portofolio?`)) { P.remove(b2.dataset.pd); rWatch(); } }));
    view.querySelectorAll('details').forEach((d) => (d.onclick = (e) => e.stopPropagation()));
  }
  function alertRow(a) {
    const s1 = E.getStock(a.sym); const d = s1 ? ((a.price - s1.f.close) / s1.f.close) * 100 : NaN;
    return `<div class="row alr ${a.on ? '' : 'off'}"><span><span class="sym">${a.sym}</span> <span class="chip ${a.op === '<=' ? 'r' : 'g'}">${a.op === '<=' ? 'turun ke ≤' : 'naik ke ≥'} ${px(a.price)}</span></span><span class="px sm">${s1 ? px(s1.f.close) : '—'}</span><span><input type="checkbox" class="sw" data-alt="${a.id}" ${a.on ? 'checked' : ''} aria-label="Aktif"></span>
      <span class="sub">${a.on ? (ok(d) ? `jarak ${d >= 0 ? '+' : ''}${num(d, 1)}%` : 'aktif') : a.hitAt ? `tersentuh ${when(a.hitAt)} di ${px(a.hitPx)}` : 'nonaktif'}${a.note ? ' · ' + esc(a.note) : ''}</span><span></span><button class="x" data-ald="${a.id}" aria-label="Hapus alert">✕</button></div>`;
  }
  function alertForm(sym0) {
    const s1 = sym0 && E.getStock(sym0);
    return `<div class="card pform" id="alForm"><b style="font-family:var(--fd)">Alert harga baru</b>
      <div class="fld"><label>Kode saham</label><input id="alSym" value="${esc(sym0 || '')}" placeholder="BBRI" autocapitalize="characters" maxlength="4"></div>
      <div class="fld"><label>Kondisi</label><div class="seg" id="alOp"><button data-v="<=" class="on">Turun ke ≤</button><button data-v=">=">Naik ke ≥</button></div></div>
      <div class="fld"><label>Harga</label><input id="alPx" type="number" inputmode="decimal" value="${s1 ? s1.f.close : ''}"></div>
      <div class="fld"><label>Catatan <span class="sm mut">(opsional)</span></label><input id="alNote" placeholder="mis. area beli ulang"></div>
      <div class="rowx" style="margin-top:10px"><button class="btn pri" id="alSave">Simpan alert</button></div></div>`;
  }
  function bindAlertForm(root, after) {
    const opSeg = root.querySelector('#alOp'); let op = '<='; if (opSeg) opSeg.onclick = (e) => { const b2 = e.target.closest('[data-v]'); if (!b2) return; op = b2.dataset.v; opSeg.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b2)); };
    const sv = root.querySelector('#alSave'); if (sv) sv.onclick = () => { const sym = (root.querySelector('#alSym').value || '').trim().toUpperCase(); const price = parseFloat(root.querySelector('#alPx').value); if (!/^[A-Z0-9]{4}$/.test(sym)) return toast('Kode saham harus 4 huruf'); if (!(price > 0)) return toast('Isi harga');
      AL.add(sym, op, price, root.querySelector('#alNote').value.trim()); hap('confirm'); toast(`Alert ${sym} ${op === '<=' ? '≤' : '≥'} ${A.fmt(price)} disimpan`); syncSchedule(); if (!E.getStock(sym)) E.ensureStock(sym).catch(() => {}); after && after(); };
    root.querySelectorAll('[data-alt]').forEach((x) => (x.onchange = () => { AL.toggle(x.dataset.alt); syncSchedule(); after && after(); }));
    root.querySelectorAll('[data-ald]').forEach((x) => (x.onclick = (e) => { e.stopPropagation(); AL.remove(x.dataset.ald); syncSchedule(); after && after(); }));
  }
  function rAlerts(seg) {
    const list = AL.list().slice().sort((a, b) => (b.on - a.on) || b.created - a.created);
    view.innerHTML = `${seg}${alertForm('')}${list.length ? `<h2>Alert kamu</h2><div class="list">${list.map(alertRow).join('')}</div>` : emptyState('Belum ada alert', 'Buat alert supaya diberi tahu saat harga sebuah saham turun atau naik ke level tertentu. Alert juga bisa dibuat dari tombol 🔔 di halaman saham.')}
      <div class="note">${D.settings.bgAlerts ? 'Dicek tiap ±15 menit selama jam bursa, juga saat aplikasi ditutup.' : 'Saat ini hanya dicek ketika aplikasi terbuka. Aktifkan "Alert di latar belakang" di Pengaturan agar tetap jalan saat aplikasi ditutup.'} Data harga tertunda ±10–15 menit.</div>`;
    bindAlertForm(view, () => rWatch());
  }
  function rWatchList(seg) {
    const w = watch(); w.forEach((sym) => { if (!E.getStock(sym)) need(sym); });
    view.innerHTML = `${seg}<div class="rowx" style="margin-top:10px"><input id="wIn" placeholder="Tambah kode saham, mis. BBRI" autocapitalize="characters" style="flex:1;background:var(--s1);border:1px solid var(--line);border-radius:10px;padding:10px 12px"><button class="btn pri" id="wAdd">Tambah</button></div>
      <div class="list" style="margin-top:10px">${w.length ? w.map((sym) => { const s1 = E.getStock(sym); return s1 ? stockRow(s1, `${esc(s1.plan.status)}`) : `<button class="row" data-sym="${sym}"><span class="sym">${sym}</span><span class="px mut">—</span><span></span><span class="sub">${pending.has(sym) ? 'Menganalisis…' : 'Ketuk untuk analisis'}</span><span></span><span></span></button>`; }).join('') : ''}</div>
      ${w.length ? '<div class="note">Hapus saham dari watchlist lewat tombol bintang di halaman saham.</div>' : emptyState('Watchlist kosong', 'Tambahkan kode saham yang ingin dipantau. Saham di watchlist ikut dipantau radar dan diprioritaskan di berita.', [])}`;
    const add = () => { const v = $('#wIn').value.trim().toUpperCase().replace(/\.JK$/, ''); if (!/^[A-Z0-9]{4}$/.test(v)) return toast('Kode saham tidak valid'); const ww = watch(); if (!ww.includes(v)) { ww.push(v); setWatch(ww); } rWatch(); };
    $('#wAdd').onclick = add; $('#wIn').onkeydown = (e) => { if (e.key === 'Enter') add(); };
  }

  // ---------------- SEARCH ----------------
  function openSearch() {
    const el = $('#search'); showLayer(el);
    el.innerHTML = `<div class="sh-h"><button class="icon" id="srBack" aria-label="Kembali">←</button><input id="srIn" class="srin" placeholder="Kode atau nama, mis. BBRI / Telkom" autocomplete="off" autocapitalize="characters" spellcheck="false"></div><div class="sh-b" id="srRes"></div>`;
    const inp = $('#srIn'); $('#srBack').onclick = closeSearch; drawSearch('');
    inp.oninput = () => drawSearch(inp.value); inp.onkeydown = (e) => { if (e.key === 'Enter') { const first = $('#srRes [data-go]'); if (first) first.click(); } };
    setTimeout(() => inp.focus(), 60);
    $('#srRes').onclick = (e) => { const b = e.target.closest('[data-go]'); if (!b) return; const sym = b.dataset.go; if (searchPick) { const cb = searchPick; searchPick = null; closeSearch(); cb(sym); return; } const rec = D.lsGet('rb.recent', []).filter((x) => x !== sym); rec.unshift(sym); D.lsSet('rb.recent', rec.slice(0, 10)); closeSearch(); openStock(sym); };
  }
  function closeSearch() { hideLayer($('#search')); setTimeout(() => { if (!isOpen($('#search'))) searchPick = null; }, 0); }
  function drawSearch(q) {
    q = q.trim(); const Q = q.toUpperCase(), ql = q.toLowerCase(); const box = $('#srRes'); const snap = E.snap;
    const row = (sym, name, sub) => { const x = snap && snap.stocks.get(sym); return `<button class="row" data-go="${sym}"><span><span class="sym">${sym === '^JKSE' ? 'IHSG' : sym}</span></span><span class="px">${x ? px(x.f.close) : ''}</span><span class="chg">${x ? pct(x.f.chg1d) : ''}</span><span class="sub">${esc(name || '')}${sub ? ' · ' + esc(sub) : ''}</span><span></span><span></span></button>`; };
    const uni = D.universe(); const nameOf = (sym) => (snap && snap.stocks.get(sym) && snap.stocks.get(sym).meta.name) || '';
    if (!q) { const rec = D.lsGet('rb.recent', []); box.innerHTML = `${row('^JKSE', 'Indeks Harga Saham Gabungan', 'indeks')}${rec.length ? `<h2>Terakhir dicari</h2><div class="list">${rec.map((r) => row(r, nameOf(r), D.sectorOf(r))).join('')}</div>` : ''}<div class="note">Bisa mencari saham apa pun di BEI dengan mengetik kode 4 huruf, termasuk yang tidak ada di daftar pantau.</div>`; return; }
    const hits = uni.filter((u) => u.sym.startsWith(Q) || nameOf(u.sym).toLowerCase().includes(ql) || (ql.length >= 3 && u.sector.toLowerCase().includes(ql)))
      .sort((a, b) => (b.sym === Q) - (a.sym === Q) || (b.sym.startsWith(Q)) - (a.sym.startsWith(Q)) || a.sym.localeCompare(b.sym)).slice(0, 30);
    const ihsg = /^(ihsg|jkse|indeks|composite)/i.test(q) ? row('^JKSE', 'Indeks Harga Saham Gabungan', 'indeks') : '';
    const direct = /^[A-Z]{4}$/.test(Q) && !uni.some((u) => u.sym === Q) ? `<button class="row" data-go="${Q}"><span><span class="sym">${Q}</span></span><span class="px sm" style="color:var(--info)">Buka ›</span><span></span><span class="sub">Di luar daftar pantau — dianalisis langsung</span><span></span><span></span></button>` : '';
    box.innerHTML = ihsg || direct || hits.length ? `<div class="list">${ihsg}${direct}${hits.map((u) => row(u.sym, nameOf(u.sym), u.sector)).join('')}</div>` : `<div class="empty"><b>Tidak ditemukan</b>Ketik kode 4 huruf (mis. BREN) untuk membuka saham di luar daftar pantau.</div>`;
  }

  // ---------------- STOCK PAGE ----------------
  const sp = { sym: null, tf: 'D', sec: 'sum', chart: null, data: null, F: null, tool: null, overlays: Object.assign({ ema: true, lv: true, smc: true, plan: true }, D.lsGet('rb.ov', {})) };
  const SECS_IDX = [['isum', 'Ringkasan'], ['breadth', 'Breadth'], ['movers', 'Penggerak'], ['tech', 'Teknikal'], ['struct', 'Struktur'], ['stats', 'Statistik & musiman'], ['global', 'Global & makro']];
  const GROUPS = [['Ringkasan', ['sum', 'range', 'risk']], ['Teknikal', ['tech', 'struct', 'vol', 'flow']], ['Bandar & pemilik', ['smc', 'own']], ['Fundamental', ['fund', 'val', 'peers']], ['Berita', ['news']]];
  const SECS = [['sum', 'Ringkasan AI'], ['peers', 'Peers'], ['own', 'Kepemilikan'], ['flow', 'Trade flow'], ['range', 'Kisaran gerak'], ['tech', 'Teknikal'], ['struct', 'Struktur'], ['smc', 'Smart Money & Flow'], ['vol', 'Volume'], ['fund', 'Fundamental'], ['val', 'Valuasi'], ['news', 'Berita'], ['risk', 'Risiko']];
  let shared = null;
  document.addEventListener('click', (e) => { const row = e.target.closest('.row[data-sym], .ev[data-sym], .flr[data-sym]'); shared = null; if (!row || noMotion() || e.target.closest('[data-share],[data-buy],[data-act]')) return;
    const sy = row.querySelector('.sym'), pr = row.querySelector('.px'); if (!sy) return; const r1 = sy.getBoundingClientRect(); if (!r1.width && !r1.height && r1.top === 0) return;
    shared = { sym: row.dataset.sym, t: Date.now(), sym0: { r: r1, txt: sy.textContent, fs: parseFloat(getComputedStyle(sy).fontSize) || 15 }, px0: pr ? { r: pr.getBoundingClientRect(), txt: pr.textContent, fs: parseFloat(getComputedStyle(pr).fontSize) || 14 } : null }; }, true);
  function flyShared(sym) {
    const sh = shared; shared = null; if (!sh || sh.sym !== sym || Date.now() - sh.t > 1500) return false;
    const tSym = $('.stk-h .sym'), tPx = $('.stk-px b'); if (!tSym) return false;
    const pairs = [[sh.sym0, tSym], sh.px0 && tPx ? [sh.px0, tPx] : null].filter(Boolean); const ghosts = [];
    for (const [src, dst] of pairs) {
      const r2 = dst.getBoundingClientRect(); const fs2 = parseFloat(getComputedStyle(dst).fontSize) || src.fs; const g = document.createElement('div'); g.className = 'ghost'; g.textContent = src.txt;
      g.style.cssText = `left:${r2.left}px;top:${r2.top}px;font-size:${fs2}px;font-weight:${getComputedStyle(dst).fontWeight};font-family:${getComputedStyle(dst).fontFamily}`;
      document.body.appendChild(g); dst.style.visibility = 'hidden'; const sc = src.fs / fs2; const dx = src.r.left - r2.left, dy = src.r.top - r2.top; ghosts.push({ g, dst, sc, dx, dy });
    }
    R.MO.spring({ from: 1, to: 0, k: 300, ratio: 0.92, onUpdate: (p) => { for (const o of ghosts) o.g.style.transform = `translate3d(${o.dx * p}px,${o.dy * p}px,0) scale(${1 + (o.sc - 1) * p})`; },
      onDone: () => { for (const o of ghosts) { o.dst.style.visibility = ''; o.g.remove(); } } });
    return true;
  }
  async function openStock(sym) {
    sp.full = false;
    sp.ctx = pendingCtx && pendingCtx.includes(sym) ? pendingCtx : null; pendingCtx = null;
    const el = $('#stock'); const flying = shared && shared.sym === sym && !isOpen(el); showLayer(el, flying ? { mode: 'fade' } : undefined); sp.sym = sym; sp.tf = 'D'; sp.sec = 'sum'; sp.stories = null; sp.storiesErr = null; el.scrollTop = 0;
    el.innerHTML = `<div class="sh-h"><button class="icon" id="skBack" aria-label="Kembali">←</button><b class="sym">${sym}</b><span class="sp"></span></div><div class="sh-b"><div class="empty"><b>Memuat ${sym}…</b></div></div>`;
    $('#skBack').onclick = closeStock;
    try {
      let s = E.snap && E.snap.stocks.get(sym); sp.isIndex = sym === '^JKSE';
      if (sp.isIndex) {
        const r = E.snap ? E.snap.ihsg : await D.candles('^JKSE', 'D'); const F0 = F.compute(r.cd, { daily: true }); if (!F0) throw new Error('Data IHSG kosong');
        s = { sym, sector: 'Indeks', meta: Object.assign({}, r.meta, { name: 'Indeks Harga Saham Gabungan' }), cd: r.cd, F: F0, f: F0.f, plan: { bias: 0 } }; sp.sec = 'isum';
        sp.data = s; sp.F = s.F; sp.cd = s.cd; sp.meta = s.meta; drawStock(); flyShared(sym); flyShared(sym); return;
      }
      if (!s) { const r = await D.candles(sym, 'D'); const ih = E.snap ? E.snap.ihsg.cd : (await D.candles('^JKSE', 'D')).cd; s = E.analyzeDaily({ sym, sector: D.sectorOf(sym), meta: r.meta, cd: r.cd }, ih, null); if (!s) throw new Error('Riwayat harga terlalu pendek'); s.f.rsRating = NaN; E.finish(s); }
      sp.data = s; sp.F = s.F; sp.cd = s.cd; sp.meta = s.meta; drawStock(); flyShared(sym);
      D.fundamentals(sym).then((fu) => { if (fu && sp.sym === sym) { E.applyFund(s, fu); E.finish(s); if (['fund', 'val', 'sum', 'risk'].includes(sp.sec)) drawSection(); } }).catch((e) => { s.fundErr = e.message; if (sp.sec === 'fund' || sp.sec === 'val') drawSection(); });
      D.news(sym).then((n) => { s.news = n; E.finish(s); if (sp.sym === sym && (sp.sec === 'news' || sp.sec === 'sum')) drawSection(); }).catch((e) => { s.news = { items: [], err: e.message }; });
    } catch (e) { el.querySelector('.sh-b').innerHTML = `<div class="empty"><b>Data ${sym} tidak bisa dimuat</b>${esc(e.message)}. Periksa kode saham atau koneksi.</div>`; }
  }
  function closeStock() { sp.tool = null; sp.tPend = null; hideLayer($('#stock')); const ch0 = sp.chart; setTimeout(() => { if (!isOpen($('#stock')) && sp.chart === ch0) { try { ch0 && ch0.remove(); } catch (e) {} sp.chart = null; } }, 500); if (st.tab === 'watch') rWatch(); }
  function drawStock() {
    const s = sp.data, f = s.f, el = $('#stock'); const inW = watch().includes(s.sym); const meta = sp.meta; const px = sp.isIndex ? (x) => num(x, 2) : A.fmt; const secs = sp.isIndex ? SECS_IDX : SECS;
    el.innerHTML = `<div class="sh-h stk-h"><button class="icon" id="skBack" aria-label="Kembali">←</button><div style="min-width:0;flex:1"><b class="sym">${sp.isIndex ? 'IHSG' : s.sym}</b><div class="nm">${esc(meta.name || '')} · ${esc(s.sector)}${sp.ctx ? ` · <span class="ctxn">${sp.ctx.indexOf(s.sym) + 1}/${sp.ctx.length} ‹ geser ›</span>` : ''}</div></div>${sp.isIndex ? '' : `<button class="icon" id="skBell" aria-label="Alert harga" style="color:${AL.forSym(s.sym).some((x) => x.on) ? 'var(--gold)' : 'var(--mut)'}">🔔</button>`}<button class="icon" id="skShare" aria-label="Bagikan">⇪</button><button class="icon" id="skCmp" aria-label="Bandingkan">⇆</button>${sp.isIndex ? '' : `<button class="icon" id="skPort" aria-label="Portofolio" style="color:${P.list().some((x) => x.sym === s.sym) ? 'var(--gold)' : 'var(--mut)'}">◫</button><button class="icon" id="skStar" aria-label="Watchlist" style="color:${inW ? 'var(--gold)' : 'var(--mut)'}">${inW ? '★' : '☆'}</button>`}</div>
      <div class="sh-b"><div class="stk-px"><b data-roll="stk:${s.sym}">${px(f.close)}</b>${pct(f.chg1d)}<span class="sp"></span><span class="chip ${meta.status === 'simulated' ? 'r' : meta.status === 'realtime' ? 'g' : 'y'}">${D.STATUS[meta.status]} · ${esc(meta.source)}</span>${gBadge(s)}</div>
      <div style="margin-top:4px">${stamp('Harga ' + (meta.asOf ? when(meta.asOf * 1000) : new Date((s.cd.t[s.cd.t.length - 1] + 25200) * 1000).toLocaleDateString('id-ID', { timeZone: 'UTC', day: 'numeric', month: 'short' })))}${s.fund && s.fund.fetchedAt ? stamp('Fundamental ' + when(s.fund.fetchedAt)) : ''}${O.cur ? stamp('KSEI ' + O.cur.date) : ''}${X.ff ? stamp('Asing EOD ' + X.ff.asOf.slice(6) + '/' + X.ff.asOf.slice(4, 6)) : ''}</div>
      ${sp.isIndex ? `<div class="sm mut" style="margin-top:4px">Sesi ${new Date((s.cd.t[s.cd.t.length - 1] + 25200) * 1000).toLocaleDateString('id-ID', { timeZone: 'UTC', weekday: 'long', day: 'numeric', month: 'long' })} · O ${px(s.cd.o[s.cd.o.length - 1])} · H ${px(s.cd.h[s.cd.h.length - 1])} · L ${px(s.cd.l[s.cd.l.length - 1])}</div>` : ''}
      ${(() => { const L = sp.isIndex ? null : A.limits(f.close); return L ? `<div class="sm mut" style="margin-top:4px">Batas sesi berikutnya: ARB <span class="dn">${px(L.arb)}</span> (−${num(L.arbPct, 0)}%) · ARA <span class="up">${px(L.ara)}</span> (+${num(L.araPct, 0)}%)${f.ppk ? ' · <span class="chip r">Papan Pemantauan Khusus</span>' : ''}</div>` : ''; })()}
      <div class="seg" id="tfSeg" style="margin-top:10px">${Object.entries(D.TF).map(([k, v]) => `<button data-tf="${k}" class="${k === sp.tf ? 'on' : ''}">${v}</button>`).join('')}</div>
      <div id="chart" class="chart"></div>
      ${liteStock() ? '' : chartTools()}<div class="seg ${liteStock() ? 'pro-hide' : ''}" id="ovSeg" style="margin-top:6px">${[['ema', 'EMA'], ['lv', 'S/R'], ['smc', 'FVG/OB/BOS'], ...(sp.isIndex ? [] : [['plan', 'Rencana']])].map(([k, v]) => `<button data-ov="${k}" class="${sp.overlays[k] ? 'on' : ''}">${v}</button>`).join('')}</div>
      ${liteStock() ? '' : `<div class="tabs2">${navHtml(secs)}</div>`}
      <div id="sec"></div></div>`;
    $('#skBack').onclick = closeStock;
    $('#skShare').onclick = () => shareStock(s);
    if ($('#skBell')) $('#skBell').onclick = () => openAlertSheet(s.sym); $('#skCmp').onclick = () => openCompare(s.sym);
    if ($('#skPort')) $('#skPort').onclick = () => { const has = P.list().find((x) => x.sym === s.sym); closeStock(); st.pw = 'port'; st.portForm = has ? Object.assign({ edit: true }, has) : { sym: s.sym }; $('#tabs button[data-tab="watch"]').click(); };
    if ($('#skStar')) $('#skStar').onclick = () => { let w = watch(); w = w.includes(s.sym) ? w.filter((x) => x !== s.sym) : [...w, s.sym]; setWatch(w); drawStock(); };
    $('#tfSeg').onclick = async (e) => { const b = e.target.closest('button'); if (!b) return; $('#tfSeg').querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); await switchTf(b.dataset.tf); drawChart(); if (['tech', 'struct', 'smc', 'vol'].includes(sp.sec)) drawSection(); };
    $('#ovSeg').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; sp.overlays[b.dataset.ov] = !sp.overlays[b.dataset.ov]; D.lsSet('rb.ov', sp.overlays); b.classList.toggle('on'); hap(); drawChart(); };
    bindTools($('#stock'));
    // let the slide-in animation finish before building the chart (avoids a stutter)
    bindNav(secs);
    $('#sec').addEventListener('click', (e) => { const a = e.target.closest('a[data-ext]'); if (a) { e.preventDefault(); return openExt(a.href); } const ai = e.target.closest('[data-ai]'); if (ai) return runAI(ai.dataset.ai); const rd = e.target.closest('[data-read]'); if (rd) return openReader(rd.dataset.read); const b = e.target.closest('[data-sym]'); if (b && b.dataset.sym !== sp.sym) openStock(b.dataset.sym); });
    rollAll($('#stock'));
    if ($('#stock').classList.contains('entering')) { const c0 = $('#chart'); if (c0) c0.innerHTML = '<div class="skel" style="height:300px;padding:10px"><i style="height:100%"></i></div>'; drawSection(); setTimeout(() => { if (isOpen($('#stock'))) drawChart(); }, 260); }
    else { drawChart(); drawSection(); }
  }
  const secLabel = (k) => (SECS.find((x) => x[0] === k) || SECS_IDX.find((x) => x[0] === k) || [k, k])[1];
  function navHtml(secs) {
    if (sp.isIndex) return `<div class="seg" id="secSeg">${secs.map(([k, v]) => `<button data-s="${k}" class="${k === sp.sec ? 'on' : ''}">${v}</button>`).join('')}</div>`;
    const g = GROUPS.find((x) => x[1].includes(sp.sec)) || GROUPS[0];
    return `<div class="seg grp" id="grpSeg">${GROUPS.map(([l, ks]) => `<button data-g="${l}" class="${l === g[0] ? 'on' : ''}">${l}</button>`).join('')}</div>${g[1].length > 1 ? `<div class="seg sub" id="secSeg">${g[1].map((k) => `<button data-s="${k}" class="${k === sp.sec ? 'on' : ''}">${secLabel(k).replace(' & Flow', '')}</button>`).join('')}</div>` : '<div id="secSeg" hidden></div>'}`;
  }
  sp.lastIn = {};
  function bindNav(secs) {
    const box = $('.tabs2'); if (!box) return;
    box.onclick = (e) => { const gb = e.target.closest('[data-g]'), sb = e.target.closest('[data-s]'); if (!gb && !sb) return;
      if (gb) { const g = GROUPS.find((x) => x[0] === gb.dataset.g); sp.sec = sp.lastIn[g[0]] || g[1][0]; } else sp.sec = sb.dataset.s;
      const g2 = GROUPS.find((x) => x[1].includes(sp.sec)); if (g2) sp.lastIn[g2[0]] = sp.sec; box.innerHTML = navHtml(secs); drawSection(); };
  }
  function drawChart(el0, h0, key0) {
    const OV = liteStock() ? { ema: true, lv: false, smc: false, plan: true } : sp.overlays; // Lite: clean chart (price, EMA, plan levels)
    const key = key0 || 'chart'; const el = el0 || $('#chart'); if (!el || !window.LightweightCharts) return; try { sp[key] && sp[key].remove(); } catch (e) {}
    const H0 = h0 || (window.innerWidth >= 900 && window.innerHeight >= 600 ? 420 : window.innerHeight < 500 ? 220 : 300); el.style.height = H0 + 'px'; el.innerHTML = '';
    const cd = sp.cd, Fx = sp.F, intraday = !['D', 'W'].includes(sp.tf); const n = cd.c.length; const k0 = Math.max(0, n - (intraday ? 400 : 260));
    const ch = LightweightCharts.createChart(el, { height: H0, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: COL.mut, fontFamily: 'IBM Plex Sans', fontSize: 11 }, grid: { vertLines: { color: COL.grid }, horzLines: { color: COL.grid } }, rightPriceScale: { borderColor: COL.line }, timeScale: { borderColor: COL.line, timeVisible: intraday, secondsVisible: false }, crosshair: { mode: 0 }, localization: { locale: 'id-ID', priceFormatter: (p) => (sp.isIndex ? num(p, 2) : A.fmt(p)) } });
    sp[key] = ch; const T = (i) => cd.t[i] + 25200;
    const cs = ch.addCandlestickSeries({ upColor: COL.up, downColor: COL.dn, borderVisible: false, wickUpColor: COL.up, wickDownColor: COL.dn });
    const rows = []; for (let i = k0; i < n; i++) rows.push({ time: T(i), open: cd.o[i], high: cd.h[i], low: cd.l[i], close: cd.c[i] }); cs.setData(rows);
    const vs = ch.addHistogramSeries({ priceScaleId: 'vol', priceFormat: { type: 'volume' }, lastValueVisible: false, priceLineVisible: false });
    ch.priceScale('vol').applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });
    vs.setData(rows.map((r, j) => ({ time: r.time, value: cd.v[k0 + j], color: r.close >= r.open ? COL.upA(.35) : COL.dnA(.35) })));
    if (OV.ema) for (const [k, c] of [['ema20', '#5AA9FF'], ['ema50', '#E9B949'], ['ema200', '#B48CFF']]) { const ser = Fx.se[k]; if (!ser) continue; const ls = ch.addLineSeries({ color: c, lineWidth: 1, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false }); ls.setData(rows.map((r, j) => ({ time: r.time, value: ser[k0 + j] })).filter((x) => ok(x.value))); }
    const line = (price, color, title, style = 2) => ok(price) && cs.createPriceLine({ price, color, lineWidth: 1, lineStyle: style, axisLabelVisible: true, title });
    if (OV.lv) { Fx.st.levels.supports.slice(0, 2).forEach((x) => line(x.price, COL.up, 'S')); Fx.st.levels.resistances.slice(0, 2).forEach((x) => line(x.price, COL.dn, 'R')); }
    const mk = [];
    if (OV.smc) {
      for (const e of Fx.st.ev) if (e.i >= k0) mk.push({ time: T(e.i), position: e.dir > 0 ? 'belowBar' : 'aboveBar', color: e.type === 'CHoCH' ? '#E9B949' : e.dir > 0 ? COL.up : COL.dn, shape: e.dir > 0 ? 'arrowUp' : 'arrowDown', text: e.type });
      for (const w of Fx.st.sweeps) if (w.i >= k0) mk.push({ time: T(w.i), position: w.dir > 0 ? 'belowBar' : 'aboveBar', color: '#5AA9FF', shape: 'circle', text: 'sweep' });
      const nb = Fx.st.nearBull; if (nb) { line(nb.hi, '#5AA9FF', 'FVG', 1); line(nb.lo, '#5AA9FF', '', 1); }
      const ob = Fx.st.obs.filter((b) => b.dir === 1 && b.status !== 'breaker').pop(); if (ob && ob.i >= k0) { line(ob.hi, '#B48CFF', 'OB', 3); line(ob.lo, '#B48CFF', '', 3); }
    }
    if (OV.plan && sp.tf === 'D' && sp.data.plan.bias > 0) { const p = sp.data.plan; line(p.entry[1], '#E9B949', 'Entry', 0); line(p.entry[0], '#E9B949', '', 0); line(p.invalid, COL.dn, 'Invalid', 0); p.targets.slice(0, 2).forEach((t, i) => line(t, COL.up, 'T' + (i + 1), 0)); }
    mk.sort((a, b) => a.time - b.time); cs.setMarkers(mk);
    ch.timeScale().setVisibleLogicalRange({ from: rows.length - (intraday ? 120 : 110), to: rows.length + 3 });
    // user drawings (horizontal lines on every timeframe, trendlines on the timeframe they were drawn)
    const dr = drawings(sp.sym); dr.h.forEach((v) => cs.createPriceLine({ price: v, color: '#5AA9FF', lineWidth: 1, lineStyle: 0, axisLabelVisible: true, title: '' }));
    dr.t.filter((x) => x.tf === sp.tf).forEach((x) => { const a = x.a.t <= x.b.t ? x.a : x.b, b = x.a.t <= x.b.t ? x.b : x.a; if (a.t === b.t) return; const ls = ch.addLineSeries({ color: '#5AA9FF', lineWidth: 2, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false }); ls.setData([{ time: a.t, value: a.p }, { time: b.t, value: b.p }]); });
    ch.subscribeClick((prm) => {
      if (!sp.tool || !prm.point) return; const price = cs.coordinateToPrice(prm.point.y); const time = prm.time || ch.timeScale().coordinateToTime(prm.point.x); if (!ok(price)) return;
      const d = drawings(sp.sym);
      if (sp.tool === 'h') { d.h.push(price); saveDrawings(sp.sym, d); sp.tool = null; hap('confirm'); redrawCharts(); toast('Garis horizontal ditambahkan'); return; }
      if (sp.tool === 't') { if (!time) return; if (!sp.tPend) { sp.tPend = { t: time, p: price }; hap(); toast('Ketuk titik kedua'); return; } d.t.push({ tf: sp.tf, a: sp.tPend, b: { t: time, p: price } }); sp.tPend = null; sp.tool = null; saveDrawings(sp.sym, d); hap('confirm'); redrawCharts(); }
    });
    // OHLC readout
    const lg = document.createElement('div'); lg.className = 'ohlc'; el.style.position = 'relative'; el.appendChild(lg);
    const fmtV = (v) => (v >= 1e9 ? num(v / 1e9, 2) + ' M' : v >= 1e6 ? num(v / 1e6, 1) + ' jt' : num(v, 0));
    const pxf = sp.isIndex ? (v) => num(v, 2) : A.fmt;
    const show = (i) => { if (i < 0) return; const ch2 = i > 0 ? ((cd.c[i] - cd.c[i - 1]) / cd.c[i - 1]) * 100 : 0; lg.innerHTML = `<span class="mut">${new Date(T(i) * 1000).toLocaleDateString('id-ID', { timeZone: 'UTC', day: 'numeric', month: 'short' })}${intraday ? ' ' + new Date(T(i) * 1000).toLocaleTimeString('id-ID', { timeZone: 'UTC', hour: '2-digit', minute: '2-digit' }) : ''}</span> O <b>${pxf(cd.o[i])}</b> H <b>${pxf(cd.h[i])}</b> L <b>${pxf(cd.l[i])}</b> C <b>${pxf(cd.c[i])}</b> <span class="${ch2 >= 0 ? 'up' : 'dn'}">${ch2 >= 0 ? '+' : ''}${num(ch2, 2)}%</span> <span class="mut">V ${fmtV(cd.v[i])}</span>${sp.tool ? ` <span class="gold">· ${sp.tool === 'h' ? 'ketuk harga untuk garis' : sp.tPend ? 'ketuk titik kedua' : 'ketuk titik pertama'}</span>` : ''}`; };
    const idxOf = new Map(); for (let i = k0; i < n; i++) idxOf.set(T(i), i); show(n - 1);
    ch.subscribeCrosshairMove((prm) => { const i = prm && prm.time !== undefined ? idxOf.get(prm.time) : undefined; show(i === undefined ? n - 1 : i); });
  }
  async function switchTf(tf) {
    const s = sp.data; sp.tf = tf;
    try { if (sp.tf === 'D') { sp.F = s.F; sp.cd = s.cd; } else { const r = await D.candles(s.sym, sp.tf); sp.cd = r.cd; sp.F = F.compute(r.cd, { intraday: !['D', 'W'].includes(sp.tf) }); if (!sp.F) throw new Error('Data terlalu pendek'); } }
    catch (err) { toast('Timeframe gagal dimuat: ' + err.message); sp.tf = 'D'; sp.F = s.F; sp.cd = s.cd; }
  }
  const drawings = (sym) => Object.assign({ h: [], t: [] }, (D.lsGet('rb.draw', {})[sym]) || {});
  const saveDrawings = (sym, d) => { const all = D.lsGet('rb.draw', {}); all[sym] = d; D.lsSet('rb.draw', all); };
  function redrawCharts() { if (isOpen($('#fs'))) drawFS(); if ($('#chart')) drawChart(); }
  function chartTools() { return `<div class="seg tools"><button data-tool="fs">⤢ Layar penuh</button><button data-tool="h" class="${sp.tool === 'h' ? 'on' : ''}">─ Garis</button><button data-tool="t" class="${sp.tool === 't' ? 'on' : ''}">／ Tren</button><button data-tool="clr">⌫ Hapus garis</button></div>`; }
  function bindTools(root) {
    root.querySelectorAll('[data-tool]').forEach((b) => (b.onclick = () => { const t = b.dataset.tool; hap();
      if (t === 'fs') return openFS();
      if (t === 'clr') { const d = drawings(sp.sym); if (!d.h.length && !d.t.length) return toast('Belum ada garis'); if (!confirm(`Hapus semua garis di ${sp.sym}?`)) return; saveDrawings(sp.sym, { h: [], t: [] }); redrawCharts(); return; }
      sp.tool = sp.tool === t ? null : t; sp.tPend = null; root.querySelectorAll('[data-tool]').forEach((x) => x.classList.toggle('on', x.dataset.tool === sp.tool)); if (sp.tool) toast(t === 'h' ? 'Ketuk chart di harga yang diinginkan' : 'Ketuk dua titik di chart'); redrawCharts(); }));
  }
  // ---- full-screen chart ----
  function openFS() {
    const el = $('#fs'); showLayer(el); hap(); try { window.AndroidBridge && window.AndroidBridge.orientation && window.AndroidBridge.orientation('landscape'); } catch (e) {}
    drawFS(); window.addEventListener('resize', fsResize);
  }
  let fsT = null; function fsResize() { clearTimeout(fsT); fsT = setTimeout(() => { if (isOpen($('#fs'))) drawFS(); }, 180); }
  function drawFS() {
    const el = $('#fs'); el.innerHTML = `<div class="fs-h"><b class="sym">${sp.isIndex ? 'IHSG' : sp.sym}</b><div class="seg" id="fsTf">${Object.entries(D.TF).map(([k, v]) => `<button data-tf="${k}" class="${k === sp.tf ? 'on' : ''}">${v}</button>`).join('')}</div>${chartTools().replace('<button data-tool="fs">⤢ Layar penuh</button>', '')}<span class="sp"></span><button class="icon" id="fsX" aria-label="Tutup">✕</button></div><div id="fsChart"></div>`;
    $('#fsX').onclick = closeFS; bindTools(el);
    $('#fsTf').onclick = async (e) => { const b = e.target.closest('[data-tf]'); if (!b) return; await switchTf(b.dataset.tf); drawFS(); };
    const h = Math.max(220, window.innerHeight - el.querySelector('.fs-h').offsetHeight - 8); drawChart($('#fsChart'), h, 'fsChartI');
  }
  function closeFS() { const el = $('#fs'); hideLayer(el); window.removeEventListener('resize', fsResize); try { sp.fsChartI && sp.fsChartI.remove(); } catch (e) {} sp.fsChartI = null; el.innerHTML = ''; try { window.AndroidBridge && window.AndroidBridge.orientation && window.AndroidBridge.orientation('auto'); } catch (e) {} if ($('#chart')) setTimeout(() => drawChart(), 250); }
  const tbl = (rows) => `<table class="t">${rows.filter(Boolean).map(([a, b]) => `<tr><td>${a}</td><td>${b}</td></tr>`).join('')}</table>`;
  const yn = (b, good = true) => (b ? `<span class="${good ? 'up' : 'dn'}">Ya</span>` : '<span class="mut">Tidak</span>');
  function scoreAnatomy(so) {
    const C = 2 * Math.PI * 42; const v = so.total;
    return `<div class="card"><div class="anat"><div class="ring"><svg width="96" height="96"><circle cx="48" cy="48" r="42" fill="none" stroke="#24344A" stroke-width="7"/><circle class="ringv" cx="48" cy="48" r="42" fill="none" stroke="#E9B949" stroke-width="7" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - v / 100)}" style="--c:${C}"/></svg><b>${v}</b><span>${so.grade}</span></div>
      <div class="comp">${so.comp.map((c) => `<span>${esc(c.label)}</span><div class="bar ${c.score < 50 ? 'lo' : ''}"><i style="width:${ok(c.score) ? c.score : 0}%"></i></div><span>${ok(c.score) ? c.score : '—'}</span>`).join('')}</div></div>
      <details class="why"><summary>Kenapa skornya ${v}?</summary><ul class="why">${so.comp.flatMap((c) => c.reasons.map((r) => `<li class="${r[1] ? 'p' : 'm'}">${esc(c.label)}: ${esc(r[0])}</li>`)).join('')}</ul></details>
      <div class="note">Skor setup menilai kualitas kondisi teknikal & fundamental. Ini bukan probabilitas profit.</div></div>`;
  }
  function drawSection() {
    if (liteStock()) return drawLiteSummary();
    const box = $('#sec'); if (!box) return; const s = sp.data, f = s.f, Fx = sp.F, g = Fx.f, stc = Fx.st; const tfl = D.TF[sp.tf]; let h = '';
    const px = sp.isIndex ? (x) => num(x, 2) : A.fmt;
    if (sp.isIndex && !['tech', 'struct'].includes(sp.sec)) { box.innerHTML = indexSection(sp.sec, s); bindIndexSection(s); return; }
    if (['peers', 'own', 'flow', 'range'].includes(sp.sec)) {
      box.innerHTML = { peers: secPeers, own: secOwn, flow: secFlow, range: secRange }[sp.sec](s);
      if (sp.sec === 'own') chartOwn(s); if (sp.sec === 'flow') chartFlow(s);
      box.querySelectorAll('[data-ps]').forEach((th) => (th.onclick = (e) => { e.stopPropagation(); pe.sort = th.dataset.ps; drawSection(); }));
      box.querySelectorAll('[data-msnet]').forEach((b) => (b.onclick = (e) => { e.stopPropagation(); const [kind, ...rest] = b.dataset.msnet.split(':'); closeStock(); openMS('net', { netKind: kind, netCenter: rest.join(':') }); }));
      return;
    }
    switch (sp.sec) {
      case 'sum': h = `${(() => { const pos = P.list().find((x) => x.sym === s.sym); if (!pos) return ''; const a = P.assess(s, pos); return `<div class="card pos"><div class="rowx"><span class="sm mut">Posisimu</span><span class="act ${toneCls[a.tone]}">${a.action}</span><span class="sp"></span>${a.pl ? `<b class="${a.pl.pct >= 0 ? 'up' : 'dn'}">${a.pl.pct >= 0 ? '+' : ''}${num(a.pl.pct, 2)}%</b>` : ''}</div><div class="sm" style="margin-top:6px">${esc(a.why)} · stop pengaman <b>${px(a.stop)}</b> · target <b>${px(a.target)}</b></div></div>`; })()}<div class="card ai">${esc(A.summary(s.sym, s.F, s.plan, s.bandar, s.fund))}</div><h2>Anatomi skor</h2>${scoreAnatomy(s.scoreObj)}<h2>Rencana trading (harian)</h2>${planCard(s)}`; break;
      case 'tech': h = `<div class="note">Timeframe: ${tfl}</div><div class="card">${tbl([
        ['EMA 20 / 50 / 200', `${px(g.ema20)} · ${px(g.ema50)} · ${px(g.ema200)}`], ['Susunan EMA', g.emaStackBull ? '<span class="up">Bertingkat naik</span>' : g.emaStackBear ? '<span class="dn">Bertingkat turun</span>' : 'Campuran'],
        ['SMA 50 / 150 / 200', `${px(g.sma50)} · ${px(g.sma150)} · ${px(g.sma200)}`], ['RSI 14', `${num(g.rsi, 1)} ${g.rsiRising ? '↑' : '↓'}`], ['MACD / signal / hist', `${num(g.macd, 1)} / ${num(g.macdSignal, 1)} / ${num(g.macdHist, 1)}`],
        ['MACD cross (3 bar)', g.macdCrossUp ? '<span class="up">Golden cross</span>' : g.macdCrossDown ? '<span class="dn">Death cross</span>' : '—'], ['ADX · +DI>−DI', `${num(g.adx, 1)} · ${yn(g.diBull)}`],
        ['Stochastic %K / %D', `${num(g.stochK, 1)} / ${num(g.stochD, 1)}`], ['Bollinger %B · lebar', `${num(g.pctB, 2)} · ${num(g.bbWidth, 1)}% (persentil ${num(g.bbWidthPctl, 0)})`], ['ATR 14', `${px(g.atr)} (${num(g.atrPct, 1)}%)`],
        ['VWAP', `${px(g.vwap)} ${g.aboveVwap ? '<span class="up">di atas</span>' : '<span class="dn">di bawah</span>'}`], ['Anchored VWAP (swing low)', ok(g.avwap) ? `${px(g.avwap)} ${g.aboveAvwap ? '<span class="up">di atas</span>' : '<span class="dn">di bawah</span>'}` : '—'],
        ['MFI 14 · CMF 20', `${num(g.mfi, 0)} · ${num(g.cmf, 2)}`], ['Divergence RSI', g.rsiDivBull ? '<span class="up">Bullish</span>' : g.rsiDivBear ? '<span class="dn">Bearish</span>' : 'Tidak ada'],
        ['Divergence MACD', g.macdDivBull ? '<span class="up">Bullish</span>' : g.macdDivBear ? '<span class="dn">Bearish</span>' : 'Tidak ada'], ['Divergence harga–OBV', g.pvDivBull ? '<span class="up">Bullish</span>' : g.pvDivBear ? '<span class="dn">Bearish</span>' : 'Tidak ada'],
        sp.tf === 'D' && ['Performa 1M / 1B / 3B', `${pct(f.perf1w, 1)} ${pct(f.perf1m, 1)} ${pct(f.perf3m, 1)}`], sp.tf === 'D' && ['Performa 6B / 1T', `${pct(f.perf6m, 1)} ${pct(f.perf1y, 1)}`],
        sp.tf === 'D' && ['RS Rating · vs IHSG 3B', `${ok(f.rsRating) ? f.rsRating : '—'} · ${pct(f.rsIhsg3m, 1)}`], sp.tf === 'D' && ['RS vs sektor 3B', pct(f.rsSector3m, 1)],
        sp.tf === 'D' && ['Range 52 minggu', `${px(f.lo52)} – ${px(f.hi52)} (${num(f.dist52wHigh, 1)}% di bawah high)`]])}</div>`; break;
      case 'struct': { const pv = stc.piv.filter((p) => p.conf <= sp.cd.c.length - 1).slice(-6).reverse(); const evs = stc.ev.slice(-5).reverse();
        h = `<div class="note">Timeframe: ${tfl}</div><div class="card">${tbl([['Struktur', esc(stc.sw.label)], ['Swing terakhir', pv.map((p) => `<span class="${p.label === 'HH' || p.label === 'HL' ? 'up' : p.label === 'LH' || p.label === 'LL' ? 'dn' : 'mut'}">${p.label}</span> ${px(p.price)}`).join('<br>') || '—'],
          ['BOS / CHoCH terakhir', evs.map((e) => `${e.type} ${e.dir > 0 ? '<span class="up">bullish</span>' : '<span class="dn">bearish</span>'} ${px(e.level)} <span class="mut">(${sp.cd.c.length - 1 - e.i} bar lalu)</span>`).join('<br>') || '—'],
          ['Support', stc.levels.supports.slice(0, 3).map((x) => `${px(x.price)} <span class="mut">(${x.touches}x)</span>`).join('<br>') || '—'], ['Resistance', stc.levels.resistances.slice(0, 3).map((x) => `${px(x.price)} <span class="mut">(${x.touches}x)</span>`).join('<br>') || '—'],
          ['Breakout / retest', stc.brk ? `Breakout ${px(stc.brk.level)} (RVOL ${num(stc.brk.rvol, 1)}x)` : stc.rt ? `Retest ${px(stc.rt.level)} bertahan` : '—'],
          ['Konsolidasi · kompresi · base', `${yn(g.consolidation)} · ${yn(g.compression)} · ${yn(g.baseFormation)}`], ['Range expansion', yn(g.rangeExpansion)],
          ['Equal highs / lows', `${stc.eqH ? px(stc.eqH.price) : '—'} / ${stc.eqL ? px(stc.eqL.price) : '—'}`], ['Liquidity sweep terakhir', (() => { const w = stc.sweeps[stc.sweeps.length - 1]; return w ? `${w.dir > 0 ? 'Bawah' : 'Atas'} ${px(w.level)} <span class="mut">(${sp.cd.c.length - 1 - w.i} bar lalu)</span>` : '—'; })()],
          ['Stop hunt (sweep + volume)', yn(g.stopHunt)], ['Premium / discount', ok(g.pdPos) ? `${g.pdPos > 0.5 ? 'Premium' : 'Discount'} (${num(g.pdPos * 100, 0)}% dari dealing range)` : '—']])}</div>`; break; }
      case 'smc': { const L = sp.cd.c.length - 1; const fv = stc.fvg.filter((x) => x.status !== 'filled' && x.i > L - 120).slice(-6).reverse(); const obs = stc.obs.slice(-5).reverse(); const b = s.bandar;
        h = `<div class="note">Timeframe: ${tfl}</div><h2>Fair value gap</h2><div class="card">${fv.length ? tbl(fv.map((x) => [`${x.dir > 0 ? '<span class="up">Bullish</span>' : '<span class="dn">Bearish</span>'} <span class="mut">${L - x.i} bar lalu</span>`, `${px(x.lo)}–${px(x.hi)} · ${x.status === 'open' ? 'terbuka' : 'termitigasi sebagian'}`])) : '<span class="mut">Tidak ada FVG aktif.</span>'}</div>
          <h2>Order block & breaker</h2><div class="card">${obs.length ? tbl(obs.map((x) => [`${x.dir > 0 ? '<span class="up">OB bullish</span>' : '<span class="dn">OB bearish</span>'} <span class="mut">${L - x.i} bar lalu</span>`, `${px(x.lo)}–${px(x.hi)} · ${x.status === 'fresh' ? 'belum disentuh' : x.status === 'mitigated' ? 'sudah dimitigasi' : 'jadi breaker'}`])) : '<span class="mut">Tidak ada order block terdeteksi.</span>'}
          ${tbl([['Displacement naik / turun (3 bar)', `${yn(g.displacementBull)} / ${yn(g.displacementBear, false)}`], ['BOS + FVG bullish', yn(g.bosFvg)], ['Sweep + reversal', yn(g.sweepReversal)]])}</div>
          <h2>Foreign flow</h2><div class="card">${s.ff ? tbl([['Net 1 hari', A.fmtRp(s.ff.net1d)], ['Net 5 hari', A.fmtRp(s.ff.net5d)], ['Hari beruntun net buy', s.ff.streak]]) : `<span class="mut">${esc(D.ffState.note)}</span>`}<div class="note">Status: ${esc(D.STATUS[D.ffState.status])}. ${esc(D.ffState.status !== 'unavailable' ? D.ffState.note : '')}</div></div>
          <h2>Bandar radar (harian)</h2><div class="card"><div class="rowx"><b>${esc(b.label)}</b><span class="sp"></span><span class="chip">Kepercayaan ${b.confLabel}</span></div>
          <div class="comp" style="margin:8px 0"><span>Akumulasi</span><div class="bar"><i style="width:${b.acc}%;background:var(--up)"></i></div><span>${b.acc}</span><span>Distribusi</span><div class="bar"><i style="width:${b.dis}%;background:var(--dn)"></i></div><span>${b.dis}</span></div>
          ${b.evidence.filter((e) => e.side !== 0 || !e.available).map((e) => `<div class="evid ${!e.available ? 'na' : e.present ? 'on ' + (e.side > 0 ? 'acc' : 'dis') : ''}"><i></i><span>${esc(e.txt)}${!e.available ? ' — tidak tersedia' : e.present ? '' : ' <span class="mut">(tidak terpenuhi)</span>'}</span></div>`).join('')}</div>`; break; }
      case 'vol': { const vp = stc.vp; const mx = vp ? Math.max(...vp.bins.map((x) => x.vol)) : 1;
        h = `<div class="note">Timeframe: ${tfl}</div><div class="card">${tbl([['Volume terakhir', num(g.volume, 0)], ['Relative volume', `${num(g.rvol, 2)}x`], ['Tren volume (avg5/avg20)', `${num(g.volTrend, 2)}x ${g.volContraction ? '<span class="mut">(menyusut)</span>' : ''}`],
          ['Up / down volume (20)', `${num(g.upDownVol, 2)}x`], ['OBV', `${g.obvRising ? '<span class="up">menanjak</span>' : '<span class="dn">melemah</span>'}${g.obvNewHigh ? ' · new high' : ''}`], ['A/D line', g.adRising ? '<span class="up">naik</span>' : '<span class="dn">turun</span>'],
          ['CMF 20 · MFI 14', `${num(g.cmf, 2)} · ${num(g.mfi, 0)}`], ['Nilai transaksi', `${A.fmtRp(g.value)} (rata-rata ${A.fmtRp(g.avgValue20)})`], vp && ['POC · VAH · VAL', `${px(vp.poc)} · ${px(vp.vah)} · ${px(vp.val)}`]])}</div>
          ${vp ? `<h2>Volume profile</h2><div class="card">${vp.bins.slice().reverse().filter((_, i) => i % 2 === 0).map((x) => `<div class="comp" style="grid-template-columns:64px 1fr"><span class="mut">${px(x.price)}</span><div class="bar"><i style="width:${(x.vol / mx) * 100}%;background:${Math.abs(x.price - vp.poc) < (vp.vah - vp.val) / 15 ? 'var(--gold)' : x.price <= vp.vah && x.price >= vp.val ? '#3d6a9c' : 'var(--s3)'}"></i></div></div>`).join('')}<div class="note">Emas = POC, biru = value area 70%.</div></div>` : ''}`; break; }
      case 'fund': { const fu = s.fund;
        h = fu ? `<div class="card">${tbl([['Pertumbuhan pendapatan (YoY)', pct(fu.revGrowth, 1)], ['Pertumbuhan laba (YoY)', pct(fu.epsGrowth, 1)], ['Pertumbuhan laba kuartalan', pct(fu.epsQGrowth, 1)], ['Akselerasi laba', fu.earningsAccel === undefined ? '—' : yn(fu.earningsAccel)],
          ['ROE · ROA', `${num(fu.roe, 1)}% · ${num(fu.roa, 1)}%`], ['ROIC (estimasi)', ok(fu.roic) ? num(fu.roic, 1) + '%' : '—'], ['Gross · operating · net margin', `${num(fu.grossMargin, 1)}% · ${num(fu.opMargin, 1)}% · ${num(fu.netMargin, 1)}%`],
          ['Debt to equity', ok(fu.der) ? num(fu.der, 0) + '%' : '—'], ['Current ratio', num(fu.currentRatio, 2)], ['Arus kas operasi', A.fmtRp(fu.ocf)], ['Free cash flow', A.fmtRp(fu.fcf)], ['FCF yield', ok(fu.fcfYield) ? num(fu.fcfYield, 1) + '%' : '—'],
          ['Skor kualitas', ok(f.qualityScore) ? `<b>${f.qualityScore}</b>/100` : '—']])}
          <div class="note">Sumber: ${esc(fu.source)} (${esc(D.STATUS[fu.status])}, laporan terakhir)${fu.currency && fu.currency !== 'IDR' ? `. Laporan dalam ${fu.currency}, nilai Rp dikonversi kurs terkini` : ''}. Rasio bank (DER, FCF) tidak dipakai dalam skor kualitas.</div></div>
          ${fu.quarterly ? `<h2>Laba kuartalan</h2><div class="card">${tbl(fu.quarterly.map((q) => [esc(q.d), `${A.fmtRp(q.earn)} <span class="mut">/ pendapatan ${A.fmtRp(q.rev)}</span>`]))}</div>` : ''}`
          : s.fundErr ? emptyState('Data fundamental tidak tersedia', esc(s.fundErr) + '. Saham baru, saham kecil, atau sumber sedang membatasi akses.') : skel(2); break; }
      case 'val': { const fu = s.fund; const sec = E.snap && E.snap.sectors.find((x) => x.name === s.sector);
        h = fu ? `<div class="card">${tbl([['P/E', ok(fu.pe) ? num(fu.pe, 1) + 'x' : '—'], ['P/B', ok(fu.pb) ? num(fu.pb, 2) + 'x' : '—'], ['EV/EBITDA', ok(fu.evEbitda) ? num(fu.evEbitda, 1) + 'x' : '—'], ['Dividend yield', ok(fu.divYield) ? num(fu.divYield, 2) + '%' : '—'],
          ['Kapitalisasi pasar', A.fmtRp(fu.marketCap)], ['P/E vs median sektor', ok(f.peVsSector) ? `${num(f.peVsSector, 2)}x <span class="mut">(median ${num(sec && sec.medPe, 1)}x)</span>` : '<span class="mut">butuh data fundamental sektor — jalankan preset fundamental</span>'],
          ['P/B vs median sektor', ok(f.pbVsSector) ? `${num(f.pbVsSector, 2)}x <span class="mut">(median ${num(sec && sec.medPb, 2)}x)</span>` : '—'], ['Valuasi vs rata-rata historis', '<span class="mut">Tidak tersedia dari sumber gratis</span>']])}</div>`
          : s.fundErr ? emptyState('Data valuasi tidak tersedia', esc(s.fundErr)) : skel(2); break; }
      case 'news': {
        if (!sp.stories && !sp.storiesErr) { h = skel(3); const sym = s.sym; N.forSymbol(sym).then((x) => { if (sp.sym === sym) { sp.stories = x; if (sp.sec === 'news') drawSection(); } }).catch((e) => { if (sp.sym === sym) { sp.storiesErr = e.message; if (sp.sec === 'news') drawSection(); } }); break; }
        if (sp.storiesErr) { h = `<div class="empty"><b>Berita tidak tersedia</b>${esc(sp.storiesErr)}</div>`; break; }
        h = sp.stories.length ? sp.stories.map((x) => storyCard(x)).join('') + '<div class="note">Label kesadaran pasar: jumlah sumber, umur berita, dan reaksi harga/volume sejak berita terbit.</div>' : '<div class="empty"><b>Tidak ada berita 7 hari terakhir</b></div>'; break; }
      case 'newsOld': { const nw = s.news;
        h = !nw ? '<div class="empty"><b>Memuat berita…</b></div>' : nw.items && nw.items.length ? `<div class="list">${nw.items.map((x) => `<a data-ext href="${esc(x.link)}" class="row" style="text-decoration:none;color:inherit;grid-template-columns:10px 1fr"><span style="width:8px;height:8px;border-radius:50%;background:${x.s > 0 ? 'var(--up)' : x.s < 0 ? 'var(--dn)' : 'var(--s3)'}"></span><span>${esc(x.title)}<div class="sm mut">${esc(x.src || '')} · ${x.date ? new Date(x.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }) : ''}</div></span></a>`).join('')}</div><div class="note">Sumber: Google News. Titik warna = sentimen kata kunci judul (kasar, bukan analisis isi).</div>`
          : `<div class="empty"><b>Tidak ada berita</b>${esc(nw.err || (D.settings.provider === 'demo' ? 'Berita tidak tersedia di mode simulasi.' : 'Belum ada berita terbaru untuk saham ini.'))}</div>`; break; }
      case 'risk': { const cd = s.cd; let peak = -Infinity, mdd = 0; for (let i = Math.max(0, cd.c.length - 250); i < cd.c.length; i++) { peak = Math.max(peak, cd.c[i]); mdd = Math.min(mdd, (cd.c[i] - peak) / peak); }
        h = `<div class="card">${tbl([['Volatilitas (ATR harian)', `${num(f.atrPct, 2)}%`], ['Beta', ok(f.beta) ? num(f.beta, 2) : '—'], ['Max drawdown 1 tahun', pct(mdd * 100, 1)], ['Jarak ke invalidasi', s.plan.bias > 0 ? `${num(s.plan.riskPct, 1)}%` : '—'],
          ['Likuiditas', `${A.fmtRp(f.avgValue20)}/hari ${f.avgValue20 < 1e9 ? '<span class="dn">(tipis)</span>' : ''}`], ['Posisi di range 52 mgg', ok(f.hi52) ? `${num(((f.close - f.lo52) / (f.hi52 - f.lo52)) * 100, 0)}%` : '—'], ['Bukti distribusi', `${s.bandar.dis}/100`]])}</div>
          ${s.goreng ? `<h2>Risiko saham gorengan</h2><div class="card"><div class="rowx"><b class="${s.goreng.level === 'Tinggi' ? 'dn' : s.goreng.level === 'Sedang' ? 'gold' : 'up'}">${s.goreng.level}</b><span class="sp"></span><span class="sm mut">skor ${s.goreng.score}/100</span></div>${s.goreng.flags.length ? `<ul class="why">${s.goreng.flags.map((x) => `<li class="m">${esc(x)}</li>`).join('')}</ul>` : '<div class="sm mut" style="margin-top:4px">Tidak ada ciri saham gorengan yang terdeteksi.</div>'}<div class="note">Dinilai dari lonjakan harga, ARA beruntun, volume tidak wajar pada saham sepi, free float, kapitalisasi, papan pemantauan, fundamental, dan berita UMA/suspensi. Saham berisiko tinggi tidak pernah lolos syarat ketat AI Picks.</div></div>` : ''}
          ${GR.ofStock(s.sym).length ? `<div class="note">Bagian dari grup: ${GR.ofStock(s.sym).map(esc).join(', ')}</div>` : ''}
          <h2>Sensitivitas makro</h2><div class="card">${(() => { const sv = M.sensitivity(s); return sv.length ? tbl(sv.map((x) => [esc(x.name), `korelasi ${x.r.toFixed(2)}${x.lag ? ' (H+1)' : ''} · beta ${num(x.beta, 2)}`])) + '<div class="note">Korelasi return harian 6 bulan terhadap komoditas/makro. Beta 0,5 = saham cenderung bergerak 0,5% saat instrumen bergerak 1%.</div>' : `<span class="mut">${M.data ? 'Tidak ada hubungan yang terukur.' : 'Data makro belum dimuat (buka tab Pasar).'}</span>`; })()}</div>
          <h2>Yang bisa membatalkan setup</h2><div class="card"><ul class="why">${A.invalidators(f, s.plan, s.ff).map((r) => `<li class="m">${esc(r)}</li>`).join('')}</ul></div>`; break; }
    }
    box.innerHTML = h; if (sp.sec === 'sum') loadStockEvidence();
  }

  // ---------------- IHSG ANALYSIS (index page) ----------------
  const ix = { movers: null, moversBusy: false, d5: null, d5Busy: false, mvPeriod: 'p1d' };
  const n2 = (x) => num(x, 2);
  const dkey = (t) => Math.floor((t + 25200) / 86400);
  function breadthSeries(days = 80) {
    const snap = E.snap; if (!snap) return null; const ih = snap.ihsg.cd; const keys = ih.t.slice(-days).map(dkey); const pos = new Map(keys.map((k, i) => [k, i]));
    const z = () => new Array(keys.length).fill(0); const a50 = z(), a20 = z(), tot = z(), adv = z(), dec = z(), nh = z(), nl = z();
    for (const st of snap.stocks.values()) { const cd = st.cd, c = cd.c; const e50 = I.ema(c, 50), e20 = I.ema(c, 20);
      for (let i = Math.max(251, c.length - days - 5); i < c.length; i++) { const k = pos.get(dkey(cd.t[i])); if (k === undefined) continue; tot[k]++; if (c[i] > e50[i]) a50[k]++; if (c[i] > e20[i]) a20[k]++; if (c[i] > c[i - 1]) adv[k]++; else if (c[i] < c[i - 1]) dec[k]++;
        let hi = -Infinity, lo = Infinity; for (let j = i - 250; j < i; j++) { if (cd.h[j] > hi) hi = cd.h[j]; if (cd.l[j] < lo) lo = cd.l[j]; } if (cd.h[i] > hi) nh[k]++; if (cd.l[i] < lo) nl[k]++; } }
    const ad = []; let cum = 0; const ratio = keys.map((_, i) => (adv[i] + dec[i] ? ((adv[i] - dec[i]) / (adv[i] + dec[i])) * 1000 : 0));
    keys.forEach((_, i) => { cum += adv[i] - dec[i]; ad.push(cum); }); const e19 = I.ema(ratio, 19), e39 = I.ema(ratio, 39);
    return { t: ih.t.slice(-days), close: ih.c.slice(-days), p50: a50.map((x, i) => (tot[i] ? (x / tot[i]) * 100 : NaN)), p20: a20.map((x, i) => (tot[i] ? (x / tot[i]) * 100 : NaN)), adv, dec, ad, nh, nl, mco: e19.map((x, i) => x - e39[i]) };
  }
  function indexSection(sec, s) {
    const f = s.f, stc = s.F.st, ih = s.cd, L = ih.c.length - 1; const px = n2;
    const perf = (k) => (L >= k ? ((ih.c[L] - ih.c[L - k]) / ih.c[L - k]) * 100 : NaN);
    const y0 = ih.t.findIndex((t) => new Date((t + 25200) * 1000).getUTCFullYear() === new Date((ih.t[L] + 25200) * 1000).getUTCFullYear()); const ytd = y0 > 0 ? ((ih.c[L] - ih.c[y0 - 1]) / ih.c[y0 - 1]) * 100 : NaN;
    switch (sec) {
      case 'isum': {
        const S = stc.levels.supports, Rr = stc.levels.resistances; const ev = stc.ev[stc.ev.length - 1]; const b = breadthSeries(30); const bl = b ? b.p50.length - 1 : -1; const r = M.regime;
        const trend = f.hhhl ? 'dalam uptrend (higher high & higher low)' : f.lhll ? 'dalam downtrend (lower high & lower low)' : 'bergerak sideways/transisi';
        const ema = `${f.close > f.ema20 ? 'di atas' : 'di bawah'} EMA 20, ${f.close > f.ema50 ? 'di atas' : 'di bawah'} EMA 50, dan ${f.close > f.ema200 ? 'di atas' : 'di bawah'} EMA 200`;
        const lines = [`IHSG ${trend}, posisi ${ema}.`];
        if (ev && L - ev.i <= 15) lines.push(`${ev.type} ${ev.dir > 0 ? 'bullish' : 'bearish'} terjadi ${L - ev.i} sesi lalu di ${px(ev.level)}.`);
        lines.push(`RSI ${num(f.rsi, 0)}${f.rsi < 30 ? ' (jenuh jual)' : f.rsi > 70 ? ' (jenuh beli)' : ''}, volatilitas harian rata-rata ${num(f.atrPct, 2)}%.`);
        if (b) lines.push(`Breadth: ${num(b.p50[bl], 0)}% saham di atas EMA 50; ${b.adv[bl]} naik vs ${b.dec[bl]} turun di sesi terakhir.`);
        if (f.rsiDivBull || f.macdDivBull) lines.push('Ada bullish divergence — tekanan jual mulai melemah.'); if (f.rsiDivBear || f.macdDivBear) lines.push('Ada bearish divergence — momentum naik melemah.');
        const s1 = S[0], s2 = S[1], r1 = Rr[0], r2 = Rr[1]; const d = (x) => (x ? `${(((x.price - f.close) / f.close) * 100 >= 0 ? '+' : '')}${num(((x.price - f.close) / f.close) * 100, 1)}%` : '');
        return `<div class="card ai">${esc(lines.join(' '))}</div>
          <h2>Skenario & level kunci</h2><div class="card"><table class="t">
            <tr><td><span class="up">Bullish</span></td><td>${r1 ? `Close di atas <b>${px(r1.price)}</b> (${d(r1)}) membuka jalan ke ${r2 ? px(r2.price) + ' (' + d(r2) + ')' : 'high berikutnya'}` : 'Tidak ada resistance dekat — di area high'}</td></tr>
            <tr><td><span class="dn">Bearish</span></td><td>${s1 ? `Tembus <b>${px(s1.price)}</b> (${d(s1)}) membuka risiko ke ${s2 ? px(s2.price) + ' (' + d(s2) + ')' : 'low berikutnya'}` : 'Tidak ada support dekat'}</td></tr>
            <tr><td><span class="gold">Netral</span></td><td>${s1 && r1 ? `Bergerak di rentang ${px(s1.price)}–${px(r1.price)} selama keduanya bertahan` : '—'}</td></tr></table>
            <div class="note">Level dari kluster swing high/low. Skenario adalah peta kemungkinan, bukan prediksi.</div></div>
          ${regimeCard()}
          <h2>Kinerja</h2><div class="card"><div class="kv">${[['1 mgg', perf(5)], ['1 bln', perf(21)], ['3 bln', perf(63)], ['YTD', ytd], ['1 thn', perf(250)], ['Dari high 52 mgg', -f.dist52wHigh]].map(([l, v]) => `<div><b>${pct(v, 1)}</b><span>${l}</span></div>`).join('')}</div></div>`;
      }
      case 'breadth': {
        const b = breadthSeries(80); if (!b) return '<div class="empty"><b>Data belum dimuat</b></div>'; const i = b.p50.length - 1;
        const hi20 = Math.max(...b.close.slice(-20)), adHi = Math.max(...b.ad.slice(-20)); const div = b.close[i] >= hi20 * 0.995 && b.ad[i] < adHi * 0.98 ? 'IHSG dekat high 20 hari tetapi A/D line tidak ikut — kenaikan ditopang sedikit saham (biasanya big cap). Waspadai pelemahan.' : b.close[i] <= Math.min(...b.close.slice(-20)) * 1.005 && b.ad[i] > Math.min(...b.ad.slice(-20)) * 1.02 ? 'IHSG dekat low 20 hari tetapi A/D line tidak ikut turun — tekanan jual mulai menyempit (potensi pembalikan).' : 'Tidak ada divergence breadth yang menonjol.';
        const mco = b.mco[i];
        return `<div class="card"><div class="kv"><div><b>${num(b.p50[i], 0)}%</b><span>di atas EMA 50</span></div><div><b>${num(b.p20[i], 0)}%</b><span>di atas EMA 20</span></div><div><b><span class="up">${b.adv[i]}</span>/<span class="dn">${b.dec[i]}</span></b><span>naik / turun</span></div><div><b><span class="up">${b.nh[i]}</span>/<span class="dn">${b.nl[i]}</span></b><span>new high / low</span></div><div><b class="${mco >= 0 ? 'up' : 'dn'}">${num(mco, 0)}</b><span>McClellan osc.</span></div><div><b>${b.p50[i] < 20 ? 'Ekstrem' : b.p50[i] > 80 ? 'Jenuh' : 'Normal'}</b><span>${b.p50[i] < 20 ? 'jenuh jual luas' : b.p50[i] > 80 ? 'jenuh beli luas' : 'partisipasi'}</span></div></div>
          <div class="note">${esc(div)} McClellan ${mco > 0 ? 'positif: momentum partisipasi naik' : 'negatif: lebih banyak saham melemah'}. Di bawah 20% saham di atas EMA 50 historisnya sering dekat dasar jangka pendek.</div></div>
          <h2>% saham di atas EMA 50 / EMA 20</h2><div class="card"><div id="ixB1" style="height:170px"></div></div>
          <h2>A/D line vs IHSG</h2><div class="card"><div id="ixB2" style="height:170px"></div><div class="note">Emas = IHSG (kiri), biru = kumulatif saham naik dikurangi turun (kanan). Dihitung dari ${E.snap.stocks.size} saham dalam daftar pantau.</div></div>`;
      }
      case 'movers': {
        if (!ix.movers) return `<div class="empty"><b>${ix.moversBusy ? 'Menghitung bobot kapitalisasi…' : 'Menyiapkan'}</b>Mengambil kapitalisasi pasar 50 saham terbesar (sekali sehari).</div>`;
        const per = ix.mvPeriod; const key = { p1d: 'perf1d', p1w: 'perf1w', p1m: 'perf1m' }[per]; const ihChg = { p1d: perf(1), p1w: perf(5), p1m: perf(21) }[per]; const k = { p1d: 1, p1w: 5, p1m: 21 }[per]; const base = ih.c[L - k];
        const rows = ix.movers.map((m) => Object.assign({}, m, { pts: base * m.w * 0.8 * ((m.st.f[key] || 0) / 100) })); const pos = rows.filter((r) => r.pts > 0).sort((a, b) => b.pts - a.pts).slice(0, 8), neg = rows.filter((r) => r.pts < 0).sort((a, b) => a.pts - b.pts).slice(0, 8);
        const mx = Math.max(...rows.map((r) => Math.abs(r.pts)), 0.01); const bySec = {}; rows.forEach((r) => (bySec[r.st.sector] = (bySec[r.st.sector] || 0) + r.pts));
        const line = (r) => `<button class="secrow mv" data-sym="${r.st.sym}"><span><b>${r.st.sym}</b> <span class="mut sm">${num(r.w * 100, 1)}%</span></span><div class="bar"><i style="width:${(Math.abs(r.pts) / mx) * 100}%;background:${r.pts > 0 ? 'var(--up)' : 'var(--dn)'}"></i></div><span class="${r.pts > 0 ? 'up' : 'dn'}">${r.pts > 0 ? '+' : ''}${num(r.pts, 1)}</span><span>${pct(r.st.f[key], 1)}</span></button>`;
        return `<div class="seg" id="mvSeg">${[['p1d', 'Hari ini'], ['p1w', '1 minggu'], ['p1m', '1 bulan']].map(([k2, l]) => `<button data-mv="${k2}" class="${k2 === per ? 'on' : ''}">${l}</button>`).join('')}</div>
          <div class="note">IHSG ${pct(ihChg, 2)} (${ihChg >= 0 ? '+' : ''}${num((ih.c[L] - base), 1)} poin). Kolom: bobot · kontribusi poin (perkiraan) · perubahan saham.</div>
          <h2>Pendorong</h2><div class="card">${pos.map(line).join('') || '<span class="mut">—</span>'}</div>
          <h2>Penekan</h2><div class="card">${neg.map(line).join('') || '<span class="mut">—</span>'}</div>
          <h2>Per sektor</h2><div class="card"><table class="t">${Object.entries(bySec).sort((a, b) => b[1] - a[1]).map(([k2, v]) => `<tr><td>${esc(k2)}</td><td class="${v >= 0 ? 'up' : 'dn'}">${v >= 0 ? '+' : ''}${num(v, 1)} poin</td></tr>`).join('')}</table>
          <div class="note">Perkiraan: bobot = kapitalisasi pasar saham / total 50 saham terbesar × 80% (porsi perkiraan mereka di IHSG). Bukan angka resmi BEI.</div></div>`;
      }
      case 'stats': {
        if (!ix.d5) return `<div class="empty"><b>${ix.d5Busy ? 'Mengunduh riwayat 5 tahun…' : 'Menyiapkan'}</b></div>`;
        const cd = ix.d5; const n = cd.c.length; const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des']; const DOW = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
        const mon = {}; let prevKey = null, startC = null, lastC = null; const dt = (t) => new Date((t + 25200) * 1000);
        for (let i = 0; i < n; i++) { const d = dt(cd.t[i]); const k = d.getUTCFullYear() * 12 + d.getUTCMonth(); if (k !== prevKey) { if (prevKey !== null && startC) (mon[prevKey % 12] = mon[prevKey % 12] || []).push((lastC - startC) / startC); startC = i > 0 ? cd.c[i - 1] : cd.o[i]; prevKey = k; } lastC = cd.c[i]; }
        const curM = dt(cd.t[n - 1]).getUTCMonth(); const dow = {}; for (let i = 1; i < n; i++) (dow[dt(cd.t[i]).getUTCDay()] = dow[dt(cd.t[i]).getUTCDay()] || []).push((cd.c[i] - cd.c[i - 1]) / cd.c[i - 1]);
        const avg = (a) => a.reduce((x, y) => x + y, 0) / a.length; const winp = (a) => a.filter((x) => x > 0).length / a.length;
        const rets = []; for (let i = 1; i < n; i++) rets.push(Math.log(cd.c[i] / cd.c[i - 1])); const vol = (i) => { const w = rets.slice(i - 20, i); const m = avg(w); return Math.sqrt(avg(w.map((x) => (x - m) ** 2)) * 252) * 100; };
        const vols = []; for (let i = 20; i <= rets.length; i++) vols.push(vol(i)); const vNow = vols[vols.length - 1]; const vPct = I.percentile(vols, vNow);
        const todayChg = (cd.c[n - 1] - cd.c[n - 2]) / cd.c[n - 2]; const lo = todayChg <= -0.015, hiD = todayChg >= 0.015; const cond = []; for (let i = 1; i < n - 5; i++) { const c0 = (cd.c[i] - cd.c[i - 1]) / cd.c[i - 1]; if (lo ? c0 <= -0.015 : hiD ? c0 >= 0.015 : Math.abs(c0) < 0.005) cond.push((cd.c[i + 5] - cd.c[i]) / cd.c[i]); }
        let peak = -Infinity, ddNow = 0; for (const c of cd.c) peak = Math.max(peak, c); ddNow = (cd.c[n - 1] - peak) / peak;
        const mrow = (m) => { const a = mon[m] || []; return a.length ? `<tr class="${m === curM ? 'hl' : ''}"><td>${MON[m]}${m === curM ? ' (bulan ini)' : ''}</td><td><span class="${avg(a) >= 0 ? 'up' : 'dn'}">${avg(a) >= 0 ? '+' : ''}${num(avg(a) * 100, 1)}%</span> · naik ${num(winp(a) * 100, 0)}% · ${a.length} thn</td></tr>` : ''; };
        return `<h2>Pola musiman (5 tahun)</h2><div class="card"><table class="t">${[...Array(12).keys()].map(mrow).join('')}</table><div class="note">Rata-rata return IHSG per bulan kalender dan persentase tahun yang naik. Sampel 5 tahun kecil — pakai sebagai konteks, bukan sinyal.</div></div>
          <h2>Hari perdagangan</h2><div class="card"><table class="t">${[1, 2, 3, 4, 5].map((d) => dow[d] ? `<tr><td>${DOW[d]}</td><td><span class="${avg(dow[d]) >= 0 ? 'up' : 'dn'}">${num(avg(dow[d]) * 100, 2)}%</span> · naik ${num(winp(dow[d]) * 100, 0)}%</td></tr>` : '').join('')}</table></div>
          <h2>Volatilitas & drawdown</h2><div class="card">${tbl([['Volatilitas 20 hari (tahunan)', `${num(vNow, 1)}% · persentil ${num(vPct, 0)} (5 thn)`], ['Jarak dari high 5 tahun', pct(ddNow * 100, 1)], [`Setelah hari seperti ini (${lo ? 'turun ≥1,5%' : hiD ? 'naik ≥1,5%' : 'datar <0,5%'})`, cond.length ? `5 hari berikutnya rata-rata ${pct(avg(cond) * 100, 2)} · naik ${num(winp(cond) * 100, 0)}% (${cond.length} kejadian)` : '—']])}</div>`;
      }
      case 'global': {
        if (!M.data) return `<div class="empty"><b>${M.loading ? 'Memuat data global…' : 'Data global belum dimuat'}</b></div>`;
        const sv = M.sensitivity(s); const keys = ['Y:^GSPC', 'Y:^HSI', 'Y:000001.SS', 'Y:EIDO', 'Y:IDR=X', 'Y:DX-Y.NYB', 'Y:^TNX', 'Y:^VIX', 'Y:BZ=F', 'Y:GC=F'];
        return `<h2>Korelasi dengan IHSG (6 bulan)</h2><div class="card">${tbl(sv.map((x) => [esc(x.name), `${x.r >= 0 ? '+' : ''}${x.r.toFixed(2)}${x.lag ? ' (H+1)' : ''} · beta ${num(x.beta, 2)}`]))}<div class="note">"(H+1)": IHSG bereaksi sehari setelahnya — mis. Wall Street tutup malam hari, IHSG merespons pagi berikutnya. Korelasi negatif USD/IDR berarti rupiah melemah biasanya bersamaan dengan IHSG turun.</div></div>
          <h2>Pasar global & makro</h2><div class="card">${tbl(keys.map((k2) => M.get(k2)).filter(Boolean).map((x) => [esc(x.name), `${num(x.last, x.last < 20 ? 3 : 2)} · ${pct(x.p1d, 2)} · 1B ${pct(x.p1m, 1)}`]))}</div>`;
      }
    }
    return '';
  }
  function bindIndexSection(s) {
    const box = $('#sec');
    if (sp.sec === 'breadth' && window.LightweightCharts) { const b = breadthSeries(80); if (!b) return; const T = b.t.map((t) => t + 25200);
      const opt = (h) => ({ localization: { locale: 'id-ID' }, height: h, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: COL.mut, fontFamily: 'IBM Plex Sans', fontSize: 11 }, grid: { vertLines: { visible: false }, horzLines: { color: COL.grid } }, rightPriceScale: { borderColor: COL.line }, leftPriceScale: { borderColor: COL.line }, timeScale: { borderColor: COL.line }, handleScroll: false, handleScale: false });
      const c1 = LightweightCharts.createChart($('#ixB1'), opt(170)); const l50 = c1.addLineSeries({ color: '#E9B949', lineWidth: 2, priceLineVisible: false }); const l20 = c1.addLineSeries({ color: '#5AA9FF', lineWidth: 1, priceLineVisible: false });
      l50.setData(T.map((t, i) => ({ time: t, value: b.p50[i] })).filter((x) => ok(x.value))); l20.setData(T.map((t, i) => ({ time: t, value: b.p20[i] })).filter((x) => ok(x.value)));
      [20, 50, 80].forEach((v) => l50.createPriceLine({ price: v, color: 'rgba(142,160,181,.35)', lineWidth: 1, lineStyle: 2, axisLabelVisible: false })); c1.timeScale().fitContent();
      const c2 = LightweightCharts.createChart($('#ixB2'), Object.assign(opt(170), { leftPriceScale: { visible: true, borderColor: COL.line } })); const li = c2.addLineSeries({ color: '#E9B949', lineWidth: 2, priceScaleId: 'left', priceLineVisible: false, priceFormat: { type: 'custom', formatter: (p) => num(p, 0) } }); const la = c2.addLineSeries({ color: '#5AA9FF', lineWidth: 2, priceScaleId: 'right', priceLineVisible: false });
      li.setData(T.map((t, i) => ({ time: t, value: b.close[i] }))); la.setData(T.map((t, i) => ({ time: t, value: b.ad[i] }))); c2.timeScale().fitContent(); }
    if (sp.sec === 'movers') {
      const sg = $('#mvSeg'); if (sg) sg.onclick = (e) => { const b = e.target.closest('[data-mv]'); if (b) { ix.mvPeriod = b.dataset.mv; drawSection(); } };
      if (!ix.movers && !ix.moversBusy && E.snap) { ix.moversBusy = true; const top = [...E.snap.stocks.values()].sort((a, b) => b.f.avgValue20 - a.f.avgValue20).slice(0, 50);
        E.ensureFundamentals(top.map((x) => x.sym)).catch(() => {}).then(() => { const withCap = top.filter((x) => x.f.marketCap > 0); const tot = withCap.reduce((a, x) => a + x.f.marketCap, 0);
          ix.movers = withCap.map((x) => ({ st: x, w: x.f.marketCap / tot })); ix.moversBusy = false; if (sp.isIndex && sp.sec === 'movers') drawSection(); }); }
    }
    if (sp.sec === 'stats' && !ix.d5 && !ix.d5Busy) { ix.d5Busy = true; D.candles('^JKSE', 'D5').then((r) => { ix.d5 = r.cd; }).catch((e) => toast('Riwayat gagal dimuat: ' + e.message)).finally(() => { ix.d5Busy = false; if (sp.isIndex && sp.sec === 'stats') drawSection(); }); }
    if (sp.sec === 'global' && !M.data && !M.loading) M.load().then(() => { if (sp.isIndex && sp.sec === 'global') drawSection(); }).catch(() => {});
  }

  // ---------------- MARKET STRUCTURE ----------------
  const ms = { page: null, ffPer: 'n5', ownType: 'all', rrgWeekly: true, netCenter: null, netKind: 'stock', invQ: '', hl: null };
  const TITLES = { brd: 'Kesehatan pasar', rot: 'Rotasi sektor', ff: 'Asing vs domestik', own: 'Kepemilikan & inventory', net: 'Jaringan pemilik', brk: 'Aktivitas broker', heat: 'Heatmap pasar', grp: 'Grup & tema' };
  function openMS(page, opt) { Object.assign(ms, { page }, opt || {}); const el = $('#ms'); showLayer(el); el.scrollTop = 0; drawMS(); }
  function closeMS() { hideLayer($('#ms')); }
  const rp = (x) => A.fmtRp(x);
  function drawMS() {
    const el = $('#ms'); let body = '';
    try { body = { brd: msBrd, rot: msRot, ff: msFF, own: msOwn, net: msNet, brk: msBrk, heat: msHeat, grp: msGrp }[ms.page](); } catch (e) { body = `<div class="empty"><b>Gagal menampilkan</b>${esc(e.message)}</div>`; }
    el.innerHTML = `<div class="sh-h"><button class="icon" id="msBack" aria-label="Kembali">←</button><b style="font-family:var(--fd)">${TITLES[ms.page]}</b></div><div class="sh-b" id="msBody">${body}</div>`;
    $('#msBack').onclick = closeMS;
    el.onclick = (e) => {
      const g = e.target.closest('[data-go],[data-sym]'); if (g && !e.target.closest('[data-grsel],[data-grback]')) return openStock(g.dataset.go || g.dataset.sym);
      const p2 = e.target.closest('[data-p]'); if (p2) { const [k, v] = p2.dataset.p.split(':'); ms[k] = v === 'true' ? true : v === 'false' ? false : v; return drawMS(); }
      const n = e.target.closest('[data-net]'); if (n) { const [kind, ...rest] = n.dataset.net.split(':'); ms.page = 'net'; ms.netKind = kind; ms.netCenter = rest.join(':'); return drawMS(); }
      const hl = e.target.closest('[data-hl]'); if (hl) { ms.hl = ms.hl === hl.dataset.hl ? null : hl.dataset.hl; return drawMS(); }
      const rf = e.target.closest('[data-reload]'); if (rf) { const k = rf.dataset.reload; if (k === 'own') { O.load({ force: true, onProg: (m) => { const b = $('#msMsg'); if (b) b.textContent = m; } }).then(drawMS); } if (k === 'ff') { X.ff = null; drawMS(); } if (k === 'brk') { X.br = null; drawMS(); } return drawMS(); }
    };
    const fi = $('#ownFile'); if (fi) fi.onchange = async () => { const f = fi.files[0]; if (!f) return; toast('Membaca file…'); try { await O.importFile(f); toast('Data kepemilikan diimpor'); } catch (err) { toast(err.message); } drawMS(); };
    const q = $('#invQ'); if (q) { q.oninput = () => { ms.invQ = q.value; const box = $('#invRes'); if (box) box.innerHTML = invResults(); }; }
    msAfter();
  }
  // lazy loads + charts after render
  function msAfter() {
    if (ms.page === 'ff') { if (!X.ff && !X.ffBusy && !X.ffErr) X.loadForeign({ onProg: (a, b) => setProg(a / b) }).then(() => { setProg(null); if (ms.page === 'ff' && isOpen($('#ms'))) drawMS(); }); else if (X.ff) chartFF(); }
    if (ms.page === 'brk' && !X.br && !X.brBusy && !X.brErr) X.loadBrokers({ onProg: (a, b) => setProg(a / b) }).then(() => { setProg(null); if (ms.page === 'brk' && isOpen($('#ms'))) drawMS(); });
    if ((ms.page === 'own' || ms.page === 'net') && !O.cur && !O.loading && !O.err) { O.useLatest().then(() => (O.cur ? null : O.load({ onProg: (m) => { const b = $('#msMsg'); if (b) b.textContent = m; } }))).then(() => { if (isOpen($('#ms'))) drawMS(); }); }
    if (ms.page === 'net' && O.cur) layoutNet();
    if (ms.page === 'heat') layoutHeat();
    if (ms.page === 'grp') { if (!O.cur && !O.loading && !O.err) O.useLatest().then(() => isOpen($('#ms')) && ms.page === 'grp' && drawMS()); grpAfter(); }
  }
  const loading = (msg) => `<div class="note" id="msMsg" style="text-align:center">${esc(msg || '')}</div>${skel(3)}`;
  const failed = (err, k) => `<div class="empty es"><b>Data belum tersedia</b><span>${esc(err)}</span><div class="rowx" style="justify-content:center;margin-top:12px"><button class="btn pri" data-reload="${k}">Coba lagi</button></div></div>`;

  // ---- Rotation (RRG) ----
  function msRot() {
    if (!E.snap) return loading('Data pasar belum dimuat');
    const data = X.rrg({ weekly: ms.rrgWeekly }); if (!data || !data.length) return '<div class="empty"><b>Riwayat belum cukup</b></div>';
    const W = 340, H = 340, xs = data.flatMap((d) => d.path.map((p) => p.x)), ys = data.flatMap((d) => d.path.map((p) => p.y));
    const span = Math.max(1.2, ...xs.map((x) => Math.abs(x - 100)), ...ys.map((y) => Math.abs(y - 100))) * 1.15;
    const sx = (x) => W / 2 + ((x - 100) / span) * (W / 2 - 14), sy = (y) => H / 2 - ((y - 100) / span) * (H / 2 - 14);
    const colors = ['#E9B949', '#5AA9FF', COL.up, COL.dn, '#B48CFF', '#FF9B70', '#7FDBCA', '#F78FB3', '#C7D36F', '#9AA9FF', '#FFD166', COL.mut];
    const qcol = { Memimpin: 'var(--up)', Melemah: 'var(--gold)', Tertinggal: 'var(--dn)', Membaik: 'var(--info)' };
    const svg = `<svg class="rrg" viewBox="0 0 ${W} ${H}"><rect x="${W / 2}" y="0" width="${W / 2}" height="${H / 2}" fill="${COL.upA(.07)}"/><rect x="${W / 2}" y="${H / 2}" width="${W / 2}" height="${H / 2}" fill="rgba(233,185,73,.07)"/><rect x="0" y="${H / 2}" width="${W / 2}" height="${H / 2}" fill="${COL.dnA(.07)}"/><rect x="0" y="0" width="${W / 2}" height="${H / 2}" fill="rgba(90,169,255,.07)"/>
      <line x1="${W / 2}" y1="0" x2="${W / 2}" y2="${H}" stroke="#2A3B52"/><line x1="0" y1="${H / 2}" x2="${W}" y2="${H / 2}" stroke="#2A3B52"/>
      <text x="${W - 8}" y="16" text-anchor="end" class="rq" fill="${COL.up}">Memimpin</text><text x="${W - 8}" y="${H - 8}" text-anchor="end" class="rq" fill="#E9B949">Melemah</text><text x="8" y="${H - 8}" class="rq" fill="${COL.dn}">Tertinggal</text><text x="8" y="16" class="rq" fill="#5AA9FF">Membaik</text>
      ${data.map((d, i) => { const c = colors[i % colors.length]; const dim = ms.hl && ms.hl !== d.sec; const pts = d.path.map((p) => `${sx(p.x).toFixed(1)},${sy(p.y).toFixed(1)}`).join(' '); const h = d.path[d.path.length - 1];
        return `<g opacity="${dim ? 0.15 : 1}"><polyline points="${pts}" fill="none" stroke="${c}" stroke-width="1.6" stroke-linejoin="round"/>${d.path.slice(0, -1).map((p) => `<circle cx="${sx(p.x)}" cy="${sy(p.y)}" r="1.8" fill="${c}"/>`).join('')}<circle cx="${sx(h.x)}" cy="${sy(h.y)}" r="5" fill="${c}"/><text x="${sx(h.x) + 7}" y="${sy(h.y) + 4}" class="rl" fill="${c}">${esc(d.sec.split(' ')[0])}</text></g>`; }).join('')}</svg>`;
    const moves = data.filter((d) => d.q !== d.prevQ);
    return `<div class="seg"><button data-p="rrgWeekly:true" class="${ms.rrgWeekly ? 'on' : ''}">Mingguan</button><button data-p="rrgWeekly:false" class="${!ms.rrgWeekly ? 'on' : ''}">Harian</button></div>
      <div class="card" style="margin-top:10px">${svg}<div class="note">Sumbu X: kekuatan relatif sektor vs IHSG (RS-Ratio). Sumbu Y: momentum kekuatan relatif (RS-Momentum). Ekor = ${ms.rrgWeekly ? '6 minggu' : '6 hari'} terakhir. Rotasi normal berputar searah jarum jam: Membaik → Memimpin → Melemah → Tertinggal.</div></div>
      ${moves.length ? `<h2>Berpindah kuadran</h2><div class="card">${moves.map((d) => `<div class="fld"><label><b>${esc(d.sec)}</b></label><span class="sm">${d.prevQ} → <span style="color:${qcol[d.q]}">${d.q}</span></span></div>`).join('')}</div>` : ''}
      <h2>Posisi sektor</h2><div class="list">${data.sort((a, b) => ['Memimpin', 'Membaik', 'Melemah', 'Tertinggal'].indexOf(a.q) - ['Memimpin', 'Membaik', 'Melemah', 'Tertinggal'].indexOf(b.q)).map((d) => { const h = d.path[d.path.length - 1]; return `<button class="row" data-hl="${esc(d.sec)}"><span><b>${esc(d.sec)}</b></span><span class="px" style="color:${qcol[d.q]}">${d.q}</span><span class="chg">${['→', '↗', '↑', '↖', '←', '↙', '↓', '↘'][Math.round(((-d.heading + Math.PI * 2) % (Math.PI * 2)) / (Math.PI / 4)) % 8]}</span><span class="sub">RS-Ratio ${num(h.x, 2)} · RS-Mom ${num(h.y, 2)} · ${d.n} saham${ms.hl === d.sec ? ' · disorot' : ''}</span><span></span><span></span></button>`; }).join('')}</div>
      <div class="note">Ketuk sektor untuk menyorot jejaknya. Indeks sektor = rata-rata sama bobot saham anggota dalam daftar pantau.</div>`;
  }

  // ---- Foreign vs domestic ----
  function msFF() {
    if (X.ffBusy) return loading('Mengambil ringkasan perdagangan IDX (30 hari, sekali unduh)…'); if (!X.ff) return X.ffErr ? failed(X.ffErr, 'ff') : loading('');
    const f = X.ff, m = f.market, L = m.length - 1; const per = [...f.per.values()]; const key = ms.ffPer; const lbl = { n1: 'Hari ini', n5: '5 hari', n20: '20 hari' };
    const sum = (k) => m.slice(-k).reduce((a, x) => a + x.net, 0); const uni = new Set(D.universe().map((u) => u.sym));
    const top = per.filter((p) => Math.abs(p[key]) > 0).sort((a, b) => b[key] - a[key]); const buy = top.slice(0, 12), sell = top.slice(-12).reverse();
    const row = (p) => `<button class="row" data-go="${p.s}"><span class="sym">${p.s}</span><span class="px ${p[key] > 0 ? 'up' : 'dn'}">${rp(p[key])}</span><span class="chg">${pct(p.pchg, 1)}</span><span class="sub">${p.streak ? `${Math.abs(p.streak)} hari beruntun ${p.streak > 0 ? 'net buy' : 'net sell'}` : ''}${ok(p.partAvg) ? ` · partisipasi asing ${num(p.partAvg, 0)}%` : ''}${uni.has(p.s) ? '' : ' · di luar daftar pantau'}</span><span></span><span class="sm mut">${lbl[key]}</span></button>`;
    const acc = per.filter((p) => p.div === 'acc' && Math.abs(p.n20) > 5e9).sort((a, b) => b.n20 - a.n20).slice(0, 8), dis = per.filter((p) => p.div === 'dist' && Math.abs(p.n20) > 5e9).sort((a, b) => a.n20 - b.n20).slice(0, 8);
    const secs = X.sectorForeign(key === 'n1' ? 'n1' : key); const mx = Math.max(...secs.map((x) => Math.abs(x[1])), 1);
    return `<div style="margin-bottom:8px">${stamp('IDX EOD ' + f.asOf.slice(6) + '/' + f.asOf.slice(4, 6) + '/' + f.asOf.slice(0, 4))}${stamp(m.length + ' hari')}</div><div class="card"><div class="kv"><div><b class="${m[L].net >= 0 ? 'up' : 'dn'}">${rp(m[L].net)}</b><span>net asing ${f.asOf.slice(6)}/${f.asOf.slice(4, 6)}</span></div><div><b class="${sum(5) >= 0 ? 'up' : 'dn'}">${rp(sum(5))}</b><span>5 hari</span></div><div><b class="${sum(20) >= 0 ? 'up' : 'dn'}">${rp(sum(20))}</b><span>20 hari</span></div><div><b>${num(m[L].part, 0)}%</b><span>porsi asing di nilai transaksi</span></div><div><b class="${-m[L].net >= 0 ? 'up' : 'dn'}">${rp(-m[L].net)}</b><span>net domestik hari itu</span></div><div><b>${m.length}</b><span>hari data</span></div></div>
        <div id="ffChart" style="height:170px;margin-top:10px"></div><div class="note">Batang = net asing harian, garis = kumulatif. Domestik adalah cermin asing (setiap lembar yang dibeli asing dijual domestik, dan sebaliknya). Sumber: IDX Ringkasan Saham (EOD); nilai = volume asing × harga penutupan, termasuk pasar negosiasi.</div></div>
      <div class="seg" style="margin-top:12px">${['n1', 'n5', 'n20'].map((k) => `<button data-p="ffPer:${k}" class="${k === key ? 'on' : ''}">${lbl[k]}</button>`).join('')}</div>
      <h2>Net buy asing terbesar</h2><div class="list">${buy.map(row).join('')}</div>
      <h2>Net sell asing terbesar</h2><div class="list">${sell.map(row).join('')}</div>
      <h2>Per sektor</h2><div class="card">${secs.map(([k, v]) => `<div class="secrow" style="grid-template-columns:120px 1fr 86px"><span>${esc(k)}</span><div class="bar"><i style="${v >= 0 ? 'left:50%' : 'right:50%'};width:${(Math.abs(v) / mx) * 50}%;background:${v >= 0 ? 'var(--up)' : 'var(--dn)'}"></i></div><span style="text-align:right" class="${v >= 0 ? 'up' : 'dn'}">${rp(v)}</span></div>`).join('')}</div>
      <h2>Divergensi asing vs harga (20 hari)</h2><div class="card"><div class="pg" style="margin-top:0">Asing menampung saat harga turun</div>${acc.length ? acc.map((p) => `<button class="secrow mv" data-go="${p.s}" style="grid-template-columns:70px 1fr 70px"><b>${p.s}</b><span class="up">${rp(p.n20)}</span><span>${pct(p.pchg, 1)}</span></button>`).join('') : '<span class="sm mut">Tidak ada</span>'}
        <div class="pg">Asing melepas saat harga naik</div>${dis.length ? dis.map((p) => `<button class="secrow mv" data-go="${p.s}" style="grid-template-columns:70px 1fr 70px"><b>${p.s}</b><span class="dn">${rp(p.n20)}</span><span>${pct(p.pchg, 1)}</span></button>`).join('') : '<span class="sm mut">Tidak ada</span>'}
        <div class="note">Asing menampung saat harga turun sering terjadi di fase akumulasi; asing melepas saat harga naik bisa menandakan distribusi ke pembeli domestik. Bukan sinyal tunggal.</div></div>`;
  }
  function chartFF() {
    const el = $('#ffChart'); if (!el || !window.LightweightCharts || !X.ff) return; const m = X.ff.market; const T = (d) => Date.UTC(+d.slice(0, 4), +d.slice(4, 6) - 1, +d.slice(6)) / 1000;
    const ch = LightweightCharts.createChart(el, { height: 170, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: COL.mut, fontSize: 11 }, grid: { vertLines: { visible: false }, horzLines: { color: COL.grid } }, rightPriceScale: { borderColor: COL.line }, leftPriceScale: { visible: false }, timeScale: { borderColor: COL.line }, handleScroll: false, handleScale: false, localization: { locale: 'id-ID', priceFormatter: (p) => A.fmtRp(p) } });
    const hs = ch.addHistogramSeries({ priceLineVisible: false, lastValueVisible: false }); hs.setData(m.map((x) => ({ time: T(x.d), value: x.net, color: x.net >= 0 ? COL.upA(.7) : COL.dnA(.7) })));
    let cum = 0; const ls = ch.addLineSeries({ color: '#E9B949', lineWidth: 2, priceScaleId: 'left', priceLineVisible: false, lastValueVisible: false }); ls.setData(m.map((x) => ({ time: T(x.d), value: (cum += x.net) }))); ch.timeScale().fitContent();
  }

  // ---- Ownership & inventory (market) ----
  const typeLbl = (t) => O.TYPES[t] || (t ? t : 'Tak teridentifikasi');
  function msOwn() {
    const head = `<div class="rowx" style="margin-bottom:8px"><span class="sm mut" style="flex:1">${O.cur ? `Data KSEI per ${esc(O.cur.date)}${O.prev ? ` · dibanding ${esc(O.prev.date)}` : ''} · ${esc(O.source || '')}` : ''}</span><label class="tg imp-btn">Impor PDF/CSV<input type="file" id="ownFile" accept=".pdf,.csv,application/pdf,text/csv"></label><button class="tg" data-reload="own">Perbarui</button></div>`;
    if (O.loading) return head + loading('Mencari data kepemilikan di situs BEI…'); if (!O.cur) return head + (O.err ? failed(O.err, 'own') : loading(''));
    const types = ['all', 'A', 'MF', 'IS', 'PF', 'IB', 'CP', 'ID'], tl = { all: 'Semua', A: 'Asing', MF: 'Reksa dana', IS: 'Asuransi', PF: 'Dana pensiun', IB: 'Bank/institusi', CP: 'Korporasi', ID: 'Individu' };
    const filt = (c) => ms.ownType === 'all' || (ms.ownType === 'A' ? c.r.lf === 'A' : c.r.type === ms.ownType);
    const ch = O.prev ? O.marketChanges().filter(filt) : []; const uni = new Set(D.universe().map((u) => u.sym));
    const chRow = (c) => `<button class="row" data-go="${c.code}"><span><span class="sym">${c.code}</span> <span class="chip ${c.kind === 'baru' || c.kind === 'tambah' ? 'g' : 'r'}">${c.kind}</span></span><span class="px ${c.d > 0 ? 'up' : 'dn'}">${c.d > 0 ? '+' : ''}${num(c.d, 2)}%</span><span class="chg sm">${num(c.r.pct, 2)}%</span><span class="sub">${esc(c.r.inv)} · ${esc(typeLbl(c.r.type))}${c.r.lf === 'A' ? ' · asing' : ''}</span><span></span><span></span></button>`;
    const conc = [...O.cur.byCode.keys()].filter((k) => uni.has(k)).map((k) => ({ k, s: O.stock(k) })).sort((a, b) => b.s.big5 - a.s.big5);
    let invTop = ''; if (X.ff) { const per = [...X.ff.per.values()].filter((p) => uni.has(p.s)); const by = per.map((p) => { const st = E.snap && E.snap.stocks.get(p.s); return { p, chgPct: st && st.f.marketCap ? ((p.inv[p.inv.length - 1] * p.c[p.c.length - 1]) / st.f.marketCap) * 100 : NaN }; });
      invTop = by.sort((a, b) => b.p.nAll - a.p.nAll).slice(0, 8).map(({ p }) => `<button class="secrow mv" data-go="${p.s}" style="grid-template-columns:70px 1fr 90px"><b>${p.s}</b><span class="sm mut">${num(p.inv[p.inv.length - 1] / 100, 0)} lot</span><span class="${p.nAll >= 0 ? 'up' : 'dn'}">${rp(p.nAll)}</span></button>`).join(''); }
    return head + `<div class="seg">${types.map((t) => `<button data-p="ownType:${t}" class="${t === ms.ownType ? 'on' : ''}">${tl[t]}</button>`).join('')}</div>
      <h2>Perubahan pemegang ≥1% bulan ini</h2>${O.prev ? `<div class="list">${ch.slice(0, 40).map(chRow).join('') || '<div class="empty">Tidak ada perubahan untuk filter ini</div>'}</div><div class="note">"Baru" = masuk daftar ≥1%, "keluar" = turun di bawah 1% atau melepas seluruhnya. Perubahan kecil bisa karena aksi korporasi (right issue, stock split).</div>` : '<div class="card sm mut">Perbandingan bulanan muncul setelah aplikasi menyimpan data 2 bulan. Data bulan berikutnya otomatis diambil saat BEI menerbitkannya.</div>'}
      <h2>Inventory asing ${X.ff ? `(${X.ff.days.length} hari)` : ''}</h2><div class="card">${X.ff ? invTop + '<div class="note">Akumulasi net beli asing sejak awal periode (lembar & nilai). Buka saham untuk melihat kurvanya.</div>' : `<span class="sm mut">Buka "Asing vs domestik" sekali untuk memuat data harian.</span>`}</div>
      <h2>Kepemilikan paling terkonsentrasi</h2><div class="card"><table class="t">${conc.slice(0, 12).map(({ k, s: x }) => `<tr data-go="${k}"><td><b>${k}</b></td><td>${num(x.big5, 1)}% di pemegang ≥5% · free float ±${num(x.floatEst, 0)}%</td></tr>`).join('')}</table><div class="note">Konsentrasi tinggi = harga mudah digerakkan sedikit pihak. Free float di sini perkiraan (100% − pemegang ≥5%).</div></div>
      <h2>Cari investor</h2><input id="invQ" class="srin" style="width:100%;text-transform:none" placeholder="mis. Salim, BPJS, Norges, Danantara" value="${esc(ms.invQ)}"><div id="invRes" style="margin-top:8px">${invResults()}</div>`;
  }
  function invResults() {
    if (!O.cur || (ms.invQ || '').trim().length < 2) return '';
    const r = O.search(ms.invQ); return r.length ? `<div class="list">${r.map((x) => `<button class="row" data-net="inv:${esc(x.key)}"><span><b>${esc(x.name)}</b></span><span class="px sm">${x.n} saham</span><span></span><span class="sub">${esc(typeLbl(x.type))}${x.lf === 'A' ? ' · asing' : x.lf === 'L' ? ' · lokal' : ''} · ketuk untuk jaringan</span><span></span><span></span></button>`).join('')}</div>` : '<div class="empty">Tidak ditemukan</div>';
  }

  // ---- Ownership network ----
  let netState = null;
  function msNet() {
    if (O.loading) return loading('Memuat data kepemilikan…'); if (!O.cur) return O.err ? failed(O.err, 'own') : loading('');
    if (!ms.netCenter) { ms.netCenter = 'BBCA'; ms.netKind = 'stock'; }
    const g = O.network(ms.netCenter, ms.netKind); netState = g;
    const centerId = (ms.netKind === 'stock' ? 'S:' : 'I:') + ms.netCenter; const center = g.nodes.find((n) => n.id === centerId);
    let list = '';
    if (ms.netKind === 'stock') { const x = O.stock(ms.netCenter); list = x && x.rows.length ? `<h2>Pemegang ≥1% ${esc(ms.netCenter)}</h2><div class="list">${x.rows.map((r) => `<button class="row" data-net="inv:${esc(r.key)}"><span><b>${esc(r.inv)}</b></span><span class="px">${num(r.pct, 2)}%</span><span></span><span class="sub">${esc(typeLbl(r.type))}${r.lf === 'A' ? ' · asing' : ''} · ${num(r.shares / 1e6, 1)} jt lembar</span><span></span><span></span></button>`).join('')}</div>` : '<div class="empty">Tidak ada pemegang ≥1% tercatat</div>'; }
    else { const v = O.investor(ms.netCenter); list = v ? `<h2>Portofolio ${esc(v.name)}</h2><div class="list">${v.rows.slice().sort((a, b) => b.pct - a.pct).map((r) => `<button class="row" data-net="stock:${r.code}"><span><span class="sym">${r.code}</span></span><span class="px">${num(r.pct, 2)}%</span><span></span><span class="sub">${esc(r.issuer)} · ${num(r.shares / 1e6, 1)} jt lembar</span><span></span><span></span></button>`).join('')}</div>${v.code ? `<div class="note">Investor ini adalah emiten tercatat: <button class="tg" data-net="stock:${v.code}">${v.code}</button></div>` : ''}` : ''; }
    return `<div class="rowx"><input id="netQ" class="srin" style="flex:1;text-transform:none" placeholder="Kode saham atau nama investor" value=""><button class="tg" id="netGo">Buka</button></div>
      <div class="card" style="margin-top:10px;padding:6px"><svg class="net" id="netSvg" viewBox="0 0 360 360"></svg>
      <div class="legend" style="padding:6px 6px 2px"><span style="--c:#E9B949">Saham</span><span style="--c:#5AA9FF">Institusi/korporasi</span><span style="--c:#22B07D">Individu</span><span style="--c:#B48CFF">Emiten sebagai pemegang</span></div>
      <div class="note" style="padding:0 6px">Pusat: <b>${esc(center ? center.label : ms.netCenter)}</b>. Garis tebal = kepemilikan besar. Ketuk lingkaran untuk pindah pusat.</div></div>
      ${ms.netKind === 'stock' ? `<div class="rowx" style="margin-top:8px"><button class="btn" data-go="${esc(ms.netCenter)}">Buka halaman ${esc(ms.netCenter)}</button></div>` : ''}${list}`;
  }
  function layoutNet() {
    const svg = $('#netSvg'); if (!svg || !netState) return; const go = $('#netGo'), q = $('#netQ');
    if (go) go.onclick = () => { const v = q.value.trim(); if (!v) return; if (/^[A-Za-z]{4}$/.test(v) && O.cur.byCode.has(v.toUpperCase())) { ms.netKind = 'stock'; ms.netCenter = v.toUpperCase(); } else { const r = O.search(v)[0]; if (!r) return toast('Tidak ditemukan'); ms.netKind = 'inv'; ms.netCenter = r.key; } drawMS(); };
    const { nodes, links } = netState; const W = 360, H = 360; const idx = new Map(nodes.map((n, i) => [n.id, i])); const cId = (ms.netKind === 'stock' ? 'S:' : 'I:') + ms.netCenter;
    nodes.forEach((n, i) => { const a = (i / nodes.length) * Math.PI * 2; n.x = n.id === cId ? W / 2 : W / 2 + Math.cos(a) * 120; n.y = n.id === cId ? H / 2 : H / 2 + Math.sin(a) * 120; n.vx = 0; n.vy = 0; });
    for (let it = 0; it < 320; it++) {
      for (let i = 0; i < nodes.length; i++) for (let j = i + 1; j < nodes.length; j++) { const a = nodes[i], b = nodes[j]; let dx = a.x - b.x, dy = a.y - b.y; const d2 = dx * dx + dy * dy + 0.01; const f = 900 / d2; const d = Math.sqrt(d2); dx /= d; dy /= d; a.vx += dx * f; a.vy += dy * f; b.vx -= dx * f; b.vy -= dy * f; }
      for (const l of links) { const a = nodes[idx.get(l.a)], b = nodes[idx.get(l.b)]; const dx = b.x - a.x, dy = b.y - a.y; const d = Math.sqrt(dx * dx + dy * dy) || 1; const f = (d - 62) * 0.02; a.vx += (dx / d) * f; a.vy += (dy / d) * f; b.vx -= (dx / d) * f; b.vy -= (dy / d) * f; }
      for (const n of nodes) { n.vx += (W / 2 - n.x) * 0.004; n.vy += (H / 2 - n.y) * 0.004; if (n.id === cId) { n.x = W / 2; n.y = H / 2; n.vx = n.vy = 0; continue; } n.x = Math.max(16, Math.min(W - 16, n.x + n.vx * 0.5)); n.y = Math.max(16, Math.min(H - 16, n.y + n.vy * 0.5)); n.vx *= 0.6; n.vy *= 0.6; }
    }
    const col = (n) => (n.type === 'stock' ? '#E9B949' : n.type === 'company' ? '#B48CFF' : n.type === 'person' ? COL.up : '#5AA9FF');
    const short = (t) => (t.length > 16 ? t.slice(0, 15) + '…' : t);
    svg.innerHTML = links.map((l) => { const a = nodes[idx.get(l.a)], b = nodes[idx.get(l.b)]; return `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="${l.same ? '#B48CFF' : 'rgba(142,160,181,.45)'}" stroke-dasharray="${l.same ? '3 3' : ''}" stroke-width="${Math.max(0.6, Math.min(4, Math.sqrt(l.w) * 0.7))}"/>`; }).join('') +
      nodes.map((n) => `<g data-nid="${esc(n.id)}" style="cursor:pointer"><circle cx="${n.x}" cy="${n.y}" r="${n.id === cId ? 11 : n.type === 'stock' ? 7 : 5.5}" fill="${col(n)}" stroke="#0F1722" stroke-width="1.5"/><text x="${n.x}" y="${n.y + (n.id === cId ? 22 : 16)}" text-anchor="middle" class="nl">${esc(short(n.label))}</text></g>`).join('');
    svg.onclick = (e) => { const g = e.target.closest('[data-nid]'); if (!g) return; const id = g.dataset.nid; ms.netKind = id.startsWith('S:') ? 'stock' : 'inv'; ms.netCenter = id.slice(2); drawMS(); };
  }

  // ---- Broker activity ----
  function msBrk() {
    if (X.brBusy) return loading('Mengambil ringkasan broker IDX…'); if (!X.br) return X.brErr ? failed(X.brErr, 'brk') : loading('');
    const b = X.br; const spark = (h) => { const mx = Math.max(...h, 1); return `<svg width="54" height="16" viewBox="0 0 54 16">${h.map((v, i) => `<rect x="${i * (54 / h.length)}" y="${16 - (v / mx) * 16}" width="${54 / h.length - 1}" height="${(v / mx) * 16}" fill="#3d6a9c"/>`).join('')}</svg>`; };
    return `<div style="margin-bottom:8px">${stamp('IDX EOD ' + b.d.slice(6) + '/' + b.d.slice(4, 6) + '/' + b.d.slice(0, 4))}</div><div class="card"><div class="kv"><div><b>${rp(b.tot)}</b><span>nilai total ${b.d.slice(6)}/${b.d.slice(4, 6)}</span></div><div><b>${num(b.fShare, 0)}%</b><span>porsi broker afiliasi asing</span></div><div><b>${b.list.length}</b><span>broker aktif</span></div></div>
      <div class="note">IDX hanya menerbitkan total transaksi per broker untuk seluruh pasar, bukan per saham. Rincian broker per saham (siapa beli saham apa) adalah data berbayar. Afiliasi asing ditandai dari nama broker.</div></div>
      <h2>Broker teraktif</h2><div class="card tbl-wrap"><table class="pt"><tr><th>Broker</th><th>Nilai</th><th>Porsi</th><th>vs rata²</th><th>${b.days.length} hari</th></tr>
      ${b.list.slice(0, 30).map((r) => `<tr><td><b>${esc(r.id)}</b> <span class="sm mut">${esc(r.name.slice(0, 22))}</span>${r.foreign ? ' <span class="chip b">asing</span>' : ''}</td><td>${rp(r.val)}</td><td>${num(r.share, 1)}%</td><td class="${r.vsAvg >= 1.3 ? 'up' : r.vsAvg <= 0.7 ? 'dn' : ''}">${ok(r.vsAvg) ? num(r.vsAvg, 2) + 'x' : '—'}</td><td>${spark(r.hist)}</td></tr>`).join('')}</table></div>
      <div class="note">"vs rata²" > 1,3x = broker jauh lebih aktif dari biasanya; lonjakan broker institusi/asing sering menyertai rebalancing atau aliran dana besar.</div>`;
  }



  // ---------------- tappable numbers: market health drill-down & regime components ----------------
  const RC_HOW = {
    'Tren IHSG': 'Posisi IHSG terhadap EMA 20, 50, dan 200 serta arah kemiringannya. Di atas ketiganya dan naik = 100.',
    'Breadth': 'Persentase saham di daftar pantau yang berada di atas EMA 50, ditambah rasio saham naik dibanding turun.',
    'Volatilitas': 'Volatilitas IHSG dibanding setahun terakhir. Makin tenang makin tinggi skornya; gejolak tinggi menekan skor.',
    'Minat asing': 'Net beli/jual investor asing di seluruh pasar dalam 5 dan 20 hari terakhir (data IDX).',
    'Rupiah': 'Arah USD/IDR sebulan terakhir. Rupiah menguat = skor tinggi; melemah tajam = skor rendah.',
    'Pasar global': 'Gabungan S&P 500, Hang Seng, Shanghai, EIDO (ETF saham Indonesia di AS), dan indeks ketakutan VIX.',
  };
  function openInfo(title, html) {
    const el = $('#gl'); hap();
    el.innerHTML = `<div class="bs-bd" data-close></div><div class="bs-p"><div class="bs-h"><b>${esc(title)}</b><span class="sp"></span><button class="icon" data-close aria-label="Tutup">✕</button></div>${html}</div>`;
    showLayer(el); el.onclick = (e) => { if (e.target.closest('[data-close]')) hideLayer(el); const b = e.target.closest('[data-brd2]'); if (b) { hideLayer(el); openBreadth(b.dataset.brd2); } };
  }
  document.addEventListener('click', (e) => {
    const rc = e.target.closest('[data-rc]'); if (rc && M.regime) { e.preventDefault(); e.stopPropagation(); const c = M.regime.comp[+rc.dataset.rc]; if (!c) return;
      return openInfo(c.label, `<div class="rowx"><b class="${c.s >= 50 ? 'up' : 'dn'}" style="font:600 28px var(--fc)">${c.s}</b><span class="sm mut">/ 100</span></div><p><b>Sekarang:</b> ${esc(c.why)}</p><p class="sm mut">${esc(RC_HOW[c.label] || '')}</p>${c.label === 'Breadth' ? '<button class="btn" data-brd2="ema50">Lihat saham di atas / di bawah EMA 50 ›</button>' : ''}`); }
    const bd = e.target.closest('[data-brd]'); if (bd) { e.preventDefault(); e.stopPropagation(); openBreadth(bd.dataset.brd); }
  });
  Object.assign(ms, { brdM: 'ema50', brdS: 'above' });
  function openBreadth(m) { ms.brdM = m; ms.brdS = 'above'; openMS('brd'); }
  function brdRows() {
    const all = [...E.snap.stocks.values()]; const m = ms.brdM, above = ms.brdS === 'above';
    const d200 = (x) => { const e = x.F && x.F.s && x.F.s.ema200; const v = e && e[e.length - 1]; return v ? (x.f.close / v - 1) * 100 : NaN; };
    let rows, val, lab;
    if (m === 'ema50') { rows = all.filter((x) => !!x.f.aboveEma50 === above); val = (x) => x.f.distEma50; lab = 'dari EMA 50'; }
    else if (m === 'ema200') { rows = all.filter((x) => !!x.f.aboveEma200 === above); val = d200; lab = 'dari EMA 200'; }
    else if (m === 'nh') { rows = all.filter((x) => x.f.newHigh52); val = (x) => -x.f.dist52wHigh; lab = 'dari high 52 mgg'; }
    else if (m === 'nl') { rows = all.filter((x) => x.f.newLow52); val = (x) => x.f.dist52wLow; lab = 'di atas low 52 mgg'; }
    else if (m === 'up') { rows = all.filter((x) => x.f.chg1d > 0); val = (x) => x.f.chg1d; lab = 'hari ini'; }
    else { rows = all.filter((x) => x.f.chg1d < 0); val = (x) => x.f.chg1d; lab = 'hari ini'; }
    const desc = !(m === 'ema50' || m === 'ema200') ? (m !== 'dn' && m !== 'nl') : above;
    rows = rows.map((x) => ({ s: x, v: val(x) })).sort((a, b) => (desc ? b.v - a.v : a.v - b.v));
    return { rows, lab, all };
  }
  function brdTree() {
    const m = ms.brdM, above = ms.brdS === 'above'; const T = (f) => ({ f, op: 'true', tf: 'D' }); const L = (f, op, v) => ({ f, op, v, tf: 'D' });
    const c = m === 'ema50' ? T('aboveEma50') : m === 'ema200' ? T('aboveEma200') : m === 'nh' ? T('newHigh52') : m === 'nl' ? T('newLow52') : m === 'up' ? L('chg1d', '>', 0) : L('chg1d', '<', 0);
    return (m === 'ema50' || m === 'ema200') && !above ? { g: 'AND', c: [{ g: 'AND', not: true, c: [c] }] } : { g: 'AND', c: [c] };
  }
  function msBrd() {
    if (!E.snap) return loading('Data pasar belum dimuat');
    const pick = (k, opts) => `<div class="seg fl">${opts.map(([v, l]) => `<button data-p="${k}:${v}" class="${ms[k] === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    const { rows, lab, all } = brdRows(); const isEma = ms.brdM === 'ema50' || ms.brdM === 'ema200';
    const secs = E.snap.sectors.map((sec) => { const k = rows.filter((r) => r.s.sector === sec.name).length; return { name: sec.name, k, n: sec.members.length }; }).filter((x) => x.n).sort((a, b) => b.k / b.n - a.k / a.n);
    const name = { ema50: 'EMA 50', ema200: 'EMA 200', nh: 'New high 52 minggu', nl: 'New low 52 minggu', up: 'Saham naik', dn: 'Saham turun' }[ms.brdM];
    return `<div class="flc">${pick('brdM', [['ema50', 'EMA 50'], ['ema200', 'EMA 200'], ['nh', 'New high'], ['nl', 'New low'], ['up', 'Naik'], ['dn', 'Turun']])}${isEma ? pick('brdS', [['above', 'Di atas'], ['below', 'Di bawah']]) : ''}</div>
      <div class="card"><div class="rowx"><b style="font:600 26px var(--fc)">${rows.length}</b><span class="sm mut">&nbsp;dari ${all.length} saham (${Math.round((rows.length / all.length) * 100)}%) · ${esc(name)}${isEma ? (ms.brdS === 'above' ? ' — di atas' : ' — di bawah') : ''}</span><span class="sp"></span><button class="tg" data-brdscr>Jadikan screener ›</button></div>
        <div class="pg">Per sektor</div>${secs.map((x) => `<div class="secrow" style="grid-template-columns:118px 1fr 56px"><span>${esc(x.name)}</span><div class="bar"><i style="width:${(x.k / x.n) * 100}%"></i></div><span style="text-align:right">${x.k}/${x.n}</span></div>`).join('')}</div>
      <h2>Daftar emiten</h2>
      ${rows.length ? `<div class="list">${rows.map((r) => `<button class="row" data-sym="${r.s.sym}"><span class="sym">${r.s.sym}</span><span class="px">${ok(r.v) ? `${r.v >= 0 ? '+' : ''}${num(r.v, 1)}%` : '—'}</span><span class="chg">${pct(r.s.f.chg1d)}</span><span class="sub">${esc(r.s.sector)} · ${lab}</span><span></span><span></span></button>`).join('')}</div>` : emptyState('Tidak ada saham di kelompok ini', 'Coba pilih kelompok lain di atas.')}
      <div class="note">Dihitung dari ${all.length} saham dalam daftar pantau aplikasi. ${stamp('Data ' + when(E.snap.asOf))}</div>`;
  }
  document.addEventListener('click', (e) => { const b = e.target.closest('[data-brdscr]'); if (!b) return; e.stopPropagation(); hap('confirm');
    st.tree = brdTree(); st.presetId = null; st.showBuilder = true; closeMS(); $('#tabs button[data-tab="screener"]').click(); setTimeout(() => runScreener(), 60); });

  // ---------------- Lite mode: stock page ----------------
  const liteStock = () => D.settings.lite && !sp.full && !sp.isIndex;
  function drawLiteSummary() {
    const s = sp.data, f = s.f, p = s.plan, box = $('#sec'); if (!box) return; const pl = PK.plain(s); const fu = s.fund;
    const trend = f.hhhl ? ['Naik', 'up'] : f.lhll ? ['Turun', 'dn'] : ['Sideways', 'mut'];
    box.innerHTML = `${p.bias > 0 ? `<div class="card lite-plan"><div class="rowx"><b>${esc(p.type.split(' (')[0])}</b><span class="sp"></span><span class="score ${scoreCls(f.score)}">${f.score}</span></div>
        <div class="keyl" style="margin-top:8px"><div class="ent"><span>Area beli</span><b>${A.fmt(p.entry[0])}–${A.fmt(p.entry[1])}</b></div><div class="inv"><span>Batal jika di bawah</span><b>${A.fmt(p.invalid)}</b></div><div class="tgt"><span>Target 1</span><b>${p.targets[0] ? A.fmt(p.targets[0]) : '—'}</b></div></div>
        <div class="sm mut" style="margin-top:6px">${esc(p.status)}${ok(p.rrNet) ? ` · potensi ${num(p.rrNet, 1)}× risiko` : ''}</div></div>`
      : `<div class="card"><b>Belum ada setup beli</b><div class="sm" style="margin-top:4px;line-height:1.5">${esc(p.type)}. Support terdekat ${s.F.st.levels.supports[0] ? A.fmt(s.F.st.levels.supports[0].price) : '—'}, resistance ${s.F.st.levels.resistances[0] ? A.fmt(s.F.st.levels.resistances[0].price) : '—'}.</div></div>`}
      <div class="card plain" style="margin-top:10px"><div class="pg" style="margin-top:0">Kenapa</div><ol>${pl.reasons.map((r) => `<li>${esc(r)}</li>`).join('') || '<li>Belum ada alasan kuat untuk masuk.</li>'}</ol><div class="prisk"><b>Risiko:</b> ${esc(pl.risk)}</div></div>
      <div class="kv" style="margin-top:10px"><div><b class="${trend[1]}">${trend[0]}</b><span>tren</span></div><div><b>${num(f.rsi, 0)}</b><span>RSI</span></div><div><b class="${s.ff && s.ff.net5d >= 0 ? 'up' : 'dn'}">${s.ff ? A.fmtRp(s.ff.net5d) : '—'}</b><span>asing 5 hari</span></div>
        ${fu ? `<div><b>${ok(f.pe) ? num(f.pe, 1) + 'x' : '—'}</b><span>P/E</span></div><div><b>${ok(f.roe) ? num(f.roe, 1) + '%' : '—'}</b><span>ROE</span></div><div><b>${ok(f.divYield) ? num(f.divYield, 1) + '%' : '—'}</b><span>dividen</span></div>` : ''}</div>
      ${s.goreng && s.goreng.level !== 'Rendah' ? `<div class="note dn">⚠ Risiko saham gorengan ${s.goreng.level.toLowerCase()}: ${esc(s.goreng.flags[0])}</div>` : ''}
      ${p.bias > 0 ? `<div class="evid2"><span class="pg">Bukti historis</span><span data-ev="${s.sym}">${esc(PK.evidenceText(s, PK.stockEv.get(s.sym + '|' + p.type)) || 'Menghitung…')}</span></div>` : ''}
      <div class="rowx" style="margin-top:12px;flex-wrap:wrap;gap:8px"><button class="btn pri" data-buy="${s.sym}">✓ Saya beli</button><button class="btn" id="liteAlert">🔔 Alert</button><span class="sp"></span><button class="btn" id="liteFull">Lihat analisis lengkap ›</button></div>`;
    $('#liteFull').onclick = () => { sp.full = true; hap(); drawStock(); }; $('#liteAlert').onclick = () => openAlertSheet(s.sym); loadStockEvidence();
  }
  // ---- Pasar: today card ----
  function todayCard() {
    if (!E.snap) return ''; const w = D.wib(); const afterClose = w.day >= 1 && w.day <= 5 && w.min >= 16 * 60 + 15;
    if (afterClose) { const r = JB.recap(); if (!r) return ''; const act = r.port.filter((x) => x.tone === 'dn');
      return `<div class="card today"><div class="rowx"><b>🌇 Rangkuman hari ini</b><span class="sp"></span>${stamp(when(E.snap.asOf))}</div>
        <div class="sm" style="margin-top:6px;line-height:1.6">IHSG ${num(r.ihsg.c, 2)} ${pct(r.ihsg.chg)} · ${r.up} naik / ${r.dn} turun.<br>Naik: ${r.gainers.map((x) => `<b>${x.sym}</b> ${pct(x.chg, 1)}`).join(', ')} · Turun: ${r.losers.map((x) => `<b>${x.sym}</b> ${pct(x.chg, 1)}`).join(', ')}<br>Inflow: ${r.inflow.map((x) => `<b>${x.sym}</b>`).join(', ')} · Outflow: ${r.outflow.map((x) => `<b>${x.sym}</b>`).join(', ')}${r.port.length ? `<br>Portofolio: ${r.portRp ? A.fmtRp(r.portRp) + ' hari ini' : r.port.length + ' posisi'}${act.length ? ` · <span class="dn">perlu tindakan: ${act.map((x) => x.sym).join(', ')}</span>` : ''}` : ''}${r.tomorrow.length ? `<br>Pantau besok: ${r.tomorrow.map((x) => `<b>${x}</b>`).join(', ')}` : ''}</div></div>`; }
    const v = PK.verdict(); const top = PK.all().filter((x) => x.pickCat !== 'risk' && PK.passes(x)).slice(0, 5);
    return `<button class="card today" data-act="tab:picks" style="display:block;width:100%;text-align:left"><div class="rowx"><b>${v.noBuy ? '⛔ Hari ini lebih baik tidak beli' : '☀️ Picks hari ini'}</b><span class="sp"></span><span class="sm" style="color:var(--info)">Buka ›</span></div>
      <div class="sm" style="margin-top:6px;line-height:1.5">${v.noBuy ? esc(v.text) : top.length ? `${v.pass} lolos syarat ketat: ${top.map((x) => `<b>${x.sym}</b>`).join(', ')}${v.pass > 5 ? ', …' : ''}` : esc(v.text)}</div></button>`;
  }

  // ---- Heatmap ----
  Object.assign(ms, { hmPer: 'perf1d', hmSize: 'value' });
  function msHeat() {
    if (!E.snap) return loading('Data pasar belum dimuat');
    const pick = (k, opts) => `<div class="seg fl">${opts.map(([v, l]) => `<button data-p="${k}:${v}" class="${ms[k] === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    const capMissing = ms.hmSize === 'cap' ? [...E.snap.stocks.values()].filter((x) => !(x.f.marketCap > 0)).length : 0;
    return `<div class="flc">${pick('hmPer', [['perf1d', 'Hari ini'], ['perf1w', '1 minggu'], ['perf1m', '1 bulan'], ['perf3m', '3 bulan']])}${pick('hmSize', [['value', 'Ukuran: nilai transaksi'], ['cap', 'Ukuran: kapitalisasi']])}</div>
      ${capMissing ? `<div class="note" id="hmMsg">Mengambil kapitalisasi ${capMissing} saham… (sekali sehari)</div>` : ''}
      <div id="hmBox" class="hm"></div>
      <div class="legend" style="margin-top:8px"><span style="--c:${COL.dnA(0.9)}">turun kuat</span><span style="--c:${COL.dnA(0.35)}">turun</span><span style="--c:var(--s3)">datar</span><span style="--c:${COL.upA(0.35)}">naik</span><span style="--c:${COL.upA(0.9)}">naik kuat</span></div>
      <div class="note">Kotak dikelompokkan per sektor. Ketuk saham untuk membuka detailnya. ${stamp('Data ' + when(E.snap.asOf))}</div>`;
  }
  function layoutHeat() {
    const box = $('#hmBox'); if (!box || !E.snap) return; const W = box.clientWidth || 360, H = Math.round(Math.min(640, Math.max(420, W * 1.25))); box.style.height = H + 'px';
    if (ms.hmSize === 'cap') { const need = [...E.snap.stocks.values()].filter((x) => !(x.f.marketCap > 0)).map((x) => x.sym); if (need.length && !ms.hmBusy) { ms.hmBusy = true; E.ensureFundamentals(need).catch(() => {}).then(() => { ms.hmBusy = false; if (isOpen($('#ms')) && ms.page === 'heat') drawMS(); }); } }
    const size = (st0) => (ms.hmSize === 'cap' ? st0.f.marketCap || 0 : st0.f.avgValue20 || 0);
    const cap = { perf1d: 4, perf1w: 8, perf1m: 15, perf3m: 25 }[ms.hmPer];
    const secs = E.snap.sectors.map((sec) => ({ name: sec.name, value: sec.members.reduce((a, m) => a + size(m), 0), members: sec.members })).filter((x) => x.value > 0);
    const outer = HM.squarify(secs, 0, 0, W, H); let html = '';
    for (const sr of outer) {
      const pad = 1, top = sr.h > 40 && sr.w > 60 ? 15 : 0; html += `<div class="hm-sec" style="left:${sr.x}px;top:${sr.y}px;width:${sr.w}px;height:${sr.h}px">${top ? `<span>${esc(sr.name)}</span>` : ''}</div>`;
      const inner = HM.squarify(sr.members.map((m) => ({ m, value: size(m) })), sr.x + pad, sr.y + pad + top, sr.w - 2 * pad, sr.h - 2 * pad - top);
      for (const r of inner) { const v = r.m.f[ms.hmPer]; const k = ok(v) ? Math.max(-1, Math.min(1, v / cap)) : 0; const bg = Math.abs(k) < 0.04 ? 'var(--s3)' : k > 0 ? COL.upA(0.22 + 0.7 * k) : COL.dnA(0.22 + 0.7 * -k);
        const big = r.w > 46 && r.h > 30, fs = Math.max(9, Math.min(18, Math.sqrt(r.w * r.h) / 5));
        html += `<button class="hm-c" data-sym="${r.m.sym}" style="left:${r.x}px;top:${r.y}px;width:${Math.max(0, r.w - 1)}px;height:${Math.max(0, r.h - 1)}px;background:${bg};font-size:${fs}px" aria-label="${r.m.sym} ${ok(v) ? num(v, 1) + '%' : ''}">${r.w > 26 && r.h > 16 ? `<b>${r.m.sym}</b>${big ? `<i>${ok(v) ? `${v >= 0 ? '+' : ''}${num(v, 1)}%` : ''}</i>` : ''}` : ''}</button>`; }
    }
    box.innerHTML = html;
  }

  // ---- Groups & themes ----
  Object.assign(ms, { grKind: 'group', grSel: null, grPer: 'p1m' });
  function msGrp() {
    if (!E.snap) return loading('Data pasar belum dimuat');
    if (ms.grSel) return grpDetail();
    const pick = (k, opts) => `<div class="seg fl">${opts.map(([v, l]) => `<button data-p="${k}:${v}" class="${ms[k] === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    const items = GR.list(ms.grKind).map((g) => Object.assign(g, { st: GR.stats(g.syms) })).filter((g) => g.syms.length).sort((a, b) => (b.st[ms.grPer] ?? -999) - (a.st[ms.grPer] ?? -999));
    const src = ms.grKind === 'group' ? (O.cur ? `Anggota grup dari data KSEI ${O.cur.date}: saham yang ≥5% dimiliki pengendali grup.` : 'Data KSEI belum dimuat — memakai daftar anggota bawaan. Buka "Kepemilikan & inventory" sekali agar anggota grup dihitung dari data resmi.') : 'Tema = daftar saham pilihan per industri/komoditas.';
    return `<div class="flc">${pick('grKind', [['group', 'Konglomerasi & BUMN'], ['theme', 'Tema']])}${pick('grPer', [['p1d', 'Hari ini'], ['p1w', '1 minggu'], ['p1m', '1 bulan'], ['p3m', '3 bulan']])}</div>
      <div class="note">${esc(src)}</div>
      <div class="list">${items.map((g) => { const v = g.st[ms.grPer]; return `<button class="row" data-grsel="${g.id}"><span><b>${esc(g.name)}</b></span><span class="px">${pct(v, 1)}</span><span class="chg sm">${g.syms.length} saham</span><span class="sub">${g.st.leader ? `Pemimpin ${g.st.leader.sym} ${pct(g.st.leader.f.perf1m, 1)} 1B` : ''}${ok(g.st.ff5) && g.st.ff5 ? ` · asing 5H ${A.fmtRp(g.st.ff5)}` : ''}${g.st.catchup.length ? ` · tertinggal: ${g.st.catchup.slice(0, 3).join(', ')}` : ''}</span><span></span><span class="sm mut">›</span></button>`; }).join('')}</div>`;
  }
  function grpDetail() {
    const g = GR.list(ms.grKind).find((x) => x.id === ms.grSel); if (!g) { ms.grSel = null; return msGrp(); }
    const stt = GR.stats(g.syms); const pctOf = new Map((g.holds || []).map((h) => [h.sym, h.pct]));
    const rows = g.syms.map((sym) => ({ sym, s1: E.getStock(sym) })); const missing = rows.filter((r) => !r.s1).map((r) => r.sym);
    return `<div class="rowx"><button class="tg" data-grback>‹ Semua</button><span class="sp"></span><span class="sm mut">${esc(g.source)}</span></div>
      <h2>${esc(g.name)}</h2>
      <div class="card"><div class="kv">${[['Hari ini', stt.p1d], ['1 minggu', stt.p1w], ['1 bulan', stt.p1m], ['3 bulan', stt.p3m]].map(([l, v]) => `<div><b>${pct(v, 1)}</b><span>${l}</span></div>`).join('')}<div><b>${ok(stt.above50) ? Math.round(stt.above50) + '%' : '—'}</b><span>anggota di atas EMA 50</span></div><div><b class="${stt.ff5 >= 0 ? 'up' : 'dn'}">${ok(stt.ff5) ? A.fmtRp(stt.ff5) : '—'}</b><span>asing 5 hari</span></div></div>
        <div id="grChart" style="height:180px;margin-top:10px"></div><div class="legend"><span style="--c:#E9B949">${esc(g.name)} (rata-rata sama bobot)</span><span style="--c:#5AA9FF">IHSG</span></div></div>
      ${stt.catchup.length ? `<div class="card" style="margin-top:10px"><b>Anggota tertinggal</b><div class="sm" style="margin-top:4px;line-height:1.5">${stt.catchup.map((x) => `<button class="tg" data-sym="${x}">${x}</button>`).join(' ')} — naik jauh lebih sedikit dari rata-rata grupnya sebulan ini, padahal trennya masih di atas EMA 50. Kandidat catch-up, perlu konfirmasi teknikal.</div></div>` : ''}
      <h2>Anggota</h2><div class="card tbl-wrap"><table class="pt"><tr><th>Saham</th>${ms.grKind === 'group' ? '<th>Porsi</th>' : ''}<th>Hari ini</th><th>1B</th><th>3B</th><th>RS</th><th>Setup</th></tr>
      ${rows.map(({ sym, s1 }) => `<tr data-sym="${sym}"><td><b>${sym}</b>${s1 && s1.goreng && s1.goreng.level === 'Tinggi' ? ' ⚠' : ''}</td>${ms.grKind === 'group' ? `<td>${ok(pctOf.get(sym)) ? num(pctOf.get(sym), 1) + '%' : '—'}</td>` : ''}<td>${s1 ? pct(s1.f.chg1d, 1) : '…'}</td><td>${s1 ? pct(s1.f.perf1m, 1) : ''}</td><td>${s1 ? pct(s1.f.perf3m, 1) : ''}</td><td>${s1 && ok(s1.f.rsRating) ? s1.f.rsRating : '—'}</td><td class="sm">${s1 ? esc(s1.plan.type.split(' (')[0].split(' — ')[0]) : ''}</td></tr>`).join('')}</table></div>
      ${missing.length ? `<div class="note" id="grMiss">Memuat ${missing.length} anggota di luar daftar pantau…</div>` : ''}
      ${g.minor && g.minor.length ? `<div class="note">Posisi minoritas (1–5%): ${g.minor.slice(0, 20).map((x) => x.sym).join(', ')}${g.minor.length > 20 ? '…' : ''}</div>` : ''}`;
  }
  function grpAfter() {
    const body = $('#msBody'); if (!body) return;
    body.querySelectorAll('[data-grsel]').forEach((b2) => (b2.onclick = () => { ms.grSel = b2.dataset.grsel; drawMS(); }));
    const bk = body.querySelector('[data-grback]'); if (bk) bk.onclick = () => { ms.grSel = null; drawMS(); };
    if (!ms.grSel) return; const g = GR.list(ms.grKind).find((x) => x.id === ms.grSel); if (!g) return;
    const missing = g.syms.filter((x) => !E.getStock(x)).slice(0, 15);
    if (missing.length && !ms.grBusy) { ms.grBusy = true; D.pool(missing, (x) => E.ensureStock(x).catch(() => null), 4).then(() => { ms.grBusy = false; if (isOpen($('#ms')) && ms.grSel === g.id) drawMS(); }); }
    const el = $('#grChart'); if (!el || !window.LightweightCharts) return; const ih = E.snap.ihsg.cd; const n = ih.c.length, k0 = Math.max(0, n - 64); const dk = (t) => Math.floor((t + 25200) / 86400);
    const mem = g.syms.map((x) => E.getStock(x)).filter(Boolean); if (!mem.length) return; const maps = mem.map((m) => new Map(m.cd.t.map((t, i) => [dk(t), m.cd.c[i]])));
    let idx = 0; const gl = [], il = []; for (let i = k0; i < n; i++) { const d0 = dk(ih.t[k0]), d1 = dk(ih.t[i]); const r = maps.map((m) => (m.get(d0) && m.get(d1) ? m.get(d1) / m.get(d0) - 1 : null)).filter((x) => x !== null); idx = r.length ? (r.reduce((a, b) => a + b, 0) / r.length) * 100 : idx; const T = d1 * 86400; gl.push({ time: T, value: idx }); il.push({ time: T, value: (ih.c[i] / ih.c[k0] - 1) * 100 }); }
    const ch = LightweightCharts.createChart(el, { height: 180, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: COL.mut, fontSize: 11 }, grid: { vertLines: { visible: false }, horzLines: { color: COL.grid } }, rightPriceScale: { borderColor: COL.line }, timeScale: { borderColor: COL.line }, handleScroll: false, handleScale: false, localization: { locale: 'id-ID', priceFormatter: (v) => `${v >= 0 ? '+' : ''}${num(v, 1)}%` } });
    ch.addLineSeries({ color: '#E9B949', lineWidth: 2, priceLineVisible: false }).setData(gl); ch.addLineSeries({ color: '#5AA9FF', lineWidth: 1, priceLineVisible: false }).setData(il); ch.timeScale().fitContent();
  }
  // ---------------- STOCK PAGE: peers, ownership, trade flow, expected move ----------------
  const pe = { sort: 'score', busy: false };
  function secPeers(s) {
    const peers = X.peers(s); if (peers.length < 2) return '<div class="empty"><b>Tidak ada pembanding</b>Saham ini tidak punya sektor dalam daftar pantau.</div>';
    const need = peers.filter((p) => !p.fund).map((p) => p.sym);
    if (need.length && !pe.busy) { pe.busy = true; E.ensureFundamentals(need.slice(0, 20)).catch(() => {}).then(() => { pe.busy = false; if (isOpen($('#stock')) && sp.sec === 'peers') drawSection(); }); }
    const cols = [['perf1m', '1B', 1], ['perf3m', '3B', 1], ['rsRating', 'RS', 0], ['score', 'Skor', 0], ['pe', 'P/E', 1], ['pb', 'P/B', 2], ['roe', 'ROE', 1], ['revGrowth', 'Pend.', 1], ['divYield', 'Div', 1], ['marketCap', 'Kap.', 0]];
    const k = pe.sort; const lowGood = k === 'pe' || k === 'pb'; const rows = peers.slice().sort((a, b) => { const x = a.f[k], y = b.f[k]; if (!ok(x) || (lowGood && x <= 0)) return 1; if (!ok(y) || (lowGood && y <= 0)) return -1; return lowGood ? x - y : y - x; });
    const rank = (key, low) => { const v = peers.filter((p) => ok(p.f[key]) && (!low || p.f[key] > 0)).sort((a, b) => (low ? a.f[key] - b.f[key] : b.f[key] - a.f[key])); const i = v.findIndex((p) => p.sym === s.sym); return i >= 0 ? `${i + 1}/${v.length}` : '—'; };
    const fmtc = (key, v, d) => (!ok(v) ? '—' : key === 'marketCap' ? A.fmtRp(v).replace('Rp', '') : ['perf1m', 'perf3m', 'roe', 'revGrowth', 'divYield'].includes(key) ? `${v > 0 && key.startsWith('perf') ? '+' : ''}${num(v, d)}%` : num(v, d));
    return `<div class="card"><div class="kv"><div><b>${rank('rsRating')}</b><span>peringkat RS</span></div><div><b>${rank('score')}</b><span>peringkat skor</span></div><div><b>${rank('pe', true)}</b><span>P/E termurah</span></div><div><b>${rank('roe')}</b><span>ROE tertinggi</span></div><div><b>${rank('perf3m')}</b><span>kinerja 3 bln</span></div><div><b>${rank('marketCap')}</b><span>kapitalisasi</span></div></div><div class="note">Dibanding ${peers.length} saham sektor ${esc(s.sector)} dalam daftar pantau.${pe.busy ? ' Memuat fundamental pembanding…' : ''}</div></div>
      <div class="card tbl-wrap" style="margin-top:10px"><table class="pt"><tr><th>Saham</th>${cols.map(([c, l]) => `<th data-ps="${c}" class="${c === k ? 'on' : ''}">${l}</th>`).join('')}</tr>
      ${rows.map((p) => `<tr class="${p.sym === s.sym ? 'me' : ''}" data-sym="${p.sym}"><td>${p.sym}</td>${cols.map(([c, , d]) => `<td>${fmtc(c, p.f[c], d)}</td>`).join('')}</tr>`).join('')}</table></div>
      <div class="note">Ketuk judul kolom untuk mengurutkan (P/E & P/B: termurah di atas). Ketuk baris untuk membuka saham.</div>`;
  }
  function secOwn(s) {
    if (!O.cur && !O.loading && !O.err) { O.useLatest().then(() => (O.cur ? null : O.load())).then(() => { if (isOpen($('#stock')) && sp.sec === 'own') drawSection(); }); return loading('Memuat data kepemilikan KSEI…'); }
    if (!X.ff && !X.ffBusy && !X.ffErr) X.loadForeign().then(() => { if (isOpen($('#stock')) && sp.sec === 'own') drawSection(); });
    let h = '';
    if (O.cur) { const x = O.stock(s.sym); if (x && x.rows.length) {
      const tc = { CP: '#B48CFF', ID: COL.up, IB: '#5AA9FF', MF: '#E9B949', IS: '#FF9B70', PF: '#7FDBCA', SC: '#F78FB3', FD: '#C7D36F', OT: COL.mut, '': '#5E7187' };
      const segs = Object.entries(x.byType).sort((a, b) => b[1] - a[1]);
      h += `<div class="card"><div class="kv"><div><b>${num(x.total1, 1)}%</b><span>dipegang pemilik ≥1%</span></div><div><b>±${num(x.floatEst, 0)}%</b><span>free float (perk.)</span></div><div><b>${num(x.foreign, 1)}%</b><span>asing ≥1%</span></div></div>
        <div class="stack">${segs.map(([t, v]) => `<i style="width:${v}%;background:${tc[t] || '#5E7187'}"></i>`).join('')}</div><div class="legend">${segs.map(([t, v]) => `<span style="--c:${tc[t] || '#5E7187'}">${esc(typeLbl(t))} ${num(v, 1)}%</span>`).join('')}</div>
        <div class="note">Data KSEI per ${esc(O.cur.date)}. Sisa ${num(100 - x.total1, 1)}% dipegang investor di bawah 1% (publik/ritel & institusi kecil).</div></div>
        ${x.changes.length ? `<h2>Perubahan vs ${esc(O.prev.date)}</h2><div class="list">${x.changes.map((c) => `<div class="row"><span><b>${esc(c.r.inv)}</b></span><span class="px ${c.d > 0 ? 'up' : 'dn'}">${c.d > 0 ? '+' : ''}${num(c.d, 2)}%</span><span class="chg sm">${c.kind}</span><span class="sub">${esc(typeLbl(c.r.type))}${c.dShares ? ` · ${c.dShares > 0 ? '+' : ''}${num(c.dShares / 1e6, 1)} jt lembar` : ''}</span><span></span><span></span></div>`).join('')}</div>` : ''}
        <h2>Pemegang ≥1%</h2><div class="list">${x.rows.map((r) => `<button class="row" data-msnet="inv:${esc(r.key)}"><span><b>${esc(r.inv)}</b></span><span class="px">${num(r.pct, 2)}%</span><span></span><span class="sub">${esc(typeLbl(r.type))}${r.lf === 'A' ? ' · asing' : ''} · ${num(r.shares / 1e6, 1)} jt lembar</span><span></span><span></span></button>`).join('')}</div>
        <div class="rowx" style="margin-top:8px"><button class="btn" data-msnet="stock:${s.sym}">Lihat jaringan pemilik</button></div>`; }
      else h += '<div class="card sm mut">Tidak ada pemegang ≥1% untuk saham ini di data KSEI terakhir.</div>'; }
    else h += `<div class="card sm mut">${esc(O.err || 'Data kepemilikan belum tersedia')}</div>`;
    const p = X.ff && X.ff.per.get(s.sym);
    h += `<h2>Inventory asing</h2>${p ? `<div class="card"><div class="kv"><div><b class="${p.n5 >= 0 ? 'up' : 'dn'}">${rp(p.n5)}</b><span>net 5 hari</span></div><div><b class="${p.n20 >= 0 ? 'up' : 'dn'}">${rp(p.n20)}</b><span>net 20 hari</span></div><div><b>${num(p.inv[p.inv.length - 1] / 100, 0)}</b><span>lot (kumulatif ${X.ff.days.length} hr)</span></div></div><div id="invChart" style="height:170px;margin-top:8px"></div><div class="note">Emas = kumulatif lembar yang diserap/dilepas asing; abu-abu = harga. Inventory naik saat harga turun sering menandakan akumulasi.</div></div>` : `<div class="card sm mut">${X.ffBusy ? 'Memuat data asing…' : esc(X.ffErr || 'Belum ada data asing untuk saham ini')}</div>`}`;
    return h;
  }
  function chartOwn(s) {
    const el = $('#invChart'); const p = X.ff && X.ff.per.get(s.sym); if (!el || !p || !window.LightweightCharts) return; const T = (d) => Date.UTC(+d.slice(0, 4), +d.slice(4, 6) - 1, +d.slice(6)) / 1000;
    const ch = LightweightCharts.createChart(el, { localization: { locale: 'id-ID' }, height: 170, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: COL.mut, fontSize: 11 }, grid: { vertLines: { visible: false }, horzLines: { color: COL.grid } }, rightPriceScale: { borderColor: COL.line }, leftPriceScale: { visible: true, borderColor: COL.line }, timeScale: { borderColor: COL.line }, handleScroll: false, handleScale: false });
    const a = ch.addLineSeries({ color: '#E9B949', lineWidth: 2, priceLineVisible: false, priceFormat: { type: 'custom', formatter: (v) => num(v / 100, 0) + ' lot' } }); a.setData(X.ff.days.map((d, i) => ({ time: T(d), value: p.inv[i] })));
    const b = ch.addLineSeries({ color: 'rgba(142,160,181,.8)', lineWidth: 1, priceScaleId: 'left', priceLineVisible: false }); b.setData(X.ff.days.map((d, i) => ({ time: T(d), value: p.c[i] })).filter((x) => ok(x.value) && x.value > 0)); ch.timeScale().fitContent();
  }
  function secFlow(s) {
    const tf = X.tradeFlow(s.cd, 60); const last = tf.bars[tf.bars.length - 1];
    const lab = (r) => (r >= 0.58 ? '<span class="up">dominan beli</span>' : r <= 0.42 ? '<span class="dn">dominan jual</span>' : 'seimbang');
    return `<div class="card"><div class="kv"><div><b>${num(tf.r5 * 100, 0)}%</b><span>porsi beli 5 hari · ${lab(tf.r5)}</span></div><div><b>${num(tf.r20 * 100, 0)}%</b><span>porsi beli 20 hari · ${lab(tf.r20)}</span></div><div><b class="${last.delta >= 0 ? 'up' : 'dn'}">${rp(last.delta)}</b><span>delta sesi terakhir</span></div></div>
      <div id="tfChart" style="height:190px;margin-top:8px"></div><div class="note">Batang = selisih perkiraan nilai beli dan jual per hari, garis = kumulatif. Perkiraan dari posisi close dalam range harian × volume (bukan data running trade/haka-haki).</div></div>
      <h2>Intraday hari ini</h2><div class="card" id="tfIntra"><span class="sm mut">Memuat candle 5 menit…</span></div>`;
  }
  function chartFlow(s) {
    const el = $('#tfChart'); if (el && window.LightweightCharts) { const tf = X.tradeFlow(s.cd, 60);
      const ch = LightweightCharts.createChart(el, { height: 190, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: COL.mut, fontSize: 11 }, grid: { vertLines: { visible: false }, horzLines: { color: COL.grid } }, rightPriceScale: { borderColor: COL.line }, leftPriceScale: { visible: false }, timeScale: { borderColor: COL.line }, handleScroll: false, handleScale: false, localization: { locale: 'id-ID', priceFormatter: (p) => A.fmtRp(p) } });
      const h = ch.addHistogramSeries({ priceLineVisible: false, lastValueVisible: false }); h.setData(tf.bars.map((b) => ({ time: b.t + 25200, value: b.delta, color: b.delta >= 0 ? COL.upA(.7) : COL.dnA(.7) })));
      const l = ch.addLineSeries({ color: '#E9B949', lineWidth: 2, priceScaleId: 'left', priceLineVisible: false, lastValueVisible: false }); l.setData(tf.bars.map((b) => ({ time: b.t + 25200, value: b.cum }))); ch.timeScale().fitContent(); }
    D.candles(s.sym, '5m').then((r) => { const box = $('#tfIntra'); if (!box) return; const cd = r.cd; const dk = (t) => Math.floor((t + 25200) / 86400); const L = cd.t.length - 1; let a = L; while (a > 0 && dk(cd.t[a - 1]) === dk(cd.t[L])) a--;
      const sub = { t: cd.t.slice(a), o: cd.o.slice(a), h: cd.h.slice(a), l: cd.l.slice(a), c: cd.c.slice(a), v: cd.v.slice(a) }; if (sub.c.length < 2) { box.innerHTML = '<span class="sm mut">Belum ada transaksi hari ini.</span>'; return; }
      const tf = X.tradeFlow(Object.assign({}, sub, { t: [sub.t[0] - 300, ...sub.t], o: [sub.o[0], ...sub.o], h: [sub.h[0], ...sub.h], l: [sub.l[0], ...sub.l], c: [sub.c[0], ...sub.c], v: [0, ...sub.v] }), sub.c.length); const tb = tf.bars.reduce((x, b) => x + b.buy, 0), ts = tf.bars.reduce((x, b) => x + b.sell, 0);
      box.innerHTML = `<div class="kv"><div><b>${num((tb / (tb + ts || 1)) * 100, 0)}%</b><span>porsi beli intraday</span></div><div><b class="${tb - ts >= 0 ? 'up' : 'dn'}">${rp(tb - ts)}</b><span>delta kumulatif</span></div><div><b>${new Date(sub.t[sub.t.length - 1] * 1000).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}</b><span>bar terakhir (tertunda)</span></div></div>`; }).catch((e) => { const box = $('#tfIntra'); if (box) box.innerHTML = `<span class="sm mut">${esc(e.message)}</span>`; });
  }
  function secRange(s) {
    const em = X.expectedMove(s.cd); if (!em) return '<div class="empty"><b>Riwayat belum cukup</b></div>'; const p = s.plan || {};
    const row = (h) => `<tr><td>${h.h} hari</td><td>${px(A.rt(h.lo68, 'down'))} – ${px(A.rt(h.hi68, 'up'))}<div class="sm mut">90%: ${px(A.rt(h.lo90, 'down'))} – ${px(A.rt(h.hi90, 'up'))}</div></td><td class="sm">${px(A.rt(h.e10))} – ${px(A.rt(h.e90))}</td></tr>`;
    const t1 = p.bias > 0 && p.targets ? p.targets[0] : NaN, t2 = p.bias > 0 && p.targets ? p.targets[1] : NaN; const pt = (x) => (ok(x) ? `${num(em.touch(x, 20) * 100, 0)}%` : '—');
    const h20 = em.H[2]; const verdict = !ok(t1) ? '' : t1 > h20.hi90 ? 'Target 1 di luar kisaran 90% dalam 20 hari — ambisius, butuh katalis.' : t1 > h20.hi68 ? 'Target 1 di luar kisaran normal (68%) tapi masih dalam 90% — mungkin, tidak mudah.' : 'Target 1 berada dalam kisaran gerak normal 20 hari — realistis.';
    return `<div class="card"><div class="kv"><div><b>${num(em.sd * 100, 2)}%</b><span>volatilitas harian (EWMA)</span></div><div><b>${num(em.annual, 0)}%</b><span>volatilitas tahunan</span></div><div><b>${num(em.pctl, 0)}</b><span>persentil vs 2 tahun</span></div></div></div>
      <h2>Kisaran gerak wajar</h2><div class="card"><table class="t"><tr><td class="sm mut">Horizon</td><td class="sm mut">68% (normal)</td><td class="sm mut">Historis 10–90%</td></tr>${em.H.map(row).join('')}</table>
      <div class="note">Kisaran 68% = ±1 standar deviasi dari volatilitas saat ini; kolom kanan dari distribusi return historis saham ini (2 tahun). Bukan prediksi arah.</div></div>
      ${p.bias > 0 ? `<h2>Realistis tidaknya rencana</h2><div class="card">${tbl([['Peluang menyentuh target 1 (20 hari)', pt(t1)], ['Peluang menyentuh target 2 (20 hari)', pt(t2)], ['Peluang menyentuh invalidasi (20 hari)', pt(p.invalid)]])}<div class="note">${esc(verdict)} Peluang dihitung dari volatilitas (model random walk tanpa arah) — gunakan untuk menilai jarak target, bukan arah harga.</div></div>` : ''}`;
  }

  // ---------------- rolling digits ----------------
  // numbers marked data-roll="<key>" animate digit-by-digit when their value changes between renders
  const rollMem = new Map(); const numOf = (t) => parseFloat(String(t).replace(/[^\d,.-]/g, '').replace(/\./g, '').replace(',', '.'));
  function rollAll(rootEl) {
    if (!rootEl) return; rootEl.querySelectorAll('[data-roll]').forEach((el) => {
      const k = el.dataset.roll, txt = el.textContent.trim(); const prev = rollMem.get(k); rollMem.set(k, txt);
      if (prev === undefined || prev === txt || noMotion() || el.dataset.rolling) return;
      const up = numOf(txt) >= numOf(prev); const a = prev.padStart(txt.length, ' ').slice(-txt.length);
      el.dataset.rolling = '1'; el.classList.add(up ? 'rollup' : 'rolldn');
      el.innerHTML = [...txt].map((ch, i) => (ch === a[i] || !/\d/.test(ch) ? esc(ch) : `<span class="rd" style="animation-delay:${i * 22}ms"><i>${esc(/\d/.test(a[i]) ? a[i] : '0')}</i><b>${esc(ch)}</b></span>`)).join('');
      setTimeout(() => { el.textContent = txt; el.classList.remove('rollup', 'rolldn'); delete el.dataset.rolling; }, 760);
    });
  }

  // ---------------- touch ripple ----------------
  document.addEventListener('pointerdown', (e) => {
    if (noMotion()) return; const b = e.target.closest('.btn, .tile, .seg button, #tabs button, .qa-g button, .preset'); if (!b || b.disabled) return;
    const r = b.getBoundingClientRect(); const d = Math.max(r.width, r.height) * 2; const sp2 = document.createElement('span'); sp2.className = 'rip';
    sp2.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`; b.appendChild(sp2); setTimeout(() => sp2.remove(), 520);
  }, { passive: true });

  // ---------------- GLOSSARY ("?") ----------------
  const GL = {
    rsi: [/\bRSI\b/, 'RSI', 'Mengukur kekuatan kenaikan dibanding penurunan (0–100). Di atas 70 jenuh beli, di bawah 30 jenuh jual. Rentang 50–70 biasanya tanda momentum naik yang sehat.'],
    macd: [/\bMACD\b/, 'MACD', 'Selisih dua EMA (12 dan 26). Histogram positif berarti momentum naik menguat; golden cross = garis MACD memotong signal ke atas.'],
    ema: [/\bEMA\b/, 'EMA', 'Rata-rata harga yang lebih berat ke data terbaru. EMA 20/50/200 tersusun naik (20 > 50 > 200) menandakan tren naik yang rapi.'],
    sma: [/\bSMA\b/, 'SMA', 'Rata-rata harga sederhana. SMA 200 sering dipakai sebagai garis pemisah tren jangka panjang.'],
    adx: [/\bADX\b|\+DI/, 'ADX & DI', 'ADX mengukur kekuatan tren (bukan arah). Di atas 25 = tren kuat. +DI di atas −DI berarti arah tren naik.'],
    atr: [/\bATR\b/, 'ATR', 'Rata-rata jarak gerak harian. Dipakai untuk menaruh stop dan target yang wajar sesuai karakter saham.'],
    vwap: [/VWAP/, 'VWAP', 'Harga rata-rata tertimbang volume. Di atas VWAP = pembeli lebih dominan pada periode itu. Anchored VWAP dihitung sejak titik tertentu (mis. swing low).'],
    rvol: [/RVOL|Relative volume/i, 'RVOL', 'Volume hari ini dibanding rata-rata 20 hari. 2x berarti dua kali lipat dari biasanya — tanda ada minat besar.'],
    bos: [/\bBOS\b|Break of structure/i, 'BOS (Break of Structure)', 'Harga menutup di atas swing high terakhir (atau di bawah swing low) searah tren. Konfirmasi tren berlanjut.'],
    choch: [/CHoCH|Change of character/i, 'CHoCH', 'Break of structure yang berlawanan arah tren sebelumnya — tanda awal tren berbalik.'],
    fvg: [/\bFVG\b|Fair value gap/i, 'FVG (Fair Value Gap)', 'Celah harga antara candle 1 dan 3 akibat gerak cepat. Harga sering kembali "mengisi" celah ini; FVG bullish yang disentuh bisa menjadi area beli.'],
    ob: [/Order block/i, 'Order block', 'Candle berlawanan terakhir sebelum gerak besar yang mematahkan struktur. Dianggap area tempat pemain besar masuk; sering jadi support/resistance saat di-retest.'],
    breaker: [/Breaker/i, 'Breaker block', 'Order block yang ditembus lalu berbalik fungsi (support jadi resistance atau sebaliknya).'],
    sweep: [/sweep|Stop hunt/i, 'Liquidity sweep', 'Harga menembus sebentar swing high/low (tempat banyak stop loss) lalu kembali. Sering terjadi sebelum pembalikan arah.'],
    eq: [/Equal high|Equal low|Equal highs/i, 'Equal highs / lows', 'Dua puncak atau dasar di level hampir sama. Menyimpan banyak stop order sehingga sering menjadi target sweep.'],
    pd: [/Premium|Discount/, 'Premium / discount', 'Posisi harga dalam rentang swing terakhir. Di bawah 50% = discount (relatif murah), di atas = premium (relatif mahal).'],
    disp: [/Displacement/i, 'Displacement', 'Candle dengan badan besar (≥1,3× ATR) — jejak pembelian/penjualan agresif.'],
    div: [/divergence/i, 'Divergence', 'Harga membuat titik ekstrem baru tetapi indikator (RSI/MACD/OBV) tidak mengikuti — momentum melemah, waspada pembalikan.'],
    obv: [/\bOBV\b/, 'OBV', 'Akumulasi volume hari naik dikurangi hari turun. OBV naik saat harga datar sering menandakan akumulasi diam-diam.'],
    cmf: [/\bCMF\b/, 'CMF', 'Chaikin Money Flow: positif berarti close cenderung di atas tengah range dengan volume — tekanan beli.'],
    mfi: [/\bMFI\b/, 'MFI', 'Money Flow Index: seperti RSI tetapi memakai volume. Di atas 80 jenuh beli, di bawah 20 jenuh jual.'],
    bb: [/Bollinger|%B/, 'Bollinger Bands', 'Pita ±2 standar deviasi dari SMA 20. Pita menyempit (squeeze) sering mendahului gerak besar.'],
    rs: [/RS Rating|Relative strength|RS vs/i, 'Relative Strength', 'Seberapa kuat saham dibanding saham lain/IHSG. RS Rating 90 = lebih kuat dari 90% saham di daftar pantau.'],
    rrg: [/RS-Ratio|RS-Momentum|RRG|Rotasi/i, 'Rotasi sektor (RRG)', 'Sumbu X = kekuatan relatif vs IHSG, sumbu Y = momentum kekuatan itu. Sektor biasanya berputar: Membaik → Memimpin → Melemah → Tertinggal.'],
    rr: [/R\/R|Risk\/reward|rata-rata R|kumulatif R/i, 'Risk/reward & R', 'Perbandingan potensi untung terhadap risiko. 1R = jarak entry ke invalidasi. R/R 2x berarti target dua kali jarak stop. "Bersih" = sudah dipotong biaya transaksi.'],
    inv: [/Invalidasi|Stop pengaman/i, 'Invalidasi / stop', 'Level yang jika ditembus (close) membuat alasan masuk tidak berlaku lagi. Batas kerugian yang direncanakan.'],
    ara: [/\bARA\b|\bARB\b/, 'ARA / ARB', 'Batas naik/turun harga harian dari BEI. Saat ini ARA 35/25/20% sesuai fraksi harga dan ARB 15%; mulai 2027 ARB mengikuti ARA (simetris).'],
    ppk: [/PPK|Papan Pemantauan/i, 'Papan Pemantauan Khusus', 'Papan untuk saham dengan kondisi tertentu (mis. ekuitas negatif). Diperdagangkan lewat full call auction — likuiditas dan pembentukan harga berbeda.'],
    ffl: [/Free float/i, 'Free float', 'Porsi saham yang beredar bebas di publik. Free float kecil = harga lebih mudah digerakkan sedikit pihak.'],
    breadth: [/Breadth|di atas EMA 50/i, 'Breadth', 'Seberapa banyak saham ikut naik. Indeks naik dengan breadth lemah berarti kenaikan hanya ditopang sedikit saham besar.'],
    mcc: [/McClellan/i, 'McClellan Oscillator', 'Selisih EMA 19 dan 39 dari (naik − turun). Positif = partisipasi pasar membaik.'],
    ad: [/A\/D/, 'A/D line', 'Kumulatif jumlah saham naik dikurangi turun (atau akumulasi/distribusi untuk satu saham).'],
    regime: [/Kondisi pasar|risk-on|risk-off/i, 'Kondisi pasar', 'Skor 0–100 dari tren IHSG, breadth, volatilitas, minat asing, rupiah, dan pasar global. Di bawah 40 risk-off: setup lebih sering gagal.'],
    score: [/Setup Score|Anatomi skor|Skor setup/i, 'Setup Score', 'Nilai 0–100 kualitas kondisi teknikal & fundamental sebuah setup. Bukan peluang profit — cek backtest untuk bukti historisnya.'],
    acc: [/akumulasi|distribusi|Bandar/i, 'Akumulasi / distribusi', 'Indikasi pemain besar mengumpulkan (akumulasi) atau melepas (distribusi), dibaca dari bukti harga–volume dan aliran asing. Bukan data broker.'],
    foreign: [/Net asing|Foreign net|Inventory asing|Foreign flow/i, 'Aliran asing', 'Selisih beli dan jual investor asing (data IDX, EOD). Inventory = akumulasi selisih itu dari waktu ke waktu.'],
    em: [/Kisaran gerak|volatilitas harian|volatilitas tahunan/i, 'Kisaran gerak', 'Perkiraan rentang harga wajar dari volatilitas saat ini. 68% berarti kira-kira 2 dari 3 periode harga berada di rentang itu.'],
    win: [/win rate/i, 'Win rate', 'Persentase trade yang untung. Harus dibaca bersama rata-rata R — win rate rendah bisa tetap untung jika untungnya besar.'],
    pf: [/profit factor/i, 'Profit factor', 'Total untung dibagi total rugi. Di atas 1,2 sudah menarik; di bawah 1 berarti strategi rugi.'],
    dd: [/drawdown/i, 'Max drawdown', 'Penurunan terbesar dari puncak ke lembah kurva hasil. Mengukur seberapa sakit strateginya di masa terburuk.'],
    poc: [/POC|value area/i, 'Volume profile', 'POC = harga dengan volume transaksi terbanyak. Value area = rentang tempat 70% volume terjadi.'],
    hh: [/HH \+ HL|higher high|LH \+ LL|Swing terakhir/i, 'HH / HL / LH / LL', 'Higher high & higher low = uptrend; lower high & lower low = downtrend. Dasar membaca struktur pasar.'],
    pe: [/P\/E/, 'P/E', 'Harga dibagi laba per saham. Makin kecil makin murah — bandingkan dengan sektornya, bukan angka absolut.'],
    pb: [/P\/B/, 'P/B', 'Harga dibagi nilai buku per saham. Di bawah 1 berarti dihargai di bawah nilai bukunya.'],
    roe: [/\bROE\b/, 'ROE', 'Laba bersih dibagi ekuitas. Di atas 15% tergolong efisien.'],
    eod: [/\bEOD\b|Tertunda/, 'EOD / Tertunda', 'Tertunda = harga dari sumber gratis telat ±10–15 menit. EOD = data penutupan final setelah bursa tutup.'],
  };
  const GLK = Object.keys(GL);
  function glossify(root) {
    if (!root) return;
    root.querySelectorAll('td:first-child, .kv span, .keyl > div > span, .pgrid span, .comp > span:nth-child(3n+1), h2, .regime .sm.mut').forEach((el) => {
      if (el.dataset.glx || el.closest('button,a,.gq')) return; el.dataset.glx = '1'; const t = el.textContent; if (!t || t.length > 90) return;
      const k = GLK.find((k2) => GL[k2][0].test(t)); if (!k) return; const b = document.createElement('button'); b.className = 'gq'; b.dataset.gl = k; b.textContent = '?'; b.setAttribute('aria-label', 'Penjelasan ' + GL[k][1]); el.appendChild(b);
    });
  }
  function openGlossary(k) {
    const el = $('#gl'); const g = GL[k]; if (!g) return; hap();
    el.innerHTML = `<div class="bs-bd" data-close></div><div class="bs-p"><div class="bs-h"><b>${esc(g[1])}</b><button class="icon" data-close aria-label="Tutup">✕</button></div><p>${esc(g[2])}</p><button class="tg" data-glall>Buka kamus lengkap</button></div>`; showLayer(el);
    el.onclick = (e) => { if (e.target.closest('[data-close]')) hideLayer(el); if (e.target.closest('[data-glall]')) openGlossaryList(); };
  }
  function openGlossaryList(q = '') {
    const el = $('#gl'); const items = GLK.filter((k) => !q || (GL[k][1] + ' ' + GL[k][2]).toLowerCase().includes(q.toLowerCase()));
    el.innerHTML = `<div class="bs-bd" data-close></div><div class="bs-p full"><div class="bs-h"><b>Kamus istilah</b><button class="icon" data-close aria-label="Tutup">✕</button></div><input id="glQ" class="srin" style="width:100%;text-transform:none" placeholder="Cari istilah" value="${esc(q)}"><div class="gll">${items.map((k) => `<div><b>${esc(GL[k][1])}</b><p>${esc(GL[k][2])}</p></div>`).join('')}</div></div>`; showLayer(el);
    el.onclick = (e) => { if (e.target.closest('[data-close]')) hideLayer(el); };
    const qi = $('#glQ'); qi.oninput = () => { const v = qi.value; openGlossaryList(v); const n = $('#glQ'); n.focus(); n.setSelectionRange(v.length, v.length); };
  }
  document.addEventListener('click', (e) => { const b = e.target.closest('.gq'); if (b) { e.preventDefault(); e.stopPropagation(); openGlossary(b.dataset.gl); } }, true);
  const glQueue = new Set(); const idle = window.requestIdleCallback || ((f) => setTimeout(f, 80));
  new MutationObserver((ms2) => {
    for (const m of ms2) for (const n of m.addedNodes) if (n.nodeType === 1 && !n.classList.contains('gq') && !n.classList.contains('rip') && n.closest('#view, #sec, #msBody, #bt, #cmp')) glQueue.add(n);
    if (glQueue.size && !glossify.pending) { glossify.pending = true; idle(() => { glossify.pending = false; const items = [...glQueue]; glQueue.clear(); for (const n of items) if (document.body.contains(n)) { glossify(n.parentElement || n); } }); }
  }).observe(document.body, { childList: true, subtree: true });

  // ---------------- QUICK ACTIONS (long press) ----------------
  let swallowClick = false, lpTimer = null, lpStart = null;
  function openQA(sym) {
    const el = $('#qa'); const s0 = E.getStock(sym); const inW = watch().includes(sym); const inP = E.P.list().some((x) => x.sym === sym); hap('long');
    el.innerHTML = `<div class="bs-bd" data-close></div><div class="bs-p"><div class="bs-h"><b class="sym">${sym}</b>${s0 ? `<span>${px(s0.f.close)} ${pct(s0.f.chg1d)}</span>` : ''}<span class="sp"></span><button class="icon" data-close aria-label="Tutup">✕</button></div>
      <div class="qa-g">${[['open', '↗', 'Buka detail'], ['watch', inW ? '★' : '☆', inW ? 'Hapus dari watchlist' : 'Tambah ke watchlist'], ['port', '◫', inP ? 'Ubah posisi' : 'Tambah ke portofolio'], ['cmp', '⇆', 'Bandingkan'], ['share', '⇪', 'Bagikan gambar'], ['copy', '⧉', 'Salin kode']].map(([k, ic, l]) => `<button data-qa="${k}"><span>${ic}</span>${l}</button>`).join('')}</div></div>`;
    showLayer(el);
    el.onclick = async (e) => {
      if (e.target.closest('[data-close]')) { hideLayer(el); return; } const b = e.target.closest('[data-qa]'); if (!b) return; hideLayer(el); const k = b.dataset.qa;
      if (k === 'open') openStock(sym);
      if (k === 'watch') { const w = watch(); setWatch(inW ? w.filter((x) => x !== sym) : [...w, sym]); toast(inW ? `${sym} dihapus dari watchlist` : `${sym} ditambahkan ke watchlist`); hap('confirm'); render(); }
      if (k === 'port') { const has = E.P.list().find((x) => x.sym === sym); if (isOpen($('#stock'))) closeStock(); st.pw = 'port'; st.portForm = has ? Object.assign({ edit: true }, has) : { sym }; $('#tabs button[data-tab="watch"]').click(); }
      if (k === 'cmp') openCompare(sym);
      if (k === 'share') { try { shareStock(E.getStock(sym) || (await E.ensureStock(sym))); } catch (err) { toast(err.message); } }
      if (k === 'copy') { try { await navigator.clipboard.writeText(sym); toast('Kode disalin'); } catch (err) { toast(sym); } }
    };
  }
  // after a long press, swallow only the synthetic click that may follow on the same row (never clicks inside the action sheet)
  let swallowEl = null;
  const longPress = (t) => { if (isOpen($('#qa'))) return; swallowEl = t; swallowClick = true; setTimeout(() => { swallowClick = false; swallowEl = null; }, 900); openQA(t.dataset.sym || t.dataset.go); };
  document.addEventListener('touchstart', (e) => { const t = e.target.closest('[data-sym],[data-go]'); if (!t || e.touches.length > 1 || t.closest('#qa')) return; lpStart = { x: e.touches[0].clientX, y: e.touches[0].clientY }; clearTimeout(lpTimer); lpTimer = setTimeout(() => longPress(t), 520); }, { passive: true });
  document.addEventListener('touchmove', (e) => { if (lpStart && (Math.abs(e.touches[0].clientX - lpStart.x) > 10 || Math.abs(e.touches[0].clientY - lpStart.y) > 10)) clearTimeout(lpTimer); }, { passive: true });
  document.addEventListener('touchend', () => clearTimeout(lpTimer), { passive: true });
  document.addEventListener('contextmenu', (e) => { const t = e.target.closest('[data-sym],[data-go]'); if (t && !t.closest('#qa')) { e.preventDefault(); longPress(t); } });
  document.addEventListener('click', (e) => { if (swallowClick && swallowEl && swallowEl.contains(e.target)) { swallowClick = false; swallowEl = null; e.preventDefault(); e.stopPropagation(); } }, true);

  // ---------------- INTERACTIVE GESTURES ----------------
  // 1) swipe from the left edge closes the top full-screen page, following the finger 1:1
  // 2) drag a bottom sheet down to dismiss it
  const EDGE_MIN = 10, EDGE_MAX = 44; const FULL = ['fs', 'search', 'settings', 'reader', 'bt', 'cmp', 'stock', 'ms'];
  const topLayer = () => { for (const [id] of LAYERS) { const el = $('#' + id); if (isOpen(el)) return el; } return null; };
  let gest = null;
  const vel = (g) => { const a = g.pts[0], b = g.pts[g.pts.length - 1]; const dt = Math.max(1, b.t - a.t); return ((g.axis === 'x' ? b.x - a.x : b.y - a.y) / dt) * 1000; };
  document.addEventListener('touchstart', (e) => {
    if (e.touches.length !== 1 || noMotion()) return; const t = e.touches[0]; const top0 = topLayer(); if (!top0) return;
    if (top0.classList.contains('bsheet')) { const p = top0.querySelector('.bs-p'); if (p && p.contains(e.target) && p.scrollTop <= 0 && !e.target.closest('input,textarea,select')) gest = { el: top0, axis: 'y', x0: t.clientX, y0: t.clientY, on: false, pts: [] }; return; }
    if (top0.id === 'fs') return;
    if (FULL.includes(top0.id) && t.clientX >= EDGE_MIN && t.clientX <= EDGE_MAX && top0.id !== 'reader') gest = { el: top0, axis: 'x', x0: t.clientX, y0: t.clientY, on: false, pts: [], edge: true };
  }, { passive: true });
  document.addEventListener('touchmove', (e) => {
    if (!gest) return; const t = e.touches[0]; const dx = t.clientX - gest.x0, dy = t.clientY - gest.y0;
    if (!gest.on) { if (gest.axis === 'x' ? dx > 8 && Math.abs(dx) > Math.abs(dy) * 1.2 : dy > 8 && Math.abs(dy) > Math.abs(dx)) { gest.on = true; gestureActive = true; clearTimeout(lpTimer); } else if (Math.abs(dx) > 12 || Math.abs(dy) > 12) { gest = null; return; } else return; }
    if (e.cancelable) e.preventDefault();
    gest.pts.push({ t: Date.now(), x: t.clientX, y: t.clientY }); if (gest.pts.length > 5) gest.pts.shift();
    R.MO.drag(gest.el, gest.axis === 'x' ? dx : dy);
  }, { passive: false });
  const endGest = () => { if (!gest) return; const g = gest; gest = null; if (!g.on) return; setTimeout(() => { gestureActive = false; }, 50);
    const closing = R.MO.release(g.el, g.pts.length > 1 ? vel(g) : 0); if (closing) { hap(); afterClose(g.el); } };
  document.addEventListener('touchend', endGest, { passive: true }); document.addEventListener('touchcancel', endGest, { passive: true });
  let gestureActive = false;
  // bookkeeping the regular close functions do (they are skipped when a gesture closed the layer)
  function afterClose(el) {
    if (el.id === 'stock') { sp.tool = null; sp.tPend = null; const ch0 = sp.chart; setTimeout(() => { if (!isOpen($('#stock')) && sp.chart === ch0) { try { ch0 && ch0.remove(); } catch (e) {} sp.chart = null; } }, 500); if (st.tab === 'watch') rWatch(); }
    if (el.id === 'bt' && B.running && B.owner === 'user') B.abort = true;
    if (el.id === 'reader') rdr.id = null;
    if (el.id === 'search') setTimeout(() => { if (!isOpen($('#search'))) searchPick = null; }, 0);
  }

  // ---------------- PULL TO REFRESH ----------------
  let ptr = null;
  root.addEventListener('touchstart', (e) => { if (gest || window.scrollY > 0 || document.body.style.overflow === 'hidden') return; ptr = { y: e.touches[0].clientY, x: e.touches[0].clientX, d: 0 }; }, { passive: true });
  root.addEventListener('touchmove', (e) => { if (!ptr) return; const dy = e.touches[0].clientY - ptr.y, dx = Math.abs(e.touches[0].clientX - ptr.x); if (dx > dy) { ptr = null; $('#ptr').style.transform = ''; $('#ptr').style.opacity = ''; return; } ptr.d = Math.max(0, Math.min(120, dy)); const el = $('#ptr'); el.style.opacity = ptr.d > 8 ? Math.min(1, ptr.d / 60) : 0; el.style.transform = `translateY(${ptr.d - 50}px) rotate(${ptr.d * 2.2}deg)`; el.classList.toggle('ready', ptr.d > 80); }, { passive: true });
  root.addEventListener('touchend', () => { if (!ptr) return; const go = ptr.d > 80; ptr = null; const el = $('#ptr'); el.style.transform = ''; el.style.opacity = ''; el.classList.remove('ready'); if (!go) return; hap('confirm');
    if (st.tab === 'news') { N.load({ force: true }).then(() => st.tab === 'news' && rNews()); toast('Memperbarui berita…'); }
    else if (st.tab === 'radar') Rd.tick();
    else if (st.tab === 'screener' && st.results) runScreener();
    else scan(true); });

  // ---------------- SWIPE BETWEEN STOCKS ----------------
  let pendingCtx = null; let sw = null;
  const stockEl = $('#stock');
  stockEl.addEventListener('touchstart', (e) => { if (e.touches[0].clientX <= EDGE_MAX || e.target.closest('#chart,.seg,.tbl-wrap,input,.rrg,.net,table.pt')) { sw = null; return; } sw = { x: e.touches[0].clientX, y: e.touches[0].clientY, t: Date.now() }; }, { passive: true });
  stockEl.addEventListener('touchend', (e) => { if (gestureActive) { sw = null; return; } if (!sw || !sp.ctx) return; const t = e.changedTouches[0]; const dx = t.clientX - sw.x, dy = t.clientY - sw.y; const ok2 = Math.abs(dx) > 90 && Math.abs(dy) < 60 && Date.now() - sw.t < 650; sw = null; if (!ok2) return; stepStock(dx < 0 ? 1 : -1); }, { passive: true });
  function stepStock(d) { const i = sp.ctx.indexOf(sp.sym); const j = i + d; if (j < 0 || j >= sp.ctx.length) { hap('reject'); toast(d > 0 ? 'Saham terakhir di daftar ini' : 'Saham pertama di daftar ini'); return; } hap(); pendingCtx = sp.ctx; const keep = sp.sec; openStock(sp.ctx[j]).then(() => { if (!sp.isIndex) { sp.sec = keep; R.UI.setSec(keep); } }); }
  const ctxFrom = (t) => { const root = t.closest('.list, #results, .secm, table, .imp') || t.closest('#view, #msBody, #sec') || view; return [...new Set([...root.querySelectorAll('[data-sym],[data-go]')].map((x) => x.dataset.sym || x.dataset.go).filter((x) => /^[A-Z0-9]{4}$/.test(x)))]; };
  document.addEventListener('click', (e) => { const t = e.target.closest('[data-sym],[data-go]'); if (t && !(swallowClick && swallowEl && swallowEl.contains(e.target))) { const c = ctxFrom(t); pendingCtx = c.length > 1 ? c : null; } }, true);

  // ---------------- DASHBOARD PINS (Pasar) ----------------
  const PINS = [['port', 'Ringkasan portofolio'], ['watch', 'Watchlist'], ['picks', 'AI Picks teratas']];
  function pinsHtml() {
    const pins = D.settings.pins || []; const saved = D.lsGet('rb.screens', []); let h = '';
    if (st.dashEdit) h += `<div class="card"><b style="font-family:var(--fd)">Atur dashboard</b>${[...PINS, ...saved.map((x, i) => ['scr:' + i, 'Screener: ' + x.name])].map(([k, l]) => `<div class="fld"><input type="checkbox" class="sw" data-pin="${k}" ${pins.includes(k) ? 'checked' : ''}><label>${esc(l)}</label></div>`).join('')}<div class="rowx" style="margin-top:8px"><button class="btn pri" data-act="dash-done">Selesai</button></div><div class="note">Bagian yang dipilih tampil paling atas di tab Pasar.</div></div>`;
    for (const k of pins) {
      if (k === 'port') { const list = E.P.list(); if (!list.length) continue; const rows = list.map((p0) => { const s1 = E.getStock(p0.sym); return s1 ? { p0, s1, a: E.P.assess(s1, p0) } : null; }).filter(Boolean).sort((a, b) => a.a.sev - b.a.sev);
        h += `<div class="card dash"><div class="rowx"><b>Portofolio</b><span class="sp"></span><button class="tg" data-act="tab:watch">Buka ›</button></div>${rows.slice(0, 5).map((r) => `<button class="drow" data-sym="${r.p0.sym}"><b>${r.p0.sym}</b><span class="act ${toneCls[r.a.tone]}">${r.a.action}</span><span class="sp"></span>${r.a.pl ? `<span class="${r.a.pl.pct >= 0 ? 'up' : 'dn'}">${r.a.pl.pct >= 0 ? '+' : ''}${num(r.a.pl.pct, 1)}%</span>` : pct(r.s1.f.chg1d)}</button>`).join('')}</div>`; }
      if (k === 'watch') { const w = watch(); if (!w.length) continue; h += `<div class="card dash"><div class="rowx"><b>Watchlist</b><span class="sp"></span><button class="tg" data-act="tab:watch">Buka ›</button></div><div class="wchips">${w.slice(0, 8).map((sym) => { const s1 = E.getStock(sym); return `<button data-sym="${sym}"><b>${sym}</b><span>${s1 ? px(s1.f.close) : '—'}</span>${s1 ? pct(s1.f.chg1d, 1) : ''}</button>`; }).join('')}</div></div>`; }
      if (k === 'picks' && E.snap) { const all = E.PICK_CATS.filter((c) => c.id !== 'risk').flatMap((c) => E.picks(c.id, { strict: true })).filter((x, i, a) => a.indexOf(x) === i).sort((a, b) => b.f.score - a.f.score).slice(0, 3);
        h += `<div class="card dash"><div class="rowx"><b>AI Picks teratas</b><span class="sp"></span><button class="tg" data-act="tab:picks">Buka ›</button></div>${all.length ? all.map((x) => `<button class="drow" data-sym="${x.sym}"><b>${x.sym}</b><span class="chip y">${esc(x.plan.type.split(' (')[0])}</span><span class="sp"></span><span class="score ${scoreCls(x.f.score)}">${x.f.score}</span></button>`).join('') : '<div class="sm mut">Belum ada pick yang lolos syarat kondisi pasar.</div>'}</div>`; }
      if (k.startsWith('scr:')) { const i = +k.slice(4); const sv = saved[i]; if (!sv) continue; const c = (st.scrCache || {})[i];
        h += `<div class="card dash"><div class="rowx"><b>${esc(sv.name)}</b><span class="sp"></span><button class="tg" data-runpin="${i}">${c && c.busy ? 'Memindai…' : 'Jalankan'}</button></div>${c && c.res ? (c.res.length ? c.res.slice(0, 5).map((x) => `<button class="drow" data-sym="${x.sym}"><b>${x.sym}</b><span class="sm mut">${esc(x.plan.type.split(' (')[0])}</span><span class="sp"></span>${pct(x.f.chg1d)}</button>`).join('') + `<div class="sm mut">${c.res.length} saham lolos · ${when(c.t)}</div>` : '<div class="sm mut">Tidak ada saham yang lolos.</div>') : '<div class="sm mut">Ketuk Jalankan untuk memindai.</div>'}</div>`; }
    }
    return h;
  }
  function bindPins() {
    view.querySelectorAll('[data-pin]').forEach((x) => (x.onchange = () => { const pins = new Set(D.settings.pins || []); x.checked ? pins.add(x.dataset.pin) : pins.delete(x.dataset.pin); D.settings.pins = [...pins]; D.saveSettings(); }));
    view.querySelectorAll('[data-runpin]').forEach((b) => (b.onclick = async (e) => { e.stopPropagation(); const i = +b.dataset.runpin; const sv = D.lsGet('rb.screens', [])[i]; st.scrCache = st.scrCache || {}; st.scrCache[i] = { busy: true }; rMarket();
      try { const res = await Sc.run(sv.tree, {}); st.scrCache[i] = { res: res.sort((a, b) => b.f.score - a.f.score), t: Date.now() }; } catch (err) { st.scrCache[i] = null; toast(err.message); } if (st.tab === 'market') rMarket(); }));
  }

  // ---------------- COMPARE ----------------
  const cmp = { a: null, b: null, per: 63 };
  let searchPick = null;
  function openCompare(a, b) {
    cmp.a = a; if (!b) { searchPick = (sym) => openCompare(a, sym); openSearch(); toast(`Pilih saham pembanding untuk ${a === '^JKSE' ? 'IHSG' : a}`); return; }
    cmp.b = b; const el = $('#cmp'); showLayer(el); drawCompare();
  }
  async function cmpStock(sym) { if (sym === '^JKSE') { const r = E.snap ? E.snap.ihsg : await D.candles('^JKSE', 'D'); const F0 = F.compute(r.cd, { daily: true }); return { sym, sector: 'Indeks', cd: r.cd, f: F0.f, F: F0, plan: { type: 'Indeks', bias: 0 }, meta: r.meta }; } return E.getStock(sym) || E.ensureStock(sym); }
  async function drawCompare() {
    const el = $('#cmp'); el.innerHTML = `<div class="sh-h"><button class="icon" id="cmpBack" aria-label="Kembali">←</button><b style="font-family:var(--fd)">Bandingkan</b></div><div class="sh-b">${skel(3)}</div>`; $('#cmpBack').onclick = closeCompare;
    let A1, B1; try { [A1, B1] = await Promise.all([cmpStock(cmp.a), cmpStock(cmp.b)]); } catch (e) { el.querySelector('.sh-b').innerHTML = emptyState('Tidak bisa membandingkan', esc(e.message)); return; }
    const nm = (x) => (x.sym === '^JKSE' ? 'IHSG' : x.sym); const P2 = (x) => (x.sym === '^JKSE' ? (v) => num(v, 2) : A.fmt);
    const rows = [['Harga', (x) => P2(x)(x.f.close), null], ['Hari ini', (x) => pct(x.f.chg1d), (x) => x.f.chg1d], ['1 bulan', (x) => pct(x.f.perf1m, 1), (x) => x.f.perf1m], ['3 bulan', (x) => pct(x.f.perf3m, 1), (x) => x.f.perf3m], ['1 tahun', (x) => pct(x.f.perf1y, 1), (x) => x.f.perf1y],
      ['RS Rating', (x) => (ok(x.f.rsRating) ? x.f.rsRating : '—'), (x) => x.f.rsRating], ['Setup Score', (x) => (ok(x.f.score) ? x.f.score : '—'), (x) => x.f.score], ['Setup', (x) => esc((x.plan.type || '—').split(' (')[0]), null], ['Tren', (x) => (x.f.hhhl ? 'Naik' : x.f.lhll ? 'Turun' : 'Sideways'), null],
      ['RSI', (x) => num(x.f.rsi, 0), null], ['Volatilitas (ATR%)', (x) => num(x.f.atrPct, 2) + '%', (x) => -x.f.atrPct], ['Jarak dari high 52 mgg', (x) => pct(-x.f.dist52wHigh, 1), (x) => -x.f.dist52wHigh], ['Akumulasi', (x) => (ok(x.f.accumScore) ? x.f.accumScore : '—'), (x) => x.f.accumScore],
      ['P/E', (x) => (ok(x.f.pe) ? num(x.f.pe, 1) + 'x' : '—'), (x) => (x.f.pe > 0 ? -x.f.pe : NaN)], ['P/B', (x) => (ok(x.f.pb) ? num(x.f.pb, 2) + 'x' : '—'), (x) => (x.f.pb > 0 ? -x.f.pb : NaN)], ['ROE', (x) => (ok(x.f.roe) ? num(x.f.roe, 1) + '%' : '—'), (x) => x.f.roe], ['Dividend yield', (x) => (ok(x.f.divYield) ? num(x.f.divYield, 1) + '%' : '—'), (x) => x.f.divYield]];
    const better = (fn) => { if (!fn) return [0, 0]; const a = fn(A1), b = fn(B1); if (!ok(a) || !ok(b) || a === b) return [0, 0]; return a > b ? [1, 0] : [0, 1]; };
    el.querySelector('.sh-b').innerHTML = `<div class="cmp-h"><button data-sym="${A1.sym}"><b>${nm(A1)}</b><span>${esc(A1.sector)}</span></button><span>vs</span><button data-sym="${B1.sym}"><b>${nm(B1)}</b><span>${esc(B1.sector)}</span></button></div>
      <div class="seg" id="cmpPer">${[[21, '1 bln'], [63, '3 bln'], [126, '6 bln'], [250, '1 thn']].map(([k, l]) => `<button data-p="${k}" class="${cmp.per === k ? 'on' : ''}">${l}</button>`).join('')}</div>
      <div class="card" style="margin-top:10px;position:relative"><div id="cmpChart" style="height:220px"></div><div class="legend" style="margin-top:6px"><span style="--c:#E9B949">${nm(A1)}</span><span style="--c:#5AA9FF">${nm(B1)}</span></div></div>
      <div class="card" style="margin-top:10px"><table class="t cmpt"><tr><td class="sm mut">Metrik</td><td class="sm mut">${nm(A1)}</td><td class="sm mut">${nm(B1)}</td></tr>${rows.map(([l, f2, fn]) => { const [ba, bb] = better(fn); return `<tr><td>${l}</td><td class="${ba ? 'win' : ''}">${f2(A1)}</td><td class="${bb ? 'win' : ''}">${f2(B1)}</td></tr>`; }).join('')}</table><div class="note">Sorotan emas = lebih baik di metrik itu (untuk P/E, P/B, dan volatilitas: lebih kecil lebih baik).</div></div>
      <div class="rowx" style="margin-top:10px"><button class="btn" id="cmpSwap">Ganti pembanding</button><button class="btn" id="cmpIhsg">vs IHSG</button></div>`;
    $('#cmpPer').onclick = (e) => { const b = e.target.closest('[data-p]'); if (b) { cmp.per = +b.dataset.p; drawCompare(); } };
    $('#cmpSwap').onclick = () => { closeCompare(); openCompare(cmp.a); }; $('#cmpIhsg').onclick = () => openCompare(cmp.a, '^JKSE');
    el.querySelector('.cmp-h').onclick = (e) => { const b = e.target.closest('[data-sym]'); if (b && b.dataset.sym !== '^JKSE') { closeCompare(); openStock(b.dataset.sym); } else if (b) { closeCompare(); openStock('^JKSE'); } };
    if (window.LightweightCharts) { const ch = LightweightCharts.createChart($('#cmpChart'), { height: 220, layout: { attributionLogo: false, background: { color: 'transparent' }, textColor: COL.mut, fontSize: 11 }, grid: { vertLines: { visible: false }, horzLines: { color: COL.grid } }, rightPriceScale: { borderColor: COL.line }, timeScale: { borderColor: COL.line }, handleScroll: false, handleScale: false, localization: { locale: 'id-ID', priceFormatter: (v) => `${v >= 0 ? '+' : ''}${num(v, 1)}%` } });
      const line = (x, color) => { const cd = x.cd, n = cd.c.length, k0 = Math.max(0, n - 1 - cmp.per); const base = cd.c[k0]; const ls = ch.addLineSeries({ color, lineWidth: 2, priceLineVisible: false }); ls.setData(cd.t.slice(k0).map((t, i) => ({ time: Math.floor((t + 25200) / 86400) * 86400, value: ((cd.c[k0 + i] - base) / base) * 100 }))); };
      line(A1, '#E9B949'); line(B1, '#5AA9FF'); ch.timeScale().fitContent(); }
  }
  function closeCompare() { hideLayer($('#cmp')); }

  // ---------------- SHARE AS IMAGE ----------------
  async function shareStock(s0, kind) {
    if (!s0) return; hap();
    try { await Promise.all([document.fonts.load('800 46px "Bricolage Grotesque"'), document.fonts.load('600 40px "IBM Plex Sans Condensed"'), document.fonts.load('500 28px "IBM Plex Sans"')]); } catch (e) {}
    const W = 1080, H = 1350, c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d');
    const bg = cssv('--bg'), s1c = cssv('--s1'), tx = cssv('--tx'), mut = cssv('--mut'), gold = cssv('--gold') || '#E9B949', up = COL.up, dn = COL.dn, line = cssv('--line');
    const isIdx = s0.sym === '^JKSE'; const f = s0.f, cd = s0.cd, p = s0.plan || {}; const fmtP = isIdx ? (v) => num(v, 2) : A.fmt;
    g.fillStyle = bg; g.fillRect(0, 0, W, H); const rg = g.createRadialGradient(W - 120, 120, 10, W - 120, 120, 620); rg.addColorStop(0, 'rgba(233,185,73,.16)'); rg.addColorStop(1, 'rgba(233,185,73,0)'); g.fillStyle = rg; g.fillRect(0, 0, W, H);
    // brand
    g.save(); g.translate(64, 56); g.scale(0.62, 0.62); const grad = g.createLinearGradient(0, 17, 0, 112); grad.addColorStop(0, '#F7D888'); grad.addColorStop(1, '#D4932A'); g.fillStyle = grad;
    ['M53 60 C35 60 18 49 16 17 C22 19 21 26 24 33 C30 45 41 49 53 49 Z', 'M67 60 C85 60 102 49 104 17 C98 19 99 26 96 33 C90 45 79 49 67 49 Z'].forEach((d) => g.fill(new Path2D(d))); g.fillRect(58.75, 34, 2.5, 78); g.beginPath(); g.roundRect ? g.roundRect(51, 45, 18, 48, 3.5) : g.rect(51, 45, 18, 48); g.fill(); g.restore();
    g.fillStyle = tx; g.font = '800 44px "Bricolage Grotesque", sans-serif'; g.fillText('Yoo Haw', 148, 108);
    g.fillStyle = mut; g.font = '500 26px "IBM Plex Sans", sans-serif'; g.textAlign = 'right'; g.fillText(new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }), W - 64, 104); g.textAlign = 'left';
    // headline
    g.fillStyle = tx; g.font = '600 104px "IBM Plex Sans Condensed", sans-serif'; g.fillText(isIdx ? 'IHSG' : s0.sym, 64, 262);
    g.fillStyle = mut; g.font = '500 30px "IBM Plex Sans", sans-serif'; g.fillText(((s0.meta && s0.meta.name) || '').slice(0, 42) + (isIdx ? '' : ' · ' + s0.sector), 64, 310);
    g.textAlign = 'right'; g.fillStyle = tx; g.font = '600 72px "IBM Plex Sans Condensed", sans-serif'; g.fillText(fmtP(f.close), W - 64, 250); g.fillStyle = f.chg1d >= 0 ? up : dn; g.font = '600 38px "IBM Plex Sans Condensed", sans-serif'; g.fillText(`${f.chg1d >= 0 ? '▲ +' : '▼ '}${num(f.chg1d, 2)}%`, W - 64, 302); g.textAlign = 'left';
    // candles (last 70 daily bars) + EMA20 + plan levels
    const n = cd.c.length, k0 = Math.max(0, n - 70), X0 = 64, Y0 = 360, CW = W - 128, CH = 520; let hi = -Infinity, lo = Infinity; for (let i = k0; i < n; i++) { hi = Math.max(hi, cd.h[i]); lo = Math.min(lo, cd.l[i]); }
    const lv = []; if (p.bias > 0) { lv.push([p.entry[0], gold], [p.entry[1], gold], [p.invalid, dn], [p.targets[0], up]); } lv.forEach(([v]) => { if (ok(v)) { hi = Math.max(hi, v); lo = Math.min(lo, v); } }); const pad = (hi - lo) * 0.06; hi += pad; lo -= pad;
    const Y = (v) => Y0 + CH - ((v - lo) / (hi - lo)) * CH; const bw = CW / (n - k0);
    g.fillStyle = s1c; g.globalAlpha = 0.6; g.fillRect(X0 - 16, Y0 - 16, CW + 32, CH + 32); g.globalAlpha = 1;
    if (p.bias > 0) { g.fillStyle = 'rgba(233,185,73,.12)'; g.fillRect(X0, Y(p.entry[1]), CW, Y(p.entry[0]) - Y(p.entry[1])); }
    for (let i = k0; i < n; i++) { const x = X0 + (i - k0) * bw + bw / 2; const upB = cd.c[i] >= cd.o[i]; g.strokeStyle = g.fillStyle = upB ? up : dn; g.lineWidth = 2; g.beginPath(); g.moveTo(x, Y(cd.h[i])); g.lineTo(x, Y(cd.l[i])); g.stroke(); const yo = Y(cd.o[i]), yc = Y(cd.c[i]); g.fillRect(x - bw * 0.32, Math.min(yo, yc), bw * 0.64, Math.max(2, Math.abs(yc - yo))); }
    const e20 = I.ema(cd.c, 20); g.strokeStyle = '#5AA9FF'; g.lineWidth = 3; g.beginPath(); for (let i = k0; i < n; i++) { const x = X0 + (i - k0) * bw + bw / 2; if (!ok(e20[i])) continue; i === k0 ? g.moveTo(x, Y(e20[i])) : g.lineTo(x, Y(e20[i])); } g.stroke();
    g.setLineDash([12, 10]); g.lineWidth = 2.5; g.font = '600 24px "IBM Plex Sans", sans-serif'; for (const [v, col, lab] of p.bias > 0 ? [[p.invalid, dn, 'Invalidasi'], [p.targets[0], up, 'Target 1']] : []) { if (!ok(v)) continue; g.strokeStyle = col; g.beginPath(); g.moveTo(X0, Y(v)); g.lineTo(X0 + CW, Y(v)); g.stroke(); g.fillStyle = col; g.fillText(`${lab} ${fmtP(v)}`, X0 + 8, Y(v) - 10); } g.setLineDash([]);
    // key boxes
    const boxes = p.bias > 0 ? [['Area entry', `${fmtP(p.entry[0])}–${fmtP(p.entry[1])}`, gold], ['Invalidasi', fmtP(p.invalid), dn], ['Target 1', p.targets[0] ? fmtP(p.targets[0]) : '—', up]] : [['Support', s0.F.st.levels.supports[0] ? fmtP(s0.F.st.levels.supports[0].price) : '—', up], ['Resistance', s0.F.st.levels.resistances[0] ? fmtP(s0.F.st.levels.resistances[0].price) : '—', dn], ['RSI', num(f.rsi, 0), gold]];
    const bwid = (W - 128 - 32) / 3; boxes.forEach(([l, v, col], i) => { const x = 64 + i * (bwid + 16), y = 930; g.fillStyle = s1c; g.fillRect(x, y, bwid, 150); g.fillStyle = col; g.fillRect(x, y, bwid, 6); g.fillStyle = mut; g.font = '500 26px "IBM Plex Sans", sans-serif'; g.fillText(l, x + 22, y + 52); g.fillStyle = col; let fs2 = 46; do { g.font = `600 ${fs2}px "IBM Plex Sans Condensed", sans-serif`; fs2 -= 2; } while (g.measureText(v).width > bwid - 40 && fs2 > 24); g.fillText(v, x + 22, y + 116); });
    g.fillStyle = tx; g.font = '600 34px "IBM Plex Sans", sans-serif'; g.fillText(isIdx ? `Kondisi pasar: ${M.regime ? M.regime.label + ' (' + M.regime.score + ')' : '—'}` : `${(p.type || '').split(' (')[0]}${ok(f.score) ? ' · Skor ' + f.score : ''}${ok(p.rrNet) && p.bias > 0 ? ' · R/R ' + p.rrNet + 'x' : ''}`, 64, 1150);
    g.fillStyle = mut; g.font = '500 25px "IBM Plex Sans", sans-serif'; g.fillText(`${f.hhhl ? 'Uptrend' : f.lhll ? 'Downtrend' : 'Sideways'} · RSI ${num(f.rsi, 0)} · RVOL ${num(f.rvol, 1)}x · ${M.regime ? 'Pasar ' + M.regime.label.toLowerCase() : ''}`, 64, 1194);
    g.strokeStyle = line; g.lineWidth = 2; g.beginPath(); g.moveTo(64, 1236); g.lineTo(W - 64, 1236); g.stroke();
    g.fillStyle = mut; g.font = '500 22px "IBM Plex Sans", sans-serif'; g.fillText(`Data ${s0.meta && s0.meta.status === 'eod' ? 'EOD' : 'tertunda'} · analisis otomatis berbasis aturan · bukan rekomendasi investasi`, 64, 1280);
    const url = c.toDataURL('image/png'); const text = isIdx ? `IHSG ${fmtP(f.close)} (${num(f.chg1d, 2)}%) — via Yoo Haw` : `${s0.sym} · ${(p.type || '').split(' (')[0]}${p.bias > 0 ? ` · entry ${fmtP(p.entry[0])}–${fmtP(p.entry[1])} · invalidasi ${fmtP(p.invalid)} · T1 ${fmtP(p.targets[0])}` : ''} — via Yoo Haw`;
    if (window.AndroidBridge && window.AndroidBridge.shareImage) { window.AndroidBridge.shareImage(url.split(',')[1], text); return; }
    try { const blob = await (await fetch(url)).blob(); const file = new File([blob], `yoohaw-${s0.sym}.png`, { type: 'image/png' }); if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], text }); return; } } catch (e) {}
    const a = document.createElement('a'); a.href = url; a.download = `yoohaw-${isIdx ? 'IHSG' : s0.sym}.png`; document.body.appendChild(a); a.click(); a.remove(); toast('Gambar diunduh');
  }

  // ---------------- SETTINGS ----------------
  function openSettings() {
    const el = $('#settings'); showLayer(el); const s = D.settings;
    const provOpts = Object.entries(D.providers).filter(([k]) => D.native || k === 'demo').map(([k, p]) => `<option value="${k}" ${k === s.provider ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
    el.innerHTML = `<div class="sh-h"><button class="icon" id="stBack" aria-label="Kembali">←</button><b>Pengaturan</b></div><div class="sh-b">
      <h2>Tampilan</h2><div class="card">
        <div class="fld"><label>Tema</label><div class="seg" id="lkTheme">${[['dark', 'Gelap'], ['light', 'Terang']].map(([k, l]) => `<button data-v="${k}" class="${(s.theme || 'dark') === k ? 'on' : ''}">${l}</button>`).join('')}</div></div>
        <div class="fld"><label>Ukuran teks</label><div class="seg" id="lkSize">${[['S', 'Kecil'], ['M', 'Normal'], ['L', 'Besar'], ['XL', 'Sangat besar']].map(([k, l]) => `<button data-v="${k}" class="${(s.textSize || 'M') === k ? 'on' : ''}">${l}</button>`).join('')}</div></div>
        <div class="fld"><label>Animasi</label><div class="seg" id="lkMotion">${[['on', 'Penuh'], ['off', 'Kurangi']].map(([k, l]) => `<button data-v="${k}" class="${(s.motion || 'on') === k ? 'on' : ''}">${l}</button>`).join('')}</div></div>
        <div class="fld"><input type="checkbox" class="sw" id="lkCb" ${s.cb ? 'checked' : ''}><label>Warna ramah buta warna <span class="sm mut">(naik biru, turun oranye)</span></label></div>
        <div class="rowx sm" style="margin-top:6px"><span class="up">▲ +2,15%</span><span class="dn">▼ −1,40%</span><span class="gold">Entry</span><span class="mut">contoh warna</span></div></div>
      <h2>Notifikasi & latar belakang</h2><div class="card">
        <div class="fld"><input type="checkbox" class="sw" id="nMorning" ${s.morning ? 'checked' : ''}><label>Picks pagi <span class="sm mut">(hari bursa)</span></label><input type="time" id="nMorningAt" value="${s.morningAt}"></div>
        <div class="fld"><input type="checkbox" class="sw" id="nEvening" ${s.evening ? 'checked' : ''}><label>Rangkuman sore</label><input type="time" id="nEveningAt" value="${s.eveningAt}"></div>
        <div class="fld"><input type="checkbox" class="sw" id="nBg" ${s.bgAlerts ? 'checked' : ''}><label>Alert di latar belakang <span class="sm mut">(cek tiap ±15 menit saat bursa buka)</span></label></div>
        <div class="fld"><input type="checkbox" class="sw" id="nGuard" ${s.guard !== false ? 'checked' : ''}><label>Jaga portofolio <span class="sm mut">(beri tahu saat posisi perlu tindakan)</span></label></div>
        <div class="rowx" style="margin-top:8px"><button class="btn" id="nBattery">Izinkan berjalan di latar belakang</button></div>
        <div class="note">Agar notifikasi tepat waktu di iQOO/vivo: buka "Izinkan berjalan di latar belakang" → Baterai → pilih <b>Tanpa batasan</b>, dan aktifkan izin notifikasi. Tanpa itu, sistem bisa menunda atau membatalkan tugas latar belakang.</div></div>
      <h2>Telegram</h2><div class="card">
        <div class="fld"><label>Token bot</label><input id="tgTok" type="password" value="${esc(s.tgToken)}" placeholder="123456:ABC…" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div>
        <div class="fld"><label>Chat ID</label><input id="tgChat" value="${esc(s.tgChat)}" placeholder="otomatis" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div>
        <div class="rowx" style="margin-top:8px"><button class="btn" id="tgDetect">Deteksi chat ID</button><button class="btn" id="tgTest">Kirim pesan uji</button></div>
        ${[['tg_pagi', 'Kirim picks pagi'], ['tg_sore', 'Kirim rangkuman sore'], ['tg_alert', 'Kirim alert harga & portofolio']].map(([k, l]) => `<div class="fld"><input type="checkbox" class="sw" data-tgk="${k}" ${s[k] !== false ? 'checked' : ''}><label>${l}</label></div>`).join('')}
        <details class="why"><summary>Cara membuat bot (±2 menit)</summary><ol class="sm" style="line-height:1.6;padding-left:18px"><li>Di Telegram, buka <b>@BotFather</b> → kirim <b>/newbot</b> → beri nama, misalnya "Yoo Haw Wahyu".</li><li>Salin token yang diberikan, tempel di kolom Token bot di atas.</li><li>Buka bot barumu dan kirim pesan apa saja (mis. "halo").</li><li>Ketuk <b>Deteksi chat ID</b>, lalu <b>Kirim pesan uji</b>.</li></ol></details>
        <div class="note">Pesan dikirim langsung dari HP-mu ke Telegram; tidak lewat server lain. Token disimpan hanya di perangkat ini.</div></div>
      <h2>Bantuan & data</h2><div class="card"><div class="fld"><input type="checkbox" class="sw" id="sSaver" ${s.saver ? 'checked' : ''}><label>Mode hemat data <span class="sm mut">(tanpa refresh otomatis, makro & pengayaan berita manual, radar tiap 5 menit)</span></label></div>
        <div class="rowx" style="margin-top:8px"><button class="btn" id="sGl">Kamus istilah</button></div><div class="note">Ketuk tanda ? kecil di samping istilah mana pun untuk penjelasan singkat.</div></div>
      <h2>Sumber data</h2><div class="card"><div class="fld"><label>Provider harga</label><select id="sProv" style="background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px">${provOpts}</select></div>
        <div id="custBox" ${s.provider === 'custom' ? '' : 'hidden'}><div class="fld"><label>URL dasar API</label><input id="sBase" value="${esc(s.customBase)}" placeholder="https://api.contoh.com/v1" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div>
        <div class="fld"><label>API key</label><input id="sKey" type="password" value="${esc(s.customKey)}" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div></div>
        <div class="fld"><input type="checkbox" class="sw" id="sFF" ${s.foreign ? 'checked' : ''}><label>Foreign flow (IDX, EOD)</label></div><div class="fld"><input type="checkbox" class="sw" id="sNews" ${s.news ? 'checked' : ''}><label>Berita (Google News)</label></div></div>
      <h2>Ringkasan berita AI (opsional)</h2><div class="card"><div class="fld"><label>Penyedia</label><select id="sAi" style="background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px;max-width:58%"><option value="none" ${s.aiProv === 'none' ? 'selected' : ''}>Tanpa AI (ringkasan otomatis)</option><option value="gemini" ${s.aiProv === 'gemini' ? 'selected' : ''}>Google Gemini</option><option value="openai" ${s.aiProv === 'openai' ? 'selected' : ''}>OpenAI-compatible (Groq, OpenRouter…)</option></select></div>
        <div id="aiBox" ${s.aiProv === 'none' ? 'hidden' : ''}><div class="fld"><label>API key</label><input id="sAiKey" type="password" value="${esc(s.aiKey)}" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div>
        <div class="fld"><label>Model</label><input id="sAiModel" value="${esc(s.aiModel)}" placeholder="${s.aiProv === 'openai' ? 'llama-3.3-70b-versatile' : 'gemini-2.5-flash'}" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div>
        <div class="fld" id="aiBaseF" ${s.aiProv === 'openai' ? '' : 'hidden'}><label>URL dasar</label><input id="sAiBase" value="${esc(s.aiBase)}" placeholder="https://api.groq.com/openai/v1" style="flex:1.4;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:6px"></div></div>
        <div class="note">Pakai API key milikmu (Gemini dan Groq punya kuota gratis). Judul & cuplikan berita dikirim ke penyedia hanya saat kamu menekan tombol ringkas. Tanpa AI, ringkasan & dampak dibuat dengan aturan.</div>
        <div style="padding-top:6px"><label class="sm mut">RSS berita tambahan (satu URL per baris)</label><textarea id="sRss" rows="2" style="width:100%;margin-top:4px;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:8px">${esc(s.rssExtra)}</textarea></div></div>
      <h2>Aturan BEI & biaya</h2><div class="card"><div class="fld"><label>Biaya beli (%)</label><input type="number" step="0.01" id="sFb" value="${s.feeBuy}"></div><div class="fld"><label>Biaya jual (%)</label><input type="number" step="0.01" id="sFs" value="${s.feeSell}"></div>
        <div style="padding-top:8px"><label class="sm mut">Saham Papan Pemantauan Khusus / FCA (dikecualikan dari AI Picks & backtest)</label><textarea id="sPpk" rows="2" placeholder="Salin daftar dari idx.co.id, pisahkan spasi/koma" style="width:100%;margin-top:4px;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:8px">${esc(s.ppkList)}</textarea></div>
        <div class="note">ARA/ARB mengikuti Kep-00136/BEI/09-2026: s.d. 31 Des 2026 ARA 35/25/20% dan ARB 15%; mulai 1 Jan 2027 simetris (ARB 35/25/20%). Harga Rp1–10: ±Rp1. Daftar PPK tidak tersedia lewat API gratis, jadi diisi manual.</div></div>
      <h2>Kondisi pasar & makro</h2><div class="card"><div class="fld"><input type="checkbox" class="sw" id="sReg" ${s.regimeFilter ? 'checked' : ''}><label>Perketat AI Picks saat pasar netral/risk-off</label></div>
        <div style="padding-top:8px"><label class="sm mut">Instrumen tambahan (satu per baris: simbolYahoo|Nama|EMITEN1,EMITEN2)</label><textarea id="sMacro" rows="2" placeholder="SB=F|Gula|" style="width:100%;margin-top:4px;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:8px">${esc(s.macroExtra)}</textarea></div></div>
      <h2>Pemindaian</h2><div class="card"><div class="fld"><label>Interval radar (detik)</label><input type="number" id="sInt" value="${s.radarInterval}"></div><div class="fld"><label>Koneksi paralel</label><input type="number" id="sConc" value="${s.concurrency}"></div>
        <div class="fld"><label>Likuiditas minimum AI Picks (miliar Rp/hari)</label><input type="number" id="sMin" value="${s.minValue / 1e9}"></div>
        <div style="padding-top:8px"><label class="sm mut">Saham tambahan (pisahkan spasi/koma)</label><textarea id="sExtra" rows="2" style="width:100%;margin-top:4px;background:var(--s2);border:1px solid var(--line);border-radius:7px;padding:8px">${esc(s.extraTickers)}</textarea></div></div>
      <div class="rowx" style="margin-top:12px"><button class="btn pri" id="sSave">Simpan & muat ulang</button><button class="btn" id="sClear">Hapus cache</button></div>
      <h2>Status data</h2><div class="card sm">${tbl([['Harga intraday', D.settings.provider === 'yahoo' ? 'Tertunda (±10 mnt, Yahoo)' : D.settings.provider === 'demo' ? 'Simulasi' : 'Sesuai provider'], ['Harga harian', 'Tertunda saat bursa buka, EOD setelah tutup'], ['Fundamental', 'Laporan terakhir (Yahoo)'], ['Foreign flow', `${D.STATUS[D.ffState.status]} — ${esc(D.ffState.note)}`], ['Akumulasi/distribusi, ROIC, sentimen berita', 'Estimasi dari data di atas'], ['Broker summary', 'Tidak tersedia (sumber berbayar)']])}</div>
      <div class="note">Grafik memakai <a data-ext href="https://www.tradingview.com/">TradingView</a> Lightweight Charts™. Aplikasi tidak pernah mengarang data pasar. Jika sumber gagal, field ditampilkan kosong. Semua analisis adalah alat bantu, bukan rekomendasi investasi.${E.snap && E.snap.failedSyms.length ? ` Gagal dimuat: ${E.snap.failedSyms.join(', ')}.` : ''}</div></div>`;
    $('#stBack').onclick = () => { hideLayer(el); };
    el.onclick = (e) => { const x = e.target.closest('a[data-ext]'); if (x) { e.preventDefault(); openExt(x.href); } };
    $('#sProv').onchange = (e) => ($('#custBox').hidden = e.target.value !== 'custom');
    const look = (id, key) => { $(id).onclick = (e) => { const b = e.target.closest('[data-v]'); if (!b) return; s[key] = b.dataset.v; D.saveSettings(); applyLook(); $(id).querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); render(); if (isOpen($('#stock'))) drawStock(); }; };
    look('#lkTheme', 'theme'); look('#lkSize', 'textSize'); look('#lkMotion', 'motion'); $('#lkCb').onchange = (e) => { s.cb = e.target.checked; D.saveSettings(); applyLook(); render(); if (isOpen($('#stock'))) drawStock(); };
    const nset = () => { s.morning = $('#nMorning').checked; s.morningAt = $('#nMorningAt').value || '08:30'; s.evening = $('#nEvening').checked; s.eveningAt = $('#nEveningAt').value || '16:30'; s.bgAlerts = $('#nBg').checked; s.guard = $('#nGuard').checked; D.saveSettings(); syncSchedule(); };
    ['#nMorning', '#nMorningAt', '#nEvening', '#nEveningAt', '#nBg', '#nGuard'].forEach((id) => ($(id).onchange = () => { nset(); hap(); toast('Jadwal notifikasi diperbarui'); }));
    $('#nBattery').onclick = () => { try { window.AndroidBridge && window.AndroidBridge.openBatterySettings ? window.AndroidBridge.openBatterySettings() : toast('Hanya di aplikasi Android'); } catch (e) {} };
    const tgSave = () => { s.tgToken = $('#tgTok').value.trim(); s.tgChat = $('#tgChat').value.trim(); D.saveSettings(); };
    $('#tgTok').onchange = tgSave; $('#tgChat').onchange = tgSave;
    el.querySelectorAll('[data-tgk]').forEach((x) => (x.onchange = () => { s[x.dataset.tgk] = x.checked; D.saveSettings(); }));
    $('#tgDetect').onclick = async () => { tgSave(); try { const id = await TG.detect(); s.tgChat = String(id); $('#tgChat').value = id; D.saveSettings(); hap('confirm'); toast('Chat ID ditemukan'); } catch (err) { toast(err.message); } };
    $('#tgTest').onclick = async () => { tgSave(); try { await TG.send('<b>Yoo Haw</b> terhubung ✅\nPicks pagi, rangkuman sore, dan alert akan dikirim ke sini.'); hap('confirm'); toast('Pesan uji terkirim'); } catch (err) { toast('Gagal: ' + err.message); } };
    $('#sSaver').onchange = (e) => { s.saver = e.target.checked; D.saveSettings(); toast(s.saver ? 'Mode hemat data aktif' : 'Mode hemat data mati'); };
    $('#sGl').onclick = () => openGlossaryList();
    $('#sAi').onchange = (e) => { $('#aiBox').hidden = e.target.value === 'none'; $('#aiBaseF').hidden = e.target.value !== 'openai'; };
    $('#sClear').onclick = async () => { await D.clearCache(); toast('Cache dihapus'); };
    $('#sSave').onclick = () => {
      Object.assign(s, { provider: $('#sProv').value, customBase: $('#sBase').value.trim(), customKey: $('#sKey').value.trim(), foreign: $('#sFF').checked, news: $('#sNews').checked, radarInterval: Math.max(30, +$('#sInt').value || 120), concurrency: Math.min(12, Math.max(1, +$('#sConc').value || 6)), minValue: Math.max(0, +$('#sMin').value || 0) * 1e9, extraTickers: $('#sExtra').value, aiProv: $('#sAi').value, aiKey: $('#sAiKey').value.trim(), aiModel: $('#sAiModel').value.trim(), aiBase: $('#sAiBase').value.trim(), rssExtra: $('#sRss').value, feeBuy: Math.max(0, parseFloat($('#sFb').value) || 0), feeSell: Math.max(0, parseFloat($('#sFs').value) || 0), ppkList: $('#sPpk').value.toUpperCase(), regimeFilter: $('#sReg').checked, macroExtra: $('#sMacro').value });
      M.data = null; M.err = null;
      D.saveSettings(); hideLayer(el); if (Rd.running) { Rd.stop(); Rd.start(); } scan(true);
    };
  }

  // Android back button
  // Layers from top to bottom — must match the z-index stack in app.css (verified by the UI test suite).
  const LAYERS = [
    ['fs', () => closeFS()], ['gl', () => (hideLayer($('#gl')))], ['qa', () => (hideLayer($('#qa')))], ['buy', () => (hideLayer($('#buy')))],
    ['search', () => closeSearch()], ['settings', () => (hideLayer($('#settings')))],
    ['reader', () => closeReader()], ['bt', () => closeBt()], ['cmp', () => closeCompare()], ['stock', () => closeStock()], ['ms', () => closeMS()],
  ];
  window.__onBack = () => {
    for (const [id, close] of LAYERS) if (isOpen($('#' + id))) { close(); return true; }
    if (st.tab !== 'market') { $('#tabs button[data-tab="market"]').click(); return true; }
    return false;
  };
  // background scroll is locked exactly while any full-screen layer is open
  const syncScroll = () => { document.body.style.overflow = LAYERS.some(([id]) => !['gl', 'qa', 'buy'].includes(id) && !$('#' + id).hidden) ? 'hidden' : ''; };
  new MutationObserver(syncScroll).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['hidden'] });
  setInterval(() => { if (!JOB && !D.settings.saver && D.marketOpen() && !E.scanning && E.snap && Date.now() - E.snap.asOf > 5 * 60e3 && document.visibilityState !== 'hidden') scan(false); }, 60e3);

  // render functions always paint into their own pane and stamp it
  const wrapTab = (tab, fn) => function () { const prev = view; view = pane(tab); try { return fn.apply(this, arguments); } finally { panes[tab].dataset.stamp = dataStamp(); if (st.tab !== tab) view = prev; } };
  rMarket = wrapTab('market', rMarket); rScreener = wrapTab('screener', rScreener); rPicks = wrapTab('picks', rPicks); rNews = wrapTab('news', rNews); rRadar = wrapTab('radar', rRadar); rWatch = wrapTab('watch', rWatch);

  // ---------------- splash ----------------
  const SP = { t0: Date.now(), done: false };
  const spSet = (msg, p) => { if (SP.done) return; const m = $('#spMsg'), b = $('#spBar'); if (m && msg) m.textContent = msg; if (b && p != null) b.style.width = Math.max(8, Math.min(100, p * 100)) + '%'; };
  const spHide = () => { if (SP.done) return; SP.done = true; const el = $('#splash'); if (!el) return; spSet(null, 1); const wait = Math.max(0, 2100 - (Date.now() - SP.t0));
    setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 500); }, wait); };
  const QS = new URLSearchParams(location.search); const JOB = QS.get('job');
  // notification taps: "picks" | "recap" | "stock:BBRI"
  window.__openTarget = (t) => { if (!t) return; if (t === 'picks') { st.pickCat = 'all'; $('#tabs button[data-tab="picks"]').click(); } else if (t === 'recap') $('#tabs button[data-tab="market"]').click(); else if (t.startsWith('stock:')) openStock(t.slice(6)); };
  // in-app alert checks (background checks run through the scheduled job)
  AL.onFire = (title) => toast(title);
  const alertTick = () => { if (JOB || !D.marketOpen() || !AL.needsBackground()) return; AL.check().then((f) => { if (f.length && st.tab === 'watch') rWatch(); }).catch(() => {}); };
  if (JOB) {
    // headless background job: no UI, run and report back to the native service
    const sp0 = $('#splash'); if (sp0) sp0.remove(); SP.done = true;
    JB.run(JOB, () => E.scan({ force: true })).catch(() => {}).finally(() => { try { window.AndroidBridge && window.AndroidBridge.jobDone(); } catch (e) {} });
  } else {
    setTimeout(spHide, 9000); // never block the app longer than this; the header progress bar keeps going
    render(); spSet(D.settings.provider === 'demo' ? 'Mode simulasi' : 'Menghubungkan ke data pasar', 0.08);
    scan(false).finally(() => { spHide(); const t = QS.get('open'); if (t) setTimeout(() => window.__openTarget(t), 400); });
    syncSchedule(); setInterval(alertTick, 120e3); setTimeout(alertTick, 20e3);
  }
  R.UI = { openStock, st, setSec: (k) => { sp.sec = k; const t = $('.tabs2'); if (t) t.innerHTML = navHtml(sp.isIndex ? SECS_IDX : SECS); drawSection(); } };
})(window.RB);
