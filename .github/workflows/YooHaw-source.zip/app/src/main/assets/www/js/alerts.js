/* Yoo Haw — manual price alerts, portfolio guard, Telegram delivery. */
(function (R) {
  const { D, A, E } = R;

  // ---------------- Telegram (user's own bot; sent straight from the phone) ----------------
  const TG = {};
  TG.cfg = () => ({ token: (D.settings.tgToken || '').trim(), chat: (D.settings.tgChat || '').toString().trim() });
  TG.ready = () => { const c = TG.cfg(); return !!(c.token && c.chat); };
  TG.on = (kind) => TG.ready() && D.settings['tg_' + kind] !== false;
  TG.esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  TG.send = async (html) => {
    const c = TG.cfg(); if (!c.token || !c.chat) throw new Error('Telegram belum diatur');
    const txt = await D.post(`https://api.telegram.org/bot${c.token}/sendMessage`, { chat_id: c.chat, text: html.slice(0, 4000), parse_mode: 'HTML', disable_web_page_preview: true });
    const j = JSON.parse(txt); if (!j.ok) throw new Error(j.description || 'Telegram menolak pesan'); return true;
  };
  // after the user sends any message to the bot, its chat id appears in getUpdates
  TG.detect = async () => {
    const c = TG.cfg(); if (!c.token) throw new Error('Isi token bot dulu');
    const j = await D.get(`https://api.telegram.org/bot${c.token}/getUpdates`); if (!j.ok) throw new Error(j.description || 'Token tidak valid');
    const m = [...(j.result || [])].reverse().find((u) => (u.message || u.channel_post)); if (!m) throw new Error('Belum ada pesan. Kirim "halo" ke bot-mu di Telegram, lalu coba lagi.');
    return (m.message || m.channel_post).chat.id;
  };

  // ---------------- manual price alerts ----------------
  const AL = {};
  AL.list = () => D.lsGet('rb.palerts', []);
  AL.save = (a) => D.lsSet('rb.palerts', a);
  AL.add = (sym, op, price, note) => { const a = AL.list(); a.push({ id: 'a' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), sym, op, price: +price, note: note || '', on: true, created: Date.now() }); AL.save(a); };
  AL.remove = (id) => AL.save(AL.list().filter((x) => x.id !== id));
  AL.toggle = (id) => AL.save(AL.list().map((x) => (x.id === id ? Object.assign(x, { on: !x.on, hitAt: x.on ? x.hitAt : null }) : x)));
  AL.forSym = (sym) => AL.list().filter((x) => x.sym === sym);
  AL.active = () => AL.list().filter((x) => x.on);
  AL.needsBackground = () => AL.active().length > 0 || (D.settings.guard !== false && E.P.list().length > 0);
  const lastPrice = async (sym) => { try { const r = await D.candles(sym, '5m', true); const c = r.cd.c; return { px: c[c.length - 1], t: r.cd.t[r.cd.t.length - 1] }; } catch (e) { const r = await D.candles(sym, 'D', true); return { px: r.cd.c[r.cd.c.length - 1], t: r.cd.t[r.cd.t.length - 1] }; } };
  const say = async (title, body, target, kind) => {
    try { window.AndroidBridge && window.AndroidBridge.notifyTo ? window.AndroidBridge.notifyTo(title, body, target || '') : window.AndroidBridge && window.AndroidBridge.notify(title, body); } catch (e) {}
    if (TG.on(kind)) { try { await TG.send(`<b>${TG.esc(title)}</b>\n${TG.esc(body)}`); } catch (e) {} }
    AL.onFire && AL.onFire(title, body);
  };
  // checks manual alerts and the portfolio guard; returns what fired
  AL.check = async () => {
    const fired = []; const alerts = AL.active(); const syms = [...new Set(alerts.map((a) => a.sym))]; const px = {};
    await D.pool(syms, async (s) => { px[s] = await lastPrice(s); }, 4);
    const all = AL.list();
    for (const a of alerts) { const p = px[a.sym]; if (!p || !(p.px > 0)) continue; const hit = a.op === '<=' ? p.px <= a.price : p.px >= a.price; if (!hit) continue;
      const x = all.find((y) => y.id === a.id); if (x) { x.on = false; x.hitAt = Date.now(); x.hitPx = p.px; }
      fired.push(a); await say(`🔔 ${a.sym} ${a.op === '<=' ? 'turun ke' : 'naik ke'} ${A.fmt(p.px)}`, `Alert ${a.op === '<=' ? '≤' : '≥'} ${A.fmt(a.price)} tersentuh${a.note ? ` · ${a.note}` : ''} (data tertunda ±10–15 menit).`, 'stock:' + a.sym, 'alert'); }
    AL.save(all);
    // portfolio guard: notify only when a position's action changes to something that needs attention
    if (D.settings.guard !== false) {
      const prev = D.lsGet('rb.guard', {}); const next = {};
      for (const pos of E.P.list()) {
        let st = null; try { E.extra.delete(pos.sym); st = await E.ensureStock(pos.sym); } catch (e) { continue; }
        const a = E.P.assess(st, pos); next[pos.sym] = a.action;
        if (prev[pos.sym] !== a.action && ['dn', 'gold'].includes(a.tone) && prev[pos.sym] !== undefined) { fired.push({ sym: pos.sym, guard: a.action }); await say(`${pos.sym}: ${a.action}`, `${a.why}. Stop pengaman ${A.fmt(a.stop)}, target ${A.fmt(a.target)}.`, 'stock:' + pos.sym, 'alert'); }
      }
      D.lsSet('rb.guard', next);
    }
    return fired;
  };
  R.AL = AL; R.TG = TG;
})((typeof window !== 'undefined' ? window : global).RB);
