/* Yoo Haw — corporate actions from IDX disclosures: buyback, rights issue, dividend, tender offer/MTO, insider trades. */
(function (R) {
  const { D, A, E } = R; const CA = { items: null, last: 0, busy: false, err: null, det: new Map(), sym: new Map() };
  const IDX = ['https://www.idx.co.id', 'https://www.idx.id'];
  CA.TYPES = [['buyback', 'Buyback'], ['rights', 'Right issue'], ['div', 'Dividen'], ['tender', 'Tender offer / MTO'], ['insider', 'Orang dalam']];
  CA.label = (t) => (CA.TYPES.find((x) => x[0] === t) || [, t])[1];
  const RULES = [
    ['buyback', /pembelian kembali saham|buy ?back/i],
    ['rights', /HMETD|hak memesan efek terlebih dahulu|penambahan modal dengan (?:memberikan )?hak|right ?issue/i],
    ['tender', /penawaran tender|tender offer|go private|pengambilalihan/i],
    ['div', /dividen/i],
    ['insider', /laporan kepemilikan|perubahan kepemilikan saham|transaksi saham (?:oleh )?(?:direksi|komisaris)/i],
  ];
  CA.classify = (title) => { for (const [k, rx] of RULES) if (rx.test(title || '')) return k; return null; };
  CA.subtype = (type, title) => (type === 'buyback' ? (/laporan|pelaksanaan|realisasi|hasil/i.test(title) ? 'report' : 'plan') : null);

  // ---------------- number & date parsing (Indonesian disclosures) ----------------
  const UNIT = { triliun: 1e12, miliar: 1e9, milyar: 1e9, juta: 1e6, ribu: 1e3 };
  CA.num = (s) => { if (s == null) return NaN; s = String(s).trim().replace(/[.,]+$/, ''); if (/,\d{1,2}$/.test(s) || /^\d{1,3}(\.\d{3})*,\d+$/.test(s)) return parseFloat(s.replace(/\./g, '').replace(',', '.')); if (/^\d{1,3}(\.\d{3})+$/.test(s)) return parseFloat(s.replace(/\./g, '')); return parseFloat(s.replace(/,/g, '')); };
  CA.rp = (s, unit) => { const v = CA.num(s); const u = unit ? UNIT[String(unit).toLowerCase()] || 1 : 1; return v * u; };
  const MON = { januari: 1, februari: 2, maret: 3, april: 4, mei: 5, juni: 6, juli: 7, agustus: 8, september: 9, oktober: 10, november: 11, desember: 12 };
  const DRX = /(\d{1,2})\s+(januari|februari|maret|april|mei|juni|juli|agustus|september|oktober|november|desember)\s+(\d{4})/i;
  const DRXG = new RegExp(DRX.source, 'gi');
  CA.date = (s) => { const m = String(s || '').match(DRX); return m ? `${m[3]}-${String(MON[m[2].toLowerCase()]).padStart(2, '0')}-${String(+m[1]).padStart(2, '0')}` : null; };
  const after = (t, rx, span = 160) => { const m = t.match(rx); return m ? t.slice(m.index + m[0].length, m.index + m[0].length + span) : ''; };
  const rpAfter = (t, rx, span = 120) => { const seg = after(t, rx, span); const m = seg.match(/Rp\.?\s*([\d.,]+)\s*(triliun|miliar|milyar|juta|ribu)?/i); return m ? CA.rp(m[1], m[2]) : NaN; };
  const dateAfter = (t, rx, span = 90) => CA.date(after(t, rx, span));
  const period = (t) => { const m = t.match(new RegExp(DRX.source + String.raw`\s*(?:sampai dengan|s\.?\s?d\.?|hingga|sampai|-|–)\s*` + DRX.source, 'i')); return m ? [CA.date(m.slice(1, 4).join(' ')), CA.date(m.slice(4, 7).join(' '))] : [null, null]; };
  // share counts: a number followed by "lembar saham" (never a Rupiah amount); prefer the one after the keyword
  const sharesNear = (t, rx) => {
    const k = t.search(rx); const all = [...t.matchAll(/(Rp\.?\s*)?([\d.]{4,})\s*(?:\([^)]*\)\s*)?lembar(?:\s*saham)?/gi)].filter((m) => !m[1]);
    const m = all.find((x) => k >= 0 && x.index >= k) || all[0]; if (m) return CA.num(m[2]);
    const seg = after(t, rx, 220); const m2 = seg.match(/(?:^|[^Rp\d.])([\d.]{4,})\s*(?:\([^)]*\)\s*)?saham/i); return m2 ? CA.num(m2[1]) : NaN;
  };

  CA.parse = (type, text, sub) => {
    const t = String(text || '').replace(/\s+/g, ' '); const o = {};
    if (type === 'buyback' && sub !== 'report') {
      o.budget = rpAfter(t, /(?:dana|biaya|nilai)[^.]{0,60}?(?:pembelian kembali|buyback)[^.]{0,40}?(?:sebanyak-banyaknya|maksimal|sebesar|tidak melebihi)/i, 120);
      if (!(o.budget > 0)) o.budget = rpAfter(t, /(?:sebanyak-banyaknya|maksimal|tidak melebihi)/i, 80);
      o.shares = sharesNear(t, /(?:jumlah saham|saham yang akan dibeli kembali|pembelian kembali saham)[^.]{0,60}?(?:sebanyak-banyaknya|maksimal|tidak melebihi)/i);
      const pm = t.match(/([\d,.]+)\s*%\s*(?:\([^)]*\)\s*)?dari\s+(?:jumlah\s+)?(?:seluruh\s+)?(?:modal|saham)/i); if (pm) o.pct = CA.num(pm[1]);
      o.maxPrice = rpAfter(t, /harga\s+(?:pembelian\s+)?(?:kembali\s+)?(?:tertinggi|maksimal|maksimum)/i, 60);
      [o.from, o.to] = period(t);
    } else if (type === 'buyback') {
      const sb = t.match(/(?:telah\s+(?:melakukan\s+)?(?:pembelian kembali|membeli kembali)[^.]{0,30}?sebanyak|total saham yang telah dibeli kembali(?: adalah| sebanyak)?)\s*([\d.]{3,})/i); if (sb) o.bought = CA.num(sb[1]);
      o.avg = rpAfter(t, /harga\s+rata-?\s?rata/i, 60);
      o.spent = rpAfter(t, /(?:total|jumlah)\s+(?:dana|nilai|biaya)/i, 90);
      [o.from, o.to] = period(t);
    } else if (type === 'rights') {
      const r = t.match(/setiap\s+([\d.]+)\s*(?:\([^)]*\)\s*)?saham\s+lama[^.]{0,160}?(?:berhak|memperoleh|mendapatkan)[^.]{0,40}?([\d.]+)\s*(?:\([^)]*\)\s*)?HMETD/i); if (r) { o.old = CA.num(r[1]); o.new = CA.num(r[2]); }
      o.price = rpAfter(t, /harga\s+pelaksanaan/i, 70);
      o.cum = dateAfter(t, /cum\s*(?:HMETD\s*)?(?:di\s*)?pasar\s*reguler/i); o.ex = dateAfter(t, /ex\s*(?:HMETD\s*)?(?:di\s*)?pasar\s*reguler/i);
      [o.from, o.to] = period(after(t, /periode\s+(?:perdagangan|pelaksanaan)/i, 120));
    } else if (type === 'div') {
      const d = t.match(/(?:sebesar|senilai)\s*Rp\.?\s*([\d.,]+)\s*(?:\([^)]*\)\s*)?(?:per|setiap)\s*(?:lembar\s*)?saham/i); if (d) o.dps = CA.num(d[1]);
      o.cum = dateAfter(t, /cum\s*dividen\s*(?:di\s*)?pasar\s*reguler/i); o.ex = dateAfter(t, /ex\s*dividen\s*(?:di\s*)?pasar\s*reguler/i);
      o.rec = dateAfter(t, /recording\s*date|tanggal\s+pencatatan/i); o.pay = dateAfter(t, /(?:pembayaran|payment)/i, 80);
      o.kind = /interim/i.test(t) ? 'Interim' : /final/i.test(t) ? 'Final' : '';
    } else if (type === 'tender') {
      o.price = rpAfter(t, /harga\s+(?:penawaran(?:\s+tender)?(?:\s+wajib)?|pelaksanaan\s+penawaran)/i, 70);
      o.kind = /wajib|MTO/i.test(t) ? 'Tender offer wajib (MTO)' : /go private/i.test(t) ? 'Go private' : 'Tender offer sukarela';
      [o.from, o.to] = period(t);
    } else if (type === 'insider') {
      const n = t.match(/nama(?:\s+(?:pemegang saham|investor|pelapor))?\s*:?\s*([A-Z][A-Za-z.,'&\- ]{3,60}?)(?=\s+(?:jabatan|kewarganegaraan|alamat|status|tujuan|jenis|nomor|kategori|\d))/i); if (n) o.who = n[1].trim();
      o.side = /penjualan|menjual|jual/i.test(t) && !/pembelian|membeli/i.test(t) ? 'Jual' : /pembelian|membeli|beli/i.test(t) ? 'Beli' : '';
      const q = t.match(/jumlah\s+saham\s+(?:yang\s+)?(?:di\s?)?(?:beli|jual|transaksikan|transaksi)[^\d]{0,30}([\d.]{3,})/i); if (q) o.qty = CA.num(q[1]);
      o.price = rpAfter(t, /harga\s+(?:transaksi|pembelian|penjualan)/i, 50);
      const ps = [...t.matchAll(/([\d]{1,2}[,.]\d{1,4})\s*%/g)].map((m) => CA.num(m[1])).filter((x) => x <= 100); if (ps.length >= 2) { o.before = ps[0]; o.after = ps[1]; }
      o.date = CA.date(t);
    }
    for (const k of Object.keys(o)) if (o[k] == null || o[k] === '' || (typeof o[k] === 'number' && !Number.isFinite(o[k]))) delete o[k];
    return o;
  };

  // derived numbers that matter to a trader
  CA.derive = (it, px) => {
    const d = it.d || {}, out = {};
    if (it.type === 'buyback') { if (d.budget > 0 && d.shares > 0) { out.implied = d.budget / d.shares; if (px > 0) out.vsImplied = (px / out.implied - 1) * 100; } const p = it.prog; if (p && d.budget > 0 && p.spent > 0) { out.used = Math.min(100, (p.spent / d.budget) * 100); out.left = Math.max(0, d.budget - p.spent); } }
    if (it.type === 'rights' && d.old > 0 && d.new > 0) { out.dilution = (d.new / (d.old + d.new)) * 100; if (px > 0 && d.price > 0) { out.terp = (px * d.old + d.price * d.new) / (d.old + d.new); out.discount = (d.price / px - 1) * 100; } }
    if (it.type === 'div' && d.dps > 0 && px > 0) out.yield = (d.dps / px) * 100;
    if (it.type === 'tender' && d.price > 0 && px > 0) out.spread = (d.price / px - 1) * 100;
    return out;
  };

  // ---------------- fetching ----------------
  const ymd = (t) => new Date(t + 7 * 3600e3).toISOString().slice(0, 10).replace(/-/g, '');
  const KEYS = ['pembelian kembali', 'HMETD', 'dividen', 'penawaran tender', 'laporan kepemilikan'];
  const norm = (r) => {
    const p = r.pengumuman || r.Pengumuman || r; const code = String(p.Kode_Emiten || p.KodeEmiten || p.Code || '').trim().toUpperCase().slice(0, 4);
    const title = String(p.JudulPengumuman || p.Judul || p.Title || '').trim(); const dt = String(p.TglPengumuman || p.CreatedDate || p.Date || '');
    const atts = (r.attachments || r.Attachments || []).map((a) => ({ url: a.FullSavePath || a.Url || '', name: a.OriginalFilename || a.FileName || '', att: !!a.IsAttachment })).filter((a) => /\.pdf/i.test(a.url));
    const type = CA.classify(title); if (!type || !/^[A-Z]{4}$/.test(code)) return null;
    return { id: String(p.NoPengumuman || p.Id2 || `${code}|${title}|${dt}`).slice(0, 120), code, title, t: Date.parse(dt) || Date.now(), type, sub: CA.subtype(type, title), pdfs: atts };
  };
  CA.fetch = async ({ days = 30, code = '' } = {}) => {
    if (D.settings.provider === 'demo') return CA.demo();
    const to = Date.now(), from = to - days * 864e5; const seen = new Map(); let lastErr = null, okAny = false;
    for (const base of IDX) {
      for (const kw of KEYS) {
        const u = `${base}/primary/ListedCompany/GetAnnouncement?kodeEmiten=${code}&emitenType=*&indexFrom=0&pageSize=100&dateFrom=${ymd(from)}&dateTo=${ymd(to)}&lang=id&keyword=${encodeURIComponent(kw)}`;
        try { const j = await D.get(u); okAny = true; const reps = (j && (j.Replies || j.Items || j.data)) || []; for (const r of reps) { const it = norm(r); if (it && !seen.has(it.id)) seen.set(it.id, it); } } catch (e) { lastErr = e; }
      }
      if (okAny) break;
    }
    if (!okAny) throw new Error(lastErr ? 'Situs BEI tidak bisa dihubungi (' + lastErr.message + ')' : 'Situs BEI tidak bisa dihubungi');
    return [...seen.values()].sort((a, b) => b.t - a.t);
  };
  CA.load = async ({ force = false } = {}) => {
    if (CA.busy) return CA.items; if (!force && CA.items && Date.now() - CA.last < 30 * 60e3) return CA.items;
    CA.busy = true; CA.err = null;
    try { const c = !force && (await D.cacheGet('ca|list', 30 * 60e3)); CA.items = c || (await CA.fetch({ days: 30 })); if (!c) await D.cacheSet('ca|list', CA.items); CA.last = Date.now(); linkReports(); }
    catch (e) { CA.err = e.message; } finally { CA.busy = false; }
    return CA.items;
  };
  CA.forSymbol = async (code) => {
    if (CA.sym.has(code)) return CA.sym.get(code); let list = [];
    try { list = D.settings.provider === 'demo' ? CA.demo().filter((x) => x.code === code) : await CA.fetch({ days: 180, code }); } catch (e) { list = (CA.items || []).filter((x) => x.code === code); }
    CA.sym.set(code, list); return list;
  };
  // buyback execution reports attach to their plan (same issuer)
  const linkReports = () => { const its = CA.items || []; for (const p of its.filter((x) => x.type === 'buyback' && x.sub === 'plan')) { const r = its.filter((x) => x.code === p.code && x.type === 'buyback' && x.sub === 'report' && x.t >= p.t).sort((a, b) => b.t - a.t)[0]; if (r && r.d) p.prog = { bought: r.d.bought, avg: r.d.avg, spent: r.d.spent, t: r.t }; } };

  // details: read the disclosure PDF once, cache the parsed numbers
  CA.pdfText = async (buf) => {
    const pdfjs = window.pdfjsLib; if (!pdfjs) throw new Error('Pembaca PDF tidak tersedia'); if (!pdfjs.GlobalWorkerOptions.workerSrc) pdfjs.GlobalWorkerOptions.workerSrc = 'js/pdf.worker.min.js';
    const doc = await pdfjs.getDocument({ data: new Uint8Array(buf), isEvalSupported: false }).promise; let out = '';
    for (let p = 1; p <= Math.min(doc.numPages, 12); p++) { const tc = await (await doc.getPage(p)).getTextContent(); out += ' ' + tc.items.map((i) => i.str).join(' '); }
    return out;
  };
  CA.details = async (it) => {
    if (it.d) return it.d; const key = 'ca|d|' + it.id; const c = await D.cacheGet(key, 30 * 864e5); if (c) { it.d = c; linkReports(); return c; }
    if (!it.pdfs || !it.pdfs.length) { it.d = {}; it.dErr = 'Tidak ada dokumen PDF'; return it.d; }
    const order = it.pdfs.slice().sort((a, b) => (b.att - a.att) || (/lampiran|keterbukaan|pengumuman/i.test(b.name) - /lampiran|keterbukaan|pengumuman/i.test(a.name)));
    let text = ''; for (const p of order.slice(0, 2)) { try { const buf = await D.get(p.url, 'buf'); text += ' ' + (await CA.pdfText(buf)); } catch (e) { it.dErr = e.message; } }
    it.d = text.trim() ? CA.parse(it.type, text, it.sub) : {}; if (!text.trim() && !it.dErr) it.dErr = 'Dokumen berupa gambar (scan) — angka tidak bisa dibaca otomatis';
    await D.cacheSet(key, it.d); linkReports(); return it.d;
  };
  CA.within = (days, type) => (CA.items || []).filter((x) => Date.now() - x.t <= days * 864e5 && (!type || type === 'all' || x.type === type));
  CA.activeBuyback = (code) => { const now = new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10); return (CA.items || []).find((x) => x.code === code && x.type === 'buyback' && x.sub === 'plan' && (!x.d || !x.d.to || x.d.to >= now) && Date.now() - x.t < 120 * 864e5) || null; };
  CA.recentRights = (code) => (CA.items || []).find((x) => x.code === code && x.type === 'rights' && Date.now() - x.t < 60 * 864e5) || null;

  // ---------------- simulation data (preview / demo provider) ----------------
  CA.demo = () => {
    const day = 864e5, now = Date.now(); const pick = (s) => (E.snap && E.snap.stocks.has(s) ? s : null);
    const px = (s) => (E.snap && E.snap.stocks.get(s) ? E.snap.stocks.get(s).f.close : 1000); const iso = (dd) => new Date(now + dd * day + 7 * 3600e3).toISOString().slice(0, 10);
    const L = [];
    const add = (code, dd, type, sub, title, d, prog) => { if (!pick(code)) return; L.push({ id: 'demo|' + code + '|' + type + '|' + dd, code, t: now - dd * day, type, sub, title, pdfs: [], d, prog, demo: true }); };
    const tw = px('TOWR'); add('TOWR', 1, 'buyback', 'plan', 'Keterbukaan Informasi Rencana Pembelian Kembali Saham', { budget: 1e12, shares: Math.round(1e12 / (tw * 1.12)), pct: 2.5, from: iso(1), to: iso(90) }, (() => { const sh = Math.round((1e12 / (tw * 1.12)) * 0.18); return { bought: sh, avg: Math.round(tw * 0.98), spent: sh * Math.round(tw * 0.98) }; })());
    const bb = px('BBRI'); add('BBRI', 2, 'div', null, 'Jadwal Pembagian Dividen Tunai Interim', { dps: Math.round(bb * 0.022), kind: 'Interim', cum: iso(9), ex: iso(10), rec: iso(11), pay: iso(25) });
    const md = px('MEDC'); add('MEDC', 4, 'rights', null, 'Prospektus Ringkas Penambahan Modal dengan HMETD', { old: 10, new: 3, price: Math.round(md * 0.82), cum: iso(14), ex: iso(15), from: iso(17), to: iso(24) });
    const as = px('ASII'); add('ASII', 6, 'buyback', 'plan', 'Pemberitahuan Rencana Pembelian Kembali Saham', { budget: 2e12, shares: Math.round(2e12 / (as * 1.05)), from: iso(5), to: iso(85) });
    const tl = px('TLKM'); add('TLKM', 6, 'insider', null, 'Laporan Kepemilikan atau Setiap Perubahan Kepemilikan Saham', { who: 'Direktur Utama', side: 'Beli', qty: 500000, price: tl, before: 0.01, after: 0.02 });
    const ic = px('ICBP'); add('ICBP', 12, 'tender', null, 'Pengumuman Penawaran Tender Sukarela', { price: Math.round(ic * 1.15), kind: 'Tender offer sukarela', from: iso(3), to: iso(33) });
    const am = px('AMRT'); add('AMRT', 20, 'div', null, 'Jadwal Pembagian Dividen Tunai Final', { dps: Math.round(am * 0.012), kind: 'Final', cum: iso(-5), ex: iso(-4), pay: iso(8) });
    return L.sort((a, b) => b.t - a.t);
  };
  R.CA = CA;
})((typeof window !== 'undefined' ? window : global).RB);
