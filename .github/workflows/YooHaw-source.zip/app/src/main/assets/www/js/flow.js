/* Yoo Haw — market structure from free official data: foreign vs domestic (IDX EOD), broker activity (market level),
   estimated trade flow, sector rotation (RRG), expected move, peer comparison. */
(function (R) {
  const { D, I, A, E } = R; const ok = I.ok; const X = { ff: null, ffBusy: false, ffErr: null, br: null, brBusy: false, brErr: null };
  const IDX = 'https://www.idx.co.id';
  const tradingDays = (n) => { const out = []; const now = Date.now() + 7 * 3600e3; for (let k = 0; out.length < n && k < n * 2 + 10; k++) { const d = new Date(now - k * 864e5); const wd = d.getUTCDay(); if (wd === 0 || wd === 6) continue; out.push(d.toISOString().slice(0, 10).replace(/-/g, '')); } return out; };
  const after16 = () => { const w = D.wib(); return w.min >= 16 * 60 + 30 || w.day === 0 || w.day === 6; };

  // ---------------- Foreign vs domestic (IDX daily trading summary) ----------------
  async function stockSummary(d) {
    const key = 'ss2|' + d; let rows = await D.cacheGet(key, 400 * 864e5); if (rows) return rows;
    const today = d === tradingDays(1)[0]; if (today && !after16()) return null;
    const j = await D.get(`${IDX}/primary/TradingSummary/GetStockSummary?length=9999&start=0&date=${d}`);
    rows = (j.data || []).map((x) => ({ s: x.StockCode, c: +x.Close || 0, v: +x.Volume || 0, val: +x.Value || 0, fb: +x.ForeignBuy || 0, fs: +x.ForeignSell || 0, chg: +x.Change || 0 })).filter((r) => r.s);
    if (rows.length) await D.cacheSet(key, rows); return rows.length ? rows : null;
  }
  X.loadForeign = async ({ days = 30, onProg } = {}) => {
    if (X.ffBusy) return X.ff; X.ffBusy = true; X.ffErr = null;
    try {
      if (D.settings.provider === 'demo') throw new Error('Data asing hanya diambil di aplikasi Android');
      const ds = tradingDays(days + 3); const got = []; let blocked = false;
      await D.pool(ds, async (d) => { try { const r = await stockSummary(d); if (r) got.push({ d, rows: r }); } catch (e) { if (e.status === 403 || e.status === 503) blocked = true; } }, 3, (a, b) => onProg && onProg(a, b));
      if (!got.length) throw new Error(blocked ? 'Situs IDX menolak koneksi otomatis saat ini (proteksi bot). Coba lagi nanti.' : 'Data ringkasan saham IDX belum tersedia');
      got.sort((a, b) => a.d.localeCompare(b.d)); const days2 = got.slice(-days);
      const market = days2.map(({ d, rows }) => { let net = 0, gross = 0, tot = 0; for (const r of rows) { net += (r.fb - r.fs) * r.c; gross += (r.fb + r.fs) * r.c; tot += r.val; } return { d, net, gross, tot, part: tot ? (gross / (2 * tot)) * 100 : NaN }; });
      const per = new Map();
      days2.forEach(({ rows }, k) => { for (const r of rows) { let p = per.get(r.s); if (!p) per.set(r.s, (p = { s: r.s, net: new Array(days2.length).fill(0), sh: new Array(days2.length).fill(0), c: new Array(days2.length).fill(NaN), part: new Array(days2.length).fill(NaN) })); p.net[k] = (r.fb - r.fs) * r.c; p.sh[k] = r.fb - r.fs; p.c[k] = r.c; p.part[k] = r.v ? ((r.fb + r.fs) / (2 * r.v)) * 100 : NaN; } });
      for (const p of per.values()) {
        const n = p.net.length, L = n - 1; const sum = (k) => p.net.slice(-k).reduce((a, b) => a + b, 0);
        p.n1 = p.net[L]; p.n5 = sum(5); p.n20 = sum(Math.min(20, n)); p.nAll = sum(n); let st = 0; const sg = Math.sign(p.net[L]); for (let i = L; i >= 0 && Math.sign(p.net[i]) === sg && sg !== 0; i--) st++; p.streak = st * sg;
        let cum = 0; p.inv = p.sh.map((x) => (cum += x)); const c0 = p.c.find(ok), c1 = p.c[L]; p.pchg = c0 ? ((c1 - c0) / c0) * 100 : NaN;
        p.div = p.n20 > 0 && p.pchg < -3 ? 'acc' : p.n20 < 0 && p.pchg > 3 ? 'dist' : null; p.partAvg = I.sma(p.part.map((x) => (ok(x) ? x : 0)), Math.min(n, 20))[L];
      }
      X.ff = { days: days2.map((x) => x.d), market, per, asOf: days2[days2.length - 1].d };
      return X.ff;
    } catch (e) { X.ffErr = e.message; return null; } finally { X.ffBusy = false; }
  };
  X.sectorForeign = (key = 'n5') => { if (!X.ff || !E.snap) return []; const m = {}; for (const st of E.snap.stocks.values()) { const p = X.ff.per.get(st.sym); if (p) m[st.sector] = (m[st.sector] || 0) + p[key]; } return Object.entries(m).sort((a, b) => b[1] - a[1]); };

  // ---------------- Broker activity (market level; IDX publishes totals per broker, not per stock) ----------------
  const FOREIGN_BRANDS = /UBS|J\.?\s?P\.?\s?MORGAN|CLSA|MACQUARIE|MORGAN STANLEY|HSBC|MAYBANK|CGS|MIRAE|KGI|SAMSUNG|KOREA|NOMURA|DAIWA|BNP|CITI|DEUTSCHE|RHB|SHINHAN|NH KORINDO|PHILLIP|UOB|DBS|OCBC|GOLDMAN|CREDIT SUISSE|KIWOOM|YUANTA|MASTERLINK|KB VALBURY|DAEWOO|NOMURA/i;
  async function brokerSummary(d) {
    const key = 'bs1|' + d; let rows = await D.cacheGet(key, 400 * 864e5); if (rows) return rows;
    if (d === tradingDays(1)[0] && !after16()) return null;
    const j = await D.get(`${IDX}/primary/TradingSummary/GetBrokerSummary?length=9999&start=0&date=${d}`);
    rows = (j.data || []).map((x) => ({ id: x.IDFirm || x.BrokerCode || x.Code, name: x.FirmName || x.BrokerName || '', val: +x.Value || 0, vol: +x.Volume || 0, freq: +x.Frequency || 0 })).filter((r) => r.id);
    if (rows.length) await D.cacheSet(key, rows); return rows.length ? rows : null;
  }
  X.loadBrokers = async ({ days = 10, onProg } = {}) => {
    if (X.brBusy) return X.br; X.brBusy = true; X.brErr = null;
    try {
      if (D.settings.provider === 'demo') throw new Error('Data broker hanya diambil di aplikasi Android');
      const ds = tradingDays(days + 3); const got = [];
      await D.pool(ds, async (d) => { try { const r = await brokerSummary(d); if (r) got.push({ d, rows: r }); } catch (e) {} }, 3, onProg);
      if (!got.length) throw new Error('Ringkasan broker IDX belum bisa diambil (situs menolak atau belum terbit)');
      got.sort((a, b) => a.d.localeCompare(b.d)); const lastD = got[got.length - 1]; const tot = lastD.rows.reduce((a, r) => a + r.val, 0);
      const hist = new Map(); for (const { rows } of got) for (const r of rows) (hist.get(r.id) || hist.set(r.id, []).get(r.id)).push(r.val);
      const list = lastD.rows.map((r) => { const h = hist.get(r.id) || []; const avg = h.length > 1 ? h.slice(0, -1).reduce((a, b) => a + b, 0) / (h.length - 1) : NaN; return Object.assign({}, r, { share: tot ? (r.val / tot) * 100 : 0, vsAvg: avg ? r.val / avg : NaN, foreign: FOREIGN_BRANDS.test(r.name), hist: h }); }).sort((a, b) => b.val - a.val);
      const fShare = list.filter((r) => r.foreign).reduce((a, r) => a + r.share, 0);
      X.br = { d: lastD.d, list, tot, fShare, days: got.map((x) => x.d) }; return X.br;
    } catch (e) { X.brErr = e.message; return null; } finally { X.brBusy = false; }
  };

  // ---------------- Trade flow (estimated buy/sell pressure from OHLCV) ----------------
  X.tradeFlow = (cd, n = 60) => {
    const L = cd.c.length, s = Math.max(1, L - n); const out = [];
    let cum = 0; for (let i = s; i < L; i++) { const rng = cd.h[i] - cd.l[i]; const buyFrac = rng > 0 ? (cd.c[i] - cd.l[i]) / rng : cd.c[i] >= cd.c[i - 1] ? 0.6 : 0.4; const buy = cd.v[i] * buyFrac, sell = cd.v[i] - buy; const delta = (buy - sell) * cd.c[i]; cum += delta; out.push({ t: cd.t[i], buy: buy * cd.c[i], sell: sell * cd.c[i], delta, cum }); }
    const sumK = (k) => out.slice(-k).reduce((a, x) => ({ b: a.b + x.buy, s: a.s + x.sell }), { b: 0, s: 0 });
    const p5 = sumK(5), p20 = sumK(20); return { bars: out, r5: p5.b / (p5.b + p5.s || 1), r20: p20.b / (p20.b + p20.s || 1) };
  };

  // ---------------- Sector rotation (RRG, JdK-style normalisation) ----------------
  X.rrg = ({ weekly = true, n = 10, tail = 6 } = {}) => {
    const snap = E.snap; if (!snap) return null; const ih = snap.ihsg.cd; const step = weekly ? 5 : 1;
    const dk = (t) => Math.floor((t + 25200) / 86400); const idxPos = new Map(ih.t.map((t, i) => [dk(t), i])); const N = ih.c.length;
    const groups = {}; for (const st of snap.stocks.values()) (groups[st.sector] = groups[st.sector] || []).push(st);
    const out = [];
    for (const [sec, mem] of Object.entries(groups)) {
      if (mem.length < 3) continue;
      // equal-weight sector index aligned to IHSG dates
      const sumR = new Array(N).fill(0), cnt = new Array(N).fill(0);
      for (const st of mem) { const cd = st.cd; let prev = null; const m = new Map(cd.t.map((t, i) => [dk(t), cd.c[i]])); for (let i = 1; i < N; i++) { const a = m.get(dk(ih.t[i - 1])), b = m.get(dk(ih.t[i])); if (a && b) { sumR[i] += Math.log(b / a); cnt[i]++; } } }
      const idx = [100]; for (let i = 1; i < N; i++) idx.push(idx[i - 1] * Math.exp(cnt[i] ? sumR[i] / cnt[i] : 0));
      const pts = []; for (let i = N - 1; i >= 0; i -= step) pts.unshift(i);
      const rs = pts.map((i) => (100 * idx[i]) / ih.c[i]);
      const roll = (arr, k, f) => arr.map((_, i) => (i < k - 1 ? NaN : f(arr.slice(i - k + 1, i + 1))));
      const mean = (a) => a.reduce((x, y) => x + y, 0) / a.length, sd = (a) => { const m = mean(a); return Math.sqrt(a.reduce((x, y) => x + (y - m) ** 2, 0) / a.length) || 1e-9; };
      const rm = roll(rs, n, mean), rsd = roll(rs, n, sd); const rsr = rs.map((x, i) => 100 + (x - rm[i]) / rsd[i]);
      const roc = rsr.map((x, i) => (i && ok(rsr[i - 1]) ? 100 * (x / rsr[i - 1] - 1) : NaN)); const valid = roc.map((x) => (ok(x) ? x : 0));
      const mm = roll(valid, n, mean), msd = roll(valid, n, sd); const rsm = valid.map((x, i) => 101 + (x - mm[i]) / msd[i]);
      const path = []; for (let i = rs.length - tail; i < rs.length; i++) if (ok(rsr[i]) && ok(rsm[i])) path.push({ x: rsr[i], y: rsm[i] });
      if (path.length < 2) continue; const p = path[path.length - 1];
      const q = p.x >= 100 && p.y >= 100 ? 'Memimpin' : p.x >= 100 ? 'Melemah' : p.y >= 100 ? 'Membaik' : 'Tertinggal';
      const prevQ = path.length > 2 ? (path[path.length - 3].x >= 100 && path[path.length - 3].y >= 100 ? 'Memimpin' : path[path.length - 3].x >= 100 ? 'Melemah' : path[path.length - 3].y >= 100 ? 'Membaik' : 'Tertinggal') : q;
      out.push({ sec, path, q, prevQ, heading: Math.atan2(p.y - path[path.length - 2].y, p.x - path[path.length - 2].x), n: mem.length });
    }
    return out;
  };

  // ---------------- Expected move & touch probability ----------------
  const Phi = (z) => { const t = 1 / (1 + 0.2316419 * Math.abs(z)); const d = 0.3989423 * Math.exp((-z * z) / 2); const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274)))); return z > 0 ? 1 - p : p; };
  X.expectedMove = (cd) => {
    const c = cd.c, L = c.length - 1; if (L < 60) return null; const r = []; for (let i = 1; i <= L; i++) r.push(Math.log(c[i] / c[i - 1]));
    let v = r.slice(0, 30).reduce((a, x) => a + x * x, 0) / 30; for (const x of r.slice(30)) v = 0.94 * v + 0.06 * x * x; const sd = Math.sqrt(v);
    const S = c[L]; const H = [1, 5, 20].map((h) => { const s = sd * Math.sqrt(h); const emp = []; for (let i = Math.max(h, L - 500); i <= L; i++) emp.push(Math.log(c[i] / c[i - h])); emp.sort((a, b) => a - b); const q = (p) => emp[Math.floor(p * (emp.length - 1))];
      return { h, lo68: S * Math.exp(-s), hi68: S * Math.exp(s), lo90: S * Math.exp(-1.645 * s), hi90: S * Math.exp(1.645 * s), e10: S * Math.exp(q(0.1)), e50: S * Math.exp(q(0.5)), e90: S * Math.exp(q(0.9)) }; });
    const annual = sd * Math.sqrt(252) * 100; const hist = []; let vv = r.slice(0, 30).reduce((a, x) => a + x * x, 0) / 30; for (const x of r.slice(30)) { vv = 0.94 * vv + 0.06 * x * x; hist.push(Math.sqrt(vv)); }
    const pctl = I.percentile(hist.slice(-500), sd);
    const touch = (target, days) => { if (!ok(target) || !(target > 0)) return NaN; const z = Math.abs(Math.log(target / S)) / (sd * Math.sqrt(days)); return Math.min(1, 2 * (1 - Phi(z))); };
    return { S, sd, annual, pctl, H, touch };
  };

  // ---------------- Peers ----------------
  X.peers = (st) => { if (!E.snap) return []; return [...E.snap.stocks.values()].filter((x) => x.sector === st.sector); };

  X.tradingDays = tradingDays;
  R.X = X;
})((typeof window !== 'undefined' ? window : global).RB);
