/* Yoo Haw — "saham gorengan" risk detector, conglomerate groups (from KSEI ≥1% data) and themes. */
(function (R) {
  const { A, I, E } = R; const ok = I.ok;

  // ---------------- gorengan risk ----------------
  const RK = {};
  RK.goreng = (st) => {
    const f = st.f, cd = st.cd, n = cd.c.length - 1; const flags = []; let s = 0; const add = (w, t) => { s += w; flags.push(t); };
    if (f.perf1w >= 25) add(20, `Naik ${Math.round(f.perf1w)}% dalam seminggu`); else if (f.chg1d >= 15) add(10, `Naik ${Math.round(f.chg1d)}% dalam sehari`);
    let ara = 0; for (let i = Math.max(1, n - 9); i <= n; i++) { const L = A.limits(cd.c[i - 1]); if (L && cd.c[i] >= L.ara) ara++; } if (ara >= 2) add(15, `${ara}× ditutup ARA dalam 10 hari`);
    if (f.avgValue20 < 5e9 && f.rvol >= 4) add(15, `Volume ${Math.round(f.rvol)}x lipat pada saham yang biasanya sepi`);
    if (R.O && R.O.cur) { const o = R.O.stock(st.sym); if (o && o.rows.length) { if (o.floatEst < 20) add(20, `Free float hanya ±${Math.round(o.floatEst)}% (kepemilikan terkonsentrasi)`); else if (o.big5 >= 75) add(8, `${Math.round(o.big5)}% saham dipegang pemilik besar`); } }
    if (f.marketCap > 0 && f.marketCap < 1e12) add(10, 'Kapitalisasi kecil (< Rp1 T)'); else if (f.close < 200) add(5, 'Harga saham di bawah Rp200');
    if (f.ppk) add(15, 'Masuk Papan Pemantauan Khusus');
    if ((ok(f.netMargin) && f.netMargin < 0) || (ok(f.roe) && f.roe < 0)) add(10, 'Perusahaan masih merugi');
    if (f.atrPct >= 8) add(10, `Sangat liar (rata-rata ${Math.round(f.atrPct)}% per hari)`);
    if (R.N && R.N.stories && R.N.stories.some((x) => x.tickers.includes(st.sym) && x.cat && x.cat.id === 'susp')) add(15, 'Ada berita UMA/suspensi');
    s = Math.min(100, s);
    return { score: s, level: s >= 60 ? 'Tinggi' : s >= 35 ? 'Sedang' : 'Rendah', flags };
  };

  // ---------------- groups (controllers resolved from KSEI data) & themes ----------------
  const GR = {};
  GR.GROUPS = [
    ['barito', 'Barito (Prajogo Pangestu)', /PRAJOGO PANGESTU|BARITO PACIFIC|BARITO RENEWABLES|GREEN ERA|PETRINDO JAYA/, ['BRPT', 'TPIA', 'BREN', 'CUAN', 'PTRO']],
    ['salim', 'Salim', /ANTHONI SALIM|FIRST PACIFIC|INDOFOOD SUKSES|INDOFOOD CBP|SALIM IVOMAS|CAB HOLDING|PRAMA ANINDHITA/, ['INDF', 'ICBP', 'LSIP', 'SIMP', 'DNET']],
    ['sinarmas', 'Sinar Mas', /SINAR ?MAS|SINARMAS|PURINUSA|DIAN SWASTATIKA|OESMAN WIDJAJA|INDAH KIAT/, ['DSSA', 'INKP', 'TKIM', 'BSIM', 'SMMA', 'GEMS']],
    ['astra', 'Astra (Jardine)', /ASTRA INTERNATIONAL|JARDINE CYCLE|UNITED TRACTORS|ASTRA AGRO/, ['ASII', 'UNTR', 'AALI', 'AUTO', 'ASGR']],
    ['djarum', 'Djarum (Hartono)', /BUDI HARTONO|BAMBANG HARTONO|DWIMURIA|DJARUM|SARANA MENARA NUSANTARA/, ['BBCA', 'TOWR', 'SSIA']],
    ['bakrie', 'Bakrie', /BAKRIE/, ['BUMI', 'BRMS', 'ENRG', 'DEWA', 'VKTR', 'UNSP']],
    ['lippo', 'Lippo (Riady)', /LIPPO|RIADY|INTI ANUGERAH/, ['LPKR', 'LPCK', 'SILO', 'MLPL']],
    ['mnc', 'MNC (Hary Tanoe)', /MNC ASIA|MNC INVESTAMA|TANOESOEDIBJO|GLOBAL MEDIACOM|MEDIA NUSANTARA CITRA|MNC CAPITAL/, ['BHIT', 'BMTR', 'MNCN', 'MSIN', 'KPIG', 'IPTV']],
    ['adaro', 'Adaro / Thohir', /GARIBALDI THOHIR|TRINUGRAHA THOHIR|ADARO STRATEGIC|ALAMTRI|ADARO ENERGY|ADARO MINERALS/, ['ADRO', 'AADI', 'ADMR', 'ESSA', 'MDKA']],
    ['saratoga', 'Saratoga (Soeryadjaya–Uno)', /SARATOGA|SOERYADJAYA|SANDIAGA/, ['SRTG', 'MPMX', 'MDKA']],
    ['bumn', 'BUMN / Danantara', /NEGARA REPUBLIK INDONESIA|DANANTARA|REPUBLIK INDONESIA|BIOFARMA/, ['BBRI', 'BMRI', 'BBNI', 'TLKM', 'PGAS', 'PTBA', 'ANTM', 'SMGR', 'JSMR', 'BBTN', 'PTPP', 'ADHI', 'GIAA']],
    ['ctcorp', 'CT Corp (Chairul Tanjung)', /CT CORPORA|TRANS CORPORA|CHAIRUL TANJUNG|MEGA CORPORA/, ['MEGA', 'BBHI']],
    ['emtek', 'Emtek (Sariaatmadja)', /ELANG MAHKOTA|SARIAATMADJA|SARIATMADJA/, ['EMTK', 'SCMA', 'BUKA']],
    ['rajawali', 'Rajawali (Sondakh)', /RAJAWALI|SONDAKH/, ['ARCI', 'BWPT']],
    ['hapsoro', 'Happy Hapsoro', /HAPSORO/, ['RAJA', 'MINA']],
  ];
  GR.THEMES = [
    ['nikel', 'Nikel & EV', ['INCO', 'ANTM', 'MBMA', 'NCKL', 'HRUM', 'VKTR']], ['coal', 'Batu bara', ['ADRO', 'AADI', 'PTBA', 'ITMG', 'HRUM', 'INDY', 'BUMI', 'BSSR', 'GEMS']],
    ['gold', 'Emas', ['ANTM', 'MDKA', 'BRMS', 'PSAB', 'ARCI', 'AMMN']], ['bank4', 'Bank besar', ['BBCA', 'BBRI', 'BMRI', 'BBNI']], ['bankdig', 'Bank digital', ['ARTO', 'BBYB', 'BBHI']],
    ['digital', 'Teknologi & data center', ['DCII', 'TLKM', 'EMTK', 'MTDL', 'WIFI', 'GOTO', 'BUKA', 'BELI']], ['ebt', 'Energi terbarukan', ['PGEO', 'BREN', 'POWR', 'KEEN']],
    ['prop', 'Properti', ['BSDE', 'CTRA', 'PWON', 'SMRA', 'PANI', 'ASRI', 'DMAS', 'BKSL']], ['cons', 'Konsumer', ['UNVR', 'ICBP', 'INDF', 'MYOR', 'AMRT', 'MIDI', 'CPIN', 'JPFA']],
    ['telco', 'Telko & menara', ['TLKM', 'ISAT', 'EXCL', 'TOWR', 'TBIG', 'MTEL']], ['infra', 'Infrastruktur & semen', ['PTPP', 'ADHI', 'JSMR', 'SMGR', 'INTP']],
    ['cpo', 'Sawit (CPO)', ['AALI', 'LSIP', 'DSNG', 'TAPG', 'SSMS', 'TBLA']], ['oil', 'Minyak & gas', ['MEDC', 'ENRG', 'ELSA', 'PGAS', 'AKRA', 'RAJA']], ['rokok', 'Rokok', ['HMSP', 'GGRM', 'WIIM']],
  ];
  // members of a group: stocks where the controller holds ≥5% (core) in the latest KSEI file; fallback to a built-in list
  const memo = new Map();
  GR.members = (g) => {
    const key = g[0] + '|' + (R.O && R.O.cur ? R.O.cur.date + R.O.cur.rows.length : '-'); if (memo.has(key)) return memo.get(key); const r0 = GR.members0(g); memo.set(key, r0); return r0;
  };
  GR.members0 = (g) => {
    const [, , rx, fallback] = g;
    if (!R.O || !R.O.cur) return { core: fallback.map((sym) => ({ sym, pct: NaN })), minor: [], source: 'daftar bawaan' };
    const m = new Map(); for (const r of R.O.cur.rows) if (rx.test((r.inv || '').toUpperCase())) m.set(r.code, Math.max(m.get(r.code) || 0, r.pct));
    const core = [...m].filter(([, p]) => p >= 5).map(([sym, pct]) => ({ sym, pct })).sort((a, b) => b.pct - a.pct), minor = [...m].filter(([, p]) => p < 5).map(([sym, pct]) => ({ sym, pct }));
    return core.length ? { core, minor, source: `KSEI ${R.O.cur.date}` } : { core: fallback.map((sym) => ({ sym, pct: NaN })), minor: [], source: 'daftar bawaan' };
  };
  const PER = { p1d: 'perf1d', p1w: 'perf1w', p1m: 'perf1m', p3m: 'perf3m' };
  GR.stats = (syms) => {
    const st = syms.map((s) => E.getStock(s)).filter(Boolean); const avg = (k) => { const v = st.map((x) => x.f[k]).filter(ok); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : NaN; };
    const out = { n: syms.length, have: st.length }; for (const [k, fk] of Object.entries(PER)) out[k] = avg(fk);
    out.above50 = st.length ? (st.filter((x) => x.f.aboveEma50).length / st.length) * 100 : NaN;
    out.ff5 = R.X && R.X.ff ? syms.reduce((a, s) => { const p = R.X.ff.per.get(s); return a + (p ? p.n5 : 0); }, 0) : NaN;
    const by = st.slice().sort((a, b) => (b.f.perf1m || -999) - (a.f.perf1m || -999)); out.leader = by[0] || null; out.laggard = by.length > 1 ? by[by.length - 1] : null;
    out.catchup = st.filter((x) => ok(x.f.perf1m) && ok(out.p1m) && x.f.perf1m < out.p1m - 5 && x.f.aboveEma50 && (x.f.rsRating || 0) >= 40).map((x) => x.sym);
    return out;
  };
  GR.list = (kind) => (kind === 'theme' ? GR.THEMES.map(([id, name, syms]) => ({ id, name, kind, syms, source: 'tema' })) : GR.GROUPS.map((g) => { const m = GR.members(g); return { id: g[0], name: g[1], kind, syms: m.core.map((x) => x.sym), holds: m.core, minor: m.minor, source: m.source }; }));
  GR.ofStock = (sym) => { if (!R.O || !R.O.cur) return []; return GR.GROUPS.filter((g) => GR.members(g).core.some((x) => x.sym === sym)).map((g) => g[1]); };
  R.RK = RK; R.GR = GR;
})((typeof window !== 'undefined' ? window : global).RB);
