/* Yoo Haw — news intelligence: aggregation → story clustering → awareness (who already knows) → impact on emitens → summary. */
(function (R) {
  const { D, A, I, E } = R; const ok = I.ok; const N = { stories: [], last: null, loading: false, err: null, llmCache: D.lsGet('rb.llm', {}) };

  // ---------- sources ----------
  const gnews = (q) => `https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=id&gl=ID&ceid=ID:id`;
  N.BASE_QUERIES = ['saham when:1d', 'IHSG when:1d', 'emiten when:1d', 'keterbukaan informasi emiten when:2d', 'dividen saham when:3d', 'right issue OR buyback OR "tender offer" when:3d', 'laba bersih emiten when:3d', 'akuisisi emiten when:3d', 'harga batu bara OR nikel OR CPO when:2d', 'BI Rate OR rupiah when:2d'];
  N.FEEDS = ['https://www.cnbcindonesia.com/market/rss', 'https://www.kabarbursa.com/feed.xml'];

  // ---------- entity dictionary ----------
  const ALIAS = {
    BBCA: ['bank central asia', '\\bbca\\b'], BBRI: ['bank rakyat indonesia', '\\bbri\\b'], BMRI: ['bank mandiri', '\\bmandiri\\b'], BBNI: ['bank negara indonesia', '\\bbni\\b'], BRIS: ['bank syariah indonesia', '\\bbsi\\b'],
    BBTN: ['\\bbtn\\b', 'bank tabungan negara'], ARTO: ['bank jago'], BJBR: ['\\bbank bjb\\b'], BJTM: ['bank jatim'], BNGA: ['cimb niaga'], BDMN: ['bank danamon'], NISP: ['bank ocbc'],
    TLKM: ['\\btelkom\\b', 'telkom indonesia'], ISAT: ['indosat'], EXCL: ['\\bxl axiata\\b', '\\bxlsmart\\b'], TOWR: ['sarana menara'], TBIG: ['tower bersama'], MTEL: ['mitratel', 'dayamitra'],
    ASII: ['astra international', '\\bastra\\b'], UNTR: ['united tractors'], AALI: ['astra agro'], AUTO: ['astra otoparts'],
    ANTM: ['\\bantam\\b', 'aneka tambang'], INCO: ['vale indonesia'], MDKA: ['merdeka copper'], MBMA: ['merdeka battery'], NCKL: ['harita nickel', 'trimegah bangun'], AMMN: ['amman mineral'], TINS: ['\\btimah\\b'], BRMS: ['bumi resources minerals'],
    PTBA: ['bukit asam'], ADRO: ['\\badaro\\b', 'alamtri'], AADI: ['adaro andalan'], ITMG: ['indo tambangraya'], HRUM: ['harum energy'], INDY: ['indika energy'], BUMI: ['bumi resources\\b(?! minerals)'],
    MEDC: ['medco'], PGAS: ['\\bpgn\\b', 'perusahaan gas negara'], AKRA: ['\\bakr corporindo\\b'], PGEO: ['pertamina geothermal'], BREN: ['barito renewables'], BRPT: ['barito pacific'], TPIA: ['chandra asri'],
    GOTO: ['\\bgoto\\b', 'gojek tokopedia'], BUKA: ['bukalapak'], EMTK: ['\\bemtek\\b', 'elang mahkota'], DCII: ['dci indonesia'],
    UNVR: ['unilever indonesia'], ICBP: ['indofood cbp'], INDF: ['indofood sukses'], MYOR: ['mayora'], CPIN: ['charoen pokphand'], JPFA: ['japfa'], AMRT: ['alfamart', 'sumber alfaria'], MIDI: ['alfamidi'],
    HMSP: ['sampoerna'], GGRM: ['gudang garam'], KLBF: ['kalbe farma'], SIDO: ['sido muncul'], MIKA: ['mitra keluarga'], HEAL: ['hermina'], SILO: ['siloam'],
    SMGR: ['semen indonesia'], INTP: ['indocement'], JSMR: ['jasa marga'], PTPP: ['\\bpp \\(persero\\)', '\\bptpp\\b'], ADHI: ['adhi karya'], GIAA: ['garuda indonesia'],
    BSDE: ['bumi serpong damai'], CTRA: ['ciputra'], PWON: ['pakuwon'], SMRA: ['summarecon'], PANI: ['pantai indah kapuk dua'], MAPI: ['mitra adiperkasa'], ACES: ['aspirasi hidup', 'ace hardware'], ERAA: ['erajaya'],
  };
  let aliasRe = null;
  function buildAlias() {
    aliasRe = [];
    for (const [sym, arr] of Object.entries(ALIAS)) for (const a of arr) aliasRe.push([sym, new RegExp(a.startsWith('\\b') ? a : `\\b${a}\\b`, 'i')]);
    if (E.snap) for (const s of E.snap.stocks.values()) {
      if (ALIAS[s.sym] || !s.meta || !s.meta.name) continue;
      const nm = s.meta.name.replace(/\bPT\b\.?|\bTbk\b\.?|\(Persero\)|\bPersero\b/gi, '').replace(/[^A-Za-z\s]/g, ' ').trim().split(/\s+/).slice(0, 2).join(' ').toLowerCase();
      if (nm.split(' ').length === 2 && nm.length >= 8) aliasRe.push([s.sym, new RegExp(`\\b${nm}\\b`, 'i')]);
    }
  }
  const universe = () => new Set(D.universe().map((u) => u.sym));
  N.tickersIn = (text) => {
    if (!aliasRe) buildAlias(); const U = universe(); const out = new Set();
    for (const m of text.matchAll(/\b([A-Z]{4})\b/g)) if (U.has(m[1])) out.add(m[1]);
    for (const [sym, re] of aliasRe) if (re.test(text)) out.add(sym);
    return [...out];
  };

  // ---------- categories (corporate & macro events) ----------
  const POS = /naik|melonjak|melesat|menguat|terbang|laba|untung|rekor|tumbuh|positif|upgrade|borong|ekspansi|surplus|meroket|cuan|tertinggi/;
  const NEG = /turun|anjlok|melemah|ambles|rugi|merugi|tekor|negatif|downgrade|lesu|tertekan|defisit|terendah|longsor|ambruk/;
  N.sentiment = (t) => { const p = (t.match(new RegExp(POS, 'g')) || []).length, n = (t.match(new RegExp(NEG, 'g')) || []).length; return Math.sign(p - n); };
  const CATS = [
    { id: 'law', name: 'Hukum / sanksi', re: /gugatan|pkpu|pailit|sanksi|denda|korupsi|tersangka|izin dicabut|digugat|wanprestasi/, dir: -1, mag: 2, why: 'Risiko hukum/likuiditas menekan kepercayaan investor' },
    { id: 'susp', name: 'Suspensi / UMA', re: /suspensi|\buma\b|unusual market|digembok|full call auction|papan pemantauan/, dir: 0, mag: 2, why: 'Volatilitas tinggi; perdagangan bisa dibatasi atau dihentikan' },
    { id: 'div', name: 'Dividen', re: /dividen|cum date|cum-date|ex date/, dir: 1, mag: 1, why: 'Dividen biasanya menopang harga menjelang cum date, lalu turun setelah ex date' },
    { id: 'buyback', name: 'Buyback', re: /buyback|pembelian kembali saham/, dir: 1, mag: 1, why: 'Buyback menambah permintaan dan sinyal saham dinilai murah oleh manajemen' },
    { id: 'rights', name: 'Right issue / private placement', re: /right issue|hmetd|private placement|pmthmetd|penambahan modal/, dir: -1, mag: 2, why: 'Potensi dilusi jangka pendek; dampak jangka panjang bergantung pada penggunaan dana' },
    { id: 'tender', name: 'Tender offer / akuisisi', re: /tender offer|akuisisi|merger|caplok|ambil alih|pengendali baru|go private|delisting sukarela/, dir: 1, mag: 2, why: 'Aksi korporasi besar; tender offer biasanya memberi harga premium' },
    { id: 'earn', name: 'Laporan keuangan', re: /laba|rugi|kinerja|kuartal|semester|pendapatan|penjualan|lapkeu|\bq[1-4]\b/, dir: null, mag: 2, why: 'Kinerja keuangan mengubah ekspektasi laba dan valuasi' },
    { id: 'contract', name: 'Kontrak / ekspansi', re: /kontrak|proyek baru|ekspansi|pabrik baru|kerja sama|\bmou\b|investasi baru|smelter|capex/, dir: 1, mag: 1, why: 'Sumber pendapatan baru di masa depan' },
    { id: 'rating', name: 'Rekomendasi analis', re: /target harga|rekomendasi|upgrade|downgrade|overweight|underweight|outperform|buy rating/, dir: null, mag: 1, why: 'Perubahan pandangan analis memengaruhi arus dana institusi' },
    { id: 'holder', name: 'Transaksi pemegang saham', re: /divestasi|lepas saham|jual saham|tambah kepemilikan|borong saham|crossing|blok saham/, dir: null, mag: 1, why: 'Perubahan kepemilikan besar memberi sinyal pandangan orang dalam/institusi' },
    { id: 'index', name: 'Indeks (MSCI/FTSE/LQ45)', re: /msci|ftse|lq45|idx80|rebalanc|kompas100/, dir: null, mag: 2, why: 'Masuk/keluar indeks memicu beli/jual paksa dana pasif' },
    { id: 'ipo', name: 'IPO / pencatatan', re: /\bipo\b|penawaran umum perdana|listing perdana|pencatatan perdana/, dir: 0, mag: 1, why: 'Saham baru; volatilitas awal tinggi' },
    { id: 'macro', name: 'Makro / kebijakan', re: /bi rate|suku bunga|inflasi|rupiah|the fed|neraca dagang|\bpdb\b|apbn|pajak|tarif|ojk|kebijakan/, dir: null, mag: 1, why: 'Kebijakan & makro memengaruhi banyak sektor sekaligus' },
    { id: 'comm', name: 'Komoditas', re: /batu ?bara|coal|nikel|nickel|emas|gold|cpo|sawit|minyak|crude|tembaga|timah/, dir: null, mag: 1, why: 'Harga komoditas menggerakkan laba produsen' },
    { id: 'market', name: 'Pasar umum', re: /ihsg|bursa|investor asing|net sell|net buy/, dir: null, mag: 0, why: 'Sentimen pasar secara luas' },
  ];
  N.category = (t) => CATS.find((c) => c.re.test(t)) || { id: 'other', name: 'Lainnya', dir: null, mag: 0, why: 'Berita umum emiten' };

  // ---------- spill-over rules (theme → affected emitens) ----------
  const UPW = /naik|melonjak|menguat|rally|tertinggi|melesat|meroket|reli/, DNW = /turun|anjlok|melemah|terendah|merosot|longsor|ambles/;
  const dirOf = (t) => (UPW.test(t) && !DNW.test(t) ? 1 : DNW.test(t) && !UPW.test(t) ? -1 : 0);
  const RULES = [
    { re: /nikel|nickel/, groups: [{ syms: ['INCO', 'ANTM', 'MBMA', 'NCKL', 'HRUM'], sign: 1, why: 'Harga nikel menentukan pendapatan penambang & smelter nikel' }] },
    { re: /batu ?bara|coal|\bhba\b/, groups: [{ syms: ['ADRO', 'AADI', 'PTBA', 'ITMG', 'HRUM', 'INDY', 'BUMI', 'BSSR', 'GEMS'], sign: 1, why: 'Harga batu bara → margin produsen' }] },
    { re: /\bemas\b|\bgold\b/, groups: [{ syms: ['ANTM', 'MDKA', 'BRMS', 'PSAB', 'ARCI', 'AMMN'], sign: 1, why: 'Harga emas → laba penambang emas' }] },
    { re: /tembaga|copper/, groups: [{ syms: ['AMMN', 'MDKA'], sign: 1, why: 'Tembaga adalah produk utama' }] },
    { re: /\btimah\b|\btin\b/, groups: [{ syms: ['TINS'], sign: 1, why: 'Harga timah → pendapatan TINS' }] },
    { re: /\bcpo\b|sawit|palm oil/, groups: [{ syms: ['AALI', 'LSIP', 'DSNG', 'TAPG', 'SSMS', 'TBLA'], sign: 1, why: 'Harga CPO → laba emiten perkebunan' }] },
    { re: /minyak|crude|brent|\bwti\b/, groups: [{ syms: ['MEDC', 'ENRG', 'ELSA', 'RAJA', 'AKRA'], sign: 1, why: 'Harga minyak → pendapatan migas' }, { syms: ['GIAA', 'BIRD', 'ASSA'], sign: -1, why: 'Bahan bakar adalah biaya utama transportasi' }] },
    { re: /bi rate|suku bunga|fed rate|the fed/, invert: true, groups: [{ syms: ['BSDE', 'CTRA', 'PWON', 'SMRA', 'PANI'], sign: 1, why: 'Bunga turun → KPR lebih murah, permintaan properti naik' }, { syms: ['BBRI', 'BMRI', 'BBNI', 'BBTN', 'ARTO'], sign: 1, why: 'Bunga turun → kredit tumbuh (NIM bisa tertekan)' }, { syms: ['ASII', 'ACES', 'MAPI', 'ERAA'], sign: 1, why: 'Bunga turun → daya beli & kredit konsumsi membaik' }] },
    { re: /rupiah/, groups: [{ syms: ['ICBP', 'INDF', 'UNVR', 'MYOR', 'KLBF', 'CPIN', 'JPFA', 'ERAA', 'AUTO'], sign: 1, why: 'Rupiah kuat → biaya bahan baku impor turun' }, { syms: ['ADRO', 'PTBA', 'ITMG', 'INCO', 'AALI'], sign: -1, why: 'Rupiah kuat → pendapatan ekspor (USD) bernilai lebih kecil' }] },
    { re: /cukai|rokok|tembakau/, invert: true, groups: [{ syms: ['HMSP', 'GGRM', 'WIIM'], sign: 1, why: 'Cukai naik → margin & volume rokok tertekan' }] },
    { def: 1, re: /data center|pusat data|kecerdasan buatan|\bai\b/, groups: [{ syms: ['DCII', 'TLKM', 'EMTK', 'MTDL', 'WIFI'], sign: 1, why: 'Permintaan infrastruktur digital' }] },
    { re: /penjualan mobil|otomotif|penjualan motor|kendaraan listrik/, groups: [{ syms: ['ASII', 'AUTO', 'SMSM', 'GJTL', 'IMPC'], sign: 1, why: 'Volume penjualan kendaraan & suku cadang' }] },
    { def: 1, re: /properti|\bkpr\b|ppn dtp|rumah subsidi/, groups: [{ syms: ['BSDE', 'CTRA', 'PWON', 'SMRA', 'PANI', 'ASRI', 'DMAS', 'BBTN'], sign: 1, why: 'Permintaan properti & KPR' }] },
    { def: 1, re: /infrastruktur|\bikn\b|jalan tol|proyek strategis|bumn karya/, groups: [{ syms: ['PTPP', 'ADHI', 'JSMR', 'SMGR', 'INTP'], sign: 1, why: 'Belanja infrastruktur → kontrak & permintaan semen' }] },
    { re: /semen|cement/, groups: [{ syms: ['SMGR', 'INTP', 'SMBR'], sign: 1, why: 'Permintaan & harga semen' }] },
    { def: 1, re: /geothermal|panas bumi|energi terbarukan|\bebt\b/, groups: [{ syms: ['PGEO', 'BREN', 'POWR', 'KEEN'], sign: 1, why: 'Kebijakan & proyek energi terbarukan' }] },
    { re: /pakan|jagung|harga ayam|unggas|\bdoc\b/, groups: [{ syms: ['CPIN', 'JPFA', 'MAIN'], sign: 1, why: 'Harga ayam/biaya pakan → margin poultry' }] },
    { re: /daya beli|lebaran|ritel|konsumsi rumah tangga|belanja masyarakat/, groups: [{ syms: ['AMRT', 'MIDI', 'MAPI', 'ACES', 'LPPF', 'ERAA', 'RALS'], sign: 1, why: 'Konsumsi masyarakat → penjualan ritel' }] },
    { re: /tarif data|operator seluler|telekomunikasi|frekuensi/, groups: [{ syms: ['TLKM', 'ISAT', 'EXCL'], sign: 1, why: 'Harga & kompetisi layanan seluler' }] },
    { re: /investor asing|net buy asing|net sell asing|foreign/, groups: [{ syms: ['BBCA', 'BBRI', 'BMRI', 'TLKM', 'ASII'], sign: 1, why: 'Saham big cap paling sensitif terhadap arus dana asing' }] },
  ];

  N.impacts = (story) => {
    const t = story.text; const out = new Map(); const U = universe();
    const cat = story.cat; const sdir = cat.dir === null ? story.sent : cat.dir;
    let idxDir = 0; if (cat.id === 'index') idxDir = /masuk|inklusi|ditambahkan|naik kelas/.test(t) ? 1 : /keluar|dikeluarkan|dihapus|ekslusi/.test(t) ? -1 : 0;
    for (const sym of story.tickers) out.set(sym, { sym, dir: cat.id === 'index' ? idxDir : sdir, mag: cat.mag >= 2 ? 'kuat' : 'sedang', why: cat.why, direct: true });
    // remove company names ("PT Merdeka Copper Gold Tbk") so themes are not triggered by names
    const tt = t.replace(/\bpt\b[^()]{0,70}?\btbk\b\.?/g, ' ').replace(/\([a-z]{4}\)/g, ' ');
    for (const r of RULES) {
      const m = tt.match(r.re); if (!m) continue;
      const win = tt.slice(m.index, m.index + m[0].length + 28); let d = dirOf(win); if (d === 0) d = dirOf(tt); if (r.invert) d = -d; if (d === 0 && r.def) d = r.def;
      if (d === 0 && story.tickers.length) continue;
      for (const g of r.groups) for (const sym of g.syms) { if (!U.has(sym) || out.has(sym)) continue; out.set(sym, { sym, dir: d * g.sign, mag: story.tickers.length ? 'ringan' : 'sedang', why: g.why + (d === 0 ? ' (arah belum jelas dari judul)' : ''), direct: false }); }
    }
    return [...out.values()].slice(0, 10);
  };

  // ---------- parsing & clustering ----------
  const STOP = new Set('yang dan di ke dari untuk dengan ini itu akan pada dalam saham tbk pt emiten hari jadi bisa ada juga karena oleh setelah sebesar rp persen the of to in on as at for by is are hingga sampai masih lagi usai jelang kini makin cara apa simak berikut'.split(' '));
  const toks = (t) => new Set(t.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((w) => w.length >= 3 && !STOP.has(w)));
  const jac = (a, b) => { let i = 0; for (const x of a) if (b.has(x)) i++; return i / (a.size + b.size - i || 1); };
  const strip = (h) => (h || '').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();
  function parseRss(xml, origin) {
    const doc = new DOMParser().parseFromString(xml, 'text/xml'); const out = [];
    doc.querySelectorAll('item').forEach((it) => {
      let title = strip(it.querySelector('title')?.textContent); const src = strip(it.querySelector('source')?.textContent) || origin;
      if (src && title.endsWith(' - ' + src)) title = title.slice(0, -(src.length + 3));
      const rawDesc = it.querySelector('description')?.textContent || ''; const coverage = (rawDesc.match(/<li>/g) || []).length;
      let desc = strip(rawDesc); if (desc.startsWith(title)) desc = desc.slice(title.length).trim(); if (desc.length < 40 || /^[\w\s.]+$/.test(desc) && desc.length < 60) desc = '';
      const date = new Date(it.querySelector('pubDate')?.textContent || Date.now()).getTime();
      if (title) out.push({ title, link: strip(it.querySelector('link')?.textContent), src, date, desc: desc.slice(0, 400), coverage });
    });
    return out;
  }
  N.cluster = (items) => {
    const seen = new Set(); const stories = [];
    items.sort((a, b) => a.date - b.date);
    for (const it of items) {
      const key = it.title.toLowerCase().replace(/\W+/g, ''); if (seen.has(key)) continue; seen.add(key);
      it.toks = toks(it.title); it.tickers = N.tickersIn(it.title + ' ' + it.desc);
      let best = null, bs = 0;
      for (const s of stories) { if (it.date - s.last > 3 * 864e5) continue; const j = jac(it.toks, s.toks); const shared = it.tickers.some((x) => s.tickers.includes(x)); const sc = j + (shared ? 0.15 : 0); if ((j >= 0.38 || (shared && j >= 0.22)) && sc > bs) { best = s; bs = sc; } }
      if (best) { best.items.push(it); best.sources.add(it.src); best.last = Math.max(best.last, it.date); for (const x of it.tickers) if (!best.tickers.includes(x)) best.tickers.push(x); for (const w of it.toks) best.toks.add(w); best.coverage = Math.max(best.coverage, it.coverage); }
      else stories.push({ id: 's' + Math.abs([...it.title].reduce((h, ch) => (Math.imul(h, 31) + ch.charCodeAt(0)) | 0, 7)), items: [it], sources: new Set([it.src]), first: it.date, last: it.date, tickers: [...it.tickers], toks: new Set(it.toks), coverage: it.coverage });
    }
    for (const s of stories) {
      s.text = s.items.map((x) => x.title + ' ' + x.desc).join(' ').toLowerCase();
      s.title = s.items[0].title; s.cat = N.category(s.text); s.sent = N.sentiment(s.text);
      s.nSources = s.sources.size + Math.min(6, s.coverage); s.impacts = N.impacts(s);
      s.primary = s.tickers[0] || (s.impacts.find((x) => x.dir !== 0) || {}).sym || null; s.primaryDirect = !!s.tickers[0];
    }
    return stories;
  };

  // ---------- awareness: how widely is this already known & priced? ----------
  N.reaction = async (sym, pubMs) => {
    const st = E.snap && E.snap.stocks.get(sym); const r = await D.candles(sym, '5m'); const cd = r.cd; const L = cd.c.length - 1; const pub = pubMs / 1000;
    let idx = -1; for (let i = L; i >= 0; i--) if (cd.t[i] <= pub) { idx = i; break; }
    if (idx < 0) return { status: 'old' };
    if (idx === L && cd.t[L] + 300 < pub) return { status: 'untested', note: 'Terbit setelah sesi perdagangan terakhir — pasar belum sempat bereaksi' };
    if (idx === L) return { status: 'untested', note: 'Baru saja terbit — reaksi belum terlihat' };
    const base = cd.c[idx], last = cd.c[L]; const move = ((last - base) / base) * 100; const atr = st ? st.f.atr : I.atr(cd.h, cd.l, cd.c)[L] * 8;
    let va = 0; for (let i = idx + 1; i <= L; i++) va += cd.v[i]; const k = L - idx; let vb = 0, nb = 0; for (let i = Math.max(0, idx - 400); i <= idx; i++) { vb += cd.v[i]; nb++; }
    const rvol = nb && vb ? va / k / (vb / nb) : NaN;
    return { status: 'tested', move, moveAtr: (last - base) / atr, rvol, bars: k, base };
  };
  N.awareness = (s) => {
    const h = (Date.now() - s.first) / 3.6e6; const n = s.nSources;
    const ageS = Math.min(40, h * 4), covS = Math.min(35, (n - 1) * 9); const re = s.reaction;
    let total, rS = 0;
    if (re && re.status === 'tested') { rS = Math.min(25, Math.abs(re.moveAtr) * 10 + Math.max(0, (re.rvol || 1) - 1) * 6); total = ageS + covS + rS; }
    else if (re && re.status === 'untested') total = ageS + covS;
    else total = ((ageS + covS) / 75) * 100;
    total = Math.round(Math.min(100, total));
    let level = total < 30 ? 'early' : total < 60 ? 'spreading' : 'known';
    const veryEarly = h < 3 && n <= 1 && rS < 6;
    const label = veryEarly ? 'Sangat awal' : level === 'early' ? 'Belum banyak yang tahu' : level === 'spreading' ? 'Mulai menyebar' : 'Sudah banyak yang tahu';
    const why = [`${n} sumber`, h < 1 ? `${Math.max(1, Math.round(h * 60))} menit lalu` : h < 48 ? `${Math.round(h)} jam lalu` : `${Math.round(h / 24)} hari lalu`];
    if (re && re.status === 'tested') why.push(`${s.primary}${s.primaryDirect ? '' : ' (emiten terdampak)'} ${re.move >= 0 ? '+' : ''}${re.move.toFixed(1)}% sejak berita (${Math.abs(re.moveAtr).toFixed(1)}× ATR), RVOL ${ok(re.rvol) ? re.rvol.toFixed(1) : '-'}x`);
    if (re && re.status === 'untested') why.push(re.note.toLowerCase());
    const priced = re && re.status === 'tested' && rS >= 15 ? 'Harga sudah bereaksi kuat — kemungkinan sebagian besar sudah priced-in' : re && re.status === 'untested' ? 'Belum diuji pasar' : null;
    return { score: total, level: veryEarly ? 'early' : level, veryEarly, label, why, priced };
  };

  // ---------- summary ----------
  const ago = (ms) => { const m = (Date.now() - ms) / 6e4; return m < 60 ? `${Math.max(1, Math.round(m))} menit lalu` : m < 2880 ? `${Math.round(m / 60)} jam lalu` : `${Math.round(m / 1440)} hari lalu`; };
  N.ago = ago;
  N.ruleSummary = (s) => {
    const parts = []; const d = s.items.find((x) => x.desc)?.desc;
    parts.push(`${s.title}.`); if (d) parts.push(d.length > 260 ? d.slice(0, 257) + '…' : d);
    parts.push(`Kategori ${s.cat.name.toLowerCase()}, nada judul ${s.sent > 0 ? 'positif' : s.sent < 0 ? 'negatif' : 'netral'}. Dilaporkan ${s.nSources} sumber, pertama ${ago(s.first)}.`);
    const dir = s.impacts.filter((x) => x.direct); if (dir.length) parts.push(`Emiten yang disebut langsung: ${dir.map((x) => x.sym).join(', ')}.`);
    const spill = s.impacts.filter((x) => !x.direct && x.dir !== 0); if (spill.length) parts.push(`Imbas tidak langsung ke ${spill.slice(0, 5).map((x) => x.sym).join(', ')}.`);
    return parts.join(' ');
  };

  // ---------- optional LLM (user's own free key) ----------
  N.llmReady = () => D.settings.aiProv && D.settings.aiProv !== 'none' && D.settings.aiKey;
  N.llm = async (s) => {
    if (N.llmCache[s.id]) return N.llmCache[s.id];
    const codes = [...new Set([...s.impacts.map((x) => x.sym), ...D.universe().map((u) => u.sym)])].slice(0, 200).join(', ');
    const news = s.items.slice(0, 8).map((x, i) => `${i + 1}. [${x.src}] ${x.title}${x.desc ? ' — ' + x.desc : ''}`).join('\n');
    const prompt = `Kamu analis pasar saham Indonesia (BEI). Dari judul & cuplikan berita di bawah, jangan menambah fakta yang tidak tertulis.\nBalas HANYA JSON valid:\n{"ringkasan":"2-3 kalimat bahasa Indonesia","kategori":"...","dampak":[{"kode":"XXXX","arah":"positif|negatif|netral","kekuatan":"ringan|sedang|kuat","jangka":"pendek|menengah","alasan":"1 kalimat"}]}\nMaksimal 6 emiten, hanya kode dari daftar ini: ${codes}.\nBerita:\n${news}`;
    let txt; const S = D.settings;
    if (S.aiProv === 'gemini') {
      const j = JSON.parse(await D.post(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(S.aiModel || 'gemini-2.5-flash')}:generateContent?key=${encodeURIComponent(S.aiKey)}`, { contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.2, responseMimeType: 'application/json' } }));
      txt = j.candidates[0].content.parts.map((p) => p.text).join('');
    } else {
      const j = JSON.parse(await D.post(`${(S.aiBase || 'https://api.groq.com/openai/v1').replace(/\/$/, '')}/chat/completions`, { model: S.aiModel || 'llama-3.3-70b-versatile', temperature: 0.2, messages: [{ role: 'user', content: prompt }] }, { Authorization: 'Bearer ' + S.aiKey }));
      txt = j.choices[0].message.content;
    }
    const out = JSON.parse(txt.replace(/```json|```/g, '').trim()); const U = universe();
    out.dampak = (out.dampak || []).filter((x) => U.has(String(x.kode).toUpperCase())).map((x) => ({ sym: String(x.kode).toUpperCase(), dir: /positif/i.test(x.arah) ? 1 : /negatif/i.test(x.arah) ? -1 : 0, mag: x.kekuatan || 'sedang', why: `${x.alasan || ''}${x.jangka ? ` (jangka ${x.jangka})` : ''}`, direct: s.tickers.includes(String(x.kode).toUpperCase()), ai: true }));
    N.llmCache[s.id] = out; const keys = Object.keys(N.llmCache); if (keys.length > 80) delete N.llmCache[keys[0]]; D.lsSet('rb.llm', N.llmCache);
    return out;
  };

  // ---------- loading ----------
  async function fetchFeeds(urls, onProg, force) {
    const res = await D.pool(urls, async (u) => { const k = 'rss|' + u; let x = force ? null : await D.cacheGet(k, 8 * 60e3); if (!x) { const xml = await D.get(u, 'text'); x = parseRss(xml, (u.match(/\/\/(?:www\.)?([^/]+)/) || [])[1]); await D.cacheSet(k, x, false); } return x; }, 4, onProg);
    const failed = res.filter((x) => !Array.isArray(x)).length; return { items: res.filter(Array.isArray).flat(), failed };
  }
  N.load = async ({ onProg, force } = {}) => {
    if (N.loading) return N.stories; N.loading = true; N.err = null;
    try {
      if (D.settings.provider === 'demo') throw new Error('Berita hanya diambil di aplikasi Android (mode simulasi tidak memakai berita)');
      buildAlias();
      const w = D.lsGet('rb.watch', []).slice(0, 8);
      const movers = E.snap ? [...E.snap.stocks.values()].sort((a, b) => Math.abs(b.f.chg1d) * (b.f.rvol || 1) - Math.abs(a.f.chg1d) * (a.f.rvol || 1)).slice(0, 6).map((s) => s.sym) : [];
      const extra = (D.settings.rssExtra || '').split(/\s+/).filter((u) => /^https?:\/\//.test(u));
      const urls = [...N.BASE_QUERIES.map(gnews), ...[...new Set([...w, ...movers])].map((s) => gnews(`${s} saham when:2d`)), ...N.FEEDS, ...extra];
      const { items, failed } = await fetchFeeds(urls, onProg, force);
      const cut = Date.now() - 4 * 864e5; const stories = N.cluster(items.filter((x) => x.date >= cut && x.date <= Date.now() + 36e5));
      // price-reaction check for stories with a primary emiten (bounded)
      const withT = stories.filter((s) => s.primary).sort((a, b) => b.last - a.last).slice(0, 30);
      await D.pool(withT, async (s) => { try { s.reaction = await N.reaction(s.primary, s.first); } catch (e) { s.reaction = null; } }, 4);
      for (const s of stories) { s.aw = N.awareness(s); const c = N.llmCache[s.id]; if (c) s.ai = c; }
      N.stories = stories; N.failed = failed; N.last = Date.now();
    } catch (e) { N.err = e.message; }
    finally { N.loading = false; }
    return N.stories;
  };
  N.forSymbol = async (sym) => {
    const { items } = await fetchFeeds([gnews(`${sym} saham when:7d`)]);
    const stories = N.cluster(items).sort((a, b) => b.last - a.last).slice(0, 12);
    await D.pool(stories.slice(0, 4), async (s) => { try { s.reaction = await N.reaction(sym, s.first); } catch (e) {} }, 2);
    for (const s of stories) { s.aw = N.awareness(s); const c = N.llmCache[s.id]; if (c) s.ai = c; }
    return stories;
  };
  R.N = N;
})((typeof window !== 'undefined' ? window : global).RB);
