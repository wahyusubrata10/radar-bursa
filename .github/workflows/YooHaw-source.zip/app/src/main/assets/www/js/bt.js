/* Yoo Haw — backtest engine. Point-in-time: at every test bar, features are recomputed from data up to that bar only. */
(function (R) {
  const { D, F, A, I, E, M } = R; const ok = I.ok; const B = { running: false, last: null, abort: false };
  const WIN = 320; // bars of history visible at each test point (covers EMA200 + 52-week range)

  // Fields that cannot be reconstructed point-in-time from free data → removed from the tree (with a warning)
  const UNSUPPORTED = new Set(['sectorRank', 'sectorLeader', 'rsSector3m', 'fNet1d', 'fNet5d', 'fStreak', 'ppk', 'riskOn']);
  B.prune = (node, dropped) => {
    if (node.g) { const c = node.c.map((x) => B.prune(x, dropped)).filter(Boolean); return c.length ? Object.assign({}, node, { c }) : null; }
    const d = F.byKey[node.f]; const bad = !d || d.fund || UNSUPPORTED.has(node.f) || (node.rf && (F.byKey[node.rf] || {}).fund) || (!d.daily && node.tf && node.tf !== 'D');
    if (bad) { dropped.push(node); return null; } return node;
  };
  const slice = (cd, a, b) => ({ t: cd.t.slice(a, b), o: cd.o.slice(a, b), h: cd.h.slice(a, b), l: cd.l.slice(a, b), c: cd.c.slice(a, b), v: cd.v.slice(a, b) });
  const dk = (t) => Math.floor((t + 25200) / 86400);
  const tick = () => new Promise((r) => setTimeout(r, 0));

  B.run = async (cfg, onProg) => {
    if (B.running) throw new Error('Backtest lain sedang berjalan'); if ((cfg.owner || 'user') === 'user') B.userPending = false; B.running = true; B.abort = false; B.owner = cfg.owner || 'user';
    try {
      const { mode = 'tree', tree, cat, nStocks = 40, period = 252, step = 2, hold = 20, entry = 'open', regimeFilter = false } = cfg;
      if (!E.snap && !cfg.syms) throw new Error('Muat data pasar dulu');
      const dropped = []; const pt = mode === 'tree' ? B.prune(JSON.parse(JSON.stringify(tree)), dropped) : null;
      if (mode === 'tree' && !pt) throw new Error('Semua kondisi memakai data yang tidak tersedia secara historis (fundamental/foreign/sektor/intraday)');
      const uni = cfg.syms || [...E.snap.stocks.values()].filter((s) => !s.f.ppk).sort((a, b) => b.f.avgValue20 - a.f.avgValue20).slice(0, nStocks).map((s) => s.sym);
      onProg && onProg(0, 1, 'Mengunduh riwayat 5 tahun…');
      const ih = (await D.candles('^JKSE', 'D5')).cd;
      const rowsR = await D.pool(uni, async (s) => { if (B.abort) throw new Error('Dibatalkan'); return { sym: s, cd: (await D.candles(s, 'D5')).cd }; }, D.settings.concurrency, (d, n) => onProg && onProg(d, n * 4, 'Mengunduh riwayat 5 tahun…'));
      if (B.abort) throw new Error('Dibatalkan');
      const rows = rowsR.filter((r) => r && !r.error && r.cd.c.length > WIN + 30);
      const regime = M.regimeSeries(ih, rows.map((r) => r.cd));
      const ihIdx = new Map(ih.t.map((t, i) => [dk(t), i]));
      // point-in-time RS rating: percentile of weighted performance across the test universe for every day
      const rsByDay = new Map();
      for (const r of rows) { const c = r.cd.c; for (let i = 250; i < c.length; i++) { const p = (k) => (c[i] - c[i - k]) / c[i - k]; const raw = 0.4 * p(63) + 0.2 * p(126) + 0.2 * p(189) + 0.2 * p(250); const k = dk(r.cd.t[i]); (rsByDay.get(k) || rsByDay.set(k, []).get(k)).push(raw); r.rs = r.rs || new Map(); r.rs.set(k, raw); } }
      for (const arr of rsByDay.values()) arr.sort((a, b) => a - b);
      const rsPct = (arr, v) => { let lo = 0, hi = arr.length; while (lo < hi) { const m = (lo + hi) >> 1; if (arr[m] < v) lo = m + 1; else hi = m; } return Math.max(1, Math.min(99, Math.round(((lo + 1) / arr.length) * 99))); };
      const fee = A.fees(); const trades = []; const base = []; let evals = 0;
      const catDef = mode === 'cat' ? E.PICK_CATS.find((c) => c.id === cat) : null;
      const syms0 = cfg.syms;

      for (let si = 0; si < rows.length; si++) {
        if (B.abort) throw new Error('Dibatalkan');
        const { sym, cd } = rows[si]; const N = cd.c.length; let freeAt = 0;
        for (let i = Math.max(WIN, N - 1 - period); i < N - 1; i += step) {
          if (evals % 20 === 19) { await tick(); if (B.abort) throw new Error('Dibatalkan'); }
          const day = dk(cd.t[i]); const pre = slice(cd, i - WIN + 1, i + 1);
          const ii = ihIdx.get(day); const ihPre = ii !== undefined ? slice(ih, Math.max(0, ii - WIN + 1), ii + 1) : null;
          const Fx = F.compute(pre, { daily: true, ihsg: ihPre }); if (!Fx) continue; const f = Fx.f; evals++;
          const arr = rsByDay.get(day); f.rsRating = arr && rows[si].rs && rows[si].rs.has(day) ? rsPct(arr, rows[si].rs.get(day)) : NaN;
          f.regimeScore = regime.get(day); f.riskOn = f.regimeScore >= 60;
          A.bandar(pre, f, null); const plan = A.plan(pre, Fx); f.score = A.score(f, plan).total;
          if (i + 10 < N) base.push((cd.c[i + 10] - cd.o[i + 1]) / cd.o[i + 1]);
          if (i < freeAt) continue;
          let sig;
          if (mode === 'any') sig = plan.bias > 0 && plan.rrNet >= 1 && f.avgValue20 >= 1e9;
          else if (mode === 'tree') sig = R.E.Sc.eval(pt, (k) => f[k], (k) => Fx.fp[k]) === true;
          else sig = catDef.id === 'risk' ? f.atrPct >= 3.5 && f.rvol >= 1.5 && plan.bias >= 0 : catDef.id === 'acc' ? f.accumScore >= 50 && plan.bias >= 0 : catDef.types.includes(plan.type) && plan.rrNet >= 1;
          if (!sig) continue;
          if (regimeFilter && f.regimeScore < 40) continue;
          const tr = B.simulate(cd, i, plan, f, { hold, entry, fee }); if (!tr) continue;
          const ihRet = B.ihsgRet(ih, ihIdx, cd.t[tr.j], cd.t[tr.k]);
          trades.push(Object.assign(tr, { sym, d: cd.t[i], score: f.score, regime: f.regimeScore, type: plan.type, ihRet }));
          freeAt = tr.k + 1;
        }
        onProg && onProg(rows.length / 4 + si + 1, rows.length * 1.25, `Menguji ${sym} (${si + 1}/${rows.length})`); await tick();
      }
      const res = B.stats(trades, base); res.cfg = cfg; res.dropped = dropped; res.nStocks = rows.length; res.evals = evals; res.asOf = Date.now();
      res.from = Math.min(...rows.map((r) => r.cd.t[Math.max(WIN, r.cd.c.length - 1 - period)])); res.to = Math.max(...rows.map((r) => r.cd.t[r.cd.c.length - 1]));
      B.last = res; return res;
    } finally { B.running = false; B.owner = null; }
  };
  // a user backtest always wins over the background evidence study
  B.preempt = async () => { B.userPending = true; if (B.running && B.owner === 'evid') { B.abort = true; for (let i = 0; i < 300 && B.running; i++) await new Promise((r) => setTimeout(r, 50)); } };

  B.ihsgRet = (ih, idx, t0, t1) => { const a = idx.get(dk(t0)), b = idx.get(dk(t1)); return a !== undefined && b !== undefined ? (ih.c[b] - ih.o[a]) / ih.o[a] : NaN; };

  // Trade simulation on full arrays (only bars after the signal are used)
  B.simulate = (cd, i, plan, f, { hold, entry, fee }) => {
    const N = cd.c.length; let j = -1, px = NaN;
    let stop = plan.bias > 0 ? plan.invalid : NaN, tgt = plan.bias > 0 ? plan.targets[0] : NaN;
    if (entry === 'limit' && plan.bias > 0) { for (let k = i + 1; k < Math.min(N, i + 6); k++) if (cd.l[k] <= plan.entry[1]) { j = k; px = Math.min(cd.o[k], plan.entry[1]); break; } if (j < 0) return null; }
    else { j = i + 1; if (j >= N) return null; px = cd.o[j]; }
    if (!(stop < px)) stop = A.rt(px - 1.5 * f.atr, 'down'); if (!(tgt > px)) tgt = A.rt(px + 3 * f.atr, 'up');
    const cost = px * (1 + fee.buy), risk = cost - stop * (1 - fee.sell); let k = j, x = NaN, out = 'Waktu habis';
    for (; k < Math.min(N, j + hold); k++) {
      if (cd.l[k] <= stop) { x = k > j ? Math.min(cd.o[k], stop) : stop; out = 'Stop'; break; }
      if (cd.h[k] >= tgt) { x = k > j ? Math.max(cd.o[k], tgt) : tgt; out = 'Target'; break; }
    }
    if (!ok(x)) { k = Math.min(N - 1, j + hold - 1); x = cd.c[k]; if (j + hold > N) out = 'Masih terbuka'; }
    const net = x * (1 - fee.sell); return { j, k, px, x, stop, tgt, out, R: (net - cost) / risk, ret: net / cost - 1, bars: k - j + 1 };
  };

  B.stats = (trades, base) => {
    const closed = trades.filter((t) => t.out !== 'Masih terbuka'); const n = closed.length;
    const sum = (a, f) => a.reduce((s, x) => s + f(x), 0); const avg = (a, f) => (a.length ? sum(a, f) / a.length : NaN);
    const win = closed.filter((t) => t.R > 0); const posR = sum(win, (t) => t.R), negR = -sum(closed.filter((t) => t.R <= 0), (t) => t.R);
    let eq = 0, peak = 0, dd = 0; const curve = [];
    for (const t of closed.slice().sort((a, b) => a.d + a.bars * 86400 - (b.d + b.bars * 86400))) { eq += t.R; peak = Math.max(peak, eq); dd = Math.min(dd, eq - peak); curve.push({ t: t.d + t.bars * 86400 * 1.4, v: eq }); }
    const group = (keyFn, order) => { const m = new Map(); for (const t of closed) { const k = keyFn(t); if (k == null) continue; (m.get(k) || m.set(k, []).get(k)).push(t); }
      return (order || [...m.keys()]).filter((k) => m.has(k)).map((k) => { const a = m.get(k); return { k, n: a.length, win: a.filter((t) => t.R > 0).length / a.length, avgR: avg(a, (t) => t.R), avgRet: avg(a, (t) => t.ret), worst: Math.min(...a.map((t) => t.ret)), best: Math.max(...a.map((t) => t.ret)), bars: avg(a, (t) => t.bars) }; }); };
    const sb = (s) => (s >= 70 ? '≥ 70' : s >= 60 ? '60–69' : s >= 50 ? '50–59' : '< 50');
    return {
      trades, n, open: trades.length - n, winRate: n ? win.length / n : NaN, avgR: avg(closed, (t) => t.R), pf: negR ? posR / negR : posR > 0 ? Infinity : NaN,
      avgRet: avg(closed, (t) => t.ret), alpha: avg(closed.filter((t) => ok(t.ihRet)), (t) => t.ret - t.ihRet), avgBars: avg(closed, (t) => t.bars), maxDD: dd, totalR: eq, curve,
      base10: avg(base, (x) => x), sig10: NaN,
      byScore: group((t) => sb(t.score), ['< 50', '50–59', '60–69', '≥ 70']),
      byRegime: group((t) => (ok(t.regime) ? M.label(t.regime) : null), ['Risk-on', 'Netral', 'Risk-off']),
      byType: group((t) => t.type), byExit: group((t) => t.out),
      byTypeReg: group((t) => (ok(t.regime) ? t.type + '|' + M.label(t.regime) : null)),
    };
  };
  R.B = B;
})((typeof window !== 'undefined' ? window : global).RB);
