/* Yoo Haw — data layer. Replaceable providers; every payload carries a status label. Never invents market data. */
(function (R) {
  const D = {};
  const SECT = { K: 'Keuangan', E: 'Energi', B: 'Barang Baku', P: 'Konsumen Primer', N: 'Konsumen Non-Primer', S: 'Kesehatan', R: 'Properti', T: 'Teknologi', F: 'Infrastruktur', I: 'Perindustrian', X: 'Transportasi' };
  const U = {
    K: 'BBCA BBRI BMRI BBNI BRIS BBTN BNGA BDMN NISP PNBN BJBR BJTM ARTO BBYB BTPS MEGA BNLI BBKP BFIN SRTG PNLF',
    E: 'ADRO AADI PTBA ITMG HRUM INDY BUMI MEDC PGAS AKRA ELSA ENRG DOID BSSR GEMS RAJA PTRO DEWA TOBA CUAN ESSA',
    B: 'ANTM INCO MDKA TINS MBMA NCKL AMMN BRMS PSAB ARCI SMGR INTP INKP TKIM BRPT TPIA AVIA MARK KRAS SMBR',
    P: 'UNVR ICBP INDF MYOR CPIN JPFA AMRT MIDI GGRM HMSP WIIM ULTJ CLEO ROTI AALI LSIP DSNG TAPG SSMS TBLA GOOD CMRY MAIN',
    N: 'ACES MAPI MAPA ERAA LPPF SCMA MNCN AUTO SMSM GJTL MSIN FILM RALS',
    S: 'KLBF SIDO MIKA HEAL SILO PRDA TSPC KAEF',
    R: 'BSDE CTRA PWON SMRA ASRI LPKR DMAS BKSL PANI',
    T: 'GOTO BUKA EMTK BELI MTDL DCII WIFI',
    F: 'TLKM ISAT EXCL TOWR TBIG MTEL JSMR PGEO BREN POWR PTPP ADHI SSIA',
    I: 'ASII UNTR HEXA IMPC ARNA SCCO',
    X: 'BIRD ASSA SMDR TMAS GIAA IPCC',
  };
  D.SECTORS = SECT;
  D.BASE_UNIVERSE = []; for (const k in U) for (const s of U[k].split(' ')) D.BASE_UNIVERSE.push({ sym: s, sector: SECT[k] });
  D.STATUS = { realtime: 'Real-time', delayed: 'Tertunda', eod: 'EOD', estimated: 'Estimasi', simulated: 'Simulasi', unavailable: 'Tidak tersedia' };
  D.TF = { '1m': '1 mnt', '5m': '5 mnt', '15m': '15 mnt', '1H': '1 jam', D: 'Harian', W: 'Mingguan' };
  D.native = typeof location !== 'undefined' && location.host === 'app.local';

  // ---------- settings ----------
  const DEF = { provider: D.native ? 'yahoo' : 'demo', customBase: '', customKey: '', radarInterval: 120, concurrency: 6, extraTickers: '', foreign: true, news: true, minValue: 1e9, aiProv: 'none', aiKey: '', aiModel: '', aiBase: '', rssExtra: '', feeBuy: 0.15, feeSell: 0.25, ppkList: '', regimeFilter: true, macroExtra: '' };
  D.settings = Object.assign({}, DEF, lsGet('rb.settings', {}));
  if (!D.native && D.settings.provider === 'yahoo') D.settings.provider = 'demo';
  D.saveSettings = () => lsSet('rb.settings', D.settings);
  function lsGet(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  D.lsGet = lsGet; D.lsSet = lsSet;

  D.universe = () => {
    const base = D.BASE_UNIVERSE.slice(); const have = new Set(base.map((x) => x.sym));
    for (const s of (D.settings.extraTickers || '').toUpperCase().split(/[\s,]+/).filter(Boolean)) if (!have.has(s)) { base.push({ sym: s, sector: 'Lainnya' }); have.add(s); }
    return base;
  };
  D.sectorOf = (sym) => (D.universe().find((x) => x.sym === sym) || {}).sector || 'Lainnya';

  // ---------- market clock (WIB) ----------
  D.wib = () => { const d = new Date(Date.now() + 7 * 3600e3); return { day: d.getUTCDay(), min: d.getUTCHours() * 60 + d.getUTCMinutes(), date: d.toISOString().slice(0, 10) }; };
  D.marketOpen = () => { const w = D.wib(); return w.day >= 1 && w.day <= 5 && w.min >= 540 && w.min <= 975; };

  // ---------- transport ----------
  D.get = async (url, as = 'json') => {
    if (!D.native) throw new Error('Akses data pasar hanya tersedia di aplikasi Android');
    let r;
    for (let k = 0; k < 3; k++) { r = await fetch('/proxy?u=' + encodeURIComponent(url)); if (r.status !== 429 && r.status !== 502) break; await new Promise((ok) => setTimeout(ok, 1500 * (k + 1))); }
    if (!r.ok) { const e = new Error(r.status === 429 ? 'Dibatasi sumber data (429), coba lagi sebentar' : 'HTTP ' + r.status); e.status = r.status; throw e; }
    return as === 'json' ? r.json() : as === 'buf' ? r.arrayBuffer() : r.text();
  };

  // POST goes through the native bridge (needed for optional LLM summaries with the user's own key)
  const cbs = {};
  if (typeof window !== 'undefined') window.__httpCb = (id, code, body) => { const c = cbs[id]; if (c) { delete cbs[id]; c(code, body); } };
  D.post = (url, body, headers = {}) => new Promise((res, rej) => {
    if (!(typeof window !== 'undefined' && window.AndroidBridge && window.AndroidBridge.httpPost)) return rej(new Error('Ringkasan AI hanya tersedia di aplikasi Android'));
    const id = 'p' + Math.random().toString(36).slice(2); const t = setTimeout(() => { delete cbs[id]; rej(new Error('Waktu habis')); }, 90000);
    cbs[id] = (code, txt) => { clearTimeout(t); if (code >= 200 && code < 300) res(txt); else rej(new Error(`HTTP ${code}: ${String(txt).slice(0, 180)}`)); };
    window.AndroidBridge.httpPost(id, url, typeof body === 'string' ? body : JSON.stringify(body), JSON.stringify(Object.assign({ 'Content-Type': 'application/json' }, headers)));
  });

  // ---------- cache (memory + IndexedDB) ----------
  const mem = new Map(); let dbp = null;
  function db() {
    if (dbp) return dbp;
    dbp = new Promise((res) => { try { const q = indexedDB.open('radarbursa', 1); q.onupgradeneeded = () => q.result.createObjectStore('kv'); q.onsuccess = () => res(q.result); q.onerror = () => res(null); } catch (e) { res(null); } });
    return dbp;
  }
  D.cacheGet = async (k, ttl) => {
    const m = mem.get(k); if (m && Date.now() - m.ts < ttl) return m.v;
    const d = await db(); if (!d) return null;
    return new Promise((res) => { try { const q = d.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => { const x = q.result; if (x && Date.now() - x.ts < ttl) { mem.set(k, x); res(x.v); } else res(null); }; q.onerror = () => res(null); } catch (e) { res(null); } });
  };
  D.cacheSet = async (k, v, persist = true) => {
    const x = { ts: Date.now(), v }; mem.set(k, x); if (!persist) return;
    const d = await db(); if (!d) return; try { d.transaction('kv', 'readwrite').objectStore('kv').put(x, k); } catch (e) {}
  };
  D.clearCache = async () => { mem.clear(); const d = await db(); if (d) try { d.transaction('kv', 'readwrite').objectStore('kv').clear(); } catch (e) {} };

  D.pool = async (items, fn, conc, onProg) => {
    let i = 0, done = 0; const out = new Array(items.length);
    const worker = async () => { while (i < items.length) { const k = i++; try { out[k] = await fn(items[k], k); } catch (e) { out[k] = { error: e.message || String(e) }; } done++; onProg && onProg(done, items.length); } };
    await Promise.all(Array.from({ length: Math.min(conc, items.length) }, worker)); return out;
  };

  const toCd = (rows) => { const cd = { t: [], o: [], h: [], l: [], c: [], v: [] }; for (const r of rows) { cd.t.push(r[0]); cd.o.push(r[1]); cd.h.push(r[2]); cd.l.push(r[3]); cd.c.push(r[4]); cd.v.push(r[5] || 0); } return cd; };

  // =================== PROVIDERS ===================
  const P = {};

  // ---- Yahoo Finance (free, delayed intraday; EOD after close) ----
  const YTF = { '1m': ['1m', '5d'], '5m': ['5m', '1mo'], '15m': ['15m', '1mo'], '1H': ['60m', '6mo'], D: ['1d', '2y'], D5: ['1d', '5y'], W: ['1wk', '5y'] };
  let crumb = null;
  P.yahoo = {
    name: 'Yahoo Finance (gratis)', intradayStatus: 'delayed',
    ysym: (s) => (s.startsWith('Y:') ? s.slice(2) : s.startsWith('^') || s.includes('=') ? s : s + '.JK'),
    async candles(sym, tf) {
      const [iv, rg] = YTF[tf]; const j = await D.get(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(this.ysym(sym))}?interval=${iv}&range=${rg}&includePrePost=false`);
      const res = j && j.chart && j.chart.result && j.chart.result[0]; if (!res || !res.timestamp) throw new Error('Data kosong');
      const q = res.indicators.quote[0]; const rows = [];
      for (let i = 0; i < res.timestamp.length; i++) if (q.close[i] != null && q.open[i] != null && q.high[i] != null && q.low[i] != null) rows.push([res.timestamp[i], q.open[i], q.high[i], q.low[i], q.close[i], q.volume[i] || 0]);
      const m = res.meta || {};
      // Yahoo's daily series for IDX sometimes lags one session behind the quote in `meta`.
      // If the quote is from a later WIB day than the last daily bar, append that session's bar from the quote.
      let patched = false;
      if ((tf === 'D' || tf === 'D5') && rows.length && m.regularMarketTime && m.regularMarketPrice > 0) {
        const dk = (t) => Math.floor((t + 25200) / 86400); const last = rows[rows.length - 1]; const px = m.regularMarketPrice;
        if (dk(m.regularMarketTime) > dk(last[0])) {
          const o = m.regularMarketOpen > 0 ? m.regularMarketOpen : last[4];
          rows.push([dk(m.regularMarketTime) * 86400 - 25200 + 9 * 3600, o, Math.max(m.regularMarketDayHigh || px, px, o), Math.min(m.regularMarketDayLow || px, px, o), px, m.regularMarketVolume || 0]); patched = true;
        } else if (dk(m.regularMarketTime) === dk(last[0])) { last[4] = px; last[2] = Math.max(last[2], px); last[3] = Math.min(last[3], px); }
      }
      const cd = toCd(rows);
      const intraday = !['D', 'D5', 'W'].includes(tf); const open = D.marketOpen();
      return { cd, meta: { patched, name: m.longName || m.shortName || sym, price: m.regularMarketPrice, prevClose: m.chartPreviousClose ?? m.previousClose, asOf: m.regularMarketTime, delayMin: m.exchangeDataDelayedBy, source: 'Yahoo Finance', status: intraday || open ? 'delayed' : 'eod' } };
    },
    async fundamentals(sym) {
      if (!crumb) { try { await D.get('https://fc.yahoo.com/', 'text'); } catch (e) {} crumb = (await D.get('https://query2.finance.yahoo.com/v1/test/getcrumb', 'text')).trim(); }
      const mods = 'financialData,defaultKeyStatistics,summaryDetail,earnings,price';
      let j; try { j = await D.get(`https://query2.finance.yahoo.com/v10/finance/quoteSummary/${this.ysym(sym)}?modules=${mods}&crumb=${encodeURIComponent(crumb)}`); }
      catch (e) { crumb = null; throw e; }
      const r = j.quoteSummary.result[0]; const fd = r.financialData || {}, ks = r.defaultKeyStatistics || {}, sd = r.summaryDetail || {}, pr = r.price || {};
      const v = (x) => (x && typeof x === 'object' ? x.raw : x); const pc = (x) => (v(x) == null ? NaN : v(x) * 100); const nn = (x) => (v(x) == null ? NaN : v(x));
      const cur = fd.financialCurrency || 'IDR'; const fx = cur === 'USD' ? await D.usdIdr() : 1;
      const out = {
        revGrowth: pc(fd.revenueGrowth), epsGrowth: pc(fd.earningsGrowth), epsQGrowth: pc(ks.earningsQuarterlyGrowth), roe: pc(fd.returnOnEquity), roa: pc(fd.returnOnAssets),
        grossMargin: pc(fd.grossMargins), opMargin: pc(fd.operatingMargins), netMargin: pc(fd.profitMargins), der: nn(fd.debtToEquity), currentRatio: nn(fd.currentRatio),
        ocf: nn(fd.operatingCashflow) * fx, fcf: nn(fd.freeCashflow) * fx, marketCap: nn(sd.marketCap) || nn(pr.marketCap), pe: nn(sd.trailingPE), pb: nn(ks.priceToBook),
        evEbitda: nn(ks.enterpriseToEbitda), divYield: pc(sd.dividendYield) || pc(sd.trailingAnnualDividendYield), beta: nn(sd.beta) || nn(ks.beta), currency: cur,
        source: 'Yahoo Finance', status: 'eod',
      };
      out.fcfYield = out.fcf && out.marketCap ? (out.fcf / out.marketCap) * 100 : NaN;
      const rev = nn(fd.totalRevenue) * fx; if (rev && out.opMargin && out.marketCap && out.pb > 0) { const eq = out.marketCap / out.pb; const inv = eq + (nn(fd.totalDebt) * fx || 0) - (nn(fd.totalCash) * fx || 0); if (inv > 0) out.roic = ((rev * out.opMargin) / 100 * 0.78 / inv) * 100; }
      const q = r.earnings && r.earnings.financialsChart && r.earnings.financialsChart.quarterly;
      if (q && q.length >= 3) { const e = q.slice(-3).map((x) => v(x.earnings)); const g1 = (e[1] - e[0]) / Math.abs(e[0] || 1), g2 = (e[2] - e[1]) / Math.abs(e[1] || 1); out.earningsAccel = e[2] > 0 && g2 > g1 && g2 > 0; out.quarterly = q.map((x) => ({ d: x.date, rev: v(x.revenue) * fx, earn: v(x.earnings) * fx })); }
      return out;
    },
  };
  let usd = null; D.usdIdr = async () => { if (usd) return usd; try { const r = await P.yahoo.candles('IDR=X', 'D'); usd = r.meta.price || r.cd.c[r.cd.c.length - 1]; } catch (e) { usd = 16000; } return usd; };

  // ---- Custom provider (e.g. paid real-time feed). Contract documented in README. ----
  P.custom = {
    name: 'Provider kustom (REST)',
    async candles(sym, tf) {
      const s = D.settings; if (!s.customBase) throw new Error('URL provider kustom belum diisi');
      const j = await D.get(`${s.customBase.replace(/\/$/, '')}/candles?symbol=${encodeURIComponent(sym)}&tf=${tf}&apikey=${encodeURIComponent(s.customKey || '')}`);
      const cd = toCd(j.candles || []); return { cd, meta: { name: j.name || sym, price: cd.c[cd.c.length - 1], prevClose: j.prevClose, source: j.source || 'Provider kustom', status: j.status || 'delayed' } };
    },
    async fundamentals(sym) { const s = D.settings; const j = await D.get(`${s.customBase.replace(/\/$/, '')}/fundamentals?symbol=${encodeURIComponent(sym)}&apikey=${encodeURIComponent(s.customKey || '')}`); return Object.assign({ source: 'Provider kustom', status: 'eod' }, j); },
  };

  // ---- Simulation (browser preview only; clearly labelled, never mixed with real data) ----
  function rng(seed) { let s = seed % 2147483647; if (s <= 0) s += 2147483646; return () => (s = (s * 16807) % 2147483647) / 2147483647; }
  const hash = (str) => { let x = 2166136261; for (const ch of str) x = Math.imul(x ^ ch.charCodeAt(0), 16777619); return Math.abs(x); };
  P.demo = {
    name: 'Simulasi (bukan data pasar)',
    async candles(sym, tf) {
      const r = rng(hash(sym)); const today = Math.floor(Date.now() / 864e5); const days = [];
      for (let d = today - (tf === 'D5' ? 1830 : 760); d <= today; d++) { const wd = new Date(d * 864e5).getUTCDay(); if (wd > 0 && wd < 6) days.push(d); }
      let p = sym === '^JKSE' ? 6500 : sym.startsWith('Y:') ? 20 + r() * 2000 : 100 + r() * 9000; const regime = r(); const rows = [];
      for (let k = 0; k < days.length; k++) {
        const ph = Math.sin(k / (40 + regime * 60) + regime * 6) * 0.0035 + (regime - 0.45) * 0.0016; const o = p;
        p = Math.max(55, p * (1 + ph + (r() - 0.5) * (sym === '^JKSE' ? 0.018 : 0.042)));
        const hi = Math.max(o, p) * (1 + r() * 0.014), lo = Math.min(o, p) * (1 - r() * 0.014);
        rows.push([days[k] * 86400 + 2 * 3600, o, hi, lo, p, Math.round((sym === '^JKSE' ? 2e10 : 2e6 + r() * 4e7) * (r() < 0.06 ? 3.5 : 1))]);
      }
      let out = rows;
      if (tf === 'W') { const cd = R.F.toWeekly(toCd(rows)); return { cd, meta: { name: sym + ' (simulasi)', price: cd.c[cd.c.length - 1], prevClose: cd.c[cd.c.length - 2], source: 'Simulasi', status: 'simulated' } }; }
      if (tf !== 'D' && tf !== 'D5') {
        const mins = { '1m': 1, '5m': 5, '15m': 15, '1H': 60 }[tf]; const per = Math.floor(400 / mins); const nDays = tf === '1H' ? 60 : tf === '1m' ? 4 : 20;
        out = []; const tick = Math.floor(Date.now() / 60e3); const rr = rng(hash(sym + tf + Math.floor(tick / 2)));
        for (const row of rows.slice(-nDays)) { let q = row[1]; const step = (row[4] - row[1]) / per;
          for (let j = 0; j < per; j++) { const o = q; q = Math.max(50, q + step + (rr() - 0.5) * row[1] * 0.006 * Math.sqrt(mins)); out.push([row[0] + j * mins * 60, o, Math.max(o, q) * (1 + rr() * 0.002), Math.min(o, q) * (1 - rr() * 0.002), q, Math.round(row[5] / per * (0.4 + rr() * 1.4) * (rr() < 0.03 ? 5 : 1))]); } }
      }
      const cd = toCd(out); return { cd, meta: { name: sym + ' (simulasi)', price: cd.c[cd.c.length - 1], prevClose: rows[rows.length - 2][4], source: 'Simulasi', status: 'simulated' } };
    },
    async fundamentals(sym) {
      const r = rng(hash(sym + 'f')); const g = (a, b) => a + r() * (b - a);
      const o = { revGrowth: g(-15, 35), epsGrowth: g(-30, 50), epsQGrowth: g(-30, 50), roe: g(-5, 30), roa: g(-2, 15), grossMargin: g(10, 60), opMargin: g(2, 35), netMargin: g(-5, 25), der: g(10, 250), currentRatio: g(0.6, 3), ocf: g(1e11, 5e12), fcf: g(-5e11, 4e12), marketCap: g(1e12, 9e14), pe: g(4, 40), pb: g(0.4, 6), evEbitda: g(3, 20), divYield: g(0, 9), beta: g(0.4, 1.6), earningsAccel: r() > 0.6, source: 'Simulasi', status: 'simulated' };
      o.fcfYield = (o.fcf / o.marketCap) * 100; o.roic = o.roe * 0.8; return o;
    },
  };
  D.providers = P;
  D.prov = () => P[D.settings.provider] || P.yahoo;

  // ---------- public API with caching ----------
  D.candles = async (sym, tf, force) => {
    const key = `c2|${D.settings.provider}|${sym}|${tf}`; const intraday = !['D', 'D5', 'W'].includes(tf);
    const ttl = intraday ? 45e3 : tf === 'D5' ? 12 * 3600e3 : D.marketOpen() ? 4 * 60e3 : 6 * 3600e3;
    if (!force) { const c = await D.cacheGet(key, ttl); if (c) return c; }
    const r = await D.prov().candles(sym, tf); if (!r.cd.c.length) throw new Error('Data kosong');
    r.fetchedAt = Date.now(); await D.cacheSet(key, r, !intraday); return r;
  };
  D.fundamentals = async (sym) => {
    const key = `f|${D.settings.provider}|${sym}`; const c = await D.cacheGet(key, 24 * 3600e3); if (c) return c;
    const p = D.prov(); if (!p.fundamentals) return null; const r = await p.fundamentals(sym); await D.cacheSet(key, r); return r;
  };

  // ---- Foreign flow from IDX daily trading summary (EOD, best effort) ----
  D.ffState = { status: 'unavailable', note: 'Belum dimuat' };
  D.foreignFlow = async () => {
    if (D.settings.provider === 'demo') { D.ffState = { status: 'unavailable', note: 'Tidak disimulasikan' }; return null; }
    if (!D.settings.foreign) { D.ffState = { status: 'unavailable', note: 'Dimatikan di pengaturan' }; return null; }
    const key = 'ff|' + D.wib().date + (D.marketOpen() ? '' : '|c'); const c = await D.cacheGet(key, 3 * 3600e3); if (c) { D.ffState = c.state; return c.map; }
    const days = []; const now = Date.now() + 7 * 3600e3;
    for (let k = 0; k < 12 && days.length < 5; k++) { const d = new Date(now - k * 864e5); const wd = d.getUTCDay(); if (wd === 0 || wd === 6) continue; days.push(d.toISOString().slice(0, 10).replace(/-/g, '')); }
    const per = [];
    for (const d of days) {
      const dk = 'ffd|' + d; let rows = await D.cacheGet(dk, 30 * 864e5);
      if (!rows) { try { const j = await D.get(`https://www.idx.co.id/primary/TradingSummary/GetStockSummary?length=9999&start=0&date=${d}`); rows = (j.data || []).map((x) => ({ s: x.StockCode, fb: +x.ForeignBuy || 0, fs: +x.ForeignSell || 0, c: +x.Close || 0 })); if (rows.length) await D.cacheSet(dk, rows); } catch (e) { if (e.status === 403 || e.status === 503) { D.ffState = { status: 'unavailable', note: 'Situs IDX menolak koneksi otomatis (proteksi bot)' }; return null; } rows = null; } }
      if (rows && rows.length) per.push({ d, rows });
    }
    if (!per.length) { D.ffState = { status: 'unavailable', note: 'Data IDX tidak dapat diambil' }; return null; }
    const map = {};
    per.forEach((day, idx) => { for (const r of day.rows) { const m = (map[r.s] = map[r.s] || { net: [], streak: 0 }); m.net[idx] = (r.fb - r.fs) * r.c; } });
    for (const s in map) { const m = map[s]; m.net1d = m.net[0] || 0; m.net5d = m.net.reduce((a, b) => a + (b || 0), 0); let k = 0; while (k < m.net.length && m.net[k] > 0) k++; m.streak = k; }
    D.ffState = { status: 'eod', note: `IDX Ringkasan Saham, ${per.length} hari terakhir (nilai = volume asing × harga penutupan, estimasi)`, asOf: per[0].d };
    await D.cacheSet(key, { state: D.ffState, map }); return map;
  };

  // ---- News (Google News RSS) with simple keyword sentiment ----
  const POS = ['naik', 'melonjak', 'menguat', 'laba', 'untung', 'rekor', 'dividen', 'ekspansi', 'akuisisi', 'buyback', 'kontrak', 'tumbuh', 'positif', 'upgrade', 'borong', 'target harga'];
  const NEG = ['turun', 'anjlok', 'melemah', 'rugi', 'merugi', 'gugatan', 'suspensi', 'pkpu', 'pailit', 'gagal', 'negatif', 'downgrade', 'jual', 'denda', 'korupsi', 'tersangka'];
  D.news = async (sym) => {
    if (D.settings.provider === 'demo' || !D.settings.news) return { items: [], sent: 0, count: 0, status: 'unavailable' };
    const key = 'n|' + sym; const c = await D.cacheGet(key, 30 * 60e3); if (c) return c;
    const xml = await D.get(`https://news.google.com/rss/search?q=${encodeURIComponent(sym + ' saham')}&hl=id&gl=ID&ceid=ID:id`, 'text');
    const doc = new DOMParser().parseFromString(xml, 'text/xml'); const items = [];
    doc.querySelectorAll('item').forEach((it, i) => { if (i >= 15) return; const title = it.querySelector('title')?.textContent || ''; const tl = title.toLowerCase();
      const s = POS.filter((w) => tl.includes(w)).length - NEG.filter((w) => tl.includes(w)).length; items.push({ title, link: it.querySelector('link')?.textContent, date: it.querySelector('pubDate')?.textContent, src: it.querySelector('source')?.textContent, s: Math.sign(s) }); });
    const recent = items.filter((x) => Date.now() - new Date(x.date).getTime() < 14 * 864e5);
    const out = { items, count: recent.length, sent: recent.length ? Math.max(-3, Math.min(3, recent.reduce((a, b) => a + b.s, 0))) : 0, status: 'delayed' };
    await D.cacheSet(key, out, false); return out;
  };

  R.D = D;
})((typeof window !== 'undefined' ? window : global).RB);
