/* Yoo Haw — squarified treemap layout (Bruls et al.) for the market heatmap. */
(function (R) {
  const HM = {};
  const worst = (row, w) => { const s = row.reduce((a, r) => a + r.area, 0); let mx = -Infinity, mn = Infinity; for (const r of row) { mx = Math.max(mx, r.area); mn = Math.min(mn, r.area); } return Math.max((w * w * mx) / (s * s), (s * s) / (w * w * mn)); };
  // items: [{value, ...}] → same items with x, y, w, h inside the rectangle
  HM.squarify = (items, x, y, w, h) => {
    const tot = items.reduce((a, it) => a + Math.max(0, it.value), 0); if (!tot || w <= 0 || h <= 0) return [];
    const list = items.filter((it) => it.value > 0).sort((a, b) => b.value - a.value).map((it) => Object.assign(it, { area: (it.value / tot) * w * h }));
    const out = []; let row = [], rx = x, ry = y, rw = w, rh = h;
    const layout = () => {
      const s = row.reduce((a, r) => a + r.area, 0);
      if (rw >= rh) { const cw = s / rh; let cy = ry; for (const r of row) { const ch = r.area / cw; out.push(Object.assign(r, { x: rx, y: cy, w: cw, h: ch })); cy += ch; } rx += cw; rw -= cw; }
      else { const ch = s / rw; let cx = rx; for (const r of row) { const cw = r.area / ch; out.push(Object.assign(r, { x: cx, y: ry, w: cw, h: ch })); cx += cw; } ry += ch; rh -= ch; }
      row = [];
    };
    for (const it of list) { const side = Math.min(rw, rh); if (!row.length || worst([...row, it], side) <= worst(row, side)) row.push(it); else { layout(); row.push(it); } }
    if (row.length) layout();
    return out;
  };
  R.HM = HM;
})((typeof window !== 'undefined' ? window : global).RB);
