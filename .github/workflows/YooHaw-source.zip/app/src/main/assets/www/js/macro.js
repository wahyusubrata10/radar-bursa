/* Yoo Haw — macro & commodity dashboard, cross-asset correlation, market regime (risk-on / netral / risk-off). */
(function (R) {
  const { D, I, F, A } = R; const ok = I.ok; const M = { data: null, loading: false, regime: null };

  // Yahoo symbols (prefix Y: = raw Yahoo symbol). links = emitens whose earnings depend on the instrument.
  M.INSTR = [
    { sym: 'Y:GC=F', name: 'Emas', unit: 'USD/oz', g: 'Komoditas', links: ['ANTM', 'MDKA', 'BRMS', 'PSAB', 'ARCI', 'AMMN'] },
    { sym: 'Y:HG=F', name: 'Tembaga', unit: 'USD/lb', g: 'Komoditas', links: ['AMMN', 'MDKA', 'MBMA'] },
    { sym: 'Y:BZ=F', name: 'Minyak Brent', unit: 'USD/bbl', g: 'Komoditas', links: ['MEDC', 'ENRG', 'ELSA', 'RAJA', 'AKRA', 'PGAS'] },
    { sym: 'Y:NG=F', name: 'Gas alam (Henry Hub)', unit: 'USD/MMBtu', g: 'Komoditas', links: ['PGAS', 'MEDC', 'RAJA', 'ESSA'] },
    { sym: 'Y:MTF=F', name: 'Batu bara (API2, proxy)', unit: 'USD/t', g: 'Komoditas', links: ['ADRO', 'AADI', 'PTBA', 'ITMG', 'HRUM', 'INDY', 'BUMI', 'BSSR', 'GEMS'], note: 'API2 Rotterdam sebagai proxy harga Newcastle' },
    { sym: 'Y:ZL=F', name: 'Minyak kedelai (proxy CPO)', unit: 'USc/lb', g: 'Komoditas', links: ['AALI', 'LSIP', 'DSNG', 'TAPG', 'SSMS', 'TBLA'], note: 'Harga CPO Bursa Malaysia tidak tersedia gratis; minyak kedelai bergerak searah' },
    { sym: 'Y:SI=F', name: 'Perak', unit: 'USD/oz', g: 'Komoditas', links: [] },
    { sym: 'Y:IDR=X', name: 'USD/IDR', unit: 'Rp', g: 'Makro', links: ['ICBP', 'INDF', 'UNVR', 'KLBF', 'ERAA', 'AUTO', 'ADRO', 'PTBA', 'ITMG'], note: 'Naik = rupiah melemah' },
    { sym: 'Y:DX-Y.NYB', name: 'Indeks dolar AS (DXY)', unit: '', g: 'Makro', links: [] },
    { sym: 'Y:^TNX', name: 'Yield obligasi AS 10 th', unit: '%', g: 'Makro', links: ['BBRI', 'BMRI', 'BBNI', 'BSDE', 'CTRA'] },
    { sym: 'Y:^VIX', name: 'VIX (rasa takut pasar AS)', unit: '', g: 'Global', links: [] },
    { sym: 'Y:^GSPC', name: 'S&P 500', unit: '', g: 'Global', links: [] },
    { sym: 'Y:^HSI', name: 'Hang Seng', unit: '', g: 'Global', links: [] },
    { sym: 'Y:000001.SS', name: 'Shanghai Composite', unit: '', g: 'Global', links: [] },
    { sym: 'Y:EIDO', name: 'ETF MSCI Indonesia (EIDO)', unit: 'USD', g: 'Global', links: ['BBCA', 'BBRI', 'BMRI', 'TLKM', 'ASII'], note: 'Proxy minat investor asing terhadap Indonesia' },
  ];
  M.instruments = () => {
    const extra = (D.settings.macroExtra || '').split('\n').map((l) => l.trim()).filter(Boolean).map((l) => { const [sym, name, links] = l.split('|').map((x) => (x || '').trim()); return { sym: 'Y:' + sym, name: name || sym, unit: '', g: 'Tambahan', links: (links || '').toUpperCase().split(/[\s,]+/).filter(Boolean) }; });
    return [...M.INSTR, ...extra];
  };

  const dayKey = (t) => Math.floor((t + 25200) / 86400);
  // daily log-returns keyed by WIB day
  const retMap = (cd, n = 130) => { const m = new Map(); const s = Math.max(1, cd.c.length - n); for (let i = s; i < cd.c.length; i++) m.set(dayKey(cd.t[i]), Math.log(cd.c[i] / cd.c[i - 1])); return m; };
  M.corr = (a, b) => {
    const xs = [], ys = []; for (const [k, v] of a) if (b.has(k)) { xs.push(v); ys.push(b.get(k)); }
    // commodities trade overnight vs IDX: also try 1-day lag and keep the stronger link
    const n = xs.length; if (n < 25) return { r: NaN, beta: NaN, n };
    const mx = xs.reduce((s, x) => s + x, 0) / n, my = ys.reduce((s, y) => s + y, 0) / n; let sxy = 0, sxx = 0, syy = 0;
    for (let i = 0; i < n; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2; syy += (ys[i] - my) ** 2; }
    return { r: sxy / Math.sqrt(sxx * syy), beta: sxy / sxx, n };
  };
  const lagMap = (m) => { const o = new Map(); const keys = [...m.keys()].sort((x, y) => x - y); for (let i = 1; i < keys.length; i++) o.set(keys[i], m.get(keys[i - 1])); return o; };
  M.link = (instrCd, stockCd) => {
    const a = retMap(instrCd), b = retMap(stockCd); const c0 = M.corr(a, b), c1 = M.corr(lagMap(a), b);
    return Math.abs(c1.r || 0) > Math.abs(c0.r || 0) ? Object.assign(c1, { lag: 1 }) : Object.assign(c0, { lag: 0 });
  };

  const perf = (cd, k) => { const n = cd.c.length - 1; return n >= k ? ((cd.c[n] - cd.c[n - k]) / cd.c[n - k]) * 100 : NaN; };
  M.load = async ({ force, onProg } = {}) => {
    if (M.loading) return M.data; M.loading = true;
    try {
      const list = M.instruments();
      const res = await D.pool(list, async (x) => { const r = await D.candles(x.sym, 'D', force); return Object.assign({}, x, { cd: r.cd, meta: r.meta }); }, 4, onProg);
      const items = list.map((x, i) => (res[i] && !res[i].error ? res[i] : Object.assign({}, x, { err: (res[i] && res[i].error) || 'gagal' })));
      for (const it of items) {
        if (it.err) continue; const cd = it.cd, n = cd.c.length - 1; const e50 = I.ema(cd.c, 50);
        Object.assign(it, { last: cd.c[n], p1d: perf(cd, 1), p1w: perf(cd, 5), p1m: perf(cd, 21), p3m: perf(cd, 63), up50: cd.c[n] > e50[n] });
        it.linked = [];
        const snap = R.E && R.E.snap;
        if (snap) for (const sym of it.links) { const st = snap.stocks.get(sym); if (!st) continue; const L = M.link(cd, st.cd); const sp = st.f.perf1m;
          const lagging = ok(L.r) && L.r >= 0.3 && Math.abs(it.p1m) >= 5 && Math.sign(it.p1m) * (sp || 0) < Math.abs(it.p1m) * 0.3;
          it.linked.push({ sym, r: L.r, beta: L.beta, lag: L.lag, p1m: sp, lagging }); }
        it.linked.sort((a, b) => (b.r || -2) - (a.r || -2));
      }
      M.data = { items, asOf: Date.now() }; M.computeRegime(); if (R.E) R.E.rescore();
      return M.data;
    } finally { M.loading = false; }
  };
  M.get = (sym) => M.data && M.data.items.find((x) => x.sym === sym && !x.err);

  // stock page: which instruments move this stock the most
  M.sensitivity = (st) => {
    if (!M.data) return []; const out = [];
    for (const it of M.data.items) { if (it.err) continue; const L = M.link(it.cd, st.cd); if (ok(L.r)) out.push({ name: it.name, sym: it.sym, r: L.r, beta: L.beta, lag: L.lag, p1m: it.p1m }); }
    return out.sort((a, b) => Math.abs(b.r) - Math.abs(a.r)).slice(0, 5);
  };

  // ---------------- regime ----------------
  const lin = (x, a, b) => Math.max(0, Math.min(100, ((x - a) / (b - a)) * 100));
  M.computeRegime = () => {
    const snap = R.E && R.E.snap; if (!snap) return null;
    const comp = []; const C = (k, label, w, s, why) => ok(s) && comp.push({ k, label, w, s: Math.round(s), why });
    const ih = snap.ihsg.cd; const Fi = F.compute(ih, { daily: true }); const fi = Fi ? Fi.f : null;
    if (fi) { let s = (fi.close > fi.ema20 ? 20 : 0) + (fi.close > fi.ema50 ? 25 : 0) + (fi.close > fi.ema200 ? 25 : 0) + (fi.ema50 > I.ema(ih.c, 50)[ih.c.length - 11] ? 15 : 0) + (fi.swingTrend > 0 ? 15 : fi.swingTrend === 0 ? 7 : 0);
      C('trend', 'Tren IHSG', 25, s, `IHSG ${fi.close > fi.ema50 ? 'di atas' : 'di bawah'} EMA 50, ${fi.close > fi.ema200 ? 'di atas' : 'di bawah'} EMA 200, struktur ${Fi.st.sw.label.toLowerCase()}`); }
    const all = [...snap.stocks.values()]; const p50 = (all.filter((x) => x.f.aboveEma50).length / all.length) * 100, p20 = (all.filter((x) => x.f.aboveEma20).length / all.length) * 100;
    let ad = 0; for (const x of all) { const c = x.cd.c, n = c.length - 1; for (let k = 0; k < 10; k++) ad += Math.sign(c[n - k] - c[n - k - 1]); } const adR = ad / (all.length * 10);
    C('breadth', 'Breadth', 25, 0.5 * lin(p50, 25, 70) + 0.25 * lin(p20, 25, 75) + 0.25 * lin(adR, -0.15, 0.15), `${Math.round(p50)}% saham di atas EMA 50, ${Math.round(p20)}% di atas EMA 20, A/D 10 hari ${adR >= 0 ? 'positif' : 'negatif'}`);
    if (fi) { const atrP = I.atr(ih.h, ih.l, ih.c).map((a, i) => a / ih.c[i]); const pct = I.percentile(atrP.slice(-250), atrP[atrP.length - 1]); const vix = M.get('Y:^VIX');
      let s = 100 - pct; let why = `Volatilitas IHSG di persentil ${Math.round(pct)} (1 tahun)`; if (vix) { s = 0.6 * s + 0.4 * lin(-vix.last, -30, -14); why += `, VIX ${vix.last.toFixed(1)}`; }
      C('vol', 'Volatilitas', 15, s, why); }
    const ffSum = all.reduce((s, x) => s + (x.f.fNet5d || 0), 0); const hasFF = all.some((x) => ok(x.f.fNet5d)); const eido = M.get('Y:EIDO');
    if (hasFF || eido) { let s = 50, why = []; if (hasFF) { s = ffSum > 0 ? 75 : 25; why.push(`foreign net 5 hari ${A.fmtRp(ffSum)}`); } if (eido) { s = hasFF ? 0.6 * s + 0.4 * lin(eido.p1m, -8, 8) : lin(eido.p1m, -8, 8); why.push(`EIDO ${eido.p1m >= 0 ? '+' : ''}${eido.p1m.toFixed(1)}% 1 bln`); } C('foreign', 'Minat asing', 15, s, why.join(', ')); }
    const idr = M.get('Y:IDR=X'); if (idr) C('idr', 'Rupiah', 10, lin(-idr.p1m, -3, 1.5), `USD/IDR ${idr.p1m >= 0 ? '+' : ''}${idr.p1m.toFixed(1)}% sebulan (${idr.p1m > 0 ? 'rupiah melemah' : 'rupiah menguat'})`);
    const spx = M.get('Y:^GSPC'); if (spx) C('global', 'Pasar global', 10, (spx.up50 ? 50 : 0) + lin(spx.p1m, -6, 6) / 2, `S&P 500 ${spx.p1m >= 0 ? '+' : ''}${spx.p1m.toFixed(1)}% sebulan, ${spx.up50 ? 'di atas' : 'di bawah'} EMA 50`);
    const tw = comp.reduce((s, c) => s + c.w, 0); const score = Math.round(comp.reduce((s, c) => s + c.s * c.w, 0) / tw);
    M.regime = { score, label: M.label(score), comp, partial: !M.data };
    for (const x of all) { x.f.regimeScore = score; x.f.riskOn = score >= 60; }
    return M.regime;
  };
  M.label = (s) => (s >= 60 ? 'Risk-on' : s >= 40 ? 'Netral' : 'Risk-off');

  // historical regime (IHSG trend + breadth + volatility) for backtests: Map dayKey -> score
  M.regimeSeries = (ih, stockCds) => {
    const out = new Map(); const n = ih.c.length; const e20 = I.ema(ih.c, 20), e50 = I.ema(ih.c, 50), e200 = I.ema(ih.c, 200);
    const atrP = I.atr(ih.h, ih.l, ih.c).map((a, i) => a / ih.c[i]);
    const above = new Map(), tot = new Map();
    for (const cd of stockCds) { const e = I.ema(cd.c, 50); for (let i = 50; i < cd.c.length; i++) { const k = dayKey(cd.t[i]); tot.set(k, (tot.get(k) || 0) + 1); if (cd.c[i] > e[i]) above.set(k, (above.get(k) || 0) + 1); } }
    for (let i = 210; i < n; i++) {
      const tr = (ih.c[i] > e20[i] ? 20 : 0) + (ih.c[i] > e50[i] ? 25 : 0) + (ih.c[i] > e200[i] ? 25 : 0) + (e50[i] > e50[i - 10] ? 30 : 0);
      const k = dayKey(ih.t[i]); const br = tot.get(k) ? lin(((above.get(k) || 0) / tot.get(k)) * 100, 25, 70) : NaN;
      const win = atrP.slice(Math.max(0, i - 250), i + 1); const vol = 100 - I.percentile(win, atrP[i]);
      out.set(k, Math.round(ok(br) ? (tr * 25 + br * 25 + vol * 15) / 65 : (tr * 25 + vol * 15) / 40));
    }
    return out;
  };
  M.dayKey = dayKey;
  R.M = M;
})((typeof window !== 'undefined' ? window : global).RB);
