/* Yoo Haw — motion: spring physics (interruptible, velocity-aware) and the layer controller used by every sheet. */
(function (R) {
  const MO = {};
  const now = () => (window.performance ? performance.now() : Date.now());
  const raf = window.requestAnimationFrame ? (f) => window.requestAnimationFrame(f) : (f) => setTimeout(() => f(now()), 16);
  const caf = window.cancelAnimationFrame ? (id) => window.cancelAnimationFrame(id) : (id) => clearTimeout(id);
  MO.reduced = () => document.documentElement.dataset.motion === 'off' || (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  // Damped spring integrated in small fixed sub-steps. Units: px and px/s.
  // ratio 1 = critically damped (no overshoot); < 1 = gentle bounce.
  MO.spring = ({ from, to, v = 0, k = 420, ratio = 1, onUpdate, onDone }) => {
    // Integrates over real elapsed time (sub-stepped for stability), so slow or throttled frames never slow the
    // animation down; a watchdog guarantees it always lands on its target.
    const c = 2 * Math.sqrt(k) * ratio; let x = from, vel = v, target = to, id = 0, last = 0, done = false, wd = 0; const t0 = now();
    const finish = () => { if (done) return; done = true; caf(id); clearTimeout(wd); x = target; vel = 0; onUpdate && onUpdate(x); onDone && onDone(); };
    const step = () => {
      if (done) return; const t = now(); const dt = Math.min(0.5, Math.max(0, (t - last) / 1000)); last = t; /* one clock only */ const n = Math.max(1, Math.ceil(dt / 0.004)), h = dt / n;
      for (let i = 0; i < n; i++) { const a = -k * (x - target) - c * vel; vel += a * h; x += vel * h; }
      if ((Math.abs(x - target) < 0.4 && Math.abs(vel) < 8) || now() - t0 > 1200) return finish();
      onUpdate && onUpdate(x); id = raf(step);
    };
    onUpdate && onUpdate(x); last = now(); id = raf(step);
    wd = setTimeout(finish, 1300);
    return { stop() { caf(id); clearTimeout(wd); done = true; }, retarget(t2) { target = t2; }, get x() { return x; }, get v() { return vel; }, get done() { return done; } };
  };

  // ---------------- layer controller ----------------
  // kind: 'h' (slides from the right), 'v' (slides up), 'b' (bottom sheet: panel + backdrop), 'f' (fade/zoom), 'fade' (container fade)
  const kindOf = (el) => (el.classList.contains('bsheet') ? 'b' : el.id === 'reader' ? 'v' : el.id === 'fs' ? 'f' : 'h');
  let scrim = null;
  const getScrim = () => { if (!scrim) { scrim = document.createElement('div'); scrim.id = 'scrim'; scrim.hidden = true; document.body.appendChild(scrim); } return scrim; };
  const zOf = (el) => +(window.getComputedStyle(el).zIndex) || 40;
  const setScrim = (el, p) => { const s = getScrim(); if (p <= 0.001 || p >= 0.999) { s.hidden = true; return; } s.hidden = false; s.style.zIndex = String(zOf(el) - 1); s.style.opacity = String(0.42 * (1 - p)); };
  const dims = (el, kind) => (kind === 'h' ? window.innerWidth || 360 : kind === 'v' ? window.innerHeight || 640 : (el.querySelector('.bs-p') || el).offsetHeight || 420);
  const apply = (el, kind, x, D) => {
    if (kind === 'h') { el.style.transform = x ? `translate3d(${x}px,0,0)` : ''; setScrim(el, x / D); }
    else if (kind === 'v') { el.style.transform = x ? `translate3d(0,${x}px,0)` : ''; setScrim(el, x / D); }
    else if (kind === 'b') { const p = el.querySelector('.bs-p'), bd = el.querySelector('.bs-bd'); if (p) p.style.transform = x ? `translate3d(0,${x}px,0)` : ''; if (bd) bd.style.opacity = String(Math.max(0, 1 - x / D)); }
    else if (kind === 'fade') { const t = x / D; el.style.opacity = String(1 - t); el.style.transform = t ? `translate3d(0,${(t * 14).toFixed(2)}px,0) scale(${(1 - t * 0.02).toFixed(4)})` : ''; }
  };
  MO.pos = (el) => (el._sp && !el._sp.done ? el._sp.x : el._mx || 0);
  MO.open = (el, opts = {}) => {
    if (!el) return; const kind = opts.mode === 'fade' ? 'fade' : kindOf(el); el.classList.remove('leaving'); el._kind = kind;
    const wasHidden = el.hidden; el.hidden = false;
    if (MO.reduced() || kind === 'f') { if (kind === 'f' && !MO.reduced() && wasHidden) { el.classList.remove('entering'); void el.offsetWidth; el.classList.add('entering'); setTimeout(() => el.classList.remove('entering'), 360); } apply(el, kind === 'f' ? 'none' : kind, 0, 1); return; }
    const D = dims(el, kind); const from = el._sp && !el._sp.done ? el._sp.x : wasHidden ? D : MO.pos(el);
    if (el._sp) el._sp.stop(); el.classList.add('entering');
    el._sp = MO.spring({ from, to: 0, v: opts.v || 0, k: kind === 'b' ? 520 : 400, ratio: 1, onUpdate: (x) => { el._mx = x; apply(el, kind, x, D); }, onDone: () => { el.classList.remove('entering'); el._mx = 0; apply(el, kind, 0, D); if (kind === 'fade') el.style.opacity = ''; } });
  };
  MO.close = (el, opts = {}) => {
    if (!el || el.hidden) return; const kind = el._kind || kindOf(el);
    if (el.classList.contains('leaving') && !opts.v) return;
    el.classList.remove('entering'); el.classList.add('leaving');
    const finish = () => { el.hidden = true; el.classList.remove('leaving'); el._mx = 0; apply(el, kind === 'f' ? 'none' : kind, 0, 1); el.style.opacity = ''; if (kind !== 'b') setScrim(el, 1); else el.innerHTML = ''; /* bottom sheets are rebuilt on every open */ opts.done && opts.done(); };
    if (MO.reduced()) { if (el._sp) el._sp.stop(); finish(); return; }
    if (kind === 'f') { clearTimeout(el._lt); el._lt = setTimeout(finish, 210); return; }
    const D = dims(el, kind); const from = MO.pos(el); if (el._sp) el._sp.stop();
    el._sp = MO.spring({ from, to: D, v: opts.v || 0, k: 520, ratio: 1, onUpdate: (x) => { el._mx = x; apply(el, kind, x, D); }, onDone: finish });
  };
  // follow the finger during a drag (no animation), then settle with the release velocity
  MO.drag = (el, x) => { if (el._sp) el._sp.stop(); const kind = el._kind || kindOf(el); el._kind = kind; el._mx = Math.max(0, x); apply(el, kind, el._mx, dims(el, kind)); };
  MO.release = (el, v) => { const kind = el._kind || kindOf(el); const D = dims(el, kind); const x = el._mx || 0; if (x > D * 0.35 || v > 700) MO.close(el, { v: Math.max(v, 0) }); else MO.open(el, { v }); return x > D * 0.35 || v > 700; };
  MO.dims = dims;
  R.MO = MO;
})((typeof window !== 'undefined' ? window : global).RB = (typeof window !== 'undefined' ? window : global).RB || {});
